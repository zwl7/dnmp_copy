const request = require('./../utils/http')
export const getCirlces = data => {
  return request({
    url: '/activityPlatform/wxCommunityPersonnel/personnelCommunities',
    data: data
  })
}
export const getTags = data => {
  return request({
    url: '/activityPlatform/wxResourceTag/list',
    data: data
  })
}
export const updateCommunityTags = data => {
  return request({
    url: '/activityPlatform/wxResourceTag/updateCommunityTags',
    data: data
  })
}
// 删除星球成员
export const delCommunityPerson = data => {
  return request({
    url: '/activityPlatform/wxCommunity/outOf',
    data: data
  })
}

// 星球钱包详情
export const getAmountInfo = data => {
  return request({
    url: '/activityPlatform/wxCommunityAmount/amountInfo',
    data: data
  })
}
// 获取星球的统计信息
export const getMyCommunityCountInfo = data => {
  return request({
    url: '/activityPlatform/wxMember/myCommunityCountInfo',
    data: data
  })
}

// 星球钱包流水
export const getAmountRecord = data => {
  return request({
    url: '/activityPlatform/wxCommunityAmount/amountRecord',
    data: data
  })
}

// 圈子成员信息统计
export const getCommunityStatistic = data => {
  return request({
    url: '/activityPlatform/wxCommunity/communityStatistic',
    data: data
  })
}

// 申请记录
export const getAuthApplyList = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/applyList',
    data: data
  })
}
// 获取账户资金明细列表数据
export const getAccountAmountRecord = data => {
  return request({
    url: '/activityPlatform/wxMember/accountAmountRecord',
    data: data
  })
}
// 活动收款统计
export const getActivityPayCount = data => {
  return request({
    url: '/activityPlatform/wxMember/activityPayCount',
    data: data
  })
}
// 活动账单内容
export const getActivityBillInfo = data => {
  return request({
    url: '/activityPlatform/wxMember/activityBillInfo',
    data: data
  })
}
// 获取活动交易记录
export const getActivityDealRecord = data => {
  return request({
    url: '/activityPlatform/wxMember/activityDealRecord',
    data: data
  })
}

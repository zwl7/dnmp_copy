const request = require('./../utils/http')

// 获取资源分签表列表
export const getWxResourceTypeAll = data => {
  return request({
    url: '/activityPlatform/wxResourceType/all',
    method: 'POST',
    data: data
  })
}

export const taskRate = data => {
  return request({
    url: '/pub/export/taskRate',
    method: 'POST',
    data: data
  })
}
export const createTask = data => {
  return request({
    url: '/pub/export/task',
    method: 'POST',
    data: data
  })
}
// 获取站内信
export const getWxMemberNoticeList = data => {
  return request({
    url: '/activityPlatform/wxMemberNotice/list',
    method: 'POST',
    data: data
  })
}

// 获取站内信未读数量
export const getWxMemberNoticeCount = data => {
  return request({
    url: '/activityPlatform/wxMemberNotice/getCount',
    method: 'POST',
    data: data
  })
}

// 获取站内信未读
export const updateWxMemberNotice = data => {
  return request({
    url: '/activityPlatform/wxMemberNotice/update',
    method: 'POST',
    data: data
  })
}

// 获取小程序码
export const getMPCode = data => {
  return request({
    url: '/activityPlatform/wxPub/getMPCode',
    method: 'POST',
    data: data
  })
}

// 获取省市区
export const getPcasChildren = data => {
  return request({
    url: '/base/pcasCode/getChildren',
    method: 'POST',
    data: data
  })
}

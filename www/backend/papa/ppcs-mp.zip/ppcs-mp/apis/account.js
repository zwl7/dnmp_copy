const request = require('./../utils/http')

// 支付(加V)认证添加
export const addWxDistributionAuth = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/add',
    method: 'POST',
    data: data
  })
}

// 支付(加V)认证更新
export const updateWxDistributionAuth = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/requestUpdate',
    method: 'POST',
    data: data
  })
}

// 发送手机验证码 phone
export const sendPhoneCode = data => {
  return request({
    url: '/activityPlatform/wxPub/sendPhoneCode',
    method: 'POST',
    data: data
  })
}

// 获取银行总行列表
export const getBankTypeList = data => {
  return request({
    url: '/activityPlatform/wxPub/getBankTypeList',
    method: 'POST',
    data: data
  })
}

// 获取银行省列表
export const getProvinceList = data => {
  return request({
    url: '/activityPlatform/wxPub/getProvinceList',
    method: 'POST',
    data: data
  })
}

// 获取银行城市列表
export const getCityList = data => {
  return request({
    url: '/activityPlatform/wxPub/getCityList',
    method: 'POST',
    data: data
  })
}

// 获取银行市列表
export const getBankList = data => {
  return request({
    url: '/activityPlatform/wxPub/getBankList',
    method: 'POST',
    data: data
  })
}

// 支付(加V)认证获取 状态
export const getWxDistributionAuth = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/get',
    method: 'POST',
    data: data
  })
}

// 验证打款
export const sendVerifyAmount = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/sendVerifyAmount',
    method: 'POST',
    data: data
  })
}

// 打款
export const verifyAmount = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/verifyAmount',
    method: 'POST',
    data: data
  })
}
// 签约检测
export const checkSign = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/checkSign',
    method: 'POST',
    data: data
  })
}
// 获取签约链接
export const getSignUrl = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/getSignUrl',
    method: 'POST',
    data: data
  })
}

// 发送短信
export const sendSignMsmRequest = data => {
  return request({
    url: '/activityPlatform/wxDistributionAuth/sendSignMsm',
    method: 'POST',
    data: data
  })
}

// 发送短信
export const getMyAccountInfo = data => {
  return request({
    url: '/activityPlatform/wxMember/myAccountInfo',
    method: 'POST',
    data: data
  })
}

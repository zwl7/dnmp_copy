const request = require('./../utils/http')
var config = require('../config')

// 获取微信code
function getWxCode() {
  return new Promise((resolve, reject) => {
    wx.login({
      success(res) {
        resolve(res)
      },
      fail() {
        reject('faily get wxcode')
      }
    })
  })
}

// 登录
const login = async () => {
  const { code } = await getWxCode()
  return request({
    url: '/activityPlatform/wxMember/miniLogin',
    data: { code, company_id: config.company_id, is_login: 1 }
  })
}

// 注册
const miniAuthLogin = data => {
  return request({
    url: '/activityPlatform/wxMember/miniAuthLogin',
    data: data
  })
}

// 会员小程序授权  更新用户信息
const updateUserInfo = data => {
  return request({
    url: '/activityPlatform/wxMember/miniAuth',
    data: data
  })
}

// 实名认证
const Authenticate = data => {
  return request({
    url: '/activityPlatform/wxMember/authenticate',
    data: data
  })
}

// 获取用户信息
const getUserInfo = data => {
  return request({
    url: '/activityPlatform/wxMember/get',
    data: data
  })
}

// 获取用户统计信息
const getMemberStatistic = data => {
  return request({
    url: '/activityPlatform/wxMember/MemberStatistic',
    data: data
  })
}

module.exports = {
  login,
  getWxCode,
  miniAuthLogin,
  updateUserInfo,
  getUserInfo,
  getMemberStatistic,
  Authenticate
}

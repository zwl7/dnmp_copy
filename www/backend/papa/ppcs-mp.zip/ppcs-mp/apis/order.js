const request = require('./../utils/http')

//参加活动创单
const createOrder = data => {
  return request({
    url: '/shop/order/create',
    method: 'POST',
    data: data
  })
}

//添加报名表单字段
const addWxFields = data => {
  return request({
    url: '/activityPlatform/wxField/adds',
    method: 'POST',
    data: data
  })
}

//支付
const shopOrderPay = data => {
  return request({
    url: '/shop/order/pay',
    method: 'POST',
    data: data
  })
}
//订单列表
const getOrderList = data => {
  return request({
    url: '/activityPlatform/wxOrder/list',
    method: 'POST',
    data: data
  })
}
//我的报名列表
const getApplicantList = data => {
  return request({
    url: '/activityPlatform/wxOrder/applicantList',
    method: 'POST',
    data: data
  })
}
//订单详情
const getOrderDetail = data => {
  return request({
    url: '/activityPlatform/wxOrder/get',
    method: 'POST',
    data: data
  })
}
// 取消订单
const cancelOrder = data => {
  return request({
    url: '/shop/order/cancel',
    method: 'POST',
    data: data
  })
}

// 轮询查询状态码
const shopOrderState = data => {
  return request({
    url: '/shop/order/state',
    method: 'POST',
    data: data
  })
}
// 退出活动
const cancelApply = data => {
  return request({
    url: '/activityPlatform/wxActivity/cancelApply',
    method: 'POST',
    data: data
  })
}

module.exports = {
  createOrder,
  shopOrderPay,
  getOrderList,
  getApplicantList,
  addWxFields,
  getOrderDetail,
  cancelOrder,
  shopOrderState,
  cancelApply
}

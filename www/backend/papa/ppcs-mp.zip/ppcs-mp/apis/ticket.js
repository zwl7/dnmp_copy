const request = require('./../utils/http')

// 添加门票
const addSession = data => {
  return request({
    url: '/activityPlatform/wxActivity/addSession',
    method: 'POST',
    data: data
  })
}

// 更新门票
const updateSession = data => {
  return request({
    url: '/activityPlatform/wxActivity/updateSession',
    method: 'POST',
    data: data
  })
}

// 删除门票
const delSession = data => {
  return request({
    url: '/activityPlatform/wxActivity/delSession',
    method: 'POST',
    data: data
  })
}

//获取门票列表
const getSessions = data => {
  return request({
    url: '/activityPlatform/wxActivity/getSessions',
    data: data
  })
}
//判断票种是否使用
const judgeSessionUse = data => {
  return request({
    url: '/activityPlatform/wxActivity/judgeSessionUse',
    data: data
  })
}

module.exports = {
  addSession,
  updateSession,
  getSessions,
  judgeSessionUse,
  delSession
}

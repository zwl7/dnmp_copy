const request = require('./../utils/http')

// 活动列表
export const getActivityList = param => {
  return request({
    url: '/activityPlatform/wxActivity/list',
    data: param
  })
}

//活动详情
export const getActivityDetail = activity_id => {
  return request({
    url: '/activityPlatform/wxActivity/get',
    data: { activity_id }
  })
}

//活动详情
export const getActivityUserInfo = data => {
  return request({
    url: '/activityPlatform/wxActivity/getUserInfo',
    data: data
  })
}

//活动报名表单
export const getApplyDetail = data => {
  return request({
    url: '/activityPlatform/wxActivity/applyGet',
    data: data
  })
}

// 创建活动
export const addWxActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/add',
    data: data
  })
}
// 更新活动
export const updateWxActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/update',
    data: data
  })
}
// 活动报名
export const applyWxActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/apply',
    data: data
  })
}

// 获取配置报名字段
export const getWxFields = data => {
  return request({
    url: '/activityPlatform/wxField/gets',
    data: data
  })
}

// 获取活动列表
export const getWxActivityList = data => {
  return request({
    url: '/activityPlatform/wxActivity/list',
    data: data
  })
}

// 获取圈子活动列表
export const getCircleActivityList = data => {
  return request({
    url: '/activityPlatform/wxCommunity/activityList',
    data: data
  })
}

// 获取用户 参与活动
export const getMyApplyList = data => {
  return request({
    url: '/activityPlatform/wxActivity/myApplyList',
    data: data
  })
}

// 获取用户 我的日程
export const getMyCalendarActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/myCalendarActivity',
    data: data
  })
}

// 获取用户 收藏活动
export const getMyCollectList = data => {
  return request({
    url: '/activityPlatform/wxActivity/myCollectList',
    data: data
  })
}

// 获取用户 发布的活动
export const getMyPublishList = data => {
  return request({
    url: '/activityPlatform/wxActivity/myPush',
    data: data
  })
}
// 正在进行的活动
export const processingActivities = function (data) {
  return request({
    url: '/activityPlatform/wxActivity/processingActivities',
    data
  })
}

// 历史活动
export const historicalActivities = function (data) {
  return request({
    url: '/activityPlatform/wxActivity/historicalActivities',
    data
  })
}

// 活动报名人员
export const getActivityApplyList = data => {
  return request({
    url: '/activityPlatform/wxActivity/applyList',
    data: data
  })
}

// 根据活动获取主理人信息
export const getMemberByActivityId = data => {
  return request({
    url: '/activityPlatform/wxMember/getByActivityId',
    data: data
  })
}
// 活动报名验证
export const activityApplyVerify = data => {
  return request({
    url: '/activityPlatform/wxActivity/applyVerify',
    data: data
  })
}

// 修改活动
export const updateActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/update',
    data: data
  })
}
// 解散活动
export const dismissActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/dismiss',
    data: data
  })
}
// 活动收藏
export const collectActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/collect',
    data: data
  })
}
// 请离开活动
export const applyRemoveActivity = data => {
  return request({
    url: '/activityPlatform/wxActivity/applyRemove',
    data: data
  })
}
// 邀请码验证
export const inviteCodeVerify = data => {
  return request({
    url: '/activityPlatform/wxActivity/inviteCodeVerify',
    data: data
  })
}

// 获取专题活动
export const getSpecialPageList = data => {
  return request({
    url: '/activityPlatform/wxActivity/specialPageList',
    data: data
  })
}

// 获取专题活动详情
export const getSpecialPageListDetail = data => {
  return request({
    url: '/activityPlatform/wxActivity/getSpecialPage',
    data: data
  })
}

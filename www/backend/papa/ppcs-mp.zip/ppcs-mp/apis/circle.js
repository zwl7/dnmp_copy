const request = require('./../utils/http')

// 星球添加
export const wxCommunityAdd = data => {
  return request({
    url: '/activityPlatform/wxCommunity/add',
    method: 'POST',
    data: data
  })
}

// 星球修改
export const wxCommunityUpdate = data => {
  return request({
    url: '/activityPlatform/wxCommunity/update',
    method: 'POST',
    data: data
  })
}

// 星球详情获取
export const wxCommunityGet = data => {
  return request({
    url: '/activityPlatform/wxCommunity/get',
    method: 'POST',
    data: data
  })
}

/**
 * 通过tag ids 获取星球
 * @param {*} tagIds
 */
export const getCirclesByTypeIds = data => {
  return request({
    url: '/activityPlatform/wxCommunity/circlesAndActivities',
    data
  })
}

// 加入星球
export const wxCommunityJoin = data => {
  return request({
    url: '/activityPlatform/wxCommunity/join',
    method: 'POST',
    data: data
  })
}

// 星球成员
export const wxCommunityJoinList = data => {
  return request({
    url: '/activityPlatform/wxCommunity/joinList',
    method: 'POST',
    data: data
  })
}

// 我的星球 统计接口
export const getMyCommunityStaticList = data => {
  return request({
    url: '/activityPlatform/wxCommunity/myCommunityStaticList',
    method: 'POST',
    data: data
  })
}

// 星球列表
export const getWxCommunityList = data => {
  return request({
    url: '/activityPlatform/wxCommunity/list',
    method: 'POST',
    data: data
  })
}
// 星球成员管理
export const getCommunityPersonnelList = data => {
  return request({
    url: '/activityPlatform/wxCommunityPersonnel/list',
    method: 'POST',
    data: data
  })
}
// 星球管理员id
export const getCommunityManagerIds = data => {
  return request({
    url: '/activityPlatform/wxCommunityPersonnel/managerIds',
    method: 'POST',
    data: data
  })
}
// 星球管理员添加
export const managerAdd = data => {
  return request({
    url: '/activityPlatform/wxCommunityPersonnel/managerAdd',
    method: 'POST',
    data: data
  })
}
// 用户主动离开星球
export const leaveCommunity = data => {
  return request({
    url: '/activityPlatform/wxCommunity/leaveCommunity',
    method: 'POST',
    data: data
  })
}

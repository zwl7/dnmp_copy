const request = require('./../utils/http')
const goodsList = data => {
  return request({
    url: 'goodsList',
    method: 'GET',
    data: data
  })
}

/**
 * 获取页面配置
 * @param {*} page 页面
 */
const getSetting = page => {
  return request({
    url: '/activityPlatform/wxSetting/getSetting',
    data: { page_router: page }
  })
}

/**
 * 根据adv ids获取广告数组
 * @param {*} advIds
 */
const getAdvListByIds = advIds => {
  return request({
    url: '/activityPlatform/wxAdv/getAdvsByIds',
    data: { adv_ids: advIds, status: 1 }
  })
}
/**
 * 根据tag ids获取tab数组
 * @param {*} tabIds
 */
const getTabListByIds = typeIds => {
  return request({
    url: '/activityPlatform/wxResourceType/list',
    data: { resource_type_ids: typeIds, page: 1, size: 1000 }
  })
}
/**
 * 我的星球
 */
const getMyCircles = data => {
  return request({
    url: '/activityPlatform/wxCommunity/myCommunity',
    data
  })
}

module.exports = {
  goodsList,
  getMyCircles,
  getSetting,
  getAdvListByIds,
  getTabListByIds
}

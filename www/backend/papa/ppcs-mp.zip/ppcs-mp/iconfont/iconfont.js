Component({
  properties: {
    // PC_renminbi | PC_paixu | PC_wenhao | PC_laba | PC_huodong1 | PC_fuzhi1 | PC_fenxiang | PC_gengduo1 | PC_single_arrow | PC_suijibofang | PC_gengduo | PC_dianhua1 | PC_lajitong | PC_xihuan-sel | PC_fuzhi | PC_xingbie-nan | PC_xingbie-nv | PC_dizhi | PC_bar-xihuannor | PC_tianjiahaoyou | PC_guanbi | PC_wode-shezhi | PC_navbanr-weizhi | PC_wode-xiaoxi | PC_shijian | PC_xiaoxi | PC_quanzixiangqing-fenxiang | PC_bianji | PC_sousuo | PC_wode-zhushou | PC_weixin | PC_navbar-shouye | PC_quanzixiangqing-fenxiang-copy | PC_wode-dingdan | PC_wode-kefu | PC_huodong | PC_qiehuan | PC_kaiguanno | PC_dianhua | PC_guanli | PC_navbar-fanhui | PC_bar-fenxiang | PC_bar-kefu | PC_tabbar-wodenor | PC_tabbar-wodesel | PC_tabbar-bulasel | PC_tabbar-huodongnor | PC_tabbar-huodongsel | PC_a-tabbar-bulanor
    name: {
      type: String,
    },
    // string | string[]
    color: {
      type: null,
      observer: function(color) {
        this.setData({
          colors: this.fixColor(),
          isStr: typeof color === 'string',
        });
      }
    },
    size: {
      type: Number,
      value: 18,
      observer: function(size) {
        this.setData({
          svgSize: size,
        });
      },
    },
  },
  data: {
    colors: '',
    svgSize: 18,
    quot: '"',
    isStr: true,
  },
  methods: {
    fixColor: function() {
      var color = this.data.color;
      var hex2rgb = this.hex2rgb;

      if (typeof color === 'string') {
        return color.indexOf('#') === 0 ? hex2rgb(color) : color;
      }

      return color.map(function (item) {
        return item.indexOf('#') === 0 ? hex2rgb(item) : item;
      });
    },
    hex2rgb: function(hex) {
      var rgb = [];

      hex = hex.substr(1);

      if (hex.length === 3) {
        hex = hex.replace(/(.)/g, '$1$1');
      }

      hex.replace(/../g, function(color) {
        rgb.push(parseInt(color, 0x10));
        return color;
      });

      return 'rgb(' + rgb.join(',') + ')';
    }
  }
});

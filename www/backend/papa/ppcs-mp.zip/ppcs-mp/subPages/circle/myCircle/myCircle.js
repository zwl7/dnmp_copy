const { getMyCommunityStaticList, leaveCommunity } = require('./../../../apis/circle')
Page({
  data: {
    tabs: [
      {
        title: '我加入的',
        type: 'joinCount',
        id: 1
      },
      {
        title: '我创建的',
        type: 'createCount',
        id: 2
      }
    ],
    activited: 1,
    joinPageInfo: {
      page: 1,
      size: 10
    },
    countObj: {
      joinCount: 0,
      createCount: 0
    },
    joinList: [],
    joinFinish: false,
    createPageInfo: {
      page: 1,
      size: 10
    },
    createList: [],
    createFinish: false,
    key_word: '',
    loading: false,
    popupShow: false,
    quitCommunityInfo: {
      name: '',
      community_id: '',
      join_day: ''
    }
  },
  clickTab(e) {
    let id = e.currentTarget.dataset.id
    let offsetLeft = e.currentTarget.offsetLeft
    this.setData({
      activited: id,
      offsetLeft: offsetLeft
    })
  },
  onLoad() {},
  onShow() {
    this.setData({
      'joinPageInfo.page': 1,
      'createPageInfo.page': 1,
      joinFinish: false,
      createFinish: false,
      joinList: [],
      createList: [],
      loading: true
    })

    this.getMyCommunityCreateList()
    this.getMyCommunityJoinList()
  },
  valueInput(event) {},
  inputConfirm(event) {
    let { value } = event.detail
    this.setData({
      key_word: value
    })
    let { activited } = this.data
    // 我加入的
    if (activited == 1) {
      this.data.joinPageInfo.page = 1
      this.setData({
        joinList: [],
        joinFinish: false
      })
      this.getMyCommunityJoinList()
    }
    // 我创建的
    if (activited == 2) {
      this.data.createPageInfo.page = 1
      this.setData({
        createList: [],
        createFinish: false
      })
      this.getMyCommunityCreateList()
    }
  },
  // 我加入的
  getMyCommunityJoinList() {
    let obj = Object.assign({ in_type: 2, key_word: this.data.key_word, is_location: 1 }, this.data.joinPageInfo)
    getMyCommunityStaticList(obj).then(res => {
      this.setData({
        loading: false
      })
      if (res.code === 200) {
        if (res.data.list.length < this.data.joinPageInfo.page) {
          this.setData({
            joinFinish: true
          })
        }
        let list = this.handleList(res.data.list)
        this.data.joinList = this.data.joinList.concat(list)
        this.setData({
          joinList: this.data.joinList,
          'countObj.joinCount': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 我创建的
  getMyCommunityCreateList() {
    let obj = Object.assign({ in_type: 1, key_word: this.data.key_word }, this.data.createPageInfo)
    getMyCommunityStaticList(obj).then(res => {
      this.setData({
        loading: false
      })
      if (res.code == 200) {
        if (res.data.list.length < this.data.createPageInfo.page) {
          this.setData({
            createFinish: true
          })
        }

        let list = this.handleList(res.data.list)
        this.data.createList = this.data.createList.concat(list)
        this.setData({
          createList: this.data.createList,
          'countObj.createCount': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  handleList(data) {
    let list = []
    data.map(e => {
      list.push({
        images: e.images,
        community_id: e.community_id,
        name: e.name,
        is_auth: e.is_auth,
        activity_num: e.activity_num,
        join_time: e.join_time,
        join_day: this.getJoinData(Number(e.join_time))
      })
    })
    wx.stopPullDownRefresh()
    return list
  },
  handleClickOperate(e) {
    console.log('操作', e)
    let info = {
      join_day: e.detail.join_day,
      name: e.detail.name,
      community_id: e.detail.community_id
    }
    this.setData({
      quitCommunityInfo: info,
      popupShow: true
    })
  },

  onCloseOperate() {
    this.setData({
      popupShow: false
    })
  },
  handleQuit() {
    this.setData({
      popupShow: false
    })
    this.selectComponent('#quitCommunityDialog').showDialog()
  },
  authConfirm() {
    let quitCommunityInfo = this.data.quitCommunityInfo
    let params = {
      community_id: quitCommunityInfo.community_id
    }
    leaveCommunity(params).then(res => {
      if (res.code == 200) {
        this.setData(
          {
            popupShow: false
          },
          () => {
            wx.showToast({
              title: '退出成功',
              icon: 'success'
            })
          }
        )
        getApp().getMemberStatistic()
        getApp().globalData.RefreshIndexMyCircle = true
        this.data.joinPageInfo.page = 1
        this.setData({
          joinList: [],
          joinFinish: false
        })
        this.getMyCommunityJoinList()
      } else {
        this.showToast('退出星球失败')
      }
    })
  },
  authCancel() {},
  getJoinData(join_time) {
    let count = 0
    let now = Math.ceil(new Date().getTime() / 1000)
    let diff = now - join_time
    if (join_time == 0) {
      return 0
    }
    count = diff / (60 * 60 * 24)
    return Math.ceil(count)
  },
  onReachBottom() {
    let { activited, joinFinish, createFinish } = this.data
    // 我加入的
    if (activited == 1 && !joinFinish) {
      this.data.joinPageInfo.page += 1
      this.getMyCommunityJoinList()
    }
    // 我创建的
    if (activited == 2 && !createFinish) {
      this.data.createPageInfo.page += 1
      this.getMyCommunityCreateList()
    }
  },
  onPullDownRefresh: function () {
    let { activited } = this.data
    // 我加入的
    if (activited == 1) {
      this.data.joinPageInfo.page = 1
      this.setData({
        joinList: [],
        key_word: '',
        joinFinish: false
      })
      this.getMyCommunityJoinList()
    }
    // 我创建的
    if (activited == 2) {
      this.data.createPageInfo.page = 1
      this.setData({
        createList: [],
        key_word: '',
        createFinish: false
      })
      this.getMyCommunityCreateList()
    }
  }
})

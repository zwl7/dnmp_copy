import { wxCommunityAdd } from './../../../apis/circle'
const { getWxResourceTypeAll } = require('./../../../apis/common')
const { uploadFile, judgeInputLength } = require('./../../../utils/util')
const app = getApp()
Page({
  data: {
    avatar: '',
    backgroundImg: '', //背景图片
    showCitypopup: false, //选择城市
    showUploadpopup: false, //选择背景图
    showchangeImgTypePopup: false, //选择图片方式
    showTypePopup: false, //选择星球类别
    sizeX: 200,
    sizeY: 200,
    globalImg: 'image', //globalImg名称
    address: '请选择',
    circle_type: '请选择',
    name: '',
    city_name: '请选择',
    isLoading: false,
    isIos: app.globalData.isIos,
    circleTypeOptions: [] //星球类别选项
  },
  customData: {
    name: '',
    city_id: '',
    type_id: '',
    street_id: '',
    address: '',
    latitude: '',
    longitude: '',
    images: '',
    banner: ''
  },
  onLoad(options) {
    app.globalData.circleBackgroundImg = ''
    app.globalData.avatarImg = ''
    this.getWxResourceTypeAll()
  },
  onShow() {
    let { circleBackgroundImg, avatarImg } = app.globalData
    let { globalImg } = this.data
    if (globalImg == 'circleBackgroundImg' && circleBackgroundImg) {
      uploadFile(circleBackgroundImg)
        .then(res => {
          if (res.code == 200) {
            this.setData({
              backgroundImg: res.data.imgUrl
            })
            this.customData.banner = res.data.imgUrl
            app.globalData.circleBackgroundImg = ''
          }
        })
        .catch(error => {
          console.log(error)
        })
    }
    if (globalImg == 'avatarImg' && avatarImg) {
      uploadFile(avatarImg)
        .then(res => {
          if (res.code == 200) {
            this.setData({
              avatar: res.data.imgUrl
            })
            this.customData.images = res.data.imgUrl
            app.globalData.avatar = ''
          }
        })
        .catch(error => {
          console.log(error)
        })
    }
  },
  showUpImgPopup(event) {
    this.setData({
      globalImg: ''
    })
    let { type } = event.currentTarget ? event.currentTarget.dataset : { type: event }
    let sizeX = 200
    let sizeY = 200
    let globalImg = 'image'
    if (type === 'background') {
      sizeX = 275
      sizeY = 187
      globalImg = 'circleBackgroundImg'
    } else if (type === 'avatar') {
      sizeX = 200
      sizeY = 200
      globalImg = 'avatarImg'
    }
    this.setData({
      sizeX: sizeX,
      sizeY: sizeY,
      globalImg: globalImg,
      showchangeImgTypePopup: !this.data.showchangeImgTypePopup
    })
  },
  // input
  valueInput(event) {
    let { type } = event.currentTarget.dataset
    let value = event.detail
    if (type === 'name') {
      value = judgeInputLength(value, 20, '圈子名称')
    }
    this.data[type] = value
    this.setData({
      [`${type}`]: this.data[type]
    })
  },
  // 设置背景图  弹出层
  showUploadPopup() {
    this.setData({
      showUploadpopup: !this.data.showUploadpopup
    })
  },
  getBackgroundImg(event) {
    this.setData({
      backgroundImg: event.detail
    })
    this.customData.banner = event.detail
  },
  changeBackgroundImg() {
    this.setData({
      showUploadpopup: false,
      globalImg: 'circleBackgroundImg'
    })
    setTimeout(() => {
      this.showUpImgPopup('background')
    }, 300)
  },
  // 城市选择弹出层
  handleShowCitypopup() {
    this.setData({
      showCitypopup: !this.data.showCitypopup
    })
  },
  getSelectCity(event) {
    let detail = event.detail
    console.log('================城市选择', detail)
    let str = ''
    detail.map(e => {
      str += e.name
    })
    this.setData({
      city_name: str
    })
    this.customData.city_id = String(detail[1].code).slice(0, 4)
    console.log(this.customData.city_id)
    this.customData.street_id = 0
  },
  // 获取具体位置
  getSite() {
    let _this = this
    wx.chooseLocation({
      longitude: _this.customData.longitude || app.globalData.longitude,
      latitude: _this.customData.latitude || app.globalData.latitude,
      success: function (res) {
        _this.setData({
          address: res.address
        })
        _this.customData.address = res.address
        _this.customData.latitude = res.latitude
        _this.customData.longitude = res.longitude
      },
      fail: function (e) {
        console.log('===============chooseLocation', e)
      }
    })
  },
  handleShowTypePopup() {
    this.setData({
      showTypePopup: true
    })
  },
  getCircleType(event) {
    let detail = event.detail
    this.setData({
      circle_type: detail.name
    })
    this.customData.type_id = detail.id
  },
  // 提交
  submit() {
    this.customData.name = this.data.name
    this.customData.company_id = 1
    this.customData.member_id = 1
    let validate = this.validate()
    if (!validate) return
    if (!this.data.isLoading) {
      this.setData({ isLoading: true })
      wxCommunityAdd(this.customData)
        .then(res => {
          if (res.code === 200) {
            wx.showToast({
              title: '添加成功'
            })
            app.getMemberStatistic()
            app.globalData.RefreshMinePage = true
            app.globalData.RefreshIndexPage = true
            app.globalData.RefreshFindPage = true
            setTimeout(() => {
              this.setData({ isLoading: false })
              app.globalData.createCircle = true
              app.globalData.createCircleInfo.community_id = res.data.community_id
              app.globalData.createCircleInfo.community_name = res.data.name
              wx.switchTab({
                url: '/pages/mine/mine'
              })
            }, 2000)
          } else {
            this.setData({ isLoading: false })
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(error => {
          console.log(error)
        })
    }
  },
  // 创建校验
  validate() {
    if (!this.customData.name) {
      this.showToast('请输入【星球名】')
      return false
    }
    if (!this.customData.type_id) {
      this.showToast('请选择星球类别')
      return false
    }
    if (!this.customData.city_id) {
      this.showToast('请选择所在城市')
      return false
    }
    if (!this.customData.address) {
      this.showToast('请选择具体地址')
      return false
    }
    if (!this.customData.images) {
      this.showToast('请上传头像')
      return false
    }
    if (!this.customData.banner) {
      this.showToast('请上传背景图片')
      return false
    }
    return true
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  // 获取星球类别
  getWxResourceTypeAll() {
    let obj = {
      type_id: 2
    }
    getWxResourceTypeAll(obj).then(res => {
      if (res.code === 200) {
        let circleTypeOptions = []
        res.data.map(e => {
          circleTypeOptions.push({
            name: e.name,
            id: e.resource_type_id
          })
        })
        this.setData({
          circleTypeOptions: circleTypeOptions
        })
      } else {
        this.showToast(res.message)
      }
    })
  }
})

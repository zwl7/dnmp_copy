const { getMyCommunityStaticList } = require('./../../../apis/circle')
const { buttonClicked } = require('./../../../utils/buttonClick')
Page({
  data: {
    pageInfo: {
      page: 1,
      size: 10
    },
    key_word: '',
    activity_type: '1',
    finish: false,
    circleList: [],
    isAttestation: false
  },
  onLoad(options) {
    console.log(options)
    // 认证申请
    if (options.isAttestation) {
      this.setData({ isAttestation: true })
      wx.setNavigationBarTitle({
        title: '选择认证的星球'
      })
    }
    if (options.activity_type) {
      this.setData({
        activity_type: options.activity_type
      })
    }
    this.getCircleList()
  },
  onShow() {},
  onPullDownRefresh() {
    this.setData({
      'pageInfo.page': 1,
      finish: false,
      circleList: [],
      key_word: ''
    })
    this.getCircleList()
  },
  onReachBottom() {
    if (!this.data.finish) {
      this.setData({
        'pageInfo.page': this.data.pageInfo.page + 1
      })
      this.getCircleList()
    }
  },
  getCircleList() {
    let obj = Object.assign({ in_type: 3, key_word: this.data.key_word }, this.data.pageInfo)
    if (!obj.key_word) {
      delete obj.key_word
    }
    getMyCommunityStaticList(obj)
      .then(res => {
        if (res.code == 200) {
          if (res.data.list.length < this.data.pageInfo.size) {
            this.setData({
              finish: true
            })
          }
          let list = this.handleList(res.data.list)
          this.data.circleList = this.data.circleList.concat(list)
          this.setData({
            circleList: this.data.circleList
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        wx.stopPullDownRefresh()
      })
      .catch(() => {
        wx.stopPullDownRefresh()
      })
  },
  handleList(data) {
    let list = []
    data.map(e => {
      list.push({
        images: e.images,
        community_id: e.community_id,
        name: e.name,
        is_auth: e.is_auth,
        activity_num: e.activity_num,
        join_time: e.join_time,
        join_day: this.getJoinData(Number(e.join_time))
      })
    })
    wx.stopPullDownRefresh()
    return list
  },
  getJoinData(join_time) {
    let count = 0
    let now = Math.ceil(new Date().getTime() / 1000)
    let diff = now - join_time
    if (join_time == 0) {
      return 0
    }
    count = diff / (60 * 60 * 24)
    return Math.ceil(count)
  },
  // 搜索
  handleSearch(event) {
    let detail = event.detail
    this.setData({
      key_word: detail,
      'pageInfo.page': 1,
      circleList: [],
      finish: false
    })
    this.getCircleList()
  },
  getCircleInfo(event) {
    this.creatActivity(event.detail)
  },
  creatActivity: buttonClicked(function (obj) {
    let { community_id, name } = obj
    let url = '/subPages/activity/create/create'
    // 认证申请选择星球
    if (this.data.isAttestation) {
      url = '/accountPages/applyAccount/apply'
    }
    url = url.concat('?community_id=', community_id).concat('&community_name=', name).concat('&op=', 'add').concat('&activity_type=', this.data.activity_type)
    wx.redirectTo({
      url: url
    })
  })
})

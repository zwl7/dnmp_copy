import Card from './circleQRCode'
const { getMPCode } = require('./../../../apis/common')
const buttonClick = require('./../../../utils/buttonClick')
const { saveImageToAlbum } = require('./../../../utils/util')
const app = getApp()
Page({
  imagePath: '',
  history: [],
  future: [],
  isSave: false,
  data: {
    loading: false,
    circleQrcode: {}
  },
  onLoad(options) {
    let circleQrcode = app.globalData.circleQrcode
    this.setData({ loading: true })
    if (!circleQrcode.community_id) {
      wx.showToast({
        title: '数据不完整,生成二维码失败',
        icon: 'none',
        duration: 10000
      })
      return
    }
    this.setData({
      circleQrcode: circleQrcode
    })
    this.getMPCode()
  },
  onHide() {
    app.globalData.circleQrcode = {}
  },
  onImgOK(e) {
    this.imagePath = e.detail.path
    this.setData({
      image: this.imagePath,
      loading: false
    })
    if (this.isSave) {
      this.saveImage(this.imagePath)
    }
  },

  saveImage: buttonClick.buttonClicked(function () {
    if (this.imagePath && typeof this.imagePath === 'string') {
      this.isSave = false
      saveImageToAlbum(this.imagePath)
    }
  }, 1000),
  getMPCode() {
    let { circleQrcode } = this.data
    let scene = `a=${circleQrcode.community_id}&m=${circleQrcode.member_id}`
    let obj = {
      page: 'subPages/circle/detail/index',
      scene: scene,
      env_version: app.globalData.env
    }
    this.setData({ loading: true })
    getMPCode(obj).then(res => {
      if (res.code === 200) {
        let url = 'data:image/jpeg;base64,' + res.data.images
        this.data.circleQrcode.qrcode = url
        this.setData(
          {
            circleQrcode: this.data.circleQrcode
          },
          () => {
            this.setData({
              paintPallette: new Card(this.data.circleQrcode).palette()
            })
          }
        )
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  }
})

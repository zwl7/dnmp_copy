const startTop = 0
const startLeft = 0
const qrcodeWidth = 800
const qrcodeLogoPercent = 1 / 2.2 //小程序中间logo占比
const avatarWidth = qrcodeWidth * qrcodeLogoPercent
export default class LastMayday {
  constructor(circleQrcode) {
    this.circleQrcode = circleQrcode
  }
  palette() {
    return {
      width: '800px',
      height: '800px',
      background: '#fff',
      views: [this.getQrcode(), this.getAvatar()]
    }
  }

  getQrcode() {
    return {
      id: 'qrcode',
      type: 'image',
      url: this.circleQrcode.qrcode,
      css: {
        top: startTop + 'px',
        left: startLeft + 'px',
        width: qrcodeWidth + 'px',
        height: qrcodeWidth + 'px'
      }
    }
  }

  getAvatar() {
    let image_start = (qrcodeWidth * (1 - qrcodeLogoPercent)) / 2
    return {
      id: 'avatar',
      type: 'image',
      url: this.circleQrcode.images,
      css: {
        width: avatarWidth + 'px',
        height: avatarWidth + 'px',
        borderRadius: avatarWidth + 'px',
        top: image_start + startTop + 'px',
        left: image_start + startLeft + 'px'
      }
    }
  }
}

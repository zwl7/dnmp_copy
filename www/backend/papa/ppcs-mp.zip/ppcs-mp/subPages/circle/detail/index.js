const { wxCommunityGet, wxCommunityJoin, wxCommunityJoinList, leaveCommunity } = require('./../../../apis/circle')
const { getCircleActivityList } = require('./../../../apis/activity')
const { getTagColor, handleQrcodeScene } = require('./../../../utils/util')
const app = getApp()
Page({
  data: {
    loading: true,
    showShare: false,
    tabActived: 'activity',
    // 星球详情
    community_info: {
      community_id: '',
      member_id: '',
      banner: '',
      images: '',
      name: '',
      hot: 0,
      tag: [],
      des: '',
      view_num: 0,
      signature: ''
    },
    member: {
      name: '',
      avatar: '',
      phone: '',
      wx: '',
      is_authenticate: 1
    },
    joinListPage: {
      page: 1,
      size: 10
    },
    joinList: [],
    joinListFinish: false,
    joinCommonsList: [],
    joinCount: 0,
    activityCount: 0,
    activityListPage: {
      page: 1,
      size: 10
    },
    historyActivityCount: 0,
    activityHistoryPage: {
      page: 1,
      size: 10
    },
    community_id: '',
    activityList: [], //正在进行的活动
    activityFinish: false,
    historyActivityList: [], //历史活动
    historyActivityFinish: false,
    showJoinBtn: false,
    is_owner: false
  },
  changeTab(e) {
    this.setData({
      tabActived: e.detail.name
    })
  },
  previewImages(e) {
    const images = e.currentTarget.dataset.images
    wx.previewImage({
      urls: images
    })
  },
  share() {
    this.setData({
      showShare: true
    })
  },
  onLoad(options) {
    if (options.scene) {
      let obj = handleQrcodeScene(options.scene)
      options.community_id = obj.a
    }
    let { community_id } = options
    this.setData({
      community_id: community_id
    })
    this.wxCommunityGet(community_id)
    this.wxCommunityJoinList(community_id)
    this.getWxActivityNow(community_id)
  },
  // 星球详情
  wxCommunityGet(community_id) {
    let obj = {
      community_id: community_id
    }
    wxCommunityGet(obj).then(res => {
      if (res.code === 200) {
        wx.setNavigationBarTitle({
          title: res.data.name
        })
        res.data.tag.map((item, index) => {
          const { color, textColor } = getTagColor(index)
          item.color = color
          item.textColor = textColor
        })
        let community_info = {
          banner: res.data.banner,
          images: res.data.images,
          name: res.data.name,
          community_id: res.data.community_id,
          member_id: res.data.member_id,
          hot: res.data.hot,
          tag: res.data.tag,
          des: res.data.des,
          view_num: res.data.view_num || 0,
          signature: res.data.signature || '星球主暂未填写。。。'
        }
        let memberInfo = res.data.member
        let member = {
          name: memberInfo.name,
          avatar: memberInfo.avatar,
          phone: memberInfo.phone,
          wx: memberInfo.wx,
          is_authenticate: memberInfo.is_authenticate
        }
        let showJoinBtn = !app.judgeIsJoin(res.data.community_id, 1)
        this.setData({
          community_info: community_info,
          member: member,
          community_id: res.data.community_id,
          showJoinBtn: showJoinBtn,
          loading: false,
          is_owner: app.globalData.userInfo.account_id == res.data.member_id
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  joinCommunity() {
    let obj = { community_id: this.data.community_id }
    wxCommunityJoin(obj).then(res => {
      if (res.code === 200) {
        wx.showToast({
          title: '加入成功'
        })
        this.setData({
          showJoinBtn: false
        })
        app.globalData.RefreshIndexMyCircle = true
        app.changeJoinList(Number(this.data.community_id), 1)
        getApp().getMemberStatistic()
      } else {
        if (res.message === '已经加入星球') {
          this.setData({
            showJoinBtn: false
          })
        }
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  quitCommunity() {
    this.selectComponent('#quitCommunityDialog').showDialog()
  },
  // 退出圈子
  authConfirm() {
    let community_id = this.data.community_info.community_id
    let params = {
      community_id: community_id
    }
    console.log(app.globalData.userStaticInfo.join_community_ids)
    leaveCommunity(params).then(res => {
      if (res.code == 200) {
        app.changeJoinList(Number(community_id), 1, 'del')
        console.log(app.globalData.userStaticInfo.join_community_ids)
        this.setData(
          {
            popupShow: false,
            showJoinBtn: true
          },
          () => {
            wx.showToast({
              title: '退出成功',
              icon: 'success'
            })
          }
        )
        getApp().getMemberStatistic()
      } else {
        wx.showToast({
          title: '退出星球失败',
          icon: 'none'
        })
      }
    })
  },
  authCancel() {
    console.log('321')
  },
  // 星球成员
  wxCommunityJoinList(community_id) {
    let obj = Object.assign({ community_id: community_id, no_location: 1 }, this.data.joinListPage)
    let role_map = {
      0: '普通会员',
      1: '主理人',
      2: '副管理员',
      3: '高级管理员'
    }
    wxCommunityJoinList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < 10) {
          this.setData({
            joinListFinish: true
          })
        }
        let list = []
        let joinCommonsList = []
        res.data.list.map(e => {
          e.role_str = role_map[e.role]
          e.city_name = ''
          let obj = {
            avatar: e.avatar,
            join_time_str: e.join_time_str,
            member_id: e.member_id,
            name: e.nick_name ? e.nick_name : e.name,
            role: e.role,
            role_str: e.role_str,
            sex: e.sex,
            city_name: e.city_name,
            is_authenticate: e.is_authenticate
          }
          if (e.role === 0) {
            joinCommonsList.push(obj)
          } else {
            list.push(obj)
          }
        })
        let joinList = this.data.joinList
        joinList = joinList.concat(list)
        let joinCommonsListData = this.data.joinCommonsList

        joinCommonsListData = joinCommonsListData.concat(joinCommonsList)
        this.setData({
          joinList: joinList,
          joinCommonsList: joinCommonsListData,
          joinCount: res.data.count,
          loading: false
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 星球正在进行活动
  getWxActivityNow(community_id) {
    let now = Math.ceil(new Date().getTime() / 1000)
    let obj = Object.assign(
      {
        community_id: community_id,
        gte_end_time: now,
        no_location: 1
      },
      this.data.activityListPage
    )
    getCircleActivityList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < this.data.activityListPage.size) {
          this.setData({
            activityFinish: true
          })
          this.getWxActivityHistory(community_id)
        }
        if (res.data.list.length === 0 && this.data.activityListPage.page == 1) {
          // this.getWxActivityHistory(community_id)
        }
        let list = this.handleActivityData(res.data.list, false)
        this.data.activityList = this.data.activityList.concat(list)
        this.setData({
          activityCount: res.data.count,
          activityList: this.data.activityList
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 星球历史活动
  getWxActivityHistory(community_id) {
    let now = Math.ceil(new Date().getTime() / 1000)
    let obj = Object.assign(
      {
        community_id: community_id,
        lte_end_time: now,
        no_location: 1
      },
      this.data.activityHistoryPage
    )
    getCircleActivityList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < this.data.activityHistoryPage.size) {
          this.setData({
            historyActivityFinish: true
          })
        }
        let list = this.handleActivityData(res.data.list, true)
        this.data.historyActivityList = this.data.historyActivityList.concat(list)
        this.setData({
          historyActivityCount: res.data.count,
          historyActivityList: this.data.historyActivityList
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 处活动数据
  handleActivityData(data, show_end) {
    let list = []
    data.map(e => {
      let obj = {
        images: e.images,
        start_time_str: e.start_time_str,
        name: e.name,
        address: e.address,
        activity_id: e.activity_id,
        people_num: e.people_num,
        apply_num: e.apply_num,
        apply_member: e.apply_member.slice(0, 3),
        show_end: show_end,
        label: app.judgeIsJoin(e.community_id, 2) ? '已加入' : '未加入',
        activity_type: e.activity_type
      }
      list.push(obj)
    })
    return list
  },

  onReachBottom() {
    let { tabActived } = this.data
    if (tabActived == 'activity') {
      if (!this.data.activityFinish) {
        this.data.activityListPage.page += 1
        this.getWxActivityNow(this.data.community_id)
      }
      if (!this.data.historyActivityFinish && this.data.activityFinish) {
        this.data.activityHistoryPage.page += 1
        this.getWxActivityHistory(this.data.community_id)
      }
    } else if (tabActived == 'member') {
      if (!this.data.joinListFinish) {
        this.data.joinListPage.page += 1
        this.wxCommunityJoinList(this.data.community_id)
      }
    }
  },
  // 转发朋友
  onShareAppMessage() {
    let { name } = this.data.community_info
    let community_id = this.data.community_id
    let { nick_name } = app.globalData.userInfo
    nick_name = nick_name ? nick_name : '微信用户'
    // return new Promise((resolve,reject) => {
    //   setTimeout(() => {
    //     resolve({})
    //   }, 2000);
    // })
    return {
      title: `${nick_name} 邀请你快来加入 ${name} 星球吧~`,
      path: '/subPages/circle/detail/index'.concat('?community_id=', community_id),
      success: function (t) {
        console.log('成功', t)
      },
      fail: function (t) {
        console.log('失败', t)
      }
    }
  },
  handleShare(event) {
    let type = event.detail
    this.setData({
      showShare: false
    })
    if (type == 1) {
      let { community_info } = this.data
      let circleQrcode = {
        name: community_info.name,
        images: community_info.images,
        community_id: community_info.community_id,
        member_id: community_info.member_id,
        signature: community_info.signature
      }
      app.globalData.circleQrcode = circleQrcode
      wx.navigateTo({
        url: '/subPages/circle/circleQRCode/index'
      })
    }
  }
})

Page({
  data: { url: '' },
  onLoad(options) {
    let url = decodeURIComponent(options.url)
    this.setData({
      url: url
    })
  }
})

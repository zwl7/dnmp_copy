const { activityApplyVerify } = require('./../../../apis/activity')
const app = getApp()
Page({
  data: {
    member_id: '',
    applicant_code: '',
    activity_id: '',
    user_info: {
      avatar: '',
      name: '--',
      session_name: '--',
      price: 0,
      applicant_code: '--',
      status: 3, //状态    1 成功  2 失败  3 提示,
      check_str: '等待核验'
    }
  },
  onLoad(options) {
    let checkTicketInfo = app.globalData.checkTicketInfo
    this.setData({
      user_info: checkTicketInfo
    })
    app.globalData.checkTicketInfo = {}
  },
  handleScan() {
    let _this = this
    wx.scanCode({
      success(res) {
        let result = res.result
        _this.getMsg(result)
        _this.checkTicket()
      },
      fail(error) {
        wx.showToast({
          title: '识别失败',
          icon: 'error'
        })
      }
    })
  },
  getMsg(result) {
    var res = result.split(',')
    this.setData({
      applicant_code: res[0],
      member_id: res[2],
      activity_id: res[1]
    })
  },
  checkTicket() {
    let obj = { applicant_code: this.data.applicant_code }
    activityApplyVerify(obj).then(res => {
      if (res.code === 200) {
        let status_info = this.getStatusInfo(
          res.data.status,
          res.data.verify_status,
          res.data.status_str
        )
        let user_info = {
          avatar: res.data.avatar,
          name: res.data.nick_name
            ? res.data.nick_name
            : res.data.name,
          session_name: res.data.sku_info,
          price: res.data.pay_price,
          applicant_code: res.data.applicant_code,
          status: status_info.status,
          check_str: status_info.status_str,
          verify_status: res.data.verify_status
        }
        this.setData({ user_info: user_info })
      } else {
        let user_info = {
          avatar: '',
          name: '',
          session_name: '',
          price: '',
          applicant_code: '',
          status: '3',
          check_str: '核验失败'
        }
        this.setData({ user_info: user_info })
      }
    })
  },
  getStatusInfo(status, verify_status, status_str) {
    let status_index = 3
    let status_new_str = status_str
    if (verify_status === 1) {
      status_index = 1
      status_new_str = '核销成功'
    } else {
      if (status == 7) {
        status_index = 3
      } else {
        status_index = 2
      }
    }
    return {
      status: status_index,
      status_str: status_new_str
    }
  }
})

const { getOrderDetail, cancelOrder, shopOrderPay, shopOrderState, cancelApply } = require('./../../../apis/order')
const { wxCommunityGet } = require('./../../../apis/circle')
const { formatActivityTime } = require('./../../../utils/date')
const { buttonClicked } = require('./../../../utils/buttonClick')
const drawQrcode = require('./../../../utils/weapp.qrcode')
const app = getApp()
let tmplIds = [
  'bGf_7nJD1RZ3ZNiO1rh7gqgKUcLK2Ptc-5WJF2V7osI', //活动改期提醒
  'sJaleyD7jpWqd5UcaieOT-AMPIhd_00ezWOQpcEBK-Q', //活动即将开始提醒
  'S1sEZLEBw_JSuEz9XVpnWkwS7FzHNdyS7yq2zhAueWc' //活动已解散通知
]
Page({
  data: {
    minutes: '00',
    seconds: '00',
    activity: {},
    orderInfo: {},
    skuList: [],
    order_status: 0,
    order_title: '',
    isPay: false,
    order_no: '',
    official: {
      images: '',
      name: '',
      member_num: 0,
      activity_num: 0,
      moment_num: 0
    },
    cancelOrderDialog: '',
    applicant_code_list: [], //票号
    confirmOrderLoading: false,
    is_parent_order: ''
  },
  ShopOrderStateTimer: null,
  ShopOrderStateCount: 0,
  setTimeoutTimer: null, //定时轮训状态
  onLoad(options) {
    let { order_no, is_parent_order } = options
    this.setData({
      order_no: order_no,
      is_parent_order: is_parent_order
    })
    this.getOrderDetail(order_no)
    this.data.cancelOrderDialog = this.selectComponent('#cancelOrderDialog')
  },
  onShow() {},
  onUnload() {
    clearInterval(this.ShopOrderStateTimer)
    this.ShopOrderStateTimer = null
    if (this.data.setTimeoutTimer) {
      clearInterval(this.data.setTimeoutTimer)
      this.setData({
        setTimeoutTimer: null
      })
    }
  },
  getOrderDetail(order_no, is_query) {
    let obj = {}
    if (this.data.is_parent_order) {
      obj.parent_order_no = order_no
    } else {
      obj.order_no = order_no
    }
    getOrderDetail(obj).then(res => {
      if (res.code === 200) {
        let applicant_code_list = []
        let activity = res.data.activity
        if (!is_query || res.data.order_status != 1) {
          activity.date = formatActivityTime(activity.start_time, activity.end_time)
          let skuList = res.data.skuList
          let sku_info_list = []
          res.data.skuList.map(e => {
            applicant_code_list.push({
              applicant_code: e.applicant_code,
              member_id: res.data.member_id,
              activity_id: res.data.activity.activity_id,
              imageSrc: ''
            })
            sku_info_list.push(e.sku_info)
          })
          let orderInfo = {
            order_no: res.data.order_no,
            parent_order_no: res.data.parent_order_no,
            c_time_str: res.data.c_time_str,
            c_time: res.data.c_time,
            order_status_str: res.data.order_status_str,
            order_status: res.data.order_status,
            order_price: res.data.order_price,
            sku_info_str: sku_info_list.join(',')
          }
          this.setData({
            activity: activity,
            orderInfo: orderInfo,
            skuList: skuList,
            order_status: res.data.order_status,
            applicant_code_list: applicant_code_list
          })
        }
        if (res.data.order_status == 1) {
          // 订单已支付
          if (!is_query) {
            applicant_code_list.map((e, index) => {
              let canvasId = e.applicant_code + '_' + index
              let list = [e.applicant_code, e.activity_id, e.member_id]
              let text = list.join(',')
              this.draw(canvasId, text, index)
            })
            this.wxCommunityGet(activity.community_id)
            this.continueGetOrderDetail()
          }
        }
        if (is_query && res.data.order_status == 5) {
          if (this.selectComponent('#checkSuccess')) {
            this.selectComponent('#checkSuccess').showDialog()
          }
        }
        if (is_query && res.data.order_status != 1) {
          if (this.data.setTimeoutTimer) {
            clearInterval(this.data.setTimeoutTimer)
            this.data.setTimeoutTimer = null
          }
        }
        this.judgeOrderPay()
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 轮训查找用户扫码情况
  continueGetOrderDetail() {
    let timer = setInterval(() => {
      this.getOrderDetail(this.data.order_no, 1)
    }, 2000)
    this.setData({
      setTimeoutTimer: timer
    })
  },
  // 判断订单是否可以支付
  judgeOrderPay() {
    let { order_status } = this.data
    let { c_time } = this.data.orderInfo
    let now_time = Math.trunc(new Date().getTime() / 1000)
    let diff = c_time + 8 * 60 - now_time
    if (order_status === 0) {
      if (diff <= 8 * 60 && diff > 0) {
        this.setData({
          order_title: '待付款',
          isPay: true
        })
        this.countdownTime(diff)
      } else {
        this.setData({
          order_title: '订单已过期',
          isPay: false
        })
      }
    } else {
      this.setData({
        order_title: this.data.orderInfo.order_status_str,
        isPay: false
      })
    }
  },
  // 订单倒计时
  countdownTime(diff) {
    let timer = setInterval(() => {
      let minutes = parseInt(diff / 60)
      let seconds = diff % 60
      diff -= 1
      if (diff == 0) {
        clearInterval(timer)
        timer = null
        this.setData({
          isPay: false,
          order_title: '订单已过期'
        })
      } else {
        this.setData({
          minutes: String(minutes).padStart(2, '0'),
          seconds: String(seconds).padStart(2, '0')
        })
      }
    }, 1000)
  },
  // 取消订单弹窗
  showCancelDialog() {
    this.data.cancelOrderDialog.showDialog()
  },
  // 取消订单弹窗 确认
  confirmOrderDialog() {
    let obj = {
      parent_order_no: this.data.orderInfo.parent_order_no
    }
    cancelOrder(obj).then(res => {
      if (res.code === 200) {
        wx.showToast({
          title: res.data.result,
          icon: 'none'
        })
        this.getOrderDetail(this.data.order_no)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
        this.getOrderDetail(this.data.order_no)
      }
    })
  },
  // 取消订单弹窗 取消
  cancelOorderDialog() {},
  // 马上支付
  confirmOrder() {
    if (this.data.confirmOrderLoading) {
      return
    }
    this.shopOrderPay()
  },
  shopOrderPay() {
    // let obj = {
    //   parent_order_no: this.data.orderInfo.parent_order_no,
    //   payment_way: 60,
    //   extend_field: JSON.stringify({
    //     trade_pay_type: 'wxPay.mini'
    //   })
    // }
    let obj = {
      parent_order_no: this.data.orderInfo.parent_order_no,
      payment_way: 110,
      extend_field: JSON.stringify({
        trade_pay_type: 'umsPay.open.mini',
        msg_type: 'wx.unifiedOrder'
      })
    }
    this.setData({
      confirmOrderLoading: true
    })
    shopOrderPay(obj).then(res => {
      if (res.code === 200) {
        this.setData({
          submitText: '正在支付...',
          loading: true
        })
        if (res.data.price == 0) {
          this.getOrderDetail(this.data.order_no)
          this.setData({
            confirmOrderLoading: false
          })
        } else {
          this.ShopOrderStateTimer = setInterval(() => {
            this.getShopOrderState()
            this.ShopOrderStateCount += 1
          }, 1500)
          wx.requestPayment({
            timeStamp: res.data.timestamp,
            nonceStr: res.data.nonce_str,
            package: 'prepay_id=' + res.data.prepay_id,
            signType: res.data.sign_type,
            paySign: res.data.pay_sign,
            success(res) {
              // 订阅消息
              wx.requestSubscribeMessage({
                tmplIds: tmplIds,
                success(res) {
                  console.log(res)
                }
              })
            },
            fail(res) {}
          })
        }
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
        this.getOrderDetail(this.data.order_no)
      }
      this.setData({
        confirmOrderLoading: false
      })
    })
  },
  // 订单状态轮训
  getShopOrderState() {
    let obj = { parent_order_no: this.data.orderInfo.parent_order_no }
    shopOrderState(obj)
      .then(res => {
        if (res.code === 200) {
          let { transaction_status, transaction_code, transaction_msg } = res.data
          if (transaction_status == 1) {
            this.getOrderDetail(this.data.order_no)
            clearInterval(this.ShopOrderStateTimer)
            this.ShopOrderStateTimer = null
            this.setData({
              confirmOrderLoading: false
            })
            return
          }
          if (transaction_status == 0 && transaction_code != 0) {
            // 支付失败
            clearInterval(this.ShopOrderStateTimer)
            this.ShopOrderStateTimer = null
            this.getOrderDetail(this.data.order_no)
            this.setData({
              confirmOrderLoading: false
            })
          }
          if (transaction_status == 0 && transaction_code === 0) {
            // 正在支付
          }
        } else {
        }
      })
      .catch(error => {
        console.log(error)
      })
  },
  // 获取星球信息
  wxCommunityGet(community_id) {
    let obj = { community_id: community_id }
    wxCommunityGet(obj).then(res => {
      if (res.code === 200) {
        let official = {
          images: res.data.images,
          name: res.data.name,
          member_num: res.data.people_num,
          activity_num: res.data.activity_num || 0,
          moment_num: res.data.moment_num
        }
        this.setData({
          official: official
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 绘制二维码
  draw(canvasId, text, index) {
    let _this = this
    drawQrcode({
      width: 180,
      height: 180,
      x: 10,
      y: 10,
      canvasId: canvasId,
      typeNumber: 10,
      text: text,
      callback(e) {
        setTimeout(() => {
          wx.canvasToTempFilePath({
            canvasId: canvasId,
            width: 200,
            height: 200,
            destWidth: 200,
            destHeight: 200,
            success: function (res) {
              let tempFilePath = res.tempFilePath
              _this.data.applicant_code_list[index]['imageSrc'] = tempFilePath
              console.log(tempFilePath)
              _this.setData({
                [`applicant_code_list[${index}]`]: _this.data.applicant_code_list[index]
              })
              console.log(_this.data.applicant_code_list)
            }
          })
        }, 100)
      }
    })
  },
  // 扫码
  handleScan() {
    wx.showToast({
      title: '扫码',
      icon: 'none'
    })
  },
  toCircle: buttonClicked(function () {
    let { community_id } = this.data.activity
    let url = '/subPages/circle/detail/index'
    url = url.concat('?community_id=', community_id)
    wx.navigateTo({
      url: url
    })
  }),
  // 退出活动
  quitActivity() {
    this.selectComponent('#quitDialogActivity').showDialog()
  },
  cancelQuitActivity() {},
  confirmlQuitActivity() {
    let obj = {
      order_no: this.data.order_no
    }
    cancelApply(obj).then(res => {
      if (res.code === 200) {
        wx.showToast({
          title: '活动退出成功！',
          icon: 'none'
        })
        this.getOrderDetail(this.data.order_no)
        app.globalData.RefreshMinePage = true
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  }
})

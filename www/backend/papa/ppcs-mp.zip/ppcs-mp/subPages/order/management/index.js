const { getApplicantList, createOrder } = require('./../../../apis/order')
const app = getApp()
const { formatActivityTime, formatTimeBase } = require('./../../../utils/date')

Page({
  data: {
    active: '-1',
    page: 1,
    size: 10,
    orderList: [],
    loading: false,
    finish: false
  },
  onLoad() {},
  onShow() {
    this.setData({
      loading: false,
      finish: false,
      orderList: [],
      page: 1
    })
    this.getApplicantList()
  },
  onPullDownRefresh: function () {
    this.onRefresh()
  },
  onReachBottom() {
    if (!this.data.finish) {
      this.setData({
        page: this.data.page + 1
      })
      this.getApplicantList()
    }
  },
  onRefresh() {
    this.setData({
      loading: false,
      finish: false,
      page: 1,
      orderList: []
    })
    this.getApplicantList()
  },
  onChange(e) {
    let { name } = e.detail
    this.setData({
      active: name,
      page: 1,
      orderList: []
    })
    this.getApplicantList()
  },
  getApplicantList() {
    let obj = {
      page: this.data.page,
      size: this.data.size,
      status: this.data.active
    }
    this.setData({
      loading: true
    })
    getApplicantList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length === 0) {
          this.setData({
            finish: true
          })
        }
        res.data.list.map(e => {
          if (e.activity && e.activity.status == 3) {
            e.activity.name = '违规活动'
            e.activity.images = app.globalData.weigui_activity_png
          }
          e.date = formatActivityTime(e.activity.start_time, e.activity.end_time)
          e.pay_price = Number(e.pay_price) / 100
        })
        this.data.orderList = this.data.orderList.concat(res.data.list)
        this.setData({
          orderList: this.data.orderList,
          loading: false
        })
      } else {
        this.setData({
          loading: false
        })
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
      wx.stopPullDownRefresh()
    })
  },
  createOrder(e) {
    let { sku_clice } = e.detail
    wx.showLoading({
      title: '创建订单中'
    })
    let obj = {
      sys_id: 30,
      sku_slice: sku_clice,
      business_type: 3001,
      request_id: 'ppsport',
      business_id: '10000001',
      handle_info: JSON.stringify({ platform_id: 3 }),
      no_location: 1
    }
    createOrder(obj)
      .then(res => {
        if (res.code === 200) {
          let order_no = res.data.parent_order_no
          let url = '/subPages/order/waitPay/index'
          url = url.concat('?order_no=', order_no).concat('&is_parent_order=1')
          wx.navigateTo({
            url: url
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        wx.hideLoading()
      })
      .catch(err => {
        wx.hideLoading()
      })
  }
})

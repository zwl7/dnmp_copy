const { getActivityDetail, getWxFields, applyWxActivity } = require('./../../../apis/activity')
const { createOrder, shopOrderPay, shopOrderState } = require('./../../../apis/order')
const { formatActivityTime, formatTimeBase } = require('./../../../utils/date')
const { getRefundRuleStr } = require('./../../../utils/util')
const { buttonClicked } = require('./../../../utils/buttonClick')
const app = getApp()
let tmplIds = [
  'bGf_7nJD1RZ3ZNiO1rh7gqgKUcLK2Ptc-5WJF2V7osI', //活动改期提醒
  'sJaleyD7jpWqd5UcaieOT-AMPIhd_00ezWOQpcEBK-Q', //活动即将开始提醒
  'S1sEZLEBw_JSuEz9XVpnWkwS7FzHNdyS7yq2zhAueWc' //活动已解散通知
]
Page({
  data: {
    activityInfo: {
      images: '',
      name: '',
      date: '',
      address: ''
    },
    sessionInfo: {
      price: 0,
      num: 0,
      total: 0,
      sessions_name: '',
      field_info: '',
      field_ids: ''
    },
    showInfo: false,
    showSuccess: false,
    showFail: false,
    options: {
      sessions_id: '',
      num: 0,
      activity_id: '',
      activity_type: 1
    },
    apply_field_info: '', //赛事报名用户信息
    baseFiled: [],
    userField: [],
    official: {
      images: '',
      name: '',
      member_num: 0,
      activity_num: 0,
      moment_num: 0
    },
    submitText: '确认支付',
    loading: false,
    info: ``,
    parent_order_no: '',
    createOrderObj: null, //创建订单后的信息
    activity_id: '',
    community_id: '',
    refundRuleStr: ''
  },
  ShopOrderStateTimer: null,
  ShopOrderStateCount: 0,
  onClickHide() {
    this.setData({
      showInfo: false
    })
  },
  infoShow() {
    wx.navigateTo({
      url: '/subPages/system/applyNote/index'
    })
  },
  // 查看订单
  watchOrder() {
    wx.redirectTo({
      url: '/subPages/order/management/index'
    })
  },
  onClose() {
    this.setData({
      showSuccess: false,
      showInfo: false
    })
  },
  // 获取活动详情
  getDetail(activityId) {
    getActivityDetail(activityId).then(res => {
      if (res.code === 200) {
        const activity = res.data
        let activityInfo = {
          images: activity.images,
          name: activity.name,
          address: activity.address,
          date: formatActivityTime(activity.start_time, activity.end_time)
        }
        let sessionItem = null
        activity.sessions.map(e => {
          if (e.activity_sessions_id == this.data.options.sessions_id) {
            sessionItem = e
          }
        })
        let field_id_list = []
        try {
          let list = JSON.parse(sessionItem.field_info)
          list.map(e => {
            field_id_list.push(e.id)
          })
        } catch (error) {}
        let sessionInfo = {
          price: sessionItem.price,
          sessions_name: sessionItem.sessions_name,
          field_info: sessionItem.field_info,
          field_ids: field_id_list.join(','),
          num: this.data.options.num,
          total: (Number(sessionItem.price) * Number(this.data.options.num)).toFixed(2)
        }
        if (field_id_list.length > 0) {
          this.getWxFields(sessionInfo.field_ids)
        }
        this.setData({
          activity_id: res.data.activity_id,
          community_id: res.data.community_id,
          activityInfo: activityInfo,
          sessionInfo: sessionInfo,
          official: activity.community,
          refundRuleStr: getRefundRuleStr(res.data.refund_rule),
          'options.activity_type': res.data.activity_type
        })
      }
    })
  },
  // 获取报名表单配置
  getWxFields(field_ids) {
    getWxFields({ field_ids: field_ids }).then(res => {
      if (res.code === 200) {
        let baseFiled = []
        let userField = []
        res.data.map(e => {
          if (e.field_select_value) {
            e.field_select_value = JSON.parse(e.field_select_value)
          }
          e.showTip = false
          e.tip = ''
          if (e.field_id <= 7) {
            e.tip = `请填写${e.field_name}`
            if (e.field_id == 4) {
              e.tip = '请输入正确的身份证号'
              e.reg = `^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$`
            }
            if (e.field_id == 2) {
              e.tip = '请输入正确的手机号'
              e.reg = '^[1][3,4,5,7,8][0-9]{9}$'
            }
            e.value = ''
            baseFiled.push(e)
          } else {
            e.value = []
            e.tip = `请填写当前问题`
            userField.push(e)
          }
        })
        this.setData({
          baseFiled: baseFiled,
          userField: userField
        })
      }
    })
  },
  getSignUpData(event) {
    let { index } = event.currentTarget.dataset
    this.data.userField[index].value = event.detail
    this.setData({
      [`userField[${index}]`]: this.data.userField[index]
    })
  },
  setTipShow(field_id, is_show) {
    this.data.userField.map(e => {
      if (e.field_id == field_id) {
        e.showTip = is_show
      }
    })
    this.setData({
      userField: this.data.userField
    })
  },
  // 校验表单
  validateForm() {
    let list = []
    let baseForm = this.selectComponent('#baseForm')
    if (baseForm) {
      let baseFieldList = baseForm.getData()
      let userFieldList = this.getuserFieldData()
      list = baseFieldList.concat(userFieldList)
    }
    let flag = true
    list.map(e => {
      if (e.value == '' || e.value == []) {
        flag = false
        if (e.field_id <= 7) {
          baseForm.setTipShow(e.field_id, true)
        } else {
          this.setTipShow(e.field_id, true)
        }
      } else {
        if (e.reg) {
          var reg = new RegExp(e.reg)
          if (reg.test(e.value)) {
            baseForm.setTipShow(e.field_id, false)
          } else {
            flag = false
            baseForm.setTipShow(e.field_id, true)
          }
        } else {
          if (e.field_id <= 7) {
            baseForm.setTipShow(e.field_id, false)
          } else {
            this.setTipShow(e.field_id, false)
          }
        }
      }
    })
    return flag
  },
  // 用户自定义数据
  getuserFieldData() {
    let list = JSON.parse(JSON.stringify(this.data.userField))
    let res = []
    list.map(e => {
      res.push({
        field_id: e.field_id,
        value: e.value
      })
    })
    return res
  },
  // 创单
  createOrder(sku_slice) {
    let obj = {
      sys_id: 30,
      sku_slice: sku_slice,
      business_type: 3001,
      request_id: 'ppsport',
      business_id: '10000001',
      handle_info: JSON.stringify({ platform_id: 3 })
    }
    createOrder(obj).then(res => {
      if (res.code === 200) {
        let obj = {
          parent_order_no: res.data.parent_order_no,
          payment_way: 110,
          extend_field: JSON.stringify({
            trade_pay_type: 'umsPay.open.mini',
            msg_type: 'wx.unifiedOrder'
          })
        }
        this.setData({
          createOrderObj: obj,
          parent_order_no: res.data.parent_order_no
        })
        this.shopOrderPay(obj)
      } else {
        this.setData({
          // showFail: true,
          loading: false
        })
        wx.showModal({
          title: '提示',
          showCancel: false,
          content: res.message,
          success(res) {
            if (res.confirm) {
              wx.navigateBack({
                delta: 0
              })
            }
          }
        })
      }
    })
  },
  //订单支付
  shopOrderPay(obj) {
    const _this = this
    shopOrderPay(obj).then(res => {
      app.globalData.RefreshMinePage = true
      if (res.code === 200) {
        this.setData({
          submitText: '正在支付...',
          loading: true
        })
        if (res.data.price == 0) {
          wx.requestSubscribeMessage({
            tmplIds: tmplIds,
            success(res) {
              console.log('requestSubscribeMessage', res)
            },
            fail(error) {
              console.log('requestSubscribeMessage', error)
            }
          })
          app.getMemberStatistic()
          this.setData({
            showSuccess: true,
            loading: false
          })
        } else {
          setTimeout(() => {
            let ShopOrderStateTimer = setInterval(() => {
              this.getShopOrderState()
              this.ShopOrderStateCount += 1
            }, 1500)
            this.ShopOrderStateTimer = ShopOrderStateTimer
          }, 50)
          wx.requestPayment({
            timeStamp: res.data.timestamp,
            nonceStr: res.data.nonce_str,
            package: 'prepay_id=' + res.data.prepay_id,
            signType: res.data.sign_type,
            paySign: res.data.pay_sign,
            success(res) {
              console.log('====支付成功====', res)
              wx.requestSubscribeMessage({
                tmplIds: tmplIds,
                success(res) {
                  console.log('requestSubscribeMessage', res)
                },
                fail(error) {
                  console.log('requestSubscribeMessage', error)
                }
              })
            },
            fail(res) {
              console.log('===微信支付失败===', res)
              clearInterval(_this.ShopOrderStateTimer)
              _this.ShopOrderStateTimer = null
              if (res.errMsg === 'requestPayment:fail cancel') {
                _this.showToast('您取消了支付~')
              } else {
                _this.showToast('支付异常~')
              }
              _this.setData({
                loading: false,
                submitText: '继续支付'
              })
            }
          })
        }
      } else {
        this.setData({
          showFail: true,
          loading: false
        })
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
        setTimeout(() => {
          wx.redirectTo({
            url: '/subPages/order/management/index'
          })
        }, 3000)
      }
    })
  },
  // 订单状态轮训
  getShopOrderState() {
    console.log('订单状态轮训', 11111)
    let obj = { parent_order_no: this.data.parent_order_no }
    shopOrderState(obj)
      .then(res => {
        if (res.code === 200) {
          let { transaction_status, transaction_code, transaction_msg } = res.data
          if (transaction_status == 1) {
            app.getMemberStatistic()
            // 支付成功
            this.setData({
              submitText: '支付成功',
              loading: false,
              showSuccess: true
            })
            // 订阅消息
            clearInterval(this.ShopOrderStateTimer)
            this.ShopOrderStateTimer = null
            return
          }
          if (transaction_status == 0 && transaction_code != 0) {
            // 支付失败
            this.setData({
              showFail: true,
              loading: false
            })
            clearInterval(this.ShopOrderStateTimer)
            this.ShopOrderStateTimer = null
          }
          if (transaction_status == 0 && transaction_code === 0) {
            // 正在支付
          }
        } else {
        }
      })
      .catch(error => {
        console.log(error)
      })
  },
  handleConfirm: buttonClicked(async function () {
    if (this.data.loading) {
      if (this.data.submitText == '支付成功') {
        this.showToast('支付成功')
      }
      return
    }
    if (this.data.createOrderObj) {
      this.setData({
        submitText: '正在支付...',
        loading: true
      })
      this.shopOrderPay(this.data.createOrderObj)
      return
    }
    if (!this.validateForm()) {
      this.showToast('请将表单填写完整')
      return
    }
    this.setData({
      submitText: '报名中...',
      loading: true
    })
    let { sessions_id, activity_id, activity_type } = this.data.options
    let apply_form = {
      activity_id: activity_id,
      activity_sessions_id: sessions_id,
      sessions_num: this.data.sessionInfo.num,
      field_info: '{}'
    }
    if (activity_type != 2 && this.selectComponent('#baseForm')) {
      let baseFieldList = this.selectComponent('#baseForm').getData()
      let userFieldList = this.getuserFieldData()
      let list = baseFieldList.concat(userFieldList)
      console.log('-----------------', list)
      let field_info = []
      let obj = {}
      list.map(e => {
        obj[e.field_id] = e.value
      })
      field_info.push(obj)
      apply_form.field_info = JSON.stringify(field_info)
    }
    if (activity_type == 2 && this.data.apply_field_info) {
      apply_form.field_info = this.data.apply_field_info
    }
    let input_invite_code = getApp().globalData.input_invite_code
    if (input_invite_code) {
      apply_form.invite_code = input_invite_code
    }
    try {
      let res = await applyWxActivity(apply_form)
      if (res.code === 200) {
        let obj = []
        res.data.map(e => {
          obj.push(e.applicant_id + ':' + this.data.options.num)
        })
        this.createOrder(obj.join(','))
      } else {
        this.showToast(res.message)
        this.setData({
          submitText: '确认支付',
          loading: false
        })
      }
    } catch (error) {
      this.setData({
        submitText: '确认支付',
        loading: false
      })
      this.showToast(error)
    }
  }),
  backToActivity() {
    let url = '/subPages/activity/detail/index'
    url = url.concat('?activity_id=', this.data.options.activity_id)
    wx.redirectTo({
      url: url
    })
  },
  // 联系客服
  bindcontact(e) {
    console.log(e)
    let errMsg = e.detail.errMsg
    if (errMsg != 'enterContact:ok') {
      wx.showToast({
        title: errMsg,
        icon: 'none'
      })
    }
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  // 活动
  toActivity() {
    let url = '/subPages/activity/detail/index'
    url = url.concat('?activity_id=', this.data.activity_id)
    wx.redirectTo({
      url: url
    })
  },
  toCircle() {
    let url = '/subPages/circle/detail/index'
    url = url.concat('?community_id=', this.data.community_id)
    wx.redirectTo({
      url: url
    })
  },
  onLoad(options) {
    const sessions_id = options.sessions_id
    const num = options.num
    const activity_id = options.activity_id
    const activity_type = options.activity_type
    if (activity_type == 2 && app.globalData.applyFieldInfo) {
      this.setData({
        apply_field_info: app.globalData.applyFieldInfo
      })
    }
    this.setData({
      'options.sessions_id': sessions_id,
      'options.num': num,
      'options.activity_id': activity_id,
      'options.activity_type': activity_type
    })
    this.getDetail(activity_id)
  },
  onHide() {}
})

const config = require('./../../config')
const { getWxCode } = require('./../../apis/login')
const { buttonClicked } = require('./../../utils/buttonClick')
Page({
  data: {
    step: 1,
    loading: false,
    step_info: {
      tip: '正在加载',
      type: 'success'
    },
    icon_list: {
      success: '/assets/images/check_ticket_success.png',
      fail: '/assets/images/check_ticket_fail.png',
      info: '/assets/images/check_ticket_info.png'
    },
    key: ''
  },
  onLoad(options) {
    console.log('options', options)
    if (options.scene) {
      try {
        let scene = decodeURIComponent(options.scene)
        var index = scene.indexOf('=')
        let key = scene.substr(index + 1, scene.length)
        console.log(key)
        this.setData({
          key: key
        })
      } catch (error) {
        this.setData({
          step: 2,
          'step_info.tip': '二维码无效',
          'step_info.type': 'fail'
        })
      }
    } else {
      this.setData({
        step: 2,
        'step_info.tip': '二维码无效',
        'step_info.type': 'fail'
      })
    }
  },
  confirmLogin: buttonClicked(function () {
    if (this.data.loading) {
      return
    }
    this.setData({ loading: true })
    wx.showLoading({
      title: '授权中'
    })
    getWxCode()
      .then(res => {
        if (res.code) {
          this.loginMethod({ key: this.data.key, code: res.code })
        } else {
          this.showToast('微信获取code失败,请重试')
        }
      })
      .catch(error => {})
  }),
  cancelLogin: buttonClicked(function () {
    if (this.data.loading) {
      return
    }
    this.setData({ loading: true })
    this.loginMethod({ key: this.data.key, code: '' })
  }),
  confirm() {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  cancel() {},
  miniLoginByKey(data) {
    let _this = this
    let url = '/activityPlatform/wxMember/miniLoginByKey'
    return new Promise((resolve, reject) => {
      wx.request({
        url: config.baseUrl + url,
        data,
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded;charset=utf-8',
          Origin: config.baseUrl.split('://')[1]
        },
        fail(res) {
          reject(res.data)
        },
        success: res => {
          resolve(res.data)
        },
        complete: () => {
          _this.setData({ loading: false })
          wx.hideLoading()
        }
      })
    })
  },
  loginMethod(obj) {
    obj = Object.assign(obj, { company_id: config.company_id })
    this.miniLoginByKey(obj)
      .then(res => {
        let type = ''
        let tip = ''
        if (res.code !== 200) {
          tip = res.message
          type = 'fail'
          this.showToast(res.message)
          this.setData({
            step: 2,
            'step_info.type': type,
            'step_info.tip': tip
          })
        } else {
          if (res.data.status == 1) {
            tip = '授权登录成功'
            type = 'success'
          } else if (res.data.status == 2) {
            tip = '登录码已过期！'
            type = 'info'
          } else if (res.data.status == 3) {
            tip = '取消登录成功！'
            type = 'info'
          }
          this.setData({
            step: 2,
            'step_info.type': type,
            'step_info.tip': tip
          })
        }
      })
      .catch(error => {
        this.showToast(error.message)
      })
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  }
})

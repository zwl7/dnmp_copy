const { Authenticate } = require('./../../../apis/login')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    name: '',
    credentials_number: '',
    loading: false
  },
  onLoad(options) {},
  handleConfirm() {
    if (!this.validateValue()) {
      return
    }
    if (this.data.loading) {
      return
    }
    let obj = {
      name: this.data.name,
      credentials_number: this.data.credentials_number
    }
    Authenticate(obj)
      .then(res => {
        if (res.code === 200) {
          app.globalData.userInfo.is_authenticate = 1
          wx.showToast({
            title: '认证成功',
            icon: 'none'
          })
          let shareActivityId = app.globalData.shareActivityId
          if (shareActivityId) {
            let url = '/subPages/activity/detail/index'
            url = url.concat('?activity_id=', shareActivityId)
            wx.redirectTo({
              url: url
            })
            app.globalData.shareActivityId = ''
          } else {
            wx.navigateBack()
          }
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        this.setData({
          loading: false
        })
      })
      .catch(err => {
        this.setData({
          loading: false
        })
      })
  },
  inputValue(event) {
    let { type } = event.currentTarget.dataset
    this.data[type] = event.detail
  },
  validateValue() {
    if (!String(this.data.name).trim()) {
      wx.showToast({
        title: '请填入姓名',
        icon: 'none'
      })
      return false
    }

    if (!String(this.data.credentials_number).trim()) {
      wx.showToast({
        title: '请填入身份证号',
        icon: 'none'
      })
      return false
    }
    return true
  }
})

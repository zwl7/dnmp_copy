const buttonClick = require('./../../../utils/buttonClick')
const app = getApp()

Page({
  data: {
    token: '',
    is_authenticate: 0 //是否认证 0 未认证  1 审核中  2 已认证
  },
  onLoad(options) {
    this.setData({
      is_authenticate: app.globalData.userInfo.is_authenticate
    })
    this.setData({
      token: app.globalData.token || 123
    })
  },
  //编辑个人信息
  toNextEditPersonal: buttonClick.buttonClicked(function () {
    this.location('/subPages/system/editPersonal/editPersonal')
  }, 2000),
  // 更改背景
  toNextCover() {
    wx.showToast({
      title: '更改背景'
    })
  },
  // 实名认证
  confimlDlPops() {
    let { is_authenticate } = this.data
    if (is_authenticate === -1) {
      wx.navigateTo({
        url: '/subPages/system/login/login?need_auth=1&page=mine'
      })
      return
    }
    if (is_authenticate === 0) {
      wx.navigateTo({
        url: '/subPages/system/Authentication/index'
      })
      return
    }
  },
  // 紧急联系人
  toNextContacts: buttonClick.buttonClicked(function () {
    this.location('/subPages/system/contacts/contacts')
  }, 2000),
  // 我要吐槽
  toNextTsuk: buttonClick.buttonClicked(function () {
    this.location('/subPages/system/tsukkomi/tsukkomi')
  }, 2000),
  // 鼓励我们
  priseUs() {
    wx.showToast({
      title: '鼓励我们'
    })
  },
  // 用户协议
  toAgreement: buttonClick.buttonClicked(function () {
    wx.navigateTo({
      url: '/subPages/system/agreement/agreement'
    })
  }, 2000),
  // 用户协议
  toPrivacy: buttonClick.buttonClicked(function () {
    wx.navigateTo({
      url: '/subPages/system/privacy/privacy'
    })
  }, 2000),
  // 皮卡宇宙公约
  toPact: buttonClick.buttonClicked(function () {
    wx.navigateTo({
      url: '/subPages/system/pact/pact'
    })
  }, 2000),
  // 关于我们
  toAboutUs: buttonClick.buttonClicked(function () {
    this.location('/subPages/system/aboutUs/aboutUs')
  }, 2000),
  // 实名跳转
  location(url) {
    let { token } = this.data
    if (token) {
      wx.navigateTo({
        url: url
      })
    } else {
      wx.showToast({
        title: '需要实名操作'
      })
    }
  }
})

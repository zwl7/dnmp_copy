const { uploadFile } = require('./../../../utils/util')
const { updateUserInfo, miniAuthLogin } = require('./../../../apis/login')
const getRandomName = require('./../../../utils/randomName')
const { judgeInputLength } = require('./../../../utils/util')
const { getToken, setToken, clearToken } = require('./../../../utils/storage')
const app = getApp()
Page({
  data: {
    myProperty: {
      // transparent
      backgroundColor: 'transparent',
      isHome: false,
      name: '注册',
      titleStyle: 'color:#fff;',
      isNeedBack: true
    },
    avatar: '/assets/images/avatar.png',
    name: '',
    sex: '',
    autoFocus: false,
    loading: false,
    need_auth: 0, // 1   需要跳转到实名页面
    code: '', //换去手机号code
    page: '',
    pageMap: {
      index: '/pages/index/index',
      mine: '/pages/mine/mine',
      entrance: '/accountPages/entrance/entrance'
    },
    showchangeImgTypePopup: false
  },

  onLoad(options) {
    let { need_auth, page, code } = options
    let nick_name = getRandomName()
    let { avatar_url } = this.getRandomAvatar()
    this.setData({
      name: nick_name,
      need_auth: need_auth,
      page: page,
      code: code,
      avatar: avatar_url
    })
  },
  onShow() {
    let { UserAvatar } = app.globalData
    if (UserAvatar) {
      this.setData({
        avatar: UserAvatar
      })
      app.globalData.UserAvatar = ''
    }
  },
  showAvatarDialog() {
    this.setData({
      showchangeImgTypePopup: true
    })
  },
  changeSex(event) {
    let { sex } = event.currentTarget.dataset
    this.setData({
      sex: sex
    })
  },
  onChooseAvatar(e) {
    const { avatarUrl } = e.detail
    let url = '/subPages/picture/picture?'.concat('imgSrc=', avatarUrl).concat('&&size_x=', 250).concat('&&size_y=', 250).concat('&&globalImg=', 'UserAvatar')
    wx.navigateTo({
      url: url
    })
  },
  handleFocus() {
    this.setData({
      autoFocus: !this.data.autoFocus
    })
  },
  onNicknameChange: function (e) {
    let value = judgeInputLength(e.detail.value, 12, '昵称')
    this.setData({
      name: value
    })
  },
  handleRandomName() {
    let nick_name = getRandomName()
    this.setData({
      name: nick_name
    })
  },
  async handleConfirm() {
    try {
      if (this.data.loading) {
        this.toast('请勿重复点击提交')
        return
      }
      // if (!this.data.avatar) {
      //   this.toast('请设置你的头像')
      //   this.setData({ loading: false })
      //   return
      // }
      if (!this.data.name) {
        this.toast('请设置你的昵称')
        this.setData({ loading: false })
        return
      }
      if (!this.data.sex) {
        this.toast('请选择你的性别')
        this.setData({ loading: false })
        return
      }
      let obj = {
        nick_name: String(this.data.name).trim(),
        avatar: this.data.avatar,
        sex: this.data.sex,
        code: this.data.code,
        token: app.globalData.userInfo.token
      }
      this.setData({ loading: true })
      let { avatar_list } = this.getRandomAvatar()
      if (obj.avatar && avatar_list.indexOf(obj.avatar) != -1) {
        try {
          let res = await uploadFile(obj.avatar)
          obj.avatar = res.data.imgUrl
        } catch (error) {}
      }

      miniAuthLogin(obj)
        .then(res => {
          this.setData({
            loading: false
          })
          if (res.code === 200) {
            let data = res.data
            if (data.avatar) {
              data.avatar_url = data.avatar
            }
            let userInfo = {
              avatar_url: data.avatar_url,
              first_login: data.first_login,
              name: data.name,
              nick_name: data.nick_name,
              phone: data.phone,
              token: data.token,
              account_id: data.account_id,
              is_authenticate: data.is_authenticate,
              sex: data.sex
            }
            app.setUserInfo(userInfo)
            clearToken().then(res => {
              console.log('demo', res)
            })
            setToken(res.data.token, true)
              .then(c => {
                console.log(c)
              })
              .catch(err => console.log(err))
            this.judgePage()
          } else {
            this.setData({
              loading: false
            })
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          wx.showToast({
            title: err,
            icon: 'none'
          })
          this.setData({
            loading: false
          })
        })
    } catch (error) {
      this.setData({
        loading: false
      })
      this.toast(error)
    }
  },
  toast: function (a) {
    wx.showToast({
      title: a,
      icon: 'none'
    })
  },
  judgePage() {
    if (this.data.need_auth == 1) {
      wx.redirectTo({
        url: '/subPages/system/Authentication/index'
      })
    } else {
      let shareActivityId = app.globalData.shareActivityId
      if (shareActivityId) {
        let url = '/subPages/activity/detail/index'
        url = url.concat('?activity_id=', shareActivityId)
        wx.reLaunch({
          url: url
        })
        app.globalData.shareActivityId = ''
      } else {
        let url = this.data.pageMap[this.data.page] ? this.data.pageMap[this.data.page] : '/pages/index/index'
        wx.reLaunch({
          url: url
        })
      }
    }
  },
  getRandomAvatar() {
    let host = app.globalData.config.host
    let avatar_list = [host + '/avatar.png', host + '/avatar_1.png', host + '/avatar_2.png', host + '/avatar_3.png', host + '/avatar_4.png']
    let index = Math.floor(Math.random() * 5)
    return { avatar_url: avatar_list[index], avatar_list: avatar_list }
  }
})

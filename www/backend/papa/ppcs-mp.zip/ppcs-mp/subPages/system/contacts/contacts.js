const app = getApp()
Page({
  data: {
    avatar: app.globalData.config.host + '/avatar_1.png',
    activity: app.globalData.config.host + '/activity_1.png'
  },
  onLoad(options) {}
})

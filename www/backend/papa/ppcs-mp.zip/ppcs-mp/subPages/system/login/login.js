const { miniAuthLogin, updateUserInfo } = require('./../../../apis/login')
const { uploadFile } = require('./../../../utils/util')
const { getToken, setToken, clearToken } = require('./../../../utils/storage')
const app = getApp()

Page({
  data: {
    login_bg: app.globalData.config.host + '/login_bg.png',
    agreement: false,
    need_auth: 0, // 1   需要跳转到实名页面
    page: '',
    name: '',
    phone: '',
    avatar: '',
    loading: false
  },
  pageMap: {
    index: '/pages/index/index',
    mine: '/pages/mine/mine',
    entrance: '/accountPages/entrance/entrance'
  },
  onLoad(options) {
    let { need_auth, page } = options
    this.setData({
      need_auth: need_auth,
      page: page
    })
  },
  onReady() {},
  onShow() {
    let { UserAvatar } = app.globalData
    if (UserAvatar) {
      this.setData({
        avatar: UserAvatar,
        avatar_show: UserAvatar
      })
      app.globalData.UserAvatar = ''
    }
  },
  bindGetUserInfo() {
    if (!this.data.agreement) {
      wx.showToast({
        title: '请先阅读并同意皮卡宇宙线下活动协议',
        icon: 'none'
      })
    }
  },
  toWalk: function () {
    console.log(this.data.agreement)
    wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  // 获取手机号
  getphonenumber(e) {
    if (e.detail.errMsg == 'getPhoneNumber:ok' && e.detail.code) {
      this.judgePage(e.detail.code)
      // this.setPhone(e.detail.code)
    } else {
      this.showToast('获取手机号失败')
      return
    }
  },
  // 设置手机号
  setPhone(code) {
    let obj = {
      code: code,
      token: app.globalData.userInfo.token
    }
    let _this = this
    miniAuthLogin(obj).then(res => {
      if (res.code === 200) {
        let userInfo = {
          avatar_url: res.data.avatar_url,
          first_login: res.data.first_login,
          name: res.data.name,
          nick_name: res.data.nick_name,
          phone: res.data.phone,
          token: res.data.token,
          account_id: res.data.account_id,
          is_authenticate: res.data.is_authenticate,
          sex: res.data.sex
        }
        app.setUserInfo(userInfo)
        clearToken().then(res => {
          console.log('demo', res)
        })
        setToken(res.data.token, true)
          .then(c => {
            console.log(c)
          })
          .catch(err => console.log(err))
        // this.judgePage()
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  radioChange(e) {
    this.setData({
      agreement: e.detail
    })
  },
  valueInput(event) {
    let value = event.detail.value
    this.setData({
      name: value
    })
  },
  judgePage(code) {
    let url = '/subPages/system/register/register'
    url = url.concat('?need_auth=', this.data.need_auth).concat('&page=', this.data.page).concat('&code=', code)
    wx.redirectTo({
      url: url
    })
    return
    if (this.data.need_auth == 1) {
      wx.redirectTo({
        url: '/subPages/system/Authentication/index'
      })
    } else {
      console.log(this.pageMap)
      let url = this.pageMap[this.data.page] ? this.pageMap[this.data.page] : '/pages/index/index'
      wx.reLaunch({
        url: url
      })
    }
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  toAgreement(event) {
    let { type } = event.currentTarget.dataset
    if (type == 1) {
      wx.navigateTo({
        url: '/subPages/system/agreement/agreement'
      })
    } else if (type == 2) {
      wx.navigateTo({
        url: '/subPages/system/privacy/privacy'
      })
    }
  }
})

const { uploadFile, judgeInputLength } = require('./../../../utils/util')
const { buttonClicked } = require('./../../../utils/buttonClick')
const { updateUserInfo, getUserInfo } = require('./../../../apis/login')
const app = getApp()
Page({
  data: {
    avatar_show: 'https://cdn-static.papa.com.cn/ppcs_mp/avatar.png',
    avatar: '',
    nick_name: '',
    signature: '',
    isIos: app.globalData.isIos,
    sex: '',
    sex_str: '',
    age: '',
    phone: '',
    sexList: ['男', '女'],
    loading: false,
    showchangeImgTypePopup: false
  },
  onLoad(options) {
    this.setData({
      phone: app.globalData.userInfo.phone
    })
    this.getUserInfo()
  },
  onShow() {
    let { UserAvatar } = app.globalData
    if (UserAvatar) {
      this.setData({
        avatar: UserAvatar,
        avatar_show: UserAvatar
      })
      app.globalData.UserAvatar = ''
    }
  },
  showAvatarDialog() {
    this.setData({
      showchangeImgTypePopup: true
    })
  },
  onChooseAvatar(e) {
    const { avatarUrl } = e.detail
    console.log(e)
    console.log(avatarUrl)
    this.setData({
      avatar: avatarUrl,
      avatar_show: avatarUrl
    })
    // let url = '/subPages/picture/picture?'.concat('imgSrc=', avatarUrl).concat('&&size_x=', 250).concat('&&size_y=', 250).concat('&&globalImg=', 'UserAvatar')
    // wx.navigateTo({
    //   url: url
    // })
  },
  bindPickerChange(e) {
    let value = Number(e.detail.value)
    let sex = value + 1
    let sex_str = this.data.sexList[value]
    this.setData({
      sex: sex,
      sex_str: sex_str
    })
  },
  valueInput(event) {
    let { type } = event.currentTarget.dataset
    let value = event.detail

    if (type === 'nick_name') {
      value = judgeInputLength(value, 10, '昵称')
    }
    if (type === 'signature') {
      value = judgeInputLength(value, 30, '个性签名')
    }
    if (type === 'age') {
      value = judgeInputLength(value, 3, '年龄')
    }
    this.data[type] = value
    this.setData({
      [`${type}`]: this.data[type]
    })
  },
  handleConfirm: buttonClicked(async function () {
    if (!this.validateForm()) {
      this.showToast('请填入信息')
      return
    } else {
      if (this.data.loading) {
        return
      }
      this.setData({
        loading: true
      })
      let obj = await this.getForm()
      updateUserInfo(obj).then(res => {
        if (res.code === 200) {
          let data = res.data
          if (data.avatar) {
            data.avatar_url = data.avatar
          }
          app.setUserInfo(data)
          wx.showToast({
            title: '提交成功'
          })
          app.globalData.RefreshMinePage = true
          setTimeout(() => {
            wx.navigateBack({
              delta: 2
            })
          }, 1500)
        } else {
          this.showToast(res.message)
        }
        this.setData({
          loading: false
        })
      })
    }
  }),
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  validateForm() {
    let obj = {
      nick_name: String(this.data.nick_name).trim(),
      signature: String(this.data.signature).trim(),
      sex: this.data.sex,
      age: this.data.age,
      avatar: this.data.avatar
    }
    if (!obj.nick_name && !obj.sex && !obj.age && !obj.avatar && !obj.signature) {
      return false
    } else {
      return true
    }
  },
  getForm() {
    return new Promise(async resolve => {
      let obj = {
        nick_name: String(this.data.nick_name).trim(),
        signature: String(this.data.signature).trim(),
        sex: this.data.sex,
        age: this.data.age,
        avatar: this.data.avatar
      }
      if (obj.avatar) {
        let res = await uploadFile(obj.avatar)
        obj.avatar = res.data.imgUrl
      }
      !obj.nick_name && delete obj.nick_name
      !obj.signature && delete obj.signature
      !obj.sex && delete obj.sex
      !obj.age && delete obj.age
      !obj.avatar && delete obj.avatar
      resolve(obj)
    })
  },
  getUserInfo() {
    getUserInfo({}).then(res => {
      if (res.code === 200) {
        this.setData({
          avatar_show: res.data.avatar,
          nick_name: res.data.nick_name,
          signature: res.data.signature,
          sex_str: res.data.sex == 1 ? '男' : '女',
          age: res.data.age,
          phone: res.data.phone
        })
        let obj = {
          avatar_url: res.data.avatar_url,
          nick_name: res.data.nick_name,
          signature: res.data.signature,
          sex: res.data.sex,
          phone: res.data.phone
        }
        app.setUserInfo(obj)
      } else {
        this.showToast(res.message)
      }
    })
  }
})

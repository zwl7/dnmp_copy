const { getWxMemberNoticeList, updateWxMemberNotice } = require('./../../../apis/common')
const { formatTimeBase } = require('./../../../utils/date')
const app = getApp()

Page({
  data: {
    page: 1,
    size: 15,
    loading: false,
    noticeList: [],
    finished: false,
    count: 0
  },
  onLoad(options) {
    this.resetData()
  },
  onShow() {},
  resetData() {
    this.setData({
      page: 1,
      size: 10,
      loading: false,
      noticeList: [],
      finished: false,
      count: 0
    })
    this.getWxMemberNoticeList()
  },
  getWxMemberNoticeList() {
    let obj = {
      page: this.data.page,
      size: this.data.size,
      type: 1,
      no_location: 1
    }
    this.setData({
      loading: true
    })
    getWxMemberNoticeList(obj)
      .then(res => {
        this.setData({
          loading: false
        })
        if (res.code === 200) {
          this.data.noticeList = this.data.noticeList.concat(res.data.list)
          this.data.noticeList.map((e, index) => {
            e.date = formatTimeBase(e.c_time, '{y}-{m}-{d}')
            e.time = formatTimeBase(e.c_time, '{h}:{i}:{s}')
          })
          this.data.noticeList.map((e, index) => {
            let pre = this.data.noticeList[index - 1]
            if (pre && pre.date == e.date) {
              e.show_date = false
            } else {
              e.show_date = true
            }
          })
          this.setData({
            noticeList: this.data.noticeList,
            count: res.data.count
          })
          if (res.data.list.length < 10) {
            this.setData({ finished: true })
            return
          }
        } else {
          this.showToast(res.message)
        }
      })
      .catch(err => {
        this.setData({
          loading: false
        })
        this.showToast(err)
      })
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  handleView(event) {
    let { link, id, status, index } = event.currentTarget.dataset
    if (status === 0) {
      this.updateWxMemberNotice(id, index)
    }
    wx.navigateTo({
      url: link
    })
  },
  // 更新状态
  updateWxMemberNotice(member_notice_id, index) {
    updateWxMemberNotice({ member_notice_id: member_notice_id, status: 1 }).then(res => {
      if (res.code === 200) {
        this.data.noticeList[index].status = 1
        this.setData({
          noticeList: this.data.noticeList
        })
      } else {
        wx.showToast({
          title: res.data,
          icon: 'none'
        })
      }
    })
  },
  onPullDownRefresh() {
    this.resetData()
    wx.stopPullDownRefresh()
  },
  onReachBottom() {
    if (!this.data.finished) {
      this.setData({
        page: this.data.page + 1
      })
      this.getWxMemberNoticeList()
    }
  }
})

const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos
  },
  onLoad(options) {},
  bindcontact(e) {
    let errMsg = e.detail.errMsg
    if (errMsg != 'enterContact:ok') {
      wx.showToast({
        title: errMsg,
        icon: 'none'
      })
    }
  },
  handleClick() {
    let url = 'https://mp.weixin.qq.com/s/U_Xg6qpaVv9Ng0Lk80GlHg'
    url = encodeURIComponent(url)
    wx.navigateTo({
      url: '/subPages/webview/index?url=' + url
    })
  },
  onPullDownRefresh() {
    wx.stopPullDownRefresh()
  }
})

const app = getApp()
Page({
  data: {
    upload_icon: '/assets/image/upload_image.png',
    imgArr: [],
    text: '',
    text_num: 0
  },
  delImg(event) {
    var index = event.currentTarget.dataset.index
    let imgArr = this.data.imgArr
    imgArr.splice(index, 1)
    this.setData({
      imgArr: imgArr
    })
  },
  addImg() {
    if (!(this.data.imgArr.length >= 3)) {
      let that = this
      let count = 3 - this.data.imgArr.length
      wx.chooseMedia({
        count: count,
        mediaType: ['image'],
        sourceType: ['album'],
        success(res) {
          let { tempFiles } = res
          let imgArr = that.data.imgArr
          tempFiles.map(e => {
            imgArr.push(e.tempFilePath)
          })
          that.setData({
            imgArr: imgArr
          })
        }
      })
    }
  },
  inputValue(t) {
    this.setData({
      text: t.detail.value,
      text_num: t.detail.value.length
    })
  },
  onConfirm() {
    console.log('发布')
  }
})

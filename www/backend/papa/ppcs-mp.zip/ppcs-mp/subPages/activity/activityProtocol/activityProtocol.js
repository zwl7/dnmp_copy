Page({
  data: {
    is_event: false
  },
  onLoad(options) {
    let { is_event } = options
    if (is_event == 1) {
      wx.setNavigationBarTitle({
        title: '赛事协议'
      })
      this.setData({
        is_event: true
      })
    } else {
      this.setData({
        is_event: false
      })
    }
  }
})

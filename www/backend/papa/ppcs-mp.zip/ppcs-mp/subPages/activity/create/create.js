const { getWxResourceTypeAll } = require('./../../../apis/common')
const { getActivityDetail } = require('../../../apis/activity')
const { clearActivityContact, clearTicketRegister, getCreateActivityStorage, setCreateActivityStorage, clearCreateActivityStorage, clearRefundRuleStorage } = require('./../../../utils/storage')
const app = getApp()
Page({
  data: {
    activity: app.globalData.config.host + '/activity_1.png',
    upload_icon: './../../../assets/image/upload_image.png',
    step: 1, //步骤  1  基础信息  2 票种信息  3预览,
    is_event: false, //是否是赛事
    previewInfo: {
      images: '',
      name: '',
      start_time: '',
      end_time: '',
      people_num: '',
      city_name: '',
      address: '',
      des: '',
      type: '',
      is_free: '',
      circle: '',
      contact_phone: ''
    },
    // 活动基础详情
    activityDetailInfo: {
      sessions: []
    },
    activityTime: {
      start: 0,
      end: 0,
      people_num: 0,
      is_free: 0
    },
    loading: false,
    activityOptions: [], //活动类型
    communityInfo: {
      community_id: '',
      community_name: ''
    },
    activity_id: '',
    handleType: 'add', //add  edit
    haveStorage: false, //是否有缓存
    haveStorageTip: '' //使用缓存提示
  },
  onLoad(options) {
    let { community_id, community_name, op, activity_id, activity_type } = options
    if (activity_type == 2) {
      this.setData({
        is_event: true
      })
    }
    // 创建
    if (!community_id && !op) {
      wx.showToast({
        title: '请先选择星球创建活动~',
        icon: 'none',
        duration: 2000
      })
      setTimeout(() => {
        wx.switchTab({
          url: '/pages/index/index'
        })
      }, 2000)
    }
    if (op === 'add' && community_id) {
      this.setData({
        'communityInfo.community_id': community_id,
        'communityInfo.community_name': community_name
      })
      this.judgeHaveCreateStorage()
    }

    // 编辑
    if (activity_id && op === 'edit') {
      this.setData({
        activity_id: activity_id,
        handleType: 'edit'
      })
      this.getActivityDetail()
    }
    this.setBarTitle(activity_id, op, activity_type)
    this.getWxResourceTypeAll()

    if (options.re_create && options.activity_id) {
      // 用户再次创办活动
      this.op = 're_create'
      this.community_id = community_id
      this.reCreate(options.activity_id)
    }
  },
  setBarTitle(activity_id, op, activity_type) {
    let type = '添加'
    let title = '活动'
    if (activity_id && op == 'edit') {
      type = '编辑'
    }
    if (activity_type == 2) {
      title = '赛事'
    }
    wx.setNavigationBarTitle({
      title: `${type}${title}`
    })
  },
  nextStep(e) {
    let { current, type } = e.detail
    if (type == 'next') {
      this.setData({
        step: current + 1
      })
    } else if (type == 'pre') {
      this.setData({
        step: current - 1
      })
    }
  },
  setActivityDesc(activityDes, activityImgList) {
    if (this.data.step === 1) {
      let baseInfo = this.selectComponent('#baseInfo')
      baseInfo.setActivityDesc(activityDes, activityImgList)
      baseInfo.setBaseInfoStorage()
    }
    if (this.data.step === 2) {
      this.selectComponent('#ticket').setActivityDesc(activityDes, activityImgList)
    }
  },
  setContacts(contactName, contactPhone, wxNumber, contacts) {
    let baseInfo = this.selectComponent('#baseInfo')
    baseInfo.setContacts(contactName, contactPhone, wxNumber, contacts)
    baseInfo.setBaseInfoStorage()
  },
  setRefundRule(list) {
    let baseInfo = this.selectComponent('#baseInfo')
    baseInfo.setRefundRule(list)
  },
  setTicketInfo(index, ticketInfo) {
    try {
      let ticket = this.selectComponent('#ticket')
      ticket.setTicketInfo(index, ticketInfo)
    } catch (error) {
      console.log(error)
    }
  },
  reCreate(activityId) {
    // 获取活动详情
    getActivityDetail(activityId).then(res => {
      const activity = res.data
      app.globalData.show_apply_member = activity.show_apply_member = activity.show_apply_member == '2' ? '2' : 1
      app.globalData.ticket_warning = activity.ticket_warning = activity.ticket_warning == '2' ? '2' : 1
      app.globalData.buy_limit_type = activity.buy_limit_type = activity.buy_limit_type ? activity.buy_limit_type : 0

      let is_event = false
      if (activity.activity_type === 2) {
        is_event = true
        wx.setNavigationBarTitle({
          title: '添加赛事'
        })
      }
      if (activity.sessions.length > 0) {
        activity.sessions.map(e => {
          delete e.activity_sessions_id
        })
      }
      this.setData({
        is_event: is_event,
        previewInfo: activity,
        activityDetailInfo: activity,
        communityInfo: {
          community_id: activity.community_id,
          community_name: activity.community.name
        }
      })
    })
  },
  // 获取活动时间
  getTimes(event) {
    let detail = event.detail
    this.setData({
      'activityTime.start': detail.start_time,
      'activityTime.end': detail.end_time,
      'activityTime.people_num': detail.people_num,
      'activityTime.is_free': detail.is_free
    })
    app.globalData.currentActivityInfo = this.data.activityTime
  },
  getPreviewInfo(event) {
    let detail = event.detail
    console.log('====================info', detail)
    this.setData({
      previewInfo: detail
    })
  },
  // 发布活动
  async handleConfirm() {
    let handleType = this.data.handleType
    let message = handleType === 'eidt' ? '正在更新' : '正在发布'
    if (this.data.loading) {
      this.showToast(message)
      return
    }
    wx.showLoading({
      title: message,
      mask: true
    })
    var baseInfo = this.selectComponent('#baseInfo')
    var ticket = this.selectComponent('#ticket')
    let baseInfo_flag = true
    let ticket_flag = true
    this.setData({ loading: true })
    try {
      let baseRes = await baseInfo.saveBaseInfo()
      let activity_id = ''
      if (baseRes.code === 200) {
        activity_id = baseRes.data.activity_id
        let ticketRes = await Promise.all(ticket.saveTicket(activity_id))
        console.log('=============发布活动2', ticketRes)
        ticketRes.map(c => {
          if (c.code !== 200) {
            ticket_flag = false
            this.showToast(c.message)
          }
        })

        if (ticket_flag) {
          let message = this.data.handleType === 'eidt' ? '更新成功' : '发布成功'
          wx.showToast({
            title: message
          })
          try {
            clearActivityContact(false)
            clearTicketRegister(false)
            clearRefundRuleStorage(false)
          } catch (error) {
            console.log('=====删除票种联系人缓存', error)
          }
          this.setData({
            loading: false
          })
        } else {
          this.setData({
            loading: false
          })
        }
        if (this.data.handleType === 'edit') {
          ticket.handleDeleteSessionMethod()
        }
      } else {
        baseInfo_flag = false
        this.showToast(baseRes.message)
        this.setData({
          loading: false
        })
      }
      if (!ticket_flag) {
      }
      app.globalData.RefreshMinePage = true
      app.globalData.RefreshIndexPage = true
      app.globalData.RefreshFindPage = true

      if (baseInfo_flag && ticket_flag) {
        console.log('发布成功')
        clearCreateActivityStorage()
        let url = '/subPages/activity/detail/index'
        url = url.concat('?activity_id=', activity_id)
        wx.redirectTo({
          url: url
        })
        wx.hideLoading()
      }
    } catch (error) {
      console.log('=============发布活动', error)
      this.setData({
        loading: false
      })
      this.showToast(error.message)
      wx.hideLoading()
    }
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  getWxResourceTypeAll() {
    let obj = {
      type_id: 1
    }
    getWxResourceTypeAll(obj).then(res => {
      if (res.code === 200) {
        let activityOptions = []
        res.data.map(e => {
          activityOptions.push({
            name: e.name,
            id: e.resource_type_id
          })
        })
        this.setData({
          activityOptions: activityOptions
        })
      } else {
        this.showToast(res.message)
      }
    })
  },
  // 获取活动详情
  getActivityDetail() {
    getActivityDetail(this.data.activity_id).then(res => {
      if (res.code === 200) {
        const activity = res.data
        app.globalData.show_apply_member = activity.show_apply_member = activity.show_apply_member == '2' ? '2' : 1
        app.globalData.ticket_warning = activity.ticket_warning = activity.ticket_warning == '2' ? '2' : 1
        app.globalData.buy_limit_type = activity.buy_limit_type = activity.buy_limit_type ? activity.buy_limit_type : 0
        let is_event = false
        if (activity.activity_type === 2) {
          wx.setNavigationBarTitle({
            title: '编辑赛事'
          })
          is_event = true
        }
        this.setData({
          is_event: is_event,
          activityDetailInfo: activity,
          communityInfo: {
            community_id: activity.community_id,
            community_name: activity.community.name
          }
        })
      }
    })
  },
  // 判断当前是否有活动缓存
  judgeHaveCreateStorage() {
    getCreateActivityStorage().then(res => {
      if (res && res.activity) {
        let community_name = res.activity.community ? res.activity.community.name : ''
        let message = '是否使用上次编辑保存的内容?'
        if (community_name) {
          message = `是否使用上次编辑保存【${community_name}】的内容?`
        }
        this.setData({
          haveStorage: true,
          haveStorageTip: message
        })
        this.selectComponent('#getCreateStorage').showDialog()
      }
    })
  },
  // 解析创建时候的活动缓存
  parseCreateActivityStorage() {
    getCreateActivityStorage().then(res => {
      if (res && res.activity) {
        let activity = res.activity
        activity.sessions = []
        let session = res.session
        if (session) {
          activity.sessions = session
        }
        if (activity.sessions.length > 0) {
          activity.sessions.map(e => {
            delete e.activity_sessions_id
          })
        }
        app.globalData.show_apply_member = activity.show_apply_member = activity.show_apply_member == '2' ? '2' : 1
        app.globalData.ticket_warning = activity.ticket_warning = activity.ticket_warning == '2' ? '2' : 1
        app.globalData.buy_limit_type = activity.buy_limit_type = activity.buy_limit_type ? activity.buy_limit_type : 0
        this.setData({
          previewInfo: activity,
          activityDetailInfo: activity,
          communityInfo: {
            community_id: activity.community_id,
            community_name: activity.community.name
          }
        })
      }
    })
  },
  // 子组件缓存事件
  handleSonSetStorage() {
    let baseInfo = this.selectComponent('#baseInfo')
    let ticket = this.selectComponent('#ticket')
    if (baseInfo) {
      baseInfo.setBaseInfoStorage()
    }
    if (ticket) {
      setTimeout(() => {
        ticket.setTicketStorage()
      }, 1000)
    }
  },
  pageScrollToBottom() {
    try {
      wx.createSelectorQuery()
        .select('#bodyview')
        .boundingClientRect(function (rect) {
          wx.pageScrollTo({
            scrollTop: rect.height
          })
        })
        .exec()
    } catch (error) {}
  },
  // 取消
  cancelStorage() {
    clearCreateActivityStorage()
  },
  onUnload() {
    console.log('页面销毁')
  },
  onHide() {
    console.log('页面隐藏')
  }
})

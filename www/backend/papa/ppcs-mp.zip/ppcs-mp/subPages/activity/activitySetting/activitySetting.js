let app = getApp()
Page({
  data: {
    buy_limit_type_radio: '0',
    buy_limit_type: 0,
    show_apply_member: '1', //是否展示报名人员
    ticket_warning: '1' //票量警示
  },
  onLoad() {
    console.log(String(app.globalData.show_apply_member))
    this.setData({
      show_apply_member: String(app.globalData.show_apply_member),
      ticket_warning: String(app.globalData.ticket_warning),
      buy_limit_type: app.globalData.buy_limit_type,
      buy_limit_type_radio: app.globalData.buy_limit_type > 0 ? '1' : '0'
    })
    app.globalData.refreshActivitySetting = true
  },
  onChangeLimitBuyType(e) {
    if (e.detail == '0') {
      this.setData({
        buy_limit_type: 0
      })
      app.globalData.buy_limit_type = 0
    }
    this.setData({
      buy_limit_type_radio: e.detail
    })
  },

  limitBuyInput(e) {
    let value = e.detail.value
    this.setData({
      buy_limit_type: value
    })
    app.globalData.buy_limit_type = value
  },
  onChangeApplyPeople(e) {
    this.setData({
      show_apply_member: e.detail
    })
    app.globalData.show_apply_member = e.detail
  },
  onChangeTicketWarning(e) {
    this.setData({
      ticket_warning: e.detail
    })
    app.globalData.ticket_warning = e.detail
  }
})

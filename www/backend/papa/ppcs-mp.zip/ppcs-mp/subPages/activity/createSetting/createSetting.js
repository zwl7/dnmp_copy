const buttonClick = require('./../../../utils/buttonClick')
const { addWxFields } = require('./../../../apis/order')
const { setTicketRegister, getTicketRegister, clearTicketRegister } = require('./../../../utils/storage')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    baseInfoOption: [
      {
        title: '基础信息',
        project: [
          {
            label: '称呼',
            status: false,
            field_id: 1
          },
          {
            label: '手机号',
            status: false,
            field_id: 2
          }
        ]
      },
      {
        title: '个人信息',
        project: [
          {
            label: '真实姓名',
            status: false,
            field_id: 3
          },
          {
            label: '身份证',
            status: false,
            field_id: 4
          },
          {
            label: '性别',
            status: false,
            field_id: 5
          },
          {
            label: '出生日期',
            status: false,
            field_id: 6
          },
          {
            label: '年龄',
            status: false,
            field_id: 7
          }
        ]
      }
    ],
    popupShow: false,
    actions: [
      {
        name: '填写项',
        type: 1
      },
      {
        name: '单选',
        type: 4
      },
      {
        name: '多选',
        type: 5
      },
      {
        name: '图片',
        type: 8
      }
    ],
    questions: [],
    notify: null,
    loading: false,
    ticketIndex: null
  },
  onLoad(options) {
    let notify = this.selectComponent('#van-notify')
    this.setData({
      notify: notify
    })

    if (options.index) {
      this.setData({
        ticketIndex: String(options.index)
      })
    }

    console.log('ticketIndex', this.data.ticketIndex)
  },
  onShow() {
    this.parseFormStorage()
  },

  showAction: function () {
    this.setData({
      popupShow: true
    })
  },
  closeAction: function () {
    this.setData({
      popupShow: false
    })
  },
  addQuestion: function (e) {
    let { type } = e.detail
    this.data.questions.push({
      type: type,
      title: '',
      option: []
    })
    this.setData({
      questions: this.data.questions
    })
    setTimeout(() => {
      this.pageScrollToBottom()
    }, 50)
    this.closeAction()
  },
  pageScrollToBottom() {
    try {
      wx.createSelectorQuery()
        .select('#bodyview')
        .boundingClientRect(function (rect) {
          wx.pageScrollTo({
            scrollTop: rect.height
          })
        })
        .exec()
    } catch (error) {}
  },
  // 删除问题
  deleteQuestion(event) {
    this.setData({
      questions: this.data.questions.filter(function (t, c_index) {
        return c_index != event.detail
      })
    })
  },
  // 删除选项
  deleteQuestionList() {},
  valueChange(event) {
    var index = event.detail.index
    var title = event.detail.title
    var option = event.detail.option
    this.setData({
      [`questions[${index}].title`]: title,
      [`questions[${index}].option`]: option
    })
  },
  switchChange(event) {
    let { cindex, index } = event.currentTarget.dataset
    this.data.baseInfoOption[index]['project'][cindex]['status'] = event.detail.value
    this.setData({
      baseInfoOption: this.data.baseInfoOption
    })
  },
  handleConfirm: buttonClick.buttonClicked(async function () {
    let ids = []
    this.data.baseInfoOption.map(e => {
      if (e.project.length) {
        e.project.map(c => {
          c.status && ids.push({ id: c.field_id, m: 0 })
        })
      }
    })
    if (this.data.questions.length === 0) {
      this.setPageField(ids)
      this.saveFormStorage(ids, [])
      wx.navigateBack()
    } else {
      if (this.data.loading) {
        console.log('正在执行')
        return
      }
      this.setData({
        loading: true
      })
      let new_ids = await this.addWxFields(ids)
      ids = ids.concat(new_ids)
      this.setPageField(ids)
      wx.navigateBack()
    }
  }),
  setPageField(ids) {
    var pages = getCurrentPages()
    pages[pages.length - 2].saveTicketFieldInfo(ids)
  },
  addWxFields(ids) {
    return new Promise((resolve, reject) => {
      let list = []
      this.data.questions.map(e => {
        let obj = {
          field_name: e.title,
          field_type: e.type,
          field_select_type: 0,
          field_select_value: ''
        }
        if (e.type == 4 || e.type == 5) {
          obj['field_select_type'] = 1
          let field_select_value = []
          e.option.map((c, index) => {
            field_select_value.push({
              name: c.content,
              value: index + 1
            })
          })
          obj['field_select_value'] = JSON.stringify(field_select_value)
        }
        list.push(obj)
      })
      let obj = {
        list: JSON.stringify(list)
      }
      this.saveFormStorage(ids, list)
      addWxFields(obj)
        .then(res => {
          this.setData({
            loading: false
          })
          if (res.code === 200) {
            let list = []
            res.data.map(e => {
              list.push({ id: e, m: 0 })
            })
            resolve(list)
          } else {
            reject(res)
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(error => {
          reject(error)
        })
    })
  },
  // 缓存表单
  saveFormStorage(base, questions) {
    let { ticketIndex } = this.data
    getTicketRegister().then(res => {
      try {
        if (!res) {
          res = {}
        }
        res[ticketIndex] = {
          base: base ? base : [],
          questions: questions ? questions : []
        }
        setTicketRegister(res)
      } catch (error) {}
    })
  },
  // 解析表单缓存
  parseFormStorage() {
    let { ticketIndex } = this.data
    console.log('-----------------parseFormStorage', ticketIndex)
    getTicketRegister().then(res => {
      try {
        let obj = res[ticketIndex]
        this.settingBase(obj.base)
        this.settingQuestions(obj.questions)
      } catch (error) {}
    })
  },
  settingBase(base) {
    const ids = {}
    base.map(item => {
      ids[item.id] = item.m
    })
    let baseInfoOption = this.data.baseInfoOption
    baseInfoOption.map(item => {
      item.project.map(p => {
        if (ids[p.field_id] >= 0) {
          p.status = true
        }
      })
    })
    this.setData({
      baseInfoOption
    })
  },
  settingQuestions(questions) {
    let list = []
    questions.map(e => {
      let obj = {
        title: e.field_name,
        type: e.field_type,
        option: ''
      }
      if (e.field_type == 4 || e.field_type == 5) {
        let field_select_value = JSON.parse(e.field_select_value)
        let option = []
        field_select_value.map(e => {
          option.push({
            content: e.name,
            value: e.value,
            maxLength: 600
          })
        })
        obj.option = option
      }
      list.push(obj)
    })
    this.setData({
      questions: list
    })
  }
})

const { setRefundRuleStorage, getRefundRuleStorage } = require('./../../../utils/storage')
const app = getApp()
Page({
  data: { isIos: app.globalData.isIos, value: 24, radio: '3' },
  onLoad(options) {
    this.setData({
      isIos: app.globalData.isIos
    })
    getRefundRuleStorage().then(res => {
      if (res && res.length > 0) {
        let item = res[0]
        let key = Object.keys(item)[0]
        let value = item[key]
        if (key == 0 && value == 100) {
          this.setData({
            radio: '1'
          })
        } else if (key == 0 && value == 0) {
          this.setData({
            radio: '2'
          })
        } else {
          this.setData({
            radio: '3',
            value: Number(key)
          })
        }
      }
    })
  },
  onChange(event) {
    let detail = event.detail
    this.setData({ radio: detail })
  },
  valueInput(event) {
    let value = event.detail.value
    this.setData({ value: Number(value) })
  },
  confirmEvent() {
    let list = []
    let { radio, value } = this.data
    value = String(value)
    if (radio == 1) {
      list.push({ 0: 100 })
    }
    if (radio == 2) {
      list.push({ 0: 0 })
    }
    if (radio == 3) {
      let obj = {}
      obj[value] = 100
      list.push(obj)
    }
    var pages = getCurrentPages()
    pages[pages.length - 2].setRefundRule(list)
    setRefundRuleStorage(list)
    wx.navigateBack()
  }
})

const { getActivityList } = require('./../../../apis/activity')
const { formatActivityTime } = require('./../../../utils/date')
const app = getApp()
Page({
  data: {
    myApplyPage: {
      page: 1,
      size: 10
    },
    myApplyFinish: false,
    myApplyList: []
  },
  viewActivityId: [],
  onLoad(options) {
    let { view_activity_ids } = app.globalData.userStaticInfo
    this.viewActivityId = JSON.parse(JSON.stringify(view_activity_ids))
    this.getActivityList()
  },
  onPullDownRefresh() {
    this.setData({
      myApplyList: [],
      'myApplyPage.page': 1
    })
    this.getActivityList()
  },
  onReachBottom() {
    if (!this.data.myApplyFinish) {
      this.setData({
        'myApplyPage.page': this.data.myApplyPage.page + 1
      })
      this.getActivityList()
    }
  },
  getActivityList() {
    let { page, size } = this.data.myApplyPage
    let start = (page - 1) * size
    let viewActivityId = JSON.parse(JSON.stringify(this.viewActivityId))
    let activity_ids = viewActivityId.splice(start, size)
    let obj = Object.assign({
      resource_ids: activity_ids,
      page: 1,
      size: 10
    })
    getActivityList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < this.data.myApplyPage.size) {
          this.setData({
            myApplyFinish: true
          })
        }
        let list = this.handleActivityList(res.data.list)
        this.data.myApplyList = this.data.myApplyList.concat(list)
        this.setData({
          myApplyList: this.data.myApplyList,
          'activityTabOptions[0].count': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
    wx.stopPullDownRefresh()
  },
  //处理活动列表数据
  handleActivityList(data) {
    let list = []
    let now = new Date().getTime()
    data.map(e => {
      list.push({
        activity_id: e.activity_id,
        images: e.images,
        name: e.name,
        date: formatActivityTime(e.start_time, e.end_time),
        address: e.address,
        apply_member: e.apply_member.slice(0, 3),
        apply_num: e.apply_num,
        tag: e.tag.slice(0, 3),
        is_free: e.is_free,
        show_end: Number(e.end_time) * 1000 < now,
        show_dismiss: e.status == 4 ? true : false
      })
    })
    return list
  }
})

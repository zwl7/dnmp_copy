const { getMyApplyList } = require('./../../../apis/activity')
const { formatActivityTime } = require('./../../../utils/date')
const app = getApp()
Page({
  data: {
    myApplyPage: {
      page: 1,
      size: 10
    },
    myApplyFinish: false,
    myApplyList: [],
    loading: false
  },
  onLoad(options) {
    if (options.title) {
      wx.setNavigationBarTitle({
        title: options.title
      })
    }
  },
  onShow() {
    this.setData({
      myApplyList: [],
      'myApplyPage.page': 1
    })
    this.getMyApplyList()
  },
  onPullDownRefresh() {
    this.setData({
      myApplyList: [],
      'myApplyPage.page': 1,
      myApplyFinish: false
    })
    this.getMyApplyList()
  },
  onReachBottom() {
    if (!this.data.myApplyFinish) {
      this.setData({
        'myApplyPage.page': this.data.myApplyPage.page + 1
      })
      this.getMyApplyList()
    }
  },
  // 我的日程
  getMyApplyList() {
    let obj = Object.assign({}, this.data.myApplyPage)
    this.setData({
      loading: true
    })
    getMyApplyList(obj)
      .then(res => {
        if (res.code === 200) {
          if (res.data.list.length === 0) {
            this.setData({
              myApplyFinish: true
            })
          }
          let list = this.handleActivityList(res.data.list)
          this.data.myApplyList = this.data.myApplyList.concat(list)
          this.setData({
            myApplyList: this.data.myApplyList,
            'activityTabOptions[0].count': res.data.count
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        this.setData({
          loading: false
        })
      })
      .catch(err => {
        wx.showToast({
          title: err,
          icon: 'none'
        })
        this.setData({
          loading: false
        })
      })
    wx.stopPullDownRefresh()
  },
  //处理活动列表数据
  handleActivityList(data) {
    let list = []
    let now = new Date().getTime()
    data.map(e => {
      list.push({
        activity_id: e.activity_id,
        images: e.status != 3 ? e.images : app.globalData.weigui_activity_png,
        name: e.status != 3 ? e.name : '违规活动',
        date: formatActivityTime(e.start_time, e.end_time),
        address: e.address,
        apply_member: e.apply_member.slice(0, 3),
        apply_num: e.apply_num,
        tag: e.tag.slice(0, 3),
        is_free: e.is_free,
        status: e.status,
        show_end: Number(e.end_time) * 1000 < now,
        show_dismiss: e.status == 4 ? true : false,
        activity_type: e.activity_type
      })
    })
    return list
  }
})

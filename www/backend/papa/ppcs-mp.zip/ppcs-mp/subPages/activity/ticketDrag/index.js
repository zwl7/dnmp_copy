const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    size: 1,
    listData: [],
    extraNodes: [],
    pageMetaScrollTop: 0,
    scrollTop: 0
  },
  sortEnd(e) {
    this.setData({
      listData: e.detail.listData
    })
  },
  change(e) {},
  itemClick(e) {
    console.log(e)
  },
  scroll(e) {
    this.setData({
      pageMetaScrollTop: e.detail.scrollTop
    })
  },
  // 页面滚动
  onPageScroll(e) {
    this.setData({
      scrollTop: e.scrollTop
    })
  },
  submit() {
    app.globalData.ticketSortList = this.data.listData
    wx.navigateBack({
      delta: 0
    })
  },
  onLoad() {
    this.drag = this.selectComponent('#drag')
    let listData = app.globalData.ticketSortList
    setTimeout(() => {
      this.setData({
        listData: listData
      })
      this.drag.init()
    }, 100)
  }
})

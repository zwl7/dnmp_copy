const buttonClick = require('./../../../utils/buttonClick')
const { judgeInputLength } = require('./../../../utils/util')
const app = getApp()
const { setActivityContact, getActivityContact, clearActivityContact } = require('./../../../utils/storage')
Page({
  data: {
    contactName: '',
    contactPhone: '',
    wxNumber: '',
    isIos: app.globalData.isIos,
    contacts: []
  },
  onLoad(options) {},
  onShow() {
    getActivityContact().then(res => {
      this.setData({
        contactName: res.contactName || '',
        contactPhone: res.contactPhone || '',
        wxNumber: res.wxNumber || '',
        contacts: res.contacts || []
      })
    })
  },
  inputCrectorPhone(event) {
    this.setData({
      contactPhone: event.detail
    })
  },
  inputContactName(event) {
    let value = judgeInputLength(event.detail, 6, '称呼')
    this.setData({
      contactName: value
    })
  },
  wxChange(event) {
    this.setData({
      wxNumber: event.detail
    })
  },
  getPhoneNumber(t) {
    console.log(t)
  },
  addContact: buttonClick.buttonClicked(function (event) {
    let { type } = event.currentTarget.dataset
    if (this.data.contacts.length < 5) {
      let obj = {
        type: Number(type),
        val: '',
        remark: ''
      }
      this.data.contacts.push(obj)
      this.setData({
        contacts: this.data.contacts
      })
    } else {
    }
  }),
  deleteContact(event) {
    var index = event.currentTarget.dataset.type
    this.data.contacts.splice(index, 1)
    this.setData({
      contacts: this.data.contacts
    })
  },
  // 完成
  confirmEvent() {
    // if (
    //   this.data.contactPhone &&
    //   !this.testPhone(this.data.contactPhone)
    // ) {
    //   this.toast('请输入正确的联系电话')
    //   return
    // }
    // if (!this.data.contactName) {
    //   this.toast('请填写称呼')
    //   return
    // }
    var contacts = this.data.contacts
    if (contacts.length) {
      for (var e = 0; e < contacts.length; e++) {
        let item = contacts[e]
        if (0 == item.type) {
          if (!item.val) return this.toast('手机号不可为空')
          if (!this.testPhone(item.val) || !item.val) {
            return this.toast('手机号格式错误，请重新输入')
          }
        }
        if (1 == item.type) {
          if (!item.val) return void this.toast('座机号不可为空')
        }
        if (2 == item.type) {
          if (!item.val) return void this.toast('微信号不可为空')
        }
        if (!item.remark.trim()) {
          return this.toast('备注不可为空')
        }
      }
    }
    var pages = getCurrentPages()
    pages[pages.length - 2].setContacts(this.data.contactName, this.data.contactPhone, this.data.wxNumber, this.data.contacts)
    let obj = {
      contactName: this.data.contactName,
      contactPhone: this.data.contactPhone,
      wxNumber: this.data.wxNumber,
      contacts: this.data.contacts
    }
    setActivityContact(obj)
    wx.navigateBack()
  },
  testPhone(val) {
    return /^1\d{10}$/.test(val)
  },
  toast(val) {
    wx.showToast({
      title: val,
      icon: 'none'
    })
  },
  valueChange(event) {
    let { index, type } = event.target.dataset
    this.data.contacts[index][type] = event.detail
    this.setData({
      contacts: this.data.contacts
    })
  },
  handleClick(event) {
    let type = event.currentTarget.dataset.type
    if (type == 1) {
      wx.navigateTo({
        url: '/subPages/system/agreement/agreement'
      })
    } else {
      wx.navigateTo({
        url: '/subPages/system/privacy/privacy'
      })
    }
  }
})

const { getMPCode } = require('../../../apis/common')
const buttonClick = require('../../../utils/buttonClick')
const { saveImageToAlbum } = require('./../../../utils/util')
import Card from './activityQRCode'
const app = getApp()
Page({
  imagePath: '',
  history: [],
  future: [],
  isSave: false,
  data: {
    isIos: app.globalData.isIos,
    shareActivity: {},
    loading: false
  },
  onLoad(options) {
    let shareActivity = app.globalData.shareActivity
    console.log(shareActivity)
    this.setData({ loading: true })
    if (!shareActivity.activity_id) {
      wx.showToast({
        title: '数据不完整,生成二维码失败',
        icon: 'none',
        duration: 10000
      })
      return
    }
    this.setData({
      shareActivity: shareActivity,
      photoUrl: shareActivity.community_images || '/assets/images/logo.png'
    })
    this.getMPCode()
  },
  onHide() {
    app.globalData.shareActivity = {}
  },
  getMPCode() {
    let { shareActivity } = this.data
    let scene = `a=${shareActivity.activity_id}&m=${shareActivity.member_id}`
    let obj = {
      page: 'subPages/activity/detail/index',
      scene: scene,
      env_version: app.globalData.env
    }
    this.setData({ loading: true })
    getMPCode(obj).then(res => {
      if (res.code === 200) {
        let url = 'data:image/jpeg;base64,' + res.data.images
        this.data.shareActivity.qrcode = url
        this.setData(
          {
            shareActivity: this.data.shareActivity
          },
          () => {
            this.setData({
              paintPallette: new Card(this.data.shareActivity).palette()
            })
          }
        )
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  onImgOK(e) {
    this.imagePath = e.detail.path
    this.setData({
      image: this.imagePath,
      loading: false
    })
    if (this.isSave) {
      this.saveImage(this.imagePath)
    }
  },

  saveImage: buttonClick.buttonClicked(function () {
    if (this.imagePath && typeof this.imagePath === 'string') {
      this.isSave = false
      saveImageToAlbum(this.imagePath)
    }
  })
})

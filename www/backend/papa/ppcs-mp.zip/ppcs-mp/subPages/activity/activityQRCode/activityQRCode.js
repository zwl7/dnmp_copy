const startTop = 76
const startLeft = 76
const qrcodeWidth = 480
const qrcodeLogoPercent = 1 / 2.2 //小程序中间logo占比
const avatarWidth = qrcodeWidth * qrcodeLogoPercent
export default class LastMayday {
  constructor(sharePoster) {
    console.log(sharePoster)
    this.activity = sharePoster
  }
  palette() {
    return {
      width: '632px',
      height: '766px',
      background: '#fff',
      views: [this.getQrcode(), this.getAvatar(), this.getLogo()]
      // this.getTitle(), this.getTip()
    }
  }
  getQrcode() {
    return {
      id: 'qrcode',
      type: 'image',
      url: this.activity.qrcode,
      css: {
        top: startTop + 'px',
        left: startLeft + 'px',
        width: qrcodeWidth + 'px',
        height: qrcodeWidth + 'px'
      }
    }
  }

  getAvatar() {
    let image_start = (qrcodeWidth * (1 - qrcodeLogoPercent)) / 2
    return {
      id: 'avatar',
      type: 'image',
      url: this.activity.community_images,
      css: {
        width: avatarWidth + 'px',
        height: avatarWidth + 'px',
        borderRadius: avatarWidth + 'px',
        top: image_start + startTop + 'px',
        left: image_start + startLeft + 'px'
      }
    }
  }

  getLogo() {
    return {
      id: 'avatar',
      type: 'image',
      url: 'https://cdn-static.papa.com.cn/ppcs_mp/activity_qrcode_bottom.png',
      css: {
        width: '390px',
        height: 'auto',
        top: '604px',
        left: '126px'
      }
    }
  }

  getTitle() {
    return {
      type: 'text',
      text: '皮卡宇宙',
      css: {
        fontSize: '24px',
        fontWeight: '400',
        color: '#FF7200',
        top: '660px',
        left: '121px',
        fontFamily: 'YouSheBiaoTiHei'
      }
    }
  }

  getTip() {
    return {
      type: 'text',
      text: '开启多元生活',
      css: {
        fontSize: '48px',
        fontWeight: '400',
        color: '#FF7200',
        top: '614px',
        left: '245px',
        fontFamily: 'YouSheBiaoTiHei'
      }
    }
  }
}

const { uploadFile } = require('./../../../utils/util')
const app = getApp()
Page({
  data: {
    placeholder: '详细介绍一下吧~',
    isComplate: true,
    isIos: app.globalData.isIos,
    actions: [
      {
        name: '拍照',
        type: 'camera'
      },
      {
        name: '从相册选择',
        type: 'album'
      }
    ],
    editorStr: '',
    oldText: '',
    oldImgArr: [],
    saveVlue: '',
    editType: 'activity'
  },
  onLoad(options) {
    console.log(options)
    if (options.title) {
      wx.setNavigationBarTitle({
        title: options.title
      })
      if (options.title == '票种简介') {
        this.setData({
          editorStr: app.globalData.activityDes,
          editType: 'ticket',
          placeholder: '介绍一下这个门票吧~'
        })
      }
    }

    this.data.oldText = app.globalData.activityDes
    this.data.oldImgArr = app.globalData.activityImgList
    this.des = options.des ? decodeURIComponent(options.des) : ''
  },
  onEditorReady() {
    var _this = this
    if (this.data.editType === 'activity') {
      wx.createSelectorQuery()
        .select('#editor')
        .context(function (e) {
          _this.editorCtx = e.context
          _this.oldDataCompatibility()
          if (_this.des) {
            _this.editorCtx.setContents({
              html: _this.des
            })
          }
        })
        .exec()
    }
  },
  oldDataCompatibility() {
    let first_index = this.data && this.data.oldText.indexOf('<p')
    let last_index = this.data && this.data.oldText.indexOf('p>')
    if (-1 == first_index && -1 == last_index && this.data.oldImgArr.length) {
      var t = ''
      this.data.oldImgArr.map(function (e) {
        t += '<img src="'.concat(e, '" width="100%" data-custom="id=abcd&amp;role=god" />')
      })
      var e = '<p>'.concat(this.data.oldText).concat(t, '</p>')
      this.data.editorStr = e
      this.editorCtx.setContents({
        html: e
      })
    } else {
      this.data.editorStr = this.data ? this.data.oldText : ''
      this.editorCtx.setContents({
        html: this.data.oldText
      })
    }
  },
  onStatusChange(event) {
    if (event.detail.html) {
      var detail = event.detail
      this.data.editorStr = event.detail.html
      this.setData({
        formats: detail
      })
    }
  },
  editorInput(event) {
    if (event.detail.html) {
      var detail = event.detail
      this.setData({
        formats: detail
      })
      this.data.editorStr = event.detail.html
    }
  },
  textAreaInput(event) {
    this.data.editorStr = event.detail.value
  },
  getimgsrc() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ''
    var e = []
    return (
      t.replace(/<img [^>]*src=['"]([^'"]+)[^>]*>/g, function (t, i) {
        e.push(i)
      }),
      e
    )
  },
  insertImage() {
    let _this = this
    let imgList = this.getimgsrc(_this.data.editorStr)
    if (imgList.length < 15) {
      this.editorCtx.insertText({
        text: '\n'
      })
      wx.chooseMedia({
        count: 9,
        mediaType: ['image'],
        sourceType: ['album', 'camera'],
        camera: 'back',
        success(res) {
          _this.setData({ isComplate: false })
          let list = res.tempFiles.splice(0, 15 - imgList.length)
          wx.showLoading({
            title: '正在上传图片'
          })
          let promiseAll = _this.uploadImage(list)
          Promise.all(promiseAll)
            .then(c_res => {
              c_res.map(d_res => {
                if (d_res.code == 200) {
                  _this.editorCtx.insertImage({
                    src: d_res.data.imgUrl,
                    data: {
                      img: true
                    },
                    width: '100%',
                    success: function () {
                      console.log('insert image success')
                    }
                  })
                  _this.editorCtx.insertText({
                    text: '\n'
                  })
                  _this.editorCtx.scrollIntoView()
                }
              })
              wx.hideLoading()
            })
            .catch(err => {
              wx.hideLoading()
              console.log(err)
            })
        },
        fail() {
          _this.editorCtx.undo()
        }
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: '最多上传15张图片！',
        duration: 2000
      })
    }
  },
  uploadImage(list) {
    let promiseAll = []
    list.map(e => {
      promiseAll.push(uploadFile(e.tempFilePath))
    })
    return promiseAll
  },
  getActivityExplain(need_back) {
    var pages = getCurrentPages()
    var current_page = pages[pages.length - 2]
    if (this.data.editType === 'activity') {
      var images = this.getimgsrc(this.data.editorStr)
      var editorStr = this.data.editorStr.replace(/\<img/gi, '<img style="max-width:100%;"')
      current_page.setActivityDesc && current_page.setActivityDesc(editorStr, images, this.data.editorStr)
    } else {
      current_page.setActivityDesc && current_page.setActivityDesc(this.data.editorStr, '', this.data.editorStr)
    }

    if (need_back) {
      wx.navigateBack()
    }
  },
  confirmCloseEvent() {
    this.getActivityExplain(1)
  },
  onHide() {
    this.getActivityExplain()
  }
})

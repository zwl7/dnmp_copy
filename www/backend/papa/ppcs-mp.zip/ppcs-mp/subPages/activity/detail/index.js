const {
  getActivityDetail,
  getActivityUserInfo,
  getActivityApplyList,
  getMemberByActivityId,
  dismissActivity,
  activityApplyVerify,
  collectActivity,
  inviteCodeVerify
} = require('../../../apis/activity')
const { createOrder } = require('./../../../apis/order')
const { trim, getRefundRuleStr, handleQrcodeScene } = require('../../../utils/util')
const { formatActivityTime, formatTimeBase } = require('./../../../utils/date')
const { getTimeTag, judgeActivityStstusMethod, handleIllegalActivity } = require('./components/detailModule') //活动详情子模块
const app = getApp()
let role_map = {
  0: '普通会员',
  1: '主理人',
  2: '副管理员',
  3: '高级管理员'
}
Page({
  data: {
    isIos: app.globalData.isIos,
    pageInfo: {
      page: 1,
      size: 10
    },
    finish: false,
    joinList: [],
    owerInfo: {
      avatar: '',
      join_time_str: '2022-12-29 14:46:33',
      member_id: 177,
      name: '',
      role: 1,
      role_str: '',
      city_name: '',
      sex: 0,
      is_authenticate: -1
    },
    loading: true,
    showShare: false,
    showNext: false,
    selSessionIndex: 0,
    is_quit: false, // 是否解散
    is_reject: false, //活动是否被驳回
    showMoreCheck: false, // 更多
    membersList: [], // 参加的成员列表 不包括主理人
    keyword: '',
    actions: [
      {
        name: '编辑活动信息',
        id: 4
      },
      {
        name: '客服',
        id: 2,
        openType: 'contact'
      },
      {
        name: '报名信息',
        id: 3
      },
      {
        name: '解散活动',
        color: '#ee0a24',
        id: 1
      }
    ],
    tagColors: [
      {
        color: 'rgba(255, 233, 214, 1)',
        textColor: 'rgba(255, 114, 0, 1)'
      },
      {
        color: 'rgba(217, 255, 248, 1)',
        textColor: 'rgba(41, 204, 174, 1)'
      },
      {
        color: 'rgba(219, 236, 255, 1)',
        textColor: 'rgba(42, 130, 228, 1)'
      }
    ],
    normalUserAction: [
      {
        name: '喜欢',
        likeStatus: 1,
        id: 1
      },
      {
        name: '客服',
        id: 2,
        openType: 'contact'
      }
    ], //普通用户更多操作面部
    normalMoreCheck: false,
    activity_id: '',
    community_id: '',
    activity_type: 1,
    buy_limit_type: 0, //票种类型购买限制  0 无限制
    user_buy_ticket_type_num: 0, //用户购买票种类型数量
    ticket_warning: true, //余量警告
    show_apply_member: false, //展示报名列表
    activity: {
      activity_id: 0,
      city_id: 0,
      community_id: 0,
      name: '',
      start_time: 0,
      end_time: 0,
      street_id: 0,
      address: '',
      latitude: '0',
      longitude: '0',
      images: '',
      banner: '',
      is_free: 0,
      hot: 0,
      people_num: 0,
      des: '',
      tag: []
    },
    activity_status_map: {
      is_manager: false, //是否管理员
      is_join: false, //是否加入
      activity_status: 0, // 活动状态 -1 活动下架 0  活动未开始  1  活动进行中  2  活动已结束  3 活动已解散  4  未开始售票  5 售票倒计时
      now_save_session: 0, //在售票数
      wait_pay_order: '', //待支付订单号
      can_apply_num: 0, //可购买总票数
      sku_clice: '',
      countdown_time: '', //票种开售倒计时  一天内
      min_session_start_time: '' //最小票种开售时间
    },
    // 活动时间地点相关
    addressInfo: {
      date: '',
      address: '',
      alert: '',
      longitude: '',
      latitude: '',
      refundRuleStr: ''
    },
    // 所在星球
    official: {
      images: '',
      name: '',
      member_num: 0,
      activity_num: 0,
      moment_num: 0,
      signature: ''
    },
    // 发起人
    ownerUser: {
      name: '',
      avatar: '',
      phone: '',
      is_authenticate: 0
    },
    member_id: '',
    circleDetail: {},
    activityList: [],
    selectedTicket: {
      isSold: false,
      max_apply_num: 80, // 票量
      apply_num: 80, //  已购票量
      price: 0, // 选中的门票
      need_invite_code: false
    },
    min_session_price: 0, //票种最低价格
    total: 0,
    maxNum: 1,
    limitedNum: 5, // 限购5张
    num: 1, //选择的票数量
    sessions: [], // 票种
    tabActived: 'detail', // detail 详情 members 参与人
    joinMemberCount: {
      all: 0,
      apply: 0
    },
    joinMembers: [], //报名成员
    showMemberAll: false,
    activity_image: 'https://api.wesais.com/images/20230209/72ba62bb0677ddf66c284f19897a199a.jpg', //详情页面背景
    wait_pay_order: '', //等待支付订单
    user_get_session_nums: null, //用户购买票种情况
    is_have_ticket: false, //拥有票种
    ticket_list: [], //用户购买票夹
    sku_clice: '',
    showTicketPopup: false,
    showTicketDesPopup: false,
    ticketDes: '', //票种描述
    invite_code: '', //票种邀请码
    countdownTimeObj: {
      show_countdown: false,
      min_session_start_time: 0,
      countdown_time: 0
    } //倒计时
  },
  previewImages(e) {
    const images = e.currentTarget.dataset.images
    wx.previewImage({
      urls: images
    })
  },
  getTagColor() {
    let index = Math.floor(Math.random() * 10)
    const len = this.data.tagColors.length
    return this.data.tagColors[index % len]
  },
  // 计算购票数量和总价
  calcTotal(num) {
    let n = this.data.num + num
    this.setData({
      total: (n * this.data.selectedTicket.price).toFixed(2),
      num: n
    })
  },
  // 减少数量
  mins() {
    this.calcTotal(-1)
  },
  // 添加数量
  plus() {
    this.calcTotal(1)
  },
  // 计算票种最大数量
  caclSessionMaxNum() {
    const surplus = this.data.selectedTicket.max_apply_num - this.data.selectedTicket.apply_num
    if (this.data.selectedTicket.can_apply_num > 0) {
      this.setData({
        limitedNum: this.data.selectedTicket.can_apply_num
      })
    }
    this.setData({
      maxNum: surplus > this.data.limitedNum ? this.data.limitedNum : surplus
    })
  },
  // 加入活动
  joinActivity() {
    this.caclSessionMaxNum()
    this.setData({
      showNext: true
    })
  },
  // 点击按钮
  async clickBtn(e) {
    switch (e.detail) {
      case 'joinActivity':
        //加入活动
        this.joinActivity()
        break
      case 'orderPay':
        //订单结算
        let flag = await this.orderPayJudgeTypeNum()
        if (!flag) {
          return
        }
        let { activity_id, activity_sessions_id, field_info, sessions_name, need_invite_code, input_invite_code } = this.data.selectedTicket
        if (need_invite_code) {
          if (String(input_invite_code).length != 4) {
            wx.showToast({
              title: '请输入四位邀请码',
              icon: 'none'
            })
            return
          }
          // 执行校验操作
          let inviteCodePass = await this.verifyInviteCode(input_invite_code, activity_sessions_id)
          if (!inviteCodePass) {
            return
          }
          getApp().globalData.input_invite_code = input_invite_code
        }
        let num = this.data.num
        let activity_type = this.data.activity_type
        let field_id_list = []
        try {
          let list = JSON.parse(field_info)
          list.map(e => {
            field_id_list.push(e.id)
          })
        } catch (error) {}
        if (activity_type === 2 && field_id_list.length > 0) {
          let event_url = '/subPages/activity/eventApplyForm/index?'
            .concat('activity_id=', activity_id)
            .concat('&&sessions_id=', activity_sessions_id)
            .concat('&&num=', num)
            .concat('&&activity_type=', activity_type)
            .concat('&&field_ids=', field_id_list.join(','))
          wx.navigateTo({
            url: event_url
          })
        } else {
          let url = '/subPages/order/pay/index?'.concat('activity_id=', activity_id).concat('&&sessions_id=', activity_sessions_id).concat('&&num=', num).concat('&&activity_type=', activity_type)
          wx.navigateTo({
            url: url
          })
        }
        setTimeout(() => {
          this.onClose()
        }, 500)
        break
      case 'share':
        this.setData({
          showShare: true
        })
        break
      case 'more':
        this.setData({
          normalMoreCheck: true
        })
        break
      case 'normalShowTicket':
        let ticket_list = this.data.ticket_list
        if (ticket_list.length == 0) {
          wx.showToast({
            title: '暂未购票',
            icon: 'none'
          })
          return
        }
        if (ticket_list.length === 1) {
          let order_no = ticket_list[0].order_no
          let url = '/subPages/order/waitPay/index'
          url = url.concat('?order_no=', String(order_no))
          wx.navigateTo({
            url: url
          })
        } else {
          this.setData({
            showTicketPopup: true
          })
        }
        break
    }
  },
  // 占座支付
  toPay() {
    if (this.data.wait_pay_order == '0') {
      this.createOrder()
    } else {
      let url = '/subPages/order/waitPay/index'
      url = url.concat('?order_no=', this.data.wait_pay_order)
      wx.navigateTo({
        url: url
      })
    }
  },
  // 创建订单
  createOrder() {
    wx.showLoading({
      title: '创建订单中'
    })
    let obj = {
      sys_id: 30,
      sku_slice: this.data.sku_clice,
      business_type: 3001,
      request_id: 'ppsport',
      business_id: '10000001',
      handle_info: JSON.stringify({ platform_id: 3 })
    }
    createOrder(obj)
      .then(res => {
        if (res.code === 200) {
          let order_no = res.data.parent_order_no
          let url = '/subPages/order/waitPay/index'
          url = url.concat('?order_no=', order_no).concat('&is_parent_order=1')
          wx.navigateTo({
            url: url
          })
        } else {
        }
        wx.hideLoading()
      })
      .catch(err => {
        wx.hideLoading()
      })
  },
  onClose(event) {
    this.setData({
      showNext: false
    })
  },
  // 校验邀请码
  verifyInviteCode(invite_code, activity_sessions_id) {
    return new Promise(async reslove => {
      let res = await inviteCodeVerify({ invite_code: invite_code, activity_sessions_id: activity_sessions_id })
      if (res.code === 200) {
        reslove(true)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
        reslove(false)
      }
    })
  },
  toAllMembers() {
    let url = '/subPages/activity/members/index'
    url = url.concat('?activity_id=', this.data.activity_id)
    wx.navigateTo({
      url: url
    })
  },
  changeTab(e) {
    this.setData({
      tabActived: e.detail.name
    })
  },

  // 获取活动详情
  getDetail(activity_id) {
    let _this = this
    return new Promise((resolve, reject) => {
      this.setData({
        loading: true
      })
      getActivityDetail(activity_id).then(async res => {
        if (res.code === 200) {
          let activity = res.data
          if (activity.is_manager) {
            this.setData({
              'activity_status_map.is_manager': true
            })
            resolve(true)
          } else {
            resolve(false)
          }
          let selectedTicket = []
          activity.tag = _this.getTagList(activity)
          let nowTime = new Date().getTime()
          let min_session_price = activity.sessions.length > 0 ? activity.sessions[0].price : 0
          activity.sessions.map(e => {
            if (e.invite_code) {
              e.need_invite_code = true
            } else {
              e.need_invite_code = false
            }
            e.input_invite_code = ''
            e.timeStatus = 0
            let start = formatTimeBase(e.apply_start_time, '{m}/{d} {h}:{i}')
            let end = formatTimeBase(e.apply_end_time, '{m}/{d} {h}:{i}')
            e.date = start + ' - ' + end
            if (nowTime > Number(e.apply_end_time) * 1000 || nowTime < Number(e.apply_start_time) * 1000) {
              if (nowTime > Number(e.apply_end_time) * 1000) {
                e.timeStatus = 1
              }
              if (nowTime < Number(e.apply_start_time) * 1000) {
                e.timeStatus = 2
              }
              e.isSold = false
            } else {
              e.isSold = true
            }

            if (e.price < min_session_price) {
              min_session_price = e.price
            }
          })
          if (activity.sessions.length > 0) {
            selectedTicket = activity.sessions[0]
          }
          // 活动结束
          if (nowTime > Number(activity.start_time) * 1000) {
            let actions = this.data.actions
            actions.map(e => {
              if (e.id == 1) {
                e.disabled = true
                e.color = '#c8c9cc'
              }
            })
            this.setData({
              actions: actions
            })
          }
          if (activity.status == 4) {
            // 活动解散
            let actions = this.data.actions
            actions.map(e => {
              if (e.id == 4) {
                e.disabled = true
              }
              if (e.id == 1) {
                e.disabled = true
                e.color = '#c8c9cc'
              }
            })
            this.setData({
              is_quit: true,
              actions: actions
            })
            setTimeout(() => {
              if (this.selectComponent('#activityQuit')) {
                this.selectComponent('#activityQuit').showDialog()
              }
            }, 100)
          }
          if (activity.status == 3) {
            activity = handleIllegalActivity(activity)
            // 活动下架
            this.setData({
              is_reject: true
            })

            setTimeout(() => {
              if (this.selectComponent('#activityIllegal')) {
                this.selectComponent('#activityIllegal').showDialog()
              }
            }, 100)
          }
          let addressInfo = {
            date: formatActivityTime(activity.start_time, activity.end_time),
            address: activity.address,
            alert: '',
            longitude: activity.longitude,
            latitude: activity.latitude,
            refundRuleStr: getRefundRuleStr(activity.refund_rule)
          }
          let ownerUser = {
            name: activity.contact_name || activity.host.nick_name || activity.host.name,
            avatar: activity.host.avatar,
            phone: activity.contact_phone,
            wx: activity.contact_email,
            is_authenticate: activity.host.is_authenticate,
            is_authenticate_str: activity.is_authenticate == 1 ? '已实名' : '未实名'
          }
          let official = {
            images: activity.community.images,
            name: activity.community.name,
            member_num: activity.community.member_num,
            activity_num: activity.community.activity_num,
            moment_num: activity.community.moment_num,
            signature: activity.community.signature
          }
          let activity_image = activity.community.activity_image || this.data.activity_image
          activity.des = trim(activity.des)
          console.log(activity.sessions)
          this.setData({
            loading: false,
            min_session_price: min_session_price,
            community_id: activity.community_id,
            activity,
            addressInfo: addressInfo,
            ownerUser: ownerUser,
            sessions: activity.sessions,
            selectedTicket,
            total: selectedTicket.price,
            official: official,
            'joinMemberCount.all': activity.people_num,
            activity_image: activity_image,
            activity_type: activity.activity_type,
            buy_limit_type: activity.buy_limit_type,
            show_apply_member: activity.show_apply_member == 1 ? true : false,
            ticket_warning: activity.ticket_warning == 1 ? true : false
          })
          await this.getActivityUserInfo()
          this.getActivityStatusMethed()
          this.caclSessionMaxNum()
        } else {
          resolve(false)
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        this.setData({
          loading: false
        })
      })
    })
  },
  // 获取tag标签组
  getTagList(activity) {
    let { is_free, type_str, tag, start_time, end_time, sessions, status } = activity
    let tag_map = getTimeTag.call(this, start_time, end_time, sessions)

    let tagList = tag
    let free_map = {
      1: '免费',
      2: 'aa制',
      3: '需付费'
    }
    tagList.push({
      name: free_map[is_free]
    })
    if (type_str) {
      tagList.push({ name: type_str })
    }
    activity.tag.forEach((item, index) => {
      const tagColor = this.getTagColor(index)
      item.color = tagColor.color
      item.textColor = tagColor.textColor
    })
    if (tag_map.tag_status && status != 4) {
      tagList.unshift(tag_map.tag)
    }
    return tagList
  },
  // 获取用户当前活动报名情况
  getActivityUserInfo() {
    return new Promise((resolve, reject) => {
      let obj = { activity_id: this.data.activity_id }
      getActivityUserInfo(obj)
        .then(res => {
          if (res.code === 200) {
            let session_nums = res.data.session_nums
            let user_buy_ticket_type_num = 0
            if (session_nums) {
              for (const i in session_nums) {
                if (session_nums[i]) {
                  user_buy_ticket_type_num += 1
                }
              }
            }
            console.log(user_buy_ticket_type_num)
            this.setData({
              is_have_ticket: res.data.is_have_ticket,
              wait_pay_order: res.data.wait_pay_order,
              user_get_session_nums: res.data.session_nums,
              sku_clice: res.data.sku_clice,
              user_buy_ticket_type_num: user_buy_ticket_type_num
            })
            this.handleTicketList(res.data.ticket_list)
          }
          resolve(true)
        })
        .catch(err => {
          resolve(true)
        })
    })
  },
  // 处理验票信息
  handleTicketList(ticket_list) {
    let sessions = this.data.sessions
    ticket_list.map(e => {
      e.sessions_name = ''
      sessions.map(c => {
        c.buy_limit_type = this.data.buy_limit_type
        c.user_buy_ticket_type_num = this.data.user_buy_ticket_type_num
        if (c.activity_sessions_id == e.activity_sessions_id) {
          e.sessions_name = c.sessions_name
          e.price = c.price
        }
      })
    })
    sessions.map(c => {
      c.is_buy = false
      if (this.data.user_get_session_nums[c.activity_sessions_id]) {
        c.is_buy = true
      }
    })
    this.setData({
      ticket_list: ticket_list,
      sessions: sessions
    })
  },
  selSession(e) {
    this.data.sessions.map(c => {
      if (c.input_invite_code) {
        c.input_invite_code = ''
      }
    })
    this.setData({
      sessions: this.data.sessions
    })
    const index = e.currentTarget.dataset.index
    const selectedTicket = this.data.sessions[index]
    console.log('-----------------当前选择票种', selectedTicket)
    this.setData({
      num: 1
    })
    this.setData({
      selSessionIndex: index,
      selectedTicket,
      total: (this.data.num * selectedTicket.price).toFixed(2),
      invite_code: ''
    })
    this.caclSessionMaxNum()
  },
  onLoad(options) {
    if (options.scene) {
      let obj = handleQrcodeScene(options.scene)
      if (app.globalData.userInfo.is_authenticate == -1) {
        app.globalData.shareActivityId = obj.a
      }
      options.activity_id = obj.a
    }
    if (options.is_share) {
      if (app.globalData.userInfo.is_authenticate == -1) {
        app.globalData.shareActivityId = options.activity_id
      }
    }
    const activity_id = options.activity_id
    this.setData({
      activity_id: activity_id
    })
    this.setNormalMoreAction()
    app.changeJoinList(activity_id, 4)
  },
  onShow() {
    this.setData({
      selSessionIndex: 0,
      num: 1,
      'pageInfo.page': 1,
      joinMembers: [],
      membersList: [],
      joinList: []
    })
    this.getDetail(this.data.activity_id).then(res => {
      this.getJoinList(res)
    })
  },
  // 获取用户信息
  async getMemberByActivityId(activity_id) {
    let ownerRes = await getMemberByActivityId({
      activity_id
    })
    if (ownerRes.code === 200) {
      let joinMembers = []
      let data = ownerRes.data
      const obj = {
        avatar: data.avatar,
        name: data.nick_name ? data.nick_name : data.name,
        sessions_num: 0,
        is_owner: true,
        is_authenticate_str: data.is_authenticate == 1 ? '已实名' : '未实名'
      }
      const owerInfo = {
        avatar: data.avatar,
        member_id: data.member_id,
        name: data.nick_name ? data.nick_name : data.name,
        role: data.role,
        role_str: role_map[data.role],
        city_name: '',
        sex: data.sex,
        is_authenticate: data.is_authenticate,
        is_authenticate_str: data.is_authenticate == 1 ? '已实名' : '未实名'
      }
      joinMembers.push({ ...obj, ...data })
      this.setData({
        owerInfo,
        member_id: data.member_id,
        joinMembers: [...this.data.joinMembers, ...joinMembers]
      })
    } else {
      wx.showToast({
        title: ownerRes.message,
        icon: 'none'
      })
    }
  },
  async getJoinList(type) {
    let { activity_id } = this.data
    let applyCount = 0
    let obj = {
      page: this.data.pageInfo.page,
      size: this.data.pageInfo.size,
      activity_id: activity_id,
      keyword: this.data.keyword,
      no_location: 1
    }
    if (this.data.activity_status_map.is_manager) {
      obj = Object.assign(obj, { is_manager: 1 })
    }
    let applyRes = await getActivityApplyList(obj)
    if (applyRes.code === 200) {
      // 管理员-搜索
      if (type == 2 && applyRes.code === 200) {
        applyCount = applyRes.data.apply_num || 0
        const membersList = []
        applyRes.data.list.map(e => {
          const obj = {
            avatar: e.avatar,
            name: e.nick_name ? e.nick_name : e.name,
            sessions_num: e.sessions_num,
            is_owner: false
          }
          membersList.push({ ...obj, ...e })
        })
        this.setData({ membersList, 'pageInfo.page': 1 })
        return
      }
      if (applyRes.data.list.length < this.data.pageInfo.size) {
        this.setData({
          finish: true
        })
      }
      const list = []
      applyCount = applyRes.data.apply_num || 0
      applyRes.data.list.map(e => {
        let item = {
          avatar: e.avatar,
          member_id: e.member_id,
          name: e.nick_name ? e.nick_name : e.name,
          role: e.role,
          role_str: role_map[e.role],
          city_name: '',
          sex: e.sex,
          is_authenticate: e.is_authenticate,
          sessions_num: e.sessions_num,
          is_owner: false,
          is_authenticate_str: e.is_authenticate_str,
          applicant_code: e.applicant_code
        }
        list.push(item)
      })
      this.data.joinList = this.data.joinList.concat(list)
      this.setData({
        joinList: this.data.joinList
      })
      // 获取用户信息
      this.getMemberByActivityId(activity_id)
      this.setData({
        'joinMemberCount.apply': applyCount,
        joinMembers: this.data.joinList,
        membersList: this.data.joinList,
        loading: false
      })
    } else {
      wx.showToast({
        title: applyRes.message,
        icon: 'none'
      })
    }
  },
  // 获取活动状态
  getActivityStatusMethed() {
    let { is_request } = app.globalData.userStaticInfo
    let timer = null
    if (!is_request) {
      timer = setInterval(() => {
        is_request = app.globalData.userStaticInfo
        if (is_request) {
          clearInterval(timer)
          timer = null
          this.judgeActivityStstus()
        }
      }, 100)
    } else {
      this.judgeActivityStstus()
    }
  },
  // 判断活动状态
  judgeActivityStstus() {
    judgeActivityStstusMethod.call(this)
  },
  // 转发朋友
  onShareAppMessage() {
    let { nick_name } = app.globalData.userInfo
    nick_name = nick_name ? nick_name : '微信用户'
    let activity_name = this.data.activity.name
    let title = `${nick_name}邀请你参加${activity_name}`
    return {
      title: title,
      path: '/subPages/activity/detail/index?is_share=1'.concat('&activity_id=', this.data.activity_id),
      // imageUrl:
      //   'http://quhuo-system-picture.oss-cn-shanghai.aliyuncs.com/MP3.10/home_share.png',
      success: function (t) {
        console.log('成功', t)
      },
      fail: function (t) {
        console.log('失败', t)
      }
    }
  },
  // 活动编辑
  handleEdit() {
    let { activity_id } = this.data
    let url = '/subPages/activity/create/create'
    url = url.concat('?activity_id=', activity_id).concat('&op=edit')
    wx.navigateTo({
      url: url
    })
  },
  // 去星球详情
  toCircle() {
    let { community_id } = this.data
    let url = '/subPages/circle/detail/index'
    url = url.concat('?community_id=', community_id)
    wx.navigateTo({
      url: url
    })
  },
  // 以下 管理员 权限操作
  more() {
    this.setData({
      showMoreCheck: true
    })
  },
  // 关闭更多
  cancel() {
    this.setData({
      showMoreCheck: false,
      normalMoreCheck: false
    })
  },
  // 更多面板选择
  onSelect(event) {
    let { id } = event.detail
    if (id == 1) {
      setTimeout(() => {
        this.selectComponent('#quitActivityDialog').showDialog()
      }, 100)
      // this.cancelActivity()
    }
    if (id == 3) {
      let url = '/subPages/helper/activityMember/activityMember'
      url = url.concat('?activity_id=', this.data.activity_id)
      wx.navigateTo({
        url: url
      })
    }
    if (id == 4) {
      console.log('编辑活动信息')
      this.edit()
    }
  },
  // 普通用户更多操作面板
  normalSelect(event) {
    let { id, likeStatus } = event.detail
    if (id == 1) {
      this.handleLike(likeStatus)
    }
  },
  // 喜欢
  handleLike(likeStatus) {
    let obj = {
      activity_id: this.data.activity_id,
      status: likeStatus
    }
    collectActivity(obj).then(res => {
      if (res.code === 200) {
        this.setNormalMoreAction(likeStatus)
        let handle = likeStatus == 1 ? 'add' : 'del'
        app.globalData.RefreshMinePage = true
        app.changeJoinList(this.data.activity_id, 3, handle)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 设置用户更多面板
  setNormalMoreAction(likeStatus) {
    if (!likeStatus) {
      let flag = app.judgeIsJoin(this.data.activity_id, 4)
      this.data.normalUserAction.map(e => {
        if (e.id == 1) {
          if (flag) {
            e.likeStatus = 2
            e.name = '不喜欢'
          } else {
            e.likeStatus = 1
            e.name = '喜欢'
          }
        }
      })
    } else {
      this.data.normalUserAction.map(e => {
        if (e.id == 1) {
          e.likeStatus = likeStatus == 1 ? 2 : 1
          e.name = likeStatus == 1 ? '不喜欢' : '喜欢'
        }
      })
    }
    this.setData({
      normalUserAction: this.data.normalUserAction
    })
  },
  // 去解散活动
  toDisMissActivity() {
    let url = '/subPages/helper/dismissActivity/index'
    url = url.concat('?activity_id=', this.data.activity_id)
    wx.navigateTo({
      url: url
    })
  },
  // 解散活动
  cancelActivity() {
    const that = this
    wx.showModal({
      content: '是否解散活动?',
      success(res) {
        app.globalData.RefreshMinePage = true
        app.globalData.RefreshIndexPage = true
        if (res.confirm) {
          dismissActivity({
            activity_id: that.data.activity_id
          }).then(res => {
            if (res.code === 200) {
              wx.showToast({
                title: '解散成功',
                icon: 'none'
              })
              that.setData({
                showMoreCheck: false,
                is_quit: true
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },
  // 复制活动
  copyActivity() {
    console.log(this.data.activity_id, this.data.community_id)
    wx.navigateTo({
      url: `/subPages/activity/create/create?activity_id=${this.data.activity_id}&community_id=${this.data.community_id}&re_create=1`
    })
  },
  // 结算或者验票
  check() {
    if (this.data.is_quit) {
      wx.showToast({
        title: '活动已解散',
        icon: 'none'
      })
      return
    }
    let _this = this
    wx.scanCode({
      success(res) {
        console.log(res)
        let result = res.result
        var res = result.split(',')
        let obj = {
          applicant_code: res[0],
          member_id: res[2],
          activity_id: res[1]
        }
        _this.checkTicket(obj.applicant_code)
      },
      fail(error) {
        if (error.errMsg != 'scanCode:fail cancel') {
          wx.showToast({
            title: '二维码识别失败',
            icon: 'none'
          })
        }
      }
    })
  },
  share() {
    this.setData({
      showShare: true
    })
  },
  checkTicket(applicant_code) {
    let obj = { applicant_code: applicant_code }
    activityApplyVerify(obj).then(res => {
      if (res.code === 200) {
        let status_info = this.getStatusInfo(res.data.status, res.data.verify_status, res.data.status_str)
        let user_info = {
          avatar: res.data.avatar,
          name: res.data.nick_name ? res.data.nick_name : res.data.name,
          session_name: res.data.sku_info,
          price: res.data.pay_price,
          applicant_code: res.data.applicant_code,
          status: status_info.status,
          verify_status: res.data.verify_status,
          check_str: status_info.status_str
        }
        app.globalData.checkTicketInfo = user_info
        let url = '/subPages/order/checkTicket/index'
        wx.navigateTo({
          url: url
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 核销
  getStatusInfo(status, verify_status, status_str) {
    let status_index = 3
    let status_new_str = status_str
    if (verify_status === 1) {
      status_index = 1
      status_new_str = '核销成功'
    } else {
      if (status == 7) {
        status_index = 3
      } else {
        status_index = 2
      }
    }
    return {
      status: status_index,
      status_str: status_new_str
    }
  },
  // 点击搜索
  search() {
    this.setData({
      'pageInfo.page': 1,
      finish: false
    })
    this.getJoinList(2)
  },
  edit() {
    if (this.data.is_quit) {
      wx.showToast({
        title: '活动已解散',
        icon: 'none'
      })
      return
    }
    let { role } = this.data.owerInfo
    let { activity_status } = this.data.activity_status_map
    if (role != 1 && activity_status == 2) {
      // 不是主管理员  活动结束
      wx.showToast({
        title: '活动已结束，暂无权限编辑',
        icon: 'none'
      })
      return
    }
    let url = `/subPages/activity/create/create?activity_id=${this.data.activity_id}&community_id=${this.data.community_id}&op=edit`
    if (getCurrentPages().length > 8) {
      wx.redirectTo({
        url: url
      })
    } else {
      wx.navigateTo({
        url: url
      })
    }
  },
  // 操作分享面板
  handleSharePanel(event) {
    let detail = event.detail
    let { official, member_id, community_id, activity_id, activity, addressInfo } = this.data
    // 活动码
    if (detail == 4) {
      let share_activity = {
        community_id: community_id,
        community_images: official.images,
        activity_id: activity_id,
        member_id: member_id
      }
      app.globalData.shareActivity = share_activity
      console.log(app.globalData.shareActivity)
      wx.navigateTo({
        url: '/subPages/activity/activityQRCode/index'
      })
    }

    // 星球海报
    if (detail == 1) {
      let sharePoster = {
        images: activity.images,
        community_id: community_id,
        community_images: official.images,
        activity_id: activity_id,
        member_id: member_id,
        name: activity.name,
        date: addressInfo.date,
        address: addressInfo.address,
        community_name: official.name,
        signature: official.signature,
        nick_name: app.globalData.userInfo.nick_name,
        avatar_url: app.globalData.userInfo.avatar_url
      }
      app.globalData.sharePoster = sharePoster
      wx.navigateTo({
        url: '/subPages/activity/activityPoster/index'
      })
    }
  },
  showTicketDes(event) {
    let { des } = event.currentTarget.dataset
    this.setData(
      {
        ticketDes: des
      },
      () => {
        this.setData({ showTicketDesPopup: true })
      }
    )
  },
  onCloseTicketDes() {
    this.setData({
      showTicketDesPopup: false
    })
  },
  onReachBottom() {
    if (!this.data.finish) {
      this.setData({
        'pageInfo.page': this.data.pageInfo.page + 1
      })
      this.setData({
        loading: true
      })
      this.getJoinList()
    }
  },
  onPullDownRefresh() {
    this.setData({
      selSessionIndex: 0,
      num: 1,
      'pageInfo.page': 1,
      joinMembers: [],
      membersList: [],
      joinList: []
    })
    this.getDetail(this.data.activity_id)
    this.getJoinList()
    setTimeout(() => {
      wx.stopPullDownRefresh()
    }, 10)
  },
  showActivityIllegal() {
    if (this.selectComponent('#activityIllegal')) {
      this.selectComponent('#activityIllegal').showDialog()
    }
  },
  // 票种邀请码
  inviteCodeInput(e) {
    let { index } = e.currentTarget.dataset
    this.data.sessions[index].input_invite_code = e.detail.value.slice(0, 4)
    this.setData({
      sessions: this.data.sessions
    })
  },
  // 购买票种时弹窗  确认购买类型数量
  orderPayJudgeTypeNum() {
    let buy_limit_type = this.data.buy_limit_type
    let user_buy_ticket_type_num = this.data.user_buy_ticket_type_num
    let sessions_name = this.data.selectedTicket.sessions_name
    let is_buy = this.data.selectedTicket.is_buy
    return new Promise(resolve => {
      if (!buy_limit_type) {
        resolve(true)
      } else {
        if (buy_limit_type - user_buy_ticket_type_num == 1 && !is_buy) {
          let message = `您只能选择1种票种/项目，是否购买【${sessions_name}】`
          wx.showModal({
            title: '提示',
            content: message,
            success(res) {
              if (res.confirm) {
                resolve(true)
              } else if (res.cancel) {
                resolve(false)
              }
            }
          })
        } else {
          resolve(true)
        }
      }
    })
  }
})

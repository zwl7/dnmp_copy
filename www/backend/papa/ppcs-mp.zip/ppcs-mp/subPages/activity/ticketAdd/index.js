const { formatTime } = require('./../../../utils/date')
const { money } = require('./../../../utils/util')
const { getWxFields } = require('./../../../apis/activity')
const { setTicketRegister, getTicketRegister } = require('./../../../utils/storage')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    handleType: 'add', //活动添加  编辑
    currentType: 'add', //当前票种 添加还是编辑  复制
    index: 1,
    is_edit: false,
    is_free: 1,
    show_price_input: true,
    // 票种信息
    sessions_name: '',
    max_apply_num: '',
    apply_start_time: '',
    one_apply_num: 1,
    apply_end_time: '',
    apply_start_str: '',
    apply_end_str: '',
    field_info: '',
    price: '',
    ticketDes: '',
    sort: 0,
    status: 0, //票种状态 0:正常 2:下架
    activity_id: '',
    activity_sessions_id: '',
    invite_code: '', //邀请码
    need_invite_code: false,
    // 票种信息
    customData: {
      start_time: '',
      end_time: '',
      startTimeStamp: '',
      endTimeStamp: '',
      activityDes: '',
      activityImgList: []
    },
    apply_start_radio: '1',
    is_sale_now: true, //立马售票
    currentDateStart: '',
    currentDateEnd: '',
    deleteSessionMethod: []
  },
  onLoad(options) {
    let { index, handleType, currentType } = options
    let currentActivityInfo = app.globalData.currentActivityInfo
    if (currentType == 'edit' || currentType == 'copy') {
      if (currentType == 'edit') {
        wx.setNavigationBarTitle({
          title: '编辑票种'
        })
      }
      let data = app.globalData.currentTicketInfo
      if (data.is_sale_now) {
        let time = new Date()
        let apply_start_str = formatTime(time)
        let apply_start_time = time.getTime()
        data.apply_start_time = apply_start_time
        data.apply_start_str = apply_start_str
      }
      this.setData({
        sessions_name: data.sessions_name,
        invite_code: data.invite_code,
        need_invite_code: data.invite_code ? true : false,
        max_apply_num: data.max_apply_num,
        apply_start_time: data.apply_start_time,
        one_apply_num: data.one_apply_num,
        apply_end_time: data.apply_end_time,
        apply_start_str: data.apply_start_str,
        apply_end_str: data.apply_end_str,
        field_info: data.field_info,
        price: data.price,
        ticketDes: data.ticketDes,
        sort: 0,
        status: data.status,
        is_sale_now: data.is_sale_now,
        apply_start_radio: data.is_sale_now ? '1' : '2',
        currentDateStart: new Date(data.apply_start_time).getTime(),
        currentDateEnd: new Date(data.apply_end_time).getTime(),
        activity_id: data.activity_id,
        activity_sessions_id: data.activity_sessions_id
      })
    } else {
      let apply_end_str = formatTime(new Date(currentActivityInfo.end))
      let time = new Date()
      let apply_start_str = formatTime(time)
      let apply_start_time = time.getTime()
      this.setData({
        apply_end_time: currentActivityInfo.end,
        apply_end_str: apply_end_str,
        apply_start_str: apply_start_str,
        apply_start_time: apply_start_time,
        currentDateStart: new Date(currentActivityInfo.start).getTime(),
        currentDateEnd: new Date(currentActivityInfo.end).getTime()
      })
    }
    this.setData({
      index: index,
      handleType: handleType,
      is_free: Number(currentActivityInfo.is_free),
      show_price_input: Number(currentActivityInfo.is_free) === 3 ? true : false
    })

    if (currentActivityInfo.is_free !== 3) {
      this.setData({
        price: 0
      })
    }
  },
  saveTicketFieldInfo(field_info) {
    console.log('-------------------field_info', field_info)
    this.setData({
      field_info: field_info
    })
  },
  valueInput(event) {
    let { type } = event.currentTarget.dataset
    let value = ''
    if (type === 'price') {
      value = money(event.detail.value)
    } else {
      value = event.detail.value
    }
    if (type == 'invite_code') {
      value = String(value).slice(0, 4)
    }
    this.setData({
      [`${type}`]: value
    })
  },
  onChangeOneApplyNum(event) {
    this.setData({
      one_apply_num: event.detail
    })
  },
  onChangeApplyStartRadio(event) {
    this.setData({
      apply_start_radio: event.detail
    })
    if (event.detail == 1) {
      let time = new Date()
      let apply_start_str = formatTime(time)
      let apply_start_time = time.getTime()
      this.setData({
        apply_start_time: apply_start_time,
        apply_start_str: apply_start_str,
        is_sale_now: true
      })
    } else {
      this.setData({
        is_sale_now: false
      })
    }
  },
  getStatrTime(event) {
    let timeTmp = event.detail
    let apply_start_str = formatTime(new Date(timeTmp))
    let apply_start_time = timeTmp
    this.setData({
      'customData.startTimeStamp': timeTmp,
      apply_start_time: apply_start_time,
      apply_start_str: apply_start_str
    })
    this.judgeActivityTime()
  },
  getEndTime(event) {
    let timeTmp = event.detail
    let apply_end_str = formatTime(new Date(timeTmp))
    let apply_end_time = timeTmp
    this.setData({
      'customData.endTimeStamp': timeTmp,
      apply_end_str: apply_end_str,
      apply_end_time: apply_end_time
    })
    this.judgeActivityTime()
  },
  // 判断活动时间
  judgeActivityTime() {
    let startTimeStamp = this.data.apply_start_time
    let endTimeStamp = this.data.apply_end_time
    if (endTimeStamp < startTimeStamp) {
      let endTime = startTimeStamp + 2 * 60 * 60 * 1000
      this.data.apply_end_str = formatTime(new Date(endTime))
      this.data.apply_end_time = endTime
      this.setData({
        apply_end_str: this.data.apply_end_str,
        apply_end_time: this.data.apply_end_time
      })
      return void this.showToast('票种售卖开始时间不能大于结束时间~')
    }
  },
  // 报名表单成员
  async toRegistrationSetting(event) {
    let { field_info, index, is_edit, currentType } = this.data
    if (this.data.handleType === 'edit' && field_info && currentType === 'copy') {
      this.showToast('编辑情况下，报名表单不可修改')
      return
    }
    if (field_info && !is_edit) {
      this.setData({
        is_edit: true
      })
      await this.saveFormStorage(field_info, index)
    }
    wx.navigateTo({
      url: `/subPages/activity/createSetting/createSetting?index=${index}`,
      fail: function (error) {
        console.log('navigateTo', error)
      }
    })
  },
  // 票种编辑
  toEditTicket(event) {
    app.globalData.activityDes = this.data.ticketDes
    wx.navigateTo({
      url: '/subPages/activity/activityDes/activityDes?title=票种简介'
    })
  },
  setActivityDesc(activityDes, activityImgList) {
    console.log(activityDes)
    this.setData({
      ticketDes: activityDes,
      htmlTicketDes: activityDes,
      htmlText: this.getHtmlPlainText(activityDes)
    })
    app.globalData.activityDes = ''
    app.globalData.activityImgList = ''
  },
  getHtmlPlainText(html_str) {
    return html_str.replace(/<[^<>]+>/g, '').replace(/<[^<>]+>/g, '')
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  // 缓存表单
  saveFormStorage(field_info, ticketIndex) {
    return new Promise(async resolve => {
      let base = []
      let questions = []
      let filed_id = []
      field_info.map(e => {
        filed_id.push(e.id)
        if (e.id <= 7) {
          base.push(e)
        }
      })
      let field_ids = filed_id.join(',')
      let res = await getWxFields({ field_ids: field_ids })
      if (res.code === 200) {
        res.data.map(e => {
          if (e.field_select_value) {
            e.field_select_value = JSON.parse(e.field_select_value)
          }
          if (e.field_id > 7) {
            questions.push({
              field_name: e.field_name,
              field_select_type: e.field_select_type,
              field_select_value: e.field_select_value ? JSON.stringify(e.field_select_value) : '',
              field_type: e.field_type
            })
          }
        })
      }
      getTicketRegister().then(res => {
        try {
          if (!res) {
            res = {}
          }
          res[ticketIndex] = {
            base: base ? base : [],
            questions: questions ? questions : []
          }
          setTicketRegister(res)
          resolve(true)
        } catch (error) {}
      })
    })
  },
  // 校验门票
  validateTicket() {
    let flag = false
    const item = this.data
    if (!item.sessions_name) {
      this.showToast('请填写正确的票种名称')
      return flag
    }
    if (item.need_invite_code && (!item.invite_code || item.invite_code.length != 4)) {
      this.showToast('请输入四位邀请码')
      return flag
    }
    if (item.price === null || item.price === undefined || item.price === '') {
      this.showToast('请填写票种价格')
      return flag
    }
    if (!item.max_apply_num) {
      this.showToast('请输入最大出售票种数')
      return flag
    }
    if (!item.one_apply_num) {
      this.showToast('请输入个人出售票种数')
      return flag
    }
    if (!item.apply_start_time) {
      this.showToast('请选择票种出售开始时间')
      return flag
    }
    if (!item.apply_end_time) {
      this.showToast('请选择票种出售结束时间')
      return flag
    }
    if (item.apply_start_time > item.apply_end_time) {
      this.showToast('票种售卖开始时间不能大于结束时间')
      return flag
    }
    flag = true
    return flag
  },
  switchChange(e) {
    console.log(e, 13213)
    this.setData({
      need_invite_code: e.detail
    })
    if (!e.detail) {
      this.setData({
        invite_code: ''
      })
    }
  },
  submit() {
    if (this.validateTicket()) {
      let data = JSON.parse(JSON.stringify(this.data))
      let ticket_info = {
        sessions_name: data.sessions_name,
        max_apply_num: data.max_apply_num,
        apply_start_time: data.apply_start_time,
        one_apply_num: data.one_apply_num,
        apply_end_time: data.apply_end_time,
        apply_start_str: data.apply_start_str,
        apply_end_str: data.apply_end_str,
        field_info: data.field_info,
        price: data.price,
        ticketDes: data.ticketDes,
        sort: 0,
        status: data.status,
        un_shelve: data.status == 2 ? true : false,
        is_sale_now: data.is_sale_now,
        activity_sessions_id: data.activity_sessions_id,
        activity_id: data.activity_id,
        invite_code: data.invite_code
      }

      var pages = getCurrentPages()
      pages[pages.length - 2].setTicketInfo(data.index, ticket_info)
      wx.navigateBack()
    }
  }
})

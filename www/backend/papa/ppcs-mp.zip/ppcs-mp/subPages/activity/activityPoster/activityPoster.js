let startTop = 60
let startLeft = 48
let width = 564 //总长度
let height = 1218 //总高度
let mainBorderWidth = 3
let mainWidth = width - startLeft * 2 - mainBorderWidth * 2
let mainHeight = 1016
let avatarWidth = 36
let qrcodeWidth = 90
const qrcodeLogoPercent = 1 / 2.2 //小程序中间logo占比
const qrcodeAvatarWidth = qrcodeWidth * qrcodeLogoPercent

export default class LastMayday {
  constructor(sharePoster) {
    this.activity = sharePoster
    this.poster_bottom = 'https://cdn-static.papa.com.cn/ppcs_mp/poster_bottom.png'
    this.blur_img = 'https://cdn-static.papa.com.cn/ppcs_mp/blur_img.png'
  }
  palette() {
    return {
      width: width + 'px',
      height: height + 'px',
      background: '#fff',
      views: [
        ...this.getBackground(),
        this.getMainContainer(),
        this.getPosterImage(),
        ...this.getUserInfo(),
        this.getAcivityTitle(),
        this.getAcivityTime(),
        this.getActivityAddress(),
        ...this.getBottomQrcode(),
        this.getBottomInfo()
      ]
    }
  }

  // 背景图片
  getBackground() {
    return [
      {
        id: 'backgroundImg',
        type: 'image',
        url: this.activity.images,
        css: {
          top: 0,
          left: 0,
          width: '100%',
          height: '100%'
        }
      },
      {
        id: 'backgroundBlurImg',
        type: 'image',
        url: this.blur_img,
        css: {
          top: 0,
          left: 0,
          width: '100%',
          height: '100%'
        }
      },
      {
        id: 'backgroundBottomImg',
        type: 'image',
        url: this.poster_bottom,
        css: {
          top: 'calc(backgroundBlurImg.height - 522px)',
          left: 0,
          width: '100%',
          height: '522px'
        }
      }
    ]
  }

  // 主要宽度
  getMainContainer() {
    return {
      id: 'mainContainer',
      type: 'rect',
      css: {
        top: startTop + 'px',
        left: startLeft + 'px',
        color: '#fff',
        borderColor: '#fff',
        borderRadius: '36px',
        borderWidth: mainBorderWidth + 'px',
        width: mainWidth + 'px',
        height: mainHeight + 'px'
      }
    }
  }

  // 活动海报图
  getPosterImage() {
    return {
      id: 'posterImage',
      type: 'image',
      url: this.activity.images,
      css: {
        top: startTop + 'px',
        left: startLeft + 'px',
        width: mainWidth + 'px',
        height: '624px',
        borderRadius: '36px 36px 234px  0'
      }
    }
  }

  // 用户邀请信息
  getUserInfo() {
    return [
      {
        id: 'avatar',
        type: 'image',
        url: this.activity.avatar_url,
        css: {
          width: avatarWidth + 'px',
          height: avatarWidth + 'px',
          borderRadius: avatarWidth + 'px',
          top: 'calc(posterImage.bottom + 36px)',
          left: 'calc(posterImage.left + 35px)'
        }
      },
      {
        type: 'text',
        text: this.activity.nick_name + '邀请你加入活动',
        css: {
          fontSize: '21px',
          fontWeight: '400',
          color: '#333333',
          top: 'calc(avatar.top + 4px)',
          left: 'calc(avatar.right + 9px)',
          width: '326px',
          maxLines: 2,
          lineHeight: '26px'
        }
      }
    ]
  }

  // 活动标题
  getAcivityTitle() {
    return {
      id: 'activityTitle',
      type: 'text',
      text: this.activity.name,
      css: {
        fontSize: '27px',
        lineHeight: '32px',
        fontWeight: '500',
        color: '#333333',
        top: '782px',
        left: startLeft + 35 + 'px',
        width: mainWidth - 35 * 2 + 'px',
        maxLines: 2,
        textAlign: 'center'
      }
    }
  }

  // 活动时间
  getAcivityTime() {
    return {
      id: 'activityTime',
      type: 'text',
      text: this.activity.date,
      css: {
        fontSize: '20px',
        lineHeight: '24px',
        fontWeight: '400',
        color: '#999999',
        top: 'calc(activityTitle.bottom +32px + 6px)',
        left: startLeft + 35 + 'px',
        width: mainWidth - 35 * 2 + 'px',
        maxLines: 2,
        textAlign: 'center'
      }
    }
  }

  // 活动地点
  getActivityAddress() {
    return {
      id: 'activityAddress',
      type: 'text',
      text: this.activity.address,
      css: {
        fontSize: '20px',
        lineHeight: '24px',
        fontWeight: '400',
        color: '#999999',
        top: 'calc(activityTime.bottom + 14px)',
        left: startLeft + 35 + 'px',
        width: mainWidth - 35 * 2 + 'px',
        maxLines: 2,
        textAlign: 'center'
      }
    }
  }

  // 底部二维码信息
  getBottomQrcode() {
    let image_start = (qrcodeWidth * (1 - qrcodeLogoPercent)) / 2 + 'px'
    return [
      {
        id: 'circleTitle',
        type: 'text',
        text: this.activity.community_name,
        css: {
          fontSize: '24px',
          lineHeight: '24px',
          fontWeight: '500',
          color: '#333333',
          top: 'calc(activityAddress.bottom + 51px)',
          left: 'calc(posterImage.left + 35px)',
          width: '270px',
          maxLines: 1
        }
      },
      {
        id: 'circleTip',
        type: 'text',
        text: this.activity.signature,
        css: {
          fontSize: '20px',
          lineHeight: '24px',
          fontWeight: '500',
          color: '#999999',
          top: 'calc(circleTitle.bottom + 12px)',
          left: 'calc(posterImage.left + 35px)',
          width: '270px',
          maxLines: 1
        }
      },
      {
        id: 'bottomQrcode',
        type: 'image',
        url: this.activity.qrcode,
        css: {
          width: qrcodeWidth + 'px',
          height: qrcodeWidth + 'px',
          borderRadius: qrcodeWidth + 'px',
          top: 'calc(activityAddress.bottom + 27px)',
          left: 390 + 'px'
        }
      },
      {
        id: 'qrcodeAvatar',
        type: 'image',
        url: this.activity.community_images,
        css: {
          width: qrcodeAvatarWidth + 'px',
          height: qrcodeAvatarWidth + 'px',
          borderRadius: qrcodeAvatarWidth + 'px',
          top: `calc(activityAddress.bottom  + ${image_start} + 27px)`,
          left: `calc(${image_start} + 390px)`
        }
      }
    ]
  }

  getBottomInfo() {
    return {
      id: 'bottom_title',
      type: 'image',
      url: 'https://cdn-static.papa.com.cn/ppcs_mp/activity_poster_bottom.png',
      css: {
        width: mainWidth+'px',
        height: 'auto',
        top: 'calc(mainContainer.bottom + 26px)',
        left: '86rpx'
      }
    }
  }
}

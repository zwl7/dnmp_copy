import Card from './activityPoster'
import { saveImageToAlbum } from './../../../utils/util'
const { getMPCode } = require('../../../apis/common')
import buttonClick from './../../../utils/buttonClick'
const app = getApp()
Page({
  imagePath: '',
  history: [],
  future: [],
  isSave: false,
  data: {
    isIos: app.globalData.isIos,
    loading: false,
    sharePoster: {}
  },
  onImgOK(e) {
    this.imagePath = e.detail.path
    this.setData({
      image: this.imagePath,
      loading: false
    })
    if (this.isSave) {
      this.saveImage(this.imagePath)
    }
  },
  saveImage: buttonClick.buttonClicked(function () {
    if (this.imagePath && typeof this.imagePath === 'string') {
      this.isSave = false
      saveImageToAlbum(this.imagePath)
    }
  }, 1000),

  onLoad: function () {
    let sharePoster = JSON.parse(JSON.stringify(app.globalData.sharePoster))
    this.setData({ loading: true })
    if (!sharePoster.activity_id) {
      wx.showToast({
        title: '数据不完整,生成二维码失败',
        icon: 'none',
        duration: 10000
      })
      return
    } else {
      sharePoster.nick_name = sharePoster.nick_name.slice(0, 2) + '****'
      this.setData({
        sharePoster: sharePoster
      })
      this.getMPCode()
    }
  },
  onHide() {
    app.globalData.sharePoster = {}
  },
  getMPCode() {
    let { sharePoster } = this.data
    let scene = `a=${sharePoster.activity_id}&m=${sharePoster.member_id}`
    let obj = {
      page: 'subPages/activity/detail/index',
      scene: scene,
      env_version: app.globalData.env
    }
    this.setData({ loading: true })
    getMPCode(obj).then(res => {
      if (res.code === 200) {
        let url = 'data:image/jpeg;base64,' + res.data.images
        this.setData(
          {
            'sharePoster.qrcode': url
          },
          () => {
            this.setData({
              paintPallette: new Card(sharePoster).palette()
            })
          }
        )
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  }
})

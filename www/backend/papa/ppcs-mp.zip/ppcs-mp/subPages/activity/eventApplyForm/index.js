const { getActivityDetail, getWxFields, applyWxActivity } = require('../../../apis/activity')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    activity_id: '',
    num: '',
    sessions_id: '',
    activity_type: '',
    field_ids: '',
    baseFiled: [],
    userField: []
  },
  onLoad(options) {
    let { sessions_id, activity_id, num, activity_type, field_ids } = options
    this.setData({
      activity_id,
      num,
      sessions_id,
      activity_type,
      field_ids
    })
    if (field_ids) {
      this.getWxFields(field_ids)
    }
  },
  // 获取报名表单配置
  getWxFields(field_ids) {
    getWxFields({ field_ids: field_ids }).then(res => {
      if (res.code === 200) {
        let baseFiled = []
        let userField = []
        res.data.map(e => {
          if (e.field_select_value) {
            e.field_select_value = JSON.parse(e.field_select_value)
          }
          e.showTip = false
          e.tip = ''
          if (e.field_id <= 7) {
            e.tip = `请填写${e.field_name}`
            if (e.field_id == 4) {
              e.tip = '请输入正确的身份证号'
              e.reg = `^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$`
            }
            if (e.field_id == 2) {
              e.tip = '请输入正确的手机号'
              e.reg = '^[1][3,4,5,7,8][0-9]{9}$'
            }
            e.value = ''
            baseFiled.push(e)
          } else {
            e.value = []
            e.tip = `请填写当前问题`
            userField.push(e)
          }
        })
        this.setData({
          baseFiled: baseFiled,
          userField: userField
        })
      }
    })
  },
  getSignUpData(event) {
    let { index } = event.currentTarget.dataset
    this.data.userField[index].value = event.detail
    this.setData({
      [`userField[${index}]`]: this.data.userField[index]
    })
  },
  setTipShow(field_id, is_show) {
    this.data.userField.map(e => {
      if (e.field_id == field_id) {
        e.showTip = is_show
      }
    })
    this.setData({
      userField: this.data.userField
    })
  },
  // 校验表单
  // 校验表单
  validateForm() {
    let list = []
    let baseForm = this.selectComponent('#baseForm')
    if (baseForm) {
      let baseFieldList = baseForm.getData()
      let userFieldList = this.getuserFieldData()
      list = baseFieldList.concat(userFieldList)
    }
    let flag = true
    list.map(e => {
      if (e.value == '' || e.value == []) {
        flag = false
        if (e.field_id <= 7) {
          baseForm.setTipShow(e.field_id, true)
        } else {
          this.setTipShow(e.field_id, true)
        }
      } else {
        if (e.reg) {
          var reg = new RegExp(e.reg)
          if (reg.test(e.value)) {
            baseForm.setTipShow(e.field_id, false)
          } else {
            flag = false
            baseForm.setTipShow(e.field_id, true)
          }
        } else {
          if (e.field_id <= 7) {
            baseForm.setTipShow(e.field_id, false)
          } else {
            this.setTipShow(e.field_id, false)
          }
        }
      }
    })
    return flag
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  // 用户自定义数据
  getuserFieldData() {
    let list = JSON.parse(JSON.stringify(this.data.userField))
    console.log(list)
    let res = []
    list.map(e => {
      res.push({
        field_id: e.field_id,
        value: e.value
      })
    })
    return res
  },
  handleSubmit() {
    if (!this.validateForm()) {
      this.showToast('请将表单填写完整')
      return
    }
    if (this.selectComponent('#baseForm')) {
      let baseFieldList = this.selectComponent('#baseForm').getData()
      let userFieldList = this.getuserFieldData()
      let list = baseFieldList.concat(userFieldList)
      console.log('-----------------', list)
      let field_info = []
      let obj = {}
      list.map(e => {
        obj[e.field_id] = e.value
      })
      field_info.push(obj)
      app.globalData.applyFieldInfo = JSON.stringify(field_info)
    }
    let { sessions_id, activity_id, num, activity_type } = this.data
    let url = '/subPages/order/pay/index?'.concat('activity_id=', activity_id).concat('&&sessions_id=', sessions_id).concat('&&num=', num).concat('&&activity_type=', activity_type)
    wx.redirectTo({
      url: url
    })
  }
})

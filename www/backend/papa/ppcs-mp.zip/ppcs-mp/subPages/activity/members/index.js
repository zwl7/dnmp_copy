const {
  getActivityApplyList,
  getMemberByActivityId
} = require('./../../../apis/activity')
const app = getApp()
let role_map = {
  0: '普通会员',
  1: '主管理员',
  2: '副管理员',
  3: '高级管理员'
}
Page({
  data: {
    activity_id: '',
    pageInfo: {
      page: 1,
      size: 10
    },
    finish: false,
    joinList: [],
    owerInfo: {
      avatar: '',
      join_time_str: '2022-12-29 14:46:33',
      member_id: 177,
      name: '',
      role: 1,
      role_str: '',
      city_name: '',
      sex: 0,
      is_authenticate: -1
    }
  },
  onLoad(options) {
    let activity_id = options.activity_id
    this.setData({
      activity_id: activity_id
    })
    this.getOwnerInfo(activity_id)
    this.getJoinPeopleList(activity_id)
  },
  onPullDownRefresh() {
    this.setData({
      'pageInfo.page': 1,
      joinList: []
    })
    this.getJoinPeopleList(this.data.activity_id)
  },
  onReachBottom() {
    if (!this.data.finish) {
      this.setData({
        'pageInfo.page': this.data.pageInfo.page + 1
      })
      this.getJoinPeopleList(this.data.activity_id)
    }
  },
  // 获取主理人信息
  getOwnerInfo(activity_id) {
    let obj = { activity_id: activity_id }
    getMemberByActivityId(obj).then(res => {
      if (res.code === 200) {
        let data = res.data
        let owerInfo = {
          avatar: data.avatar,
          member_id: data.member_id,
          name: data.nick_name ? data.nick_name : data.name,
          role: data.role,
          role_str: role_map[data.role],
          city_name: '',
          sex: data.sex,
          is_authenticate: data.is_authenticate
        }
        this.setData({
          owerInfo: owerInfo
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
    wx.stopPullDownRefresh()
  },
  // 获取参与人员列表
  getJoinPeopleList(activity_id) {
    let obj = Object.assign(
      { activity_id: activity_id },
      this.data.pageInfo
    )
    getActivityApplyList(obj).then(res => {
      if (res.code == 200) {
        if (res.data.list.length < this.data.pageInfo.size) {
          this.setData({
            finish: true
          })
        }
        let list = []
        res.data.list.map(e => {
          let item = {
            avatar: e.avatar,
            member_id: e.member_id,
            name: e.nick_name ? e.nick_name : e.name,
            role: e.role,
            role_str: role_map[e.role],
            city_name: '',
            sex: e.sex,
            is_authenticate: e.is_authenticate
          }
          list.push(item)
        })

        this.data.joinList = this.data.joinList.concat(list)
        this.setData({
          joinList: this.data.joinList
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  }
})

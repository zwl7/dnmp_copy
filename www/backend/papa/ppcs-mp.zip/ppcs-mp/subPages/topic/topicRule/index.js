const { getSpecialPageList, getSpecialPageListDetail } = require('./../../../apis/activity')
Page({
  data: {
    myProperty: {
      // transparent
      backgroundColor: 'transparent',
      isHome: false,
      name: '',
      titleStyle: 'color:#fff;',
      isNeedBack: true
    },
    activity_special_page_id: '',
    content: '', //活动简介
    join_process: '', //参与流程
    others: '' //其他说明
  },
  onLoad(options) {
    console.log(options)
    if (options && options.id) {
      this.setData({
        activity_special_page_id: options.id
      })
      this.getDetail()
    }
  },
  onReady() {},
  getDetail() {
    let { activity_special_page_id } = this.data
    let obj = { activity_special_page_id }
    getSpecialPageListDetail(obj).then(res => {
      if (res.code === 200) {
        this.setData({
          content: this.transformText(res.data.content),
          join_process: this.transformText(res.data.join_process),
          others: this.transformText(res.data.others)
        })
      }
    })
  },
  transformText(content) {
    return content.replace(/&nbsp;/g, '\xa0')
  }
})

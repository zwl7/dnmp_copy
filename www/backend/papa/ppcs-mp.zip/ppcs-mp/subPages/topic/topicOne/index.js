const { getSpecialPageList, getSpecialPageListDetail } = require('./../../../apis/activity')
const { formatActivityTime } = require('../../../utils/date')
const { setLocationInfo, getLocationInfo, clearLocationInfo } = require('../../../utils/storage')
let app = getApp()
Page({
  data: {
    myProperty: {
      // transparent
      backgroundColor: 'transparent',
      isHome: false,
      name: '',
      titleStyle: 'color:#fff;',
      isNeedBack: true
    },
    swiperList: [],
    selectedValue: 'time',
    selectList: [
      {
        text: '时间最近',
        value: 'time'
      },
      {
        text: '距离最近',
        value: 'distance_asc'
      }
    ],
    keyword: '',
    activityList: [],
    loading: false,
    finished: false,
    page: 1,
    size: 10,
    activity_special_page_id: '', //专题id
    banner: '', //banner 图片
    is_get_location: false
  },
  // 搜索页面
  tosearch() {
    wx.navigateTo({
      url: '/pages/search/search'
    })
  },
  showOrders() {
    this.setData({
      showSelected: true
    })
  },
  selOrder(e) {
    this.setData({
      selectedValue: e.detail,
      finished: false,
      page: 1,
      activityList: []
    })
    this.getList()
  },
  onConfirm(e) {
    this.setData({
      keyword: e.detail.value
    })
    this.setData({
      finished: false,
      page: 1,
      activityList: []
    })
    this.getList()
  },
  onLoad(options) {
    if (options.id) {
      this.setData({
        activity_special_page_id: options.id
      })
    } else {
      setTimeout(() => {
        if (this.selectComponent('#activityQuit')) {
          this.selectComponent('#activityQuit').showDialog()
        }
      }, 500)
      return
    }
    this.getDetail()
    this.setData({ is_get_location: app.globalData.is_get_location })
    if (!app.globalData.is_get_location) {
      this.getLocation().then(res => {
        this.getList()
      })
    } else {
      this.getList()
    }
  },
  onReachBottom() {
    console.log('触底加载')
    if (this.data.finished) {
      console.log('加载完成')
      this.setData({
        loading: false
      })
      return
    }
    this.setData({
      page: this.data.page + 1
    })
    this.getList()
  },
  isFullScreen() {
    wx.createSelectorQuery()
      .selectViewport()
      .scrollOffset()
      .exec(async res => {
        const windowHeight = wx.getSystemInfoSync().windowHeight
        const scrollHeight = res[0].scrollHeight
        console.log(windowHeight, scrollHeight)
        if (windowHeight + 160 >= scrollHeight) {
          this.onReachBottom()
        }
      })
  },
  // 活动列表
  getList(refresh) {
    let { activity_special_page_id, page, size, selectedValue, keyword } = this.data
    let obj = { activity_special_page_id, order_by: selectedValue, page, size }
    if (keyword) {
      obj.keyword = keyword
    }
    getSpecialPageList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length == 0) {
          this.setData({
            finished: true
          })
        }
        let list = this.handleActivityList(res.data.list, 3)
        this.data.activityList = this.data.activityList.concat(list)
        this.setData({
          activityList: this.data.activityList
        })
        if (res.data.list.length === 0) {
          this.setData({
            finished: true
          })
        }
        if (!this.data.finished) {
          this.isFullScreen()
        }
      } else {
        this.showToast(res.message)
      }
      if (this.data.loading) {
        this.setData({
          loading: false
        })
      }
    })
    if (refresh) {
      wx.stopPullDownRefresh()
    }
  },
  getDetail() {
    console.log(1111)
    let { activity_special_page_id } = this.data
    let obj = { activity_special_page_id: activity_special_page_id }
    getSpecialPageListDetail(obj).then(res => {
      console.log(res.code)
      if (res.code == 200) {
        this.setData({
          banner: res.data.banner,
          title: res.data.title
        })
      } else {
      }
    })
  },
  //处理活动列表数据
  handleActivityList(data, type) {
    let list = []
    let now = new Date().getTime()

    data.map(e => {
      if (e.distance <= 1000) {
        e.distance = e.distance.toFixed(1) + 'M'
      } else if (e.distance > 1000 && e.distance < 100000) {
        e.distance = Math.round((e.distance / 1000) * 10) / 10 + 'KM'
      } else {
        e.distance = Math.round(e.distance / 1000) + 'KM'
      }
      list.push({
        distance: e.distance,
        activity_id: e.activity_id,
        images: e.status != 3 ? e.images : app.globalData.weigui_activity_png,
        name: e.status != 3 ? e.name : '违规活动',
        date: formatActivityTime(e.start_time, e.end_time),
        address: e.address,
        apply_member: e.apply_member.slice(0, 3),
        apply_num: e.apply_num,
        tag: e.tag.slice(0, 3),
        show_end: Number(e.end_time) * 1000 < now,
        show_dismiss: e.status == 4 ? true : false,
        is_manager: app.judgeIsJoin(e.community_id, 3),
        is_free: e.is_free,
        order_no: e.order_no,
        status: e.status,
        show_tag: type != 2 ? true : false,
        activity_type: e.activity_type
      })
    })
    return list
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  getLocation() {
    let _this = this
    return new Promise(resolve => {
      try {
        wx.getFuzzyLocation({
          type: 'wgs84',
          success(res) {
            const latitude = res.latitude
            const longitude = res.longitude
            app.globalData.latitude = latitude
            app.globalData.longitude = longitude
            app.globalData.user_latitude = latitude
            app.globalData.user_longitude = longitude
            _this.setData({
              is_get_location: true
            })
            console.log(res)
            try {
              let obj = JSON.parse(wx.getStorageSync('user_info'))
              obj.latitude = latitude
              obj.longitude = longitude
              wx.setStorageSync('user_info', JSON.stringify(obj))
            } catch (error) {
              let obj = { latitude, longitude }
              wx.setStorageSync('user_info', JSON.stringify(obj))
            }
            resolve(true)
          },
          fail(error) {
            wx.getSetting({
              success(res) {
                if ('undefined' == res.authSetting['scope.userLocation'] || res.authSetting['scope.userLocation']) {
                  console.log('系统没有给定位权限=====================', res)
                } else {
                  console.log('用户拒绝了授权=====================', res)
                  wx.showToast({
                    title: '获取定位失败，请前往设置打开定位权限',
                    icon: 'none',
                    duration: 3000
                  })
                }
              }
            })
            resolve(false)
          }
        })
      } catch (error) {
        console.log('-------------2', error)
        resolve(false)
      }
    })
  },
  jumpToRule() {
    wx.navigateTo({
      url: '/subPages/topic/topicRule/index?id=' + this.data.activity_special_page_id
    })
  },
  cancelEvent() {
    wx.switchTab({
      url: '/pages/index/index'
    })
  },
  onPullDownRefresh() {
    this.setData({
      finished: false,
      page: 1,
      activityList: []
    })
    this.getList(1)
    this.getDetail()
  },
  // 转发给朋友
  onShareAppMessage() {
    let title = '一起来寻找属于你的星球吧~'
    if (this.data.title) {
      title = this.data.title
    }
    let imageUrl = this.data.banner
    return {
      title: title,
      path: '/subPages/topic/topicOne/index',
      imageUrl: imageUrl ? imageUrl : '',
      success: function (t) {
        console.log('成功', t)
      },
      fail: function (t) {
        console.log('失败', t)
      }
    }
  }
})

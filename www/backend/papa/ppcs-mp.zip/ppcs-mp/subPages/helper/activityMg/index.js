const { getActivityDetail } = require('../../../apis/activity')
const { getTagColor } = require('../../../utils/util')
const { activityApplyVerify } = require('./../../../apis/activity')
const { getActivityApplyList, updateActivity, dismissActivity } = require('../../../apis/activity')
const buttonClick = require('../../../utils/buttonClick')
const createRecycleContext = require('./../../../components/miniprogram-recycle-view/index')
const { formatActivityTime } = require('./../../../utils/date')
const app = getApp()
Page({
  data: {
    showShare: false,
    showNext: false,
    selSessionIndex: 0,
    showMore: false,
    keyword: '',
    activity: {
      activity_id: 2,
      city_id: 0,
      community_id: 0,
      name: '',
      start_time: 0,
      end_time: 0,
      street_id: 0,
      address: '',
      latitude: '0',
      longitude: '0',
      images: '',
      banner: '',
      is_free: 0,
      hot: 0,
      people_num: 0,
      des: '',
      tag: []
    },
    // 活动时间地点相关
    addressInfo: {
      date: '',
      address: '',
      alert: '',
      longitude: '',
      latitude: ''
    },
    // 所在星球
    official: {
      images: '',
      name: '',
      member_num: 0,
      activity_num: 0,
      moment_num: 0
    },
    // 发起人
    ownerUser: {
      name: '',
      avatar: '',
      phone: '',
      is_authenticate: 0
    },
    circleDetail: {},
    activityList: [],
    selectedTicket: {
      isSold: false,
      max_apply_num: 80, // 票量
      apply_num: 80, //  已购票量
      price: 0 // 选中的门票
    },
    total: 0,
    maxNum: 1,
    limitedNum: 5, // 限购5张
    num: 1, //选择的票数量
    sessions: [], // 票种
    joinList: [],
    tabActived: 'detail', // detail 详情 members 参与人+
    is_quit: false, //是否退出
    actions: [
      {
        name: '解散活动',
        color: '#ee0a24',
        id: 1
      },

      {
        name: '客服',
        id: 2,
        openType: 'contact'
      },
      {
        name: '报名信息',
        id: 3
      }
    ]
  },
  activityId: 0,
  page: 1,
  size: 10,
  applyNum: 0,
  count: 0,
  finished: false,
  onClose() {
    this.setData({
      showNext: false
    })
  },
  changeTab(e) {
    this.setData({
      tabActived: e.detail.name
    })
  },
  edit() {
    wx.navigateTo({
      url: `/subPages/activity/create/create?activity_id=${this.data.activity.activity_id}&community_id=${this.data.activity.community_id}&op=edit`
    })
  },
  // 滚动条滚动到底部
  scrollBottom() {
    const that = this
    if (!this.finished) {
      buttonClick.throttle(function () {
        // 调用对象需要实现load方法
        that.page += 1
        that.getApplicants()
      }, 800)()
    }
  },
  setCtx() {
    var ctx = createRecycleContext({
      id: 'recycleId3',
      dataKey: 'recycleList',
      page: this,
      itemSize: {
        width: 100,
        height: 144
      }
    })
    this.ctx = ctx
  },
  // 获取活动详情
  getDetail() {
    getActivityDetail(this.activityId).then(res => {
      if (res.code === 200) {
        console.log(res.data)
        const activity = res.data
        let selectedTicket = []
        activity.tag.forEach((item, index) => {
          const tagColor = getTagColor(index)
          item.color = tagColor.color
          item.textColor = tagColor.textColor
        })
        if (activity.sessions.length > 0) {
          selectedTicket = activity.sessions[0]
        }
        let addressInfo = {
          date: formatActivityTime(activity.start_time, activity.end_time),
          address: activity.address,
          alert: '',
          longitude: activity.longitude,
          latitude: activity.latitude
        }
        let ownerUser = {
          name: activity.contact_name || activity.host.nick_name || activity.host.name,
          nick_name: activity.host.nick_name,
          avatar: activity.host.avatar,
          phone: activity.contact_phone || activity.host.phone,
          wx: activity.contact_email || activity.host.wx,
          sex: activity.host.sex,
          role: 1,
          role_str: '联系人',
          is_authenticate_str: activity.host.is_authenticate_str,
          is_authenticate: activity.host.is_authenticate
        }

        this.setData({
          activity,
          addressInfo: addressInfo,
          ownerUser: ownerUser,
          selectedTicket
        })
        if (activity.status == 4) {
          this.setData({
            is_quit: true
          })
        }
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  getApplicants() {
    getActivityApplyList({
      keyword: this.data.keyword,
      activity_id: this.activityId,
      status: 0,
      page: this.page,
      size: this.size
    }).then(res => {
      if (res.data.list.length == 0) {
        this.finished = true
      }

      this.page == 1 &&
        this.setData({
          applyNum: res.data.apply_num || 0
        })
      this.count = res.data.count
      this.ctx.append(res.data.list)
    })
  },

  // 点击搜索
  search() {
    this.page = 1
    this.finished = false
    this.ctx.splice(0, this.count)
    this.getApplicants()
  },
  onLoad(options) {
    this.activityId = options.activity_id
  },
  onShow() {
    this.setCtx()
    this.getDetail()
    this.page = 1
    this.ctx.splice(0, 1000000000)
    this.getApplicants()
  },
  share() {},
  cancelActivity() {
    const that = this
    wx.showModal({
      content: '是否解散活动?',
      success(res) {
        app.globalData.RefreshMinePage = true
        app.globalData.RefreshIndexPage = true
        if (res.confirm) {
          dismissActivity({
            activity_id: that.activityId
          }).then(res => {
            if (res.code === 200) {
              wx.showToast({
                title: '解散成功',
                icon: 'none'
              })
              that.setData({
                showMore: false,
                is_quit: true
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },
  service() {},
  cancel() {
    this.setData({
      showMore: false
    })
  },
  //面板选择
  onSelect(event) {
    let { id } = event.detail
    console.log(event.detail)
    console.log(this.activityId)
    if (id == 1) {
      this.cancelActivity()
    }
    if (id == 3) {
      let url = '/subPages/helper/activityMember/activityMember'
      url = url.concat('?activity_id=', this.activityId)
      wx.navigateTo({
        url: url
      })
    }
  },
  copyActivity() {
    console.log(this.activityId, this.data.activity.community_id)
    wx.navigateTo({
      url: `/subPages/activity/create/create?activity_id=${this.activityId}&community_id=${this.data.activity.community_id}&re_create=1`
    })
  },
  more() {
    this.setData({
      showMore: true
    })
  },
  check() {
    if (this.data.is_quit) {
      wx.showToast({
        title: '活动已解散',
        icon: 'none'
      })
      return
    }
    let _this = this
    wx.scanCode({
      success(res) {
        let result = res.result
        var res = result.split(',')
        let obj = {
          applicant_code: res[0],
          member_id: res[2],
          activity_id: res[1]
        }
        _this.checkTicket(obj.applicant_code)
      },
      fail(error) {
        if (error.errMsg != 'scanCode:fail cancel') {
          wx.showToast({
            title: '二维码识别失败',
            icon: 'none'
          })
        }
      }
    })
  },
  checkTicket(applicant_code) {
    let obj = { applicant_code: applicant_code }
    activityApplyVerify(obj).then(res => {
      if (res.code === 200) {
        let status_info = this.getStatusInfo(res.data.status, res.data.status_str)
        let user_info = {
          avatar: res.data.avatar,
          name: res.data.nick_name ? res.data.nick_name : res.data.name,
          session_name: res.data.sku_info,
          price: res.data.pay_price,
          applicant_code: res.data.applicant_code,
          status: status_info.status,
          check_str: status_info.status_str
        }
        app.globalData.checkTicketInfo = user_info
        let url = '/subPages/order/checkTicket/index'
        wx.navigateTo({
          url: url
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 转发朋友
  onShareAppMessage() {
    let { nick_name } = app.globalData.userInfo
    nick_name = nick_name ? nick_name : '微信用户'
    let activity_name = this.data.activity.name
    let activity_id = this.data.activity.activity_id
    let title = `${nick_name}邀请你参加${activity_name}`
    return {
      title: title,
      path: '/subPages/activity/detail/index'.concat('?activity_id=', activity_id),
      // imageUrl: 'http://quhuo-system-picture.oss-cn-shanghai.aliyuncs.com/MP3.10/home_share.png',
      success: function (t) {
        console.log('成功', t)
      },
      fail: function (t) {
        console.log('失败', t)
      }
    }
  }
})

const { getTags, updateCommunityTags } = require('../../../apis/helper')
const { trim } = require('../../../utils/util')
const app = getApp()
Page({
  data: {
    name: '',
    isIos: app.globalData.isIos,
    tags: [], // 已选标签
    hotTags: [], // 热门标签
    limit: 5 // 限制标签数
  },
  communityId: 0,
  onLoad(options) {
    this.communityId = options.community_id
    this.getTags()
    this.getSelectedTags()
  },

  // 已选标签
  getSelectedTags() {
    getTags({
      community_id: this.communityId,
      resource_type_id: 2
    }).then(res => {
      this.setData({
        tags: res.data.list
      })
    })
  },

  // 热门标签
  getTags() {
    getTags({ page: 1, size: 10, resource_type_id: 2 }).then(res => {
      this.setData({
        hotTags: res.data.list
      })
    })
  },
  // 删除标签
  delTag(e) {
    const index = e.target.dataset.index
    let tags = this.data.tags
    tags.splice(index, 1)
    this.setData({
      tags
    })
  },
  toast(title) {
    wx.showToast({
      title,
      icon: 'none'
    })
  },
  // 追加标签
  pushTag(e) {
    if (this.data.tags.length < this.data.limit) {
      const item = e.target.dataset.item
      const index = this.data.tags.findIndex(d => d.name === item.name)
      index == -1 &&
        this.setData({
          tags: this.data.tags.concat({
            name: item.name,
            resource_tag_id: item.resource_tag_id
          })
        })
    } else {
      this.toast(`最多${this.data.limit}个标签`)
    }
  },
  // 添加标签
  addTag() {
    if (this.data.tags.length < this.data.limit) {
      // 判断标签是否重复
      const name = trim(this.data.name)
      const index = this.data.tags.findIndex(item => item.name === name)
      if (name == '') return
      if (index > -1) {
        this.toast('标签重复')
      } else if (name.length > 5) {
        this.toast('最多输入5个字符')
      } else {
        this.setData({
          tags: this.data.tags.concat({ name: name }),
          name: ''
        })
      }
    } else {
      this.toast(`最多${this.data.limit}个标签`)
    }
  },
  // 点击完成
  update() {
    updateCommunityTags({
      tags: JSON.stringify(this.data.tags),
      community_id: this.communityId
    }).then(res => {
      if (res.code == 200) {
        wx.redirectTo({
          url: `/subPages/helper/index/index?community_id=${this.communityId}`
        })
      } else {
        this.toast('修改失败')
      }
    })
  }
})

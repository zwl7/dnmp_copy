const { wxCommunityGet } = require('../../../apis/circle')
const { getAmountInfo, getAmountRecord, getCommunityStatistic } = require('../../../apis/helper')
const app = getApp()
Page({
  data: {
    userInfo: {
      avatarUrl: '',
      nickName: ''
    },
    communityId: 0,
    active: 'management',
    amountInfo: {}, // 钱包详情
    amountRecordList: [],
    amountPage: 1,
    amountSize: 10,
    amountRefresh: false,
    loading: false,
    total_data: {
      activity_month_apply_num: 0,
      activity_month_num: 0,
      member_month_incr_num: 0,
      member_num: 0,
      month_lose_num: 0,
      month_true_join: 0,
      exposure_num_community: 0,
      exposure_num_activity: 0
    },
    sex_data: [
      { value: 0, name: '未知' },
      { value: 0, name: '男生' },
      { value: 0, name: '女生' }
    ],
    age_data: []
  },

  onLoad(options) {
    // this.getMember()
    this.setData({
      communityId: options.community_id
    })
    this.getAmountRecord()
    this.getAmountInfo()
    this.getCommunityStatistic()
  },
  // getMember() {
  //   this.setData({
  //     userInfo: {
  //       avatarUrl: app.globalData.userInfo.avatar_url,
  //       nickName: app.globalData.userInfo.nick_name
  //     }
  //   })
  // },
  // 钱包流水
  async getAmountRecord() {
    this.setData({
      loading: true
    })
    if (this.data.amountRefresh) {
      this.setData({
        loading: false
      })
      return
    }
    const { communityId, amountSize, amountPage } = this.data
    const params = {
      community_id: communityId,
      page: amountPage,
      size: amountSize
    }
    const { data } = await getAmountRecord(params)
    console.log(data)
    const amountRecordList = [...this.data.amountRecordList, ...data.list]
    this.setData({
      amountRecordList
    })
    if (amountRecordList.length >= data.count) {
      this.setData({ amountRefresh: true })
    }
    this.setData({ amountPage: this.data.amountPage + 1, loading: false })
  },
  // 钱包详情
  async getAmountInfo() {
    const res = await getAmountInfo({ community_id: this.data.communityId })
    if (res.code === 200) {
      this.setData({ amountInfo: res.data })
    } else {
      wx.showToast({
        title: res.message,
        icon: 'none'
      })
    }
  },
  // exchange() {
  //   wx.redirectTo({
  //     url: '/subPages/helper/login/index'
  //   })
  // },
  getCommunityStatistic() {
    const params = {
      community_id: this.data.communityId
    }
    getCommunityStatistic(params).then(res => {
      if (res.code === 200) {
        let sex_data = [
          { value: res.data.sex_data.unkonw_num, name: '未知' },
          { value: res.data.sex_data.boy_num, name: '男生' },
          { value: res.data.sex_data.girl_num, name: '女生' }
        ]
        this.setData({
          total_data: res.data.total_data,
          sex_data: sex_data,
          age_data: res.data.age_data
        })
      }
    })
  },
  onChangeTab(e) {
    this.setData({ active: e.detail.name })
  },
  onReachBottom() {
    if (this.data.active === 'pocket' && this.data.amountRecordList.length) {
      this.getAmountRecord()
      console.log('触底了')
    }
  },
  onPullDownRefresh() {
    setTimeout(() => {
      wx.stopPullDownRefresh({
        success: res => {}
      })
    }, 10)
  }
})

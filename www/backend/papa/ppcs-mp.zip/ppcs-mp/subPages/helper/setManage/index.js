const { getCommunityPersonnelList } = require('./../../../apis/circle')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    managerList: [], //星球主
    memberInfoList: [], //用户
    community_id: '',
    finished: false,
    loading: false,
    loading: false,
    page: 1
  },
  onLoad(options) {
    let { community_id } = options
    this.setData({
      community_id: community_id
    })
  },
  onShow() {
    this.resetData()
  },
  getList() {
    let obj = {
      page: this.data.page,
      size: 20,
      is_manager: 1,
      no_location: 1,
      community_id: this.data.community_id
    }
    this.setData({
      loading: true
    })
    getCommunityPersonnelList(obj)
      .then(res => {
        this.setData({
          loading: false
        })
        if (res.code === 200) {
          let managerList = []
          let memberInfoList = []
          res.data.list.map(e => {
            let obj = {
              is_authenticate_str: e.is_authenticate_str,
              nick_name: e.nick_name,
              name: e.name,
              sex: e.sex,
              avatar: e.avatar
            }
            if (e.role === 1) {
              obj.role_str = e.role_str
              obj.role = e.role
              managerList.push(obj)
            } else {
              memberInfoList.push(obj)
            }
          })
          this.data.managerList = this.data.managerList.concat(managerList)
          this.data.memberInfoList = this.data.memberInfoList.concat(memberInfoList)
          this.setData({
            managerList: this.data.managerList,
            memberInfoList: this.data.memberInfoList
          })
          if (res.data.list < 20) {
            this.setData({ finished: true })
          }
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        this.setData({ loading: false })
      })
  },
  addManage(e) {
    wx.navigateTo({
      url: `/subPages/helper/selectManage/index?community_id=${this.data.community_id}`
    })
  },
  resetData() {
    this.setData({
      page: 1,
      managerList: [],
      memberInfoList: [],
      finished: false
    })
    this.getList()
  },
  onPullDownRefresh() {
    this.resetData()
    wx.stopPullDownRefresh()
  },
  onReachBottom() {
    if (!this.data.finished) {
      this.setData({
        page: this.data.page + 1
      })
      this.getList()
    }
  }
})

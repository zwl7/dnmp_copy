const { getApplyDetail, getWxFields, applyRemoveActivity } = require('./../../../apis/activity')
const app = getApp()
Page({
  data: {
    userInfo: {},
    applicant_code: '',
    field_info: {},
    session_info: {
      session_name: '',
      sessions_num: 0,
      price: 0
    },
    baseFiled: [],
    userField: [],
    handle_loading: false,
    is_quit: false,
    isIos: app.globalData.isIos
  },
  onLoad(options) {
    let { applicant_code } = options
    this.setData({
      applicant_code: applicant_code
    })
    this.getApplyDetail()
    let _this = this
    wx.getStorage({
      key: 'registerUserInfo',
      success(res) {
        _this.setData({
          userInfo: res.data
        })
      }
    })
  },
  getApplyDetail() {
    let obj = { applicant_code: this.data.applicant_code }
    getApplyDetail(obj).then(res => {
      if (res.code === 200) {
        this.setData({
          'session_info.session_name': res.data.sessions_name,
          'session_info.sessions_num': res.data.sessions_num,
          'session_info.price': res.data.price || 0
        })
        this.setData({
          'userInfo.avatar': res.data.avatar,
          'userInfo.sex': res.data.sex,
          'userInfo.nick_name': res.data.nick_name
        })
        try {
          let field_info = res.data.field_info
          if (field_info) {
            let field_list = JSON.parse(field_info)
            let tmp = field_list
            if (field_list instanceof Array) {
              tmp = field_list[0]
            }
            this.setData({ field_info: tmp })
            let field_id_list = Object.keys(tmp)
            let field_ids = field_id_list.join(',')
            if (field_ids) {
              this.getWxFields(field_ids)
            }
          }
        } catch (error) {
          console.log(error)
        }
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 获取报名表单配置
  getWxFields(field_ids) {
    getWxFields({ field_ids: field_ids }).then(res => {
      if (res.code === 200) {
        let baseFiled = []
        let userField = []
        res.data.map(e => {
          let obj = {
            field_id: e.field_id,
            field_name: e.field_name,
            field_type: e.field_type,
            field_select_type: e.field_select_type,
            value: this.data.field_info[e.field_id]
          }
          if (e.field_select_value) {
            e.field_select_value = JSON.parse(e.field_select_value)
            let field_value = this.data.field_info[e.field_id]
            if (e.field_type == 4) {
              // 单选问题
              e.field_select_value.map(c => {
                if (c.value == field_value) {
                  field_value = c.name
                }
              })
            }
            if (e.field_type == 5) {
              // 多选问题
              let value_list = []
              e.field_select_value.map(c => {
                field_value.map(f => {
                  if (c.value == f) {
                    value_list.push(c.name)
                  }
                })
              })
              field_value = value_list
            }
            if (e.field_type == 8) {
              // 图片问题
            }

            obj.value = field_value
          }
          if (e.field_id <= 7) {
            e.value = ''
            baseFiled.push(obj)
          } else {
            e.value = []
            userField.push(obj)
          }
        })
        this.setData({
          baseFiled: baseFiled,
          userField: userField
        })
        console.log(userField)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 预览图片
  previewImage(event) {
    let { image } = event.currentTarget.dataset
    if (image && image.length > 0) {
      wx.previewImage({
        current: image[0],
        urls: image
      })
    }
  },
  // 离开活动
  leaveActivity() {
    let _this = this
    if (this.data.handle_loading) {
      return
    }
    if (this.data.is_quit) {
      wx.showToast({
        title: '已经请离成功',
        icon: 'none'
      })
      return
    }
    wx.showModal({
      title: '提示',
      content: '是否将当前用户踢出活动',
      success(res) {
        if (res.confirm) {
          _this.applyRemoveActivity()
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  applyRemoveActivity() {
    this.setData({ handle_loading: true })
    let obj = { applicant_code: this.data.applicant_code }
    app.globalData.RefreshRegisterInfoPage = true
    applyRemoveActivity(obj).then(res => {
      if (res.code === 200) {
        this.setData({ is_quit: true })
        wx.showToast({
          title: '操作成功',
          icon: 'success'
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
      this.setData({ handle_loading: false })
    })
  },
  callPhone(event) {
    let { phone } = event.currentTarget.dataset
    if (phone) {
      wx.makePhoneCall({
        phoneNumber: phone
      })
    }
    console.log(event)
  }
})

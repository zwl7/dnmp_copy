const { dismissActivity } = require('../../../apis/activity')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    value: 24,
    radio: '',
    remark: '',
    activity_id: '',
    options: [
      {
        type: 1,
        title: '活动设置有误，需重新创建'
      },
      {
        type: 2,
        title: '活动人数不足，活动取消'
      },
      {
        type: 3,
        title: '活动时间变更'
      },
      {
        type: 4,
        title: '不想举办了，临时有事'
      },
      {
        type: 5,
        title: '其他原因'
      }
    ],
    loading: false
  },
  onLoad(options) {
    console.log(options)
    if (options && options.activity_id) {
      this.setData({
        activity_id: options.activity_id
      })
    }
  },
  onChange(event) {
    this.setData({
      radio: event.detail
    })
  },
  inputValue(event) {
    let value = event.detail.value
    this.setData({
      remark: value
    })
  },
  confirmEvent() {
    let { radio, remark, loading, activity_id, options } = this.data
    if (loading) {
      this.showToast('请勿重复提交')
      return
    }
    if (!radio) {
      this.showToast('请选择解散活动原因')
      return
    }
    if (radio == 5 && !remark) {
      this.showToast('请输入解散原因')
      return
    }
    this.setData({
      loading: true
    })
    if (radio != 5) {
      options.map(e => {
        if (e.type == radio) {
          remark = e.title
        }
      })
    }
    dismissActivity({
      activity_id: activity_id,
      remark: remark,
      no_location: 1
    })
      .then(res => {
        this.setData({
          loading: false
        })
        if (res.code === 200) {
          app.globalData.RefreshMinePage = true
          app.globalData.RefreshIndexPage = true
          wx.showToast({
            title: '解散成功',
            icon: 'none'
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 50)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        this.setData({ loading: false })
      })
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  }
})

const { getCommunityPersonnelList, getCommunityManagerIds, managerAdd } = require('./../../../apis/circle')
const buttonClick = require('./../../../utils/buttonClick')
const app = getApp()
Page({
  data: {
    isIos: app.globalData.isIos,
    managerList: [],
    memberInfoList: [],
    result: [],
    community_id: '',
    page: 1,
    loading: false,
    managerFinished: false,
    finished: false,
    key_word: '',
    submit_loading: false
  },
  onLoad(options) {
    let { community_id } = options
    this.setData({
      community_id: community_id
    })
  },
  onShow() {
    let obj = {
      community_id: this.data.community_id,
      is_manager: 1,
      need_member_id: 1
    }
    this.setData({
      loading: true
    })
    getCommunityManagerIds(obj).then(res => {
      if (res.code === 200) {
        let list = res.data.list.map(e => {
          return String(e)
        })
        this.setData({
          result: list
        })
        this.resetData()
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none',
          duration: 3000
        })
      }
    })
  },
  addManage(e) {
    wx.navigateTo({
      url: '/subPages/helper/selectManage/index'
    })
  },
  onChange(event) {
    if (this.data.result.length >= 200) {
      wx.showToast({
        title: '最多添加200个管理员',
        icon: 'none'
      })
      return
    }
    this.setData({
      result: event.detail
    })
  },
  handleSearch(e) {
    let value = e.detail
    this.setData({
      key_word: value
    })
    this.resetData()
  },
  textInput: buttonClick.buttonClicked(function (e) {
    let value = e.detail.detail.value
    if (!value) {
      return
    }
    this.setData({
      key_word: value
    })
  }),
  handleConfirm(e) {
    let value = e.detail.value
    this.setData({
      key_word: value
    })
    this.resetData()
  },
  onPullDownRefresh() {
    wx.stopPullDownRefresh()
  },
  onReachBottom() {
    if (!this.data.managerFinished) {
      this.data({
        page: this.data.page + 1
      })
      this.getManagerList()
    }
    if (!this.data.finished && this.data.managerFinished) {
      this.data({
        page: this.data.page + 1
      })
      this.getManagerList()
    }
  },
  resetData() {
    this.setData({
      page: 1,
      loading: false,
      managerFinished: false,
      finished: false,
      managerList: [],
      memberInfoList: []
    })
    this.getManagerList()
  },
  searchData() {
    this.setData({
      page: 1,
      loading: false,
      managerFinished: false,
      finished: false,
      memberInfoList: []
    })
    this.getUserList()
  },
  // 管理员
  getManagerList() {
    let obj = {
      page: this.data.page,
      size: 30,
      is_manager: 1,
      no_location: 1,
      community_id: this.data.community_id
    }
    if (this.data.key_word) {
      obj['key_word'] = this.data.key_word
    }
    this.setData({
      loading: true
    })
    getCommunityPersonnelList(obj)
      .then(res => {
        this.setData({
          loading: false
        })
        if (res.code === 200) {
          let managerList = []
          res.data.list.map(e => {
            let obj = {
              is_authenticate_str: e.is_authenticate_str,
              nick_name: e.nick_name,
              name: e.name,
              sex: e.sex,
              avatar: e.avatar,
              role_str: e.role_str || '管理人员',
              role: e.role,
              member_id: e.member_id
            }
            managerList.push(obj)
          })
          this.data.managerList = this.data.managerList.concat(managerList)
          this.setData({
            managerList: this.data.managerList
          })
          if (res.data.list.length < 30) {
            this.setData({
              managerFinished: true,
              page: 1
            })
            this.getUserList()
          }
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        this.setData({
          loading: false
        })
      })
  },
  //普通用户
  getUserList() {
    let obj = {
      page: this.data.page,
      size: 10,
      no_location: 1,
      community_id: this.data.community_id
    }
    if (this.data.key_word) {
      obj['key_word'] = this.data.key_word
    }
    this.setData({
      loading: true
    })
    getCommunityPersonnelList(obj)
      .then(res => {
        this.setData({
          loading: false
        })
        if (res.code === 200) {
          let memberInfoList = []
          res.data.list.map(e => {
            let obj = {
              is_authenticate_str: e.is_authenticate_str,
              nick_name: e.nick_name,
              name: e.name,
              sex: e.sex,
              avatar: e.avatar,
              member_id: e.member_id
            }
            memberInfoList.push(obj)
          })
          this.data.memberInfoList = this.data.memberInfoList.concat(memberInfoList)
          this.setData({
            memberInfoList: this.data.memberInfoList
          })
          if (res.data.list.length < 10) {
            this.setData({
              finished: true
            })
          }
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        this.setData({
          loading: false
        })
      })
  },
  handleSubmit() {
    if (this.data.submit_loading) {
      return
    }
    this.setData({
      submit_loading: true
    })
    let obj = {
      member_ids: this.data.result.join(','),
      community_id: this.data.community_id
    }
    wx.showLoading({
      title: '保存中'
    })
    managerAdd(obj)
      .then(res => {
        wx.hideLoading()
        this.setData({
          submit_loading: false
        })
        if (res.code === 200) {
          wx.showToast({
            title: '保存成功',
            icon: 'success'
          })
          wx.navigateBack()
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        wx.hideLoading()
      })
  }
})

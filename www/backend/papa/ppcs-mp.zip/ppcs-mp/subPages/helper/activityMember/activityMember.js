const { getActivityApplyList } = require('./../../../apis/activity')
const { taskRate, createTask } = require('./../../../apis/common')
const { baseUrl } = require('./../../../config')
const app = getApp()
Page({
  data: {
    tabs: [
      {
        title: '未验票',
        type: 'joinCount',
        id: 1
      },
      {
        title: '已验票',
        type: 'createCount',
        id: 2
      }
    ],
    activity_id: '',
    activited: 1,
    countObj: {
      joinCount: 0,
      createCount: 0
    },
    noCheckList: [],
    noCheckPageInfo: {
      page: 1,
      size: 10
    },
    noCheckFinish: false,
    chceckPageInfo: {
      page: 1,
      size: 10
    },
    checkList: [],
    checkFinish: false,
    export_loading: false
  },
  timer: null,
  onShow() {
    try {
      wx.removeStorageSync('registerUserInfo')
    } catch (error) {
      console.log(error)
    }
    console.log('onshow', app.globalData.RefreshRegisterInfoPage)
    if (app.globalData.RefreshRegisterInfoPage) {
      console.log(3213123)
      app.globalData.RefreshRegisterInfoPage = false
      this.resetData()
    }
  },
  onLoad(options) {
    let activity_id = options.activity_id
    this.setData({
      activity_id: activity_id
    })
    this.getNoCheckApplyList()
    this.getCheckApplyList()
  },
  clickTab(e) {
    let id = e.currentTarget.dataset.id
    let offsetLeft = e.currentTarget.offsetLeft
    this.setData({
      activited: id,
      offsetLeft: offsetLeft
    })
  },
  resetData() {
    this.setData({
      activited: 1,
      noCheckFinish: false,
      checkFinish: false,
      'noCheckPageInfo.page': 1,
      'chceckPageInfo.page': 1,
      checkList: [],
      noCheckList: []
    })
    this.getCheckApplyList()
    this.getNoCheckApplyList()
  },
  // 未验票
  getNoCheckApplyList() {
    let obj = Object.assign({ activity_id: this.data.activity_id, status: 1, is_manager: 1 }, this.data.noCheckPageInfo)
    getActivityApplyList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < this.data.noCheckPageInfo.page) {
          this.setData({
            noCheckFinish: true
          })
        }
        let list = res.data.list
        this.data.noCheckList = this.data.noCheckList.concat(list)
        this.setData({
          noCheckList: this.data.noCheckList,
          'countObj.joinCount': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  // 已验票
  getCheckApplyList() {
    let obj = Object.assign({ activity_id: this.data.activity_id, status: 7, is_manager: 1 }, this.data.chceckPageInfo)
    getActivityApplyList(obj).then(res => {
      console.log(res.data)
      if (res.code == 200) {
        if (res.data.list.length < this.data.chceckPageInfo.page) {
          this.setData({
            checkFinish: true
          })
        }

        let list = res.data.list
        this.data.checkList = this.data.checkList.concat(list)
        this.setData({
          checkList: this.data.checkList,
          'countObj.createCount': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },
  onReachBottom() {
    let { activited, noCheckFinish, checkFinish } = this.data
    // 未验票
    if (activited == 1 && !noCheckFinish) {
      this.data.noCheckPageInfo.page += 1
      this.getNoCheckApplyList()
    }
    // 已验票
    if (activited == 2 && !checkFinish) {
      this.data.chceckPageInfo.page += 1
      this.getCheckApplyList()
    }
  },
  onPullDownRefresh: function () {
    let { activited } = this.data
    // 未验票
    if (activited == 1) {
      this.data.noCheckPageInfo.page = 1
      this.setData({
        noCheckList: [],
        key_word: '',
        noCheckFinish: false
      })
      this.getNoCheckApplyList()
    }
    // 已验票
    if (activited == 2) {
      this.data.chceckPageInfo.page = 1
      this.setData({
        checkList: [],
        key_word: '',
        checkFinish: false
      })
      this.getCheckApplyList()
    }
  },
  handleExport() {
    if (this.data.export_loading) {
      this.showToast('请勿重复操作')
      return
    }
    let obj = {
      task_name: 'activityPlatform_ActivityApplyList',
      activity_id: this.data.activity_id,
      no_location: 1
    }
    this.setData({
      export_loading: true
    })
    wx.showLoading({
      title: '生成中'
    })

    createTask(obj).then(res => {
      if (res.code === 200) {
        obj = Object.assign(obj, { task_id: res.data.task_id })
        this.timer = setInterval(() => {
          taskRate(obj).then(res => {
            let data = res.data
            if (res.code === 200) {
              if (data.status === 1) {
                if (data.completed.path) {
                  let url = baseUrl + data.completed.path
                  this.openDocument(url)
                  clearInterval(this.timer)
                  this.timer = null
                  this.setData({
                    export_loading: false
                  })
                  wx.hideLoading()
                } else {
                  wx.hideLoading()
                  this.showToast('报名信息导出失败！')
                  this.setData({
                    export_loading: false
                  })
                  clearInterval(this.timer)
                  this.timer = null
                }
              } else {
                if (data.status === 2) {
                } else if (data.status === 3) {
                  // 上一个旧文件
                }
              }
            } else {
              console.log(res)
              this.showToast(res.message)
              wx.hideLoading()
              clearInterval(this.timer)
              this.setData({
                export_loading: false
              })
              this.timer = null
            }
          })
        }, 1000)
      } else {
        wx.hideLoading()
        this.showToast(res.message)
      }
    })
  },
  openDocument(url) {
    wx.downloadFile({
      url: url,
      success(res) {
        if (res.statusCode == 200) {
          wx.openDocument({
            filePath: res.tempFilePath,
            fileType: 'xls',
            showMenu: true,
            success: function (res) {},
            fail: function (err) {
              this.showToast('文件打开失败！')
            },
            complete: function () {
              wx.hideLoading()
            }
          })
        }
      }
    })
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  }
})

const app = getApp()
const { getCirlces } = require('../../../apis/helper')
Page({
  data: {
    userInfo: {
      avatarUrl: '',
      nickName: ''
    },
    circles: []
  },
  onLoad(options) {
    this.getMember()
  },

  getMember() {
    this.setData({
      userInfo: {
        avatarUrl: app.globalData.userInfo.avatar_url,
        nickName: app.globalData.userInfo.nick_name
      }
    })
  },
  // 获取星球
  getCircles() {
    getCirlces().then(res => {
      // if (res.data.length === 1) {
      //   // 一个直接跳转到首页
      //   wx.navigateTo({
      //     url: `/subPages/helper/index/index?community_id=${res.data[0].community_id}`
      //   })
      // }
      this.setData({
        circles: res.data
      })
    })
  },
  navIndex(e) {
    wx.navigateTo({
      url: `/subPages/helper/index/index?community_id=${e.currentTarget.dataset.community_id}`
    })
  },
  onReady() {},
  onShow() {
    this.getCircles()
  }
})

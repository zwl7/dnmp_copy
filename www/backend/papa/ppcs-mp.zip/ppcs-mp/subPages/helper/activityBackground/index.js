const app = getApp()
Page({
  data: {
    image_list: [
      'https://api.wesais.com/images/20230209/72ba62bb0677ddf66c284f19897a199a.jpg',
      'https://api.wesais.com/images/20230209/cd1fa53aaa9043545bcf1d95f9b854d7.jpg',
      'https://api.wesais.com/images/20230209/b467be67af2ba590101e5e802f25542d.jpg',
      'https://api.wesais.com/images/20230209/a4dae8b79877099fc9e1b3eb8210331a.jpg',
      'https://api.wesais.com/images/20230209/cea9f6dea83807a5fdd74fa73284e874.jpg',
      'https://api.wesais.com/images/20230209/6b02f5792a90e737c7fee01e245ac217.jpg'
    ]
  },
  handleSelect(event) {
    let { image } = event.currentTarget.dataset
    app.globalData.activityBackgroundImage = image
    wx.navigateBack()
  }
})

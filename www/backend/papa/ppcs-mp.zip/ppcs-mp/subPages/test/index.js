// subPages/test/index.js
Page({
  /**
   * 页面的初始数据
   */
  data: {},

  handleClick() {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  }
})

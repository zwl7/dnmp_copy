var host = 'https://cdn-static.papa.com.cn/ppcs_mp' //图片服务地址  到时候没用的话就删除
const company_id = 54
var env = 'develop'
var baseUrl = 'http://api.linksports.com.cn:8180' //接口地址
var uploadUrl = 'https://apitest.wesais.cn' //图片上传地址  到时
var qqmapKey = 'KAOBZ-AHQ65-KY3ID-QJ72A-EXXNQ-42BNK'
var default_city_name = '上海'
var default_city_id = '3100' //默认城市id
var default_latitude = '31.23037'
var default_longitude = '121.4737'
var config = {
  host,
  env,
  baseUrl,
  uploadUrl,
  company_id,
  qqmapKey,
  default_city_name,
  default_city_id,
  default_latitude,
  default_longitude
}

module.exports = config

// 深圳
// city_id: '4403',
// latitude: '22.54286',
// longitude: '114.05956',

const buttonClick = require('./../../utils/buttonClick')
const createRecycleContext = require('./../../components/miniprogram-recycle-view/index')
const { getActivityList } = require('../../apis/activity')
const { getSetting, getTabListByIds } = require('../../apis/index')
const { map } = require('./../../utils/util')
const { setLocationInfo, getLocationInfo, clearLocationInfo } = require('./../../utils/storage')
const config = require('./../../config')
var QQMapWX = require('./../../utils/qqmap-wx-jssdk')
const app = getApp()
var qqmapsdk = ''
Page({
  data: {
    refresherenabled: true,
    triggered: false,
    myProperty: {
      backgroundColor: '#f7ece2',
      isFindPage: true
    },
    scrollTop: 0,
    navBarHeight: 0,
    isFixed: false,
    scrollTop: 0,
    tabBackageColor: '',
    tabs: [
      {
        name: '推荐活动',
        resource_type_id: 0
      }
    ],
    showSelected: true,
    selectedValue: 'time',
    selectList: [
      {
        text: '时间最近',
        value: 'time'
      },
      {
        text: '距离最近',
        value: 'distance_asc'
      }
    ],
    tabActived: 0,
    avatar: app.globalData.config.host + '/avatar_1.png',
    recycleList: [],
    loading: true,
    finished: false,
    have_cityid_finished: false,
    page: 1,
    activities: [],
    get_success_location: true //获取定位成功
  },

  onLoad(options) {
    qqmapsdk = new QQMapWX({
      key: config.qqmapKey
    })
    let { navBarHeight } = app.globalData
    app.watchGlobalData('is_change_city', 'find', this.watchChangeCityFind.bind(this))
    this.setData({
      navBarHeight: navBarHeight
    })
    var ctx = createRecycleContext({
      id: 'recycleId2',
      dataKey: 'recycleList',
      page: this,
      itemSize: {
        width: 100,
        height: 191
      }
    })
    this.ctx = ctx
    if (!app.globalData.is_get_location) {
      this.getLocation().then(res => {
        this.getSetting()
      })
    } else {
      this.getSetting()
    }
  },
  touchend() {
    if (this.ctx.getScrollTop() < -100) {
      this.setData({
        finished: false,
        have_cityid_finished: false,
        page: 1,
        activities: []
      })
      this.ctx.splice(0, this.data.activities.length)
      this.getActivities()
    }
  },
  onShow(options) {
    let RefreshFindPage = app.globalData.RefreshFindPage
    if (RefreshFindPage) {
      console.log('执行')
      this.changeTab({
        detail: 0
      })
      app.globalData.RefreshFindPage = false
    }
  },
  resetData() {
    this.setData({
      recycleList: [],
      finished: false,
      have_cityid_finished: false,
      page: 1,
      tabs: [
        {
          name: '推荐活动',
          resource_type_id: 0
        }
      ]
    })
    this.ctx.splice(0, 10000000)
    this.getSetting()
  },
  watchChangeCityFind(value) {
    console.log('-----------------find', value)
    if (value) {
      this.resetData()
    }
  },
  // 滚动条滚动到底部
  scrollBottom() {
    const that = this
    console.log('this.data.finished', this.data.finished)
    if (!this.data.finished) {
      buttonClick.throttle(function () {
        that.setData({
          page: that.data.page + 1
        })
        that.getActivities()
      }, 1500)()
    }
  },
  showOrders() {
    this.setData({
      showSelected: true
    })
  },
  selOrder(e) {
    this.ctx.splice(0, this.data.activities.length)
    this.setData({
      selectedValue: e.detail,
      finished: false,
      have_cityid_finished: false,
      page: 1,
      activities: []
    })
    this.getActivities()
  },
  // 切换tab
  changeTab(e) {
    console.log(e)
    this.ctx.splice(0, this.data.activities.length)
    this.setData({
      tabActived: e.detail,
      loading: true,
      finished: false,
      have_cityid_finished: false,
      page: 1,
      activities: []
    })
    this.getActivities()
  },
  // 获取活动
  getActivities() {
    if (this.data.finished) {
      this.setData({
        loading: false
      })
      return
    }
    this.setData({
      loading: true
    })
    let obj = {
      type_id: this.data.tabActived,
      order_by: this.data.selectedValue,
      page: this.data.page,
      size: 10,
      latitude: app.globalData.user_latitude,
      longitude: app.globalData.user_longitude
    }
    if (this.data.have_cityid_finished) {
      obj = Object.assign(obj, {
        no_city_id: 1
      })
    }
    getActivityList(obj)
      .then(res => {
        this.setData({
          loading: false
        })

        // 不带城市id
        if (this.data.have_cityid_finished && res.data.list.length === 0) {
          this.setData({
            finished: true
          })
          return
        }
        res.data.list.map(item => {
          if (item.distance <= 1000) {
            // 1km以内精确到米
            item.distance = item.distance.toFixed(1) + 'M'
          } else if (item.distance > 1000 && item.distance < 100000) {
            // 1km-100km精确到小数点后1位
            item.distance = Math.round((item.distance / 1000) * 10) / 10 + 'KM'
          } else {
            // 大于等于100km只取整数部分
            item.distance = Math.round(item.distance / 1000) + 'KM'
          }
        })
        this.data.activities = this.data.activities.concat(res.data.list)
        this.ctx.append(res.data.list)
        this.setData({
          activities: this.data.activities
        })
        // 带城市id
        if (!this.data.have_cityid_finished && res.data.list.length < 10) {
          this.setData({
            have_cityid_finished: true,
            page: 1
          })
          this.getActivities()
          return
        }
      })
      .catch(err => {
        this.setData({
          loading: false
        })
      })
  },
  //获取设置
  getSetting() {
    // 首页设置
    getSetting('find').then(res => {
      let { tab } = res.data
      let tabs = this.data.tabs
      tab = tab.join(',')
      // tabs
      getTabListByIds(tab).then(res => {
        let arrMap = map(res.data.list, null, 'resource_type_id')
        tab.split(',').map(item => {
          if (arrMap[item]) {
            tabs.push(arrMap[item])
          }
        })
        const tabActived = tabs.length > 0 ? tabs[0].resource_type_id : 0
        console.log(tabs)
        this.setData({
          tabs,
          tabActived
        })
        this.getActivities()
      })
    })
  },

  onReady() {},
  bindscroll(e) {
    let { scrollTop, isFixed } = e.detail
    if (isFixed) {
      this.setData({
        tabBackageColor: '#f7ece2'
      })
    } else {
      this.setData({
        tabBackageColor: ''
      })
    }
  },
  // 搜索页面
  tosearch: buttonClick.buttonClicked(function () {
    wx.navigateTo({
      url: '/pages/search/search'
    })
  }),
  getLocation() {
    let _this = this
    return new Promise(resolve => {
      try {
        wx.getFuzzyLocation({
          type: 'wgs84',
          success(res) {
            console.log('---获取经纬度', res)
            const latitude = res.latitude
            const longitude = res.longitude
            app.globalData.latitude = latitude
            app.globalData.longitude = longitude
            app.globalData.user_latitude = latitude
            app.globalData.user_longitude = longitude
            app.globalData.is_get_location = true
            if (app.globalData.city) {
              getLocationInfo().then(res => {
                if (res) {
                  res.latitude = latitude
                  res.longitude = longitude
                  setLocationInfo(res).then(res => {
                    resolve(true)
                  })
                }
              })
            } else {
              _this.getLocal(latitude, longitude)
              resolve(false)
            }
          },
          fail(error) {
            console.log('首页wx.getFuzzyLocation失败,', error)
            // wx.showToast({
            //   title: '经纬度获取失败',
            //   icon: 'none'
            // })
            resolve(false)
          }
        })
      } catch (error) {
        // wx.showToast({
        //   title: '经纬度获取失败',
        //   icon: 'none'
        // })
        _this.setData({ get_success_location: false })
        _this.getLocal(app.globalData.latitude, app.globalData.longitude)
        resolve(false)
        console.error('定位授权', error)
      }
    })
  },
  getLocal(latitude, longitude) {
    let _this = this
    if (qqmapsdk) {
      qqmapsdk.reverseGeocoder({
        location: {
          latitude: latitude,
          longitude: longitude
        },
        success(res) {
          let city = res.result.ad_info.city
          let city_code = res.result.ad_info.city_code
          city_code = String(city_code).slice(3, 7)
          app.globalData.city = city
          app.globalData.city_id = city_code

          let addressInfo = {
            latitude: latitude,
            longitude: longitude,
            city: city,
            city_id: city_code,
            date: new Date().getTime(),
            is_user_select: false
          }
          setLocationInfo(addressInfo).then(res => {
            _this.getSetting()
          })
        },
        fail(error) {
          console.error(error)
          app.globalData.city = config.default_city_name
          app.globalData.latitude = config.default_latitude
          app.globalData.longitude = config.default_longitude
          app.globalData.city_id = config.default_city_id
          clearLocationInfo()
        }
      })
    }
  },
  onRefresh(e) {
    this.setData({
      recycleList: [],
      finished: false,
      have_cityid_finished: false,
      page: 1
    })
    this.ctx.splice(0, 10000000)
    this.getActivities()
    setTimeout(() => {
      this.setData({
        triggered: false
      })
    }, 500)
  }
})

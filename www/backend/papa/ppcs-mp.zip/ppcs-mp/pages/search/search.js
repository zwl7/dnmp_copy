const { getWxCommunityList } = require('./../../apis/circle')
const { getWxActivityList } = require('./../../apis/activity')
const { formatActivityTime } = require('./../../utils/date')
const { setGlobalSearchKey, getGlobalSearchKey, clearGlobalSearchKey } = require('./../../utils/storage')
Page({
  data: {
    tabActive: '1',
    searchKeyword: '',
    searchKeywordList: [],
    showSearchResult: false,
    // 星球
    communityList: [],
    communityPage: {
      page: 1,
      size: 2
    },
    communityFinish: false,
    showCommunityMore: false,
    // 活动
    activityList: [],
    activityPage: {
      page: 1,
      size: 2
    },
    activityFinish: false,
    showActivityMore: false
  },
  onLoad(options) {
    this.getSearchList()
  },
  onShow() {},
  changeTab: function (e) {
    let { name } = e.detail
    this.setData({
      tabActive: name
    })
    this.changeTabActivityId(name)
  },
  changeTabActivityId(name) {
    if (name == 1) {
      this.setData({
        'communityPage.page': 1,
        'communityPage.size': 2,
        communityFinish: false,
        'activityPage.page': 1,
        'activityPage.size': 2,
        activityFinish: false,
        communityList: [],
        activityList: []
      })
      this.getCommunityList()
      this.getActivityList()
    }
    if (name == 2) {
      this.setData({
        'communityPage.page': 1,
        'communityPage.size': 10,
        communityFinish: false,
        communityList: []
      })
      this.getCommunityList()
    }
    if (name == 3) {
      this.setData({
        'activityPage.page': 1,
        'activityPage.size': 10,
        activityFinish: false,
        activityList: []
      })
      this.getActivityList()
    }
  },
  // 点击搜索
  handleSearch(event) {
    let keyword = event.detail
    this.setData({
      searchKeyword: keyword,
      showSearchResult: true,
      'activityPage.page': 1,
      'communityPage.page': 1,
      showCommunityMore: false,
      showActivityMore: false,
      communityList: [],
      activityList: []
    })
    if (keyword) {
      this.getCommunityList()
      this.getActivityList()
      this.pushHistory(keyword)
    }
  },
  pushHistory(keyword) {
    let searchKeywordList = this.data.searchKeywordList
    let index = searchKeywordList.indexOf(keyword)
    if (index === -1 && searchKeywordList.length <= 10) {
      searchKeywordList.push(keyword)
    }
    this.setData({
      searchKeywordList: searchKeywordList
    })
    this.setSearchList()
  },
  // 加载星球列表
  getCommunityList() {
    let obj = Object.assign({ keyword: this.data.searchKeyword, no_location: 1 }, this.data.communityPage)
    getWxCommunityList(obj)
      .then(res => {
        if (res.code === 200) {
          if (res.data.list.length < this.data.communityPage.size && this.data.communityPage.size !== 2) {
            this.setData({
              communityFinish: true
            })
          }
          if (this.data.tabActive == 1 && res.data.list.length > 0 && !this.data.communityFinish) {
            this.setData({
              showCommunityMore: true
            })
          }
          let list = []
          res.data.list.map(e => {
            list.push({
              images: e.images,
              community_id: e.community_id,
              name: e.name,
              is_auth: e.is_auth,
              activity_num: e.activity_num,
              people_num: e.people_num
            })
          })
          this.data.communityList = this.data.communityList.concat(list)
          this.setData({
            communityList: this.data.communityList
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        wx.stopPullDownRefresh()
      })
      .catch(() => {
        wx.stopPullDownRefresh()
      })
  },
  // 加载活动列表
  getActivityList() {
    let obj = Object.assign({ keyword: this.data.searchKeyword }, this.data.activityPage)
    getWxActivityList(obj)
      .then(res => {
        if (res.code === 200) {
          if (res.data.list.length < this.data.activityPage.size && this.data.activityPage.size !== 2) {
            this.setData({
              activityFinish: true
            })
          }
          if (this.data.tabActive == 1 && res.data.list.length > 0 && !this.data.activityFinish) {
            this.setData({
              showActivityMore: true
            })
          }
          let list = this.handleActivityList(res.data.list)
          this.data.activityList = this.data.activityList.concat(list)
          this.setData({
            activityList: this.data.activityList
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        wx.stopPullDownRefresh()
      })
      .catch(() => {
        wx.stopPullDownRefresh()
      })
  },
  //处理活动列表数据
  handleActivityList(data) {
    let list = []
    let now = new Date().getTime()
    data.map(e => {
      list.push({
        activity_id: e.activity_id,
        images: e.images,
        name: e.name,
        date: formatActivityTime(e.start_time, e.end_time),
        address: e.address,
        apply_member: e.apply_member.slice(0, 3),
        apply_num: e.apply_num,
        tag: e.tag.slice(0, 3),
        show_end: Number(e.end_time) * 1000 < now,
        show_dismiss: e.status == 4 ? true : false,
        activity_type: e.activity_type
      })
    })
    return list
  },
  onPullDownRefresh() {
    let { tabActive } = this.data
    if (tabActive == 1) {
      this.setData({
        'activityPage.page': 1,
        activityFinish: false,
        'communityPage.page': 1,
        communityFinish: false,
        activityList: [],
        communityList: []
      })
      this.getActivityList()
      this.getCommunityList()
    }
    if (tabActive == 3) {
      this.setData({
        'activityPage.page': 1,
        activityFinish: false,
        activityList: []
      })
      this.getActivityList()
    }
    if (tabActive == 2) {
      this.setData({
        'communityPage.page': 1,
        communityFinish: false,
        communityList: []
      })
      this.getCommunityList()
    }
    setTimeout(() => {
      wx.stopPullDownRefresh()
    }, 100)
  },
  onReachBottom() {
    let { tabActive, activityFinish, communityFinish } = this.data
    if (tabActive == 3 && !activityFinish) {
      this.setData({
        'activityPage.page': this.data.activityPage.page + 1
      })
      this.getActivityList()
    }
    if (tabActive == 2 && !communityFinish) {
      this.setData({
        'communityPage.page': this.data.communityPage.page + 1
      })
      this.getCommunityList()
    }
  },
  // 点击查看更多
  viewMore(event) {
    let { index } = event.currentTarget.dataset
    this.setData({
      tabActive: String(index)
    })
    // this.changeTabActivityId(index)
  },
  //搜索历史
  getSearchList() {
    getGlobalSearchKey()
      .then(res => {
        if (Array.isArray(res)) {
          this.setData({
            searchKeywordList: res
          })
        }
      })
      .catch(err => {
        console.log(err)
        clearGlobalSearchKey()
      })
  },
  setSearchList() {
    let searchKeywordList = this.data.searchKeywordList
    setGlobalSearchKey(searchKeywordList)
  },
  handleClickHistory(event) {
    let { item } = event.currentTarget.dataset
    if (item) {
      this.setData({
        showSearchResult: true
      })
      this.handleSearch({ detail: item })
    }
  },
  clearHistory() {
    if (this.data.searchKeywordList.length === 0) {
      return
    }
    clearGlobalSearchKey()
    this.setData({
      searchKeywordList: []
    })
  }
})

const { buttonClicked } = require('./../../utils/buttonClick')
const { getUserInfo } = require('./../../apis/login')
const { getMyCalendarActivity, getMyCollectList, getMyPublishList } = require('./../../apis/activity')
const { getWxMemberNoticeCount } = require('./../../apis/common')
const { formatActivityTime } = require('./../../utils/date')
const { getWxDistributionAuth, getMyAccountInfo } = require('./../../apis/account')
const app = getApp()
Page({
  data: {
    myProperty: {
      backgroundColor: 'rgba(255, 255, 255, 0)',
      color: '',
      name: ''
    },
    navBarHeight: 0,
    menuRight: 0,
    menuTop: 0,
    menuHeight: 0,
    leftStyle: '',
    userInfo: {
      avatar_url: '',
      nick_name: '',
      sex: 0,
      is_authenticate: 0,
      signature: '还没有个性签名~'
    },
    userStaticInfo: {
      community_num: 0,
      activity_num: 0
    },
    current_tab_id: 1,
    activityTabOptions: [
      {
        title: '我的日程',
        count: 0,
        id: 1
      },
      {
        title: '收藏活动',
        count: 0,
        id: 2
      },
      {
        title: '我管理的',
        count: 0,
        id: 3
      }
    ],
    // 我的日程
    myApplyPage: {
      page: 1,
      size: 10
    },
    myApplyFinish: false,
    myApplyList: [],
    // 收藏活动
    myCollectPage: {
      page: 1,
      size: 10
    },
    myCollectFinish: false,
    myCollectList: [],
    // 我发布的
    myPublishPage: {
      page: 1,
      size: 10
    },
    myPublishFinish: false,
    myPublishList: [],
    helperDialog: {
      tip: '您还未创建属于自己的星球?',
      cancelText: '下一次',
      confirmText: '去创建'
    },
    loading: false,
    no_read: 0, //站内信未读
    noticeCountTimer: null,
    apply_status: -1,
    amount: {
      can_draw_amount: '0.00',
      has_draw_amount: '0.00'
    }
  },
  onLoad(options) {
    let { apply } = options
    if (apply) {
      setTimeout(() => {
        if (this.selectComponent('#Application')) {
          this.selectComponent('#Application').showDialog()
        }
      }, 100)
    }
    let { menuRight, menuTop, navBarHeight, menuHeight } = app.globalData
    this.setData({
      navBarHeight,
      menuRight,
      menuTop,
      menuHeight
    })
    app.watchGlobalData('userStaticInfo', 'minePage', this.watchUserStaticInfo.bind(this))
    app.globalData.RefreshMinePage = true

    // this.data.noticeCountTimer = setInterval(() => {
    //   this.getWxMemberNoticeCount()
    // }, 1000 * 60)
  },
  onUnload() {
    if (this.data.noticeCountTimer) {
      clearInterval(this.data.noticeCountTimer)
      this.setData({
        noticeCountTimer: null
      })
    }
  },
  onShow(options) {
    if (!app.globalData.userInfo.token) {
      this.getUserInfo()
    } else {
      let userInfo = {
        avatar_url: app.globalData.userInfo.avatar_url,
        nick_name: app.globalData.userInfo.nick_name,
        sex: app.globalData.userInfo.sex,
        is_authenticate: app.globalData.userInfo.is_authenticate,
        signature: app.globalData.userInfo.signature
      }
      this.setData({
        userInfo: userInfo
      })
      this.getUserInfo()
    }
    if (app.globalData.RefreshMinePage) {
      this.getUserInfo()
      this.resetData()
      app.globalData.RefreshMinePage = false
    }
    if (app.globalData.createCircle) {
      try {
        setTimeout(() => {
          app.globalData.createCircle = false
          this.selectComponent('#createCircleDialog').showDialog()
        }, 100)
      } catch (error) {}
    }
    this.getWxMemberNoticeCount()
    this.getApplyStatus()
  },
  toLogin: buttonClicked(function () {
    wx.reLaunch({
      url: '/subPages/system/login/login?page=mine'
    })
  }, 1000),
  getUserInfo() {
    getUserInfo({}).then(res => {
      if (res.code === 200) {
        let userInfo = {
          avatar_url: res.data.avatar_url,
          nick_name: res.data.nick_name,
          sex: res.data.sex,
          is_authenticate: res.data.is_authenticate,
          signature: res.data.signature
        }
        app.globalData.official_auth = res.data.official_auth
        this.setData({
          userInfo: userInfo
        })
        if (res.data.is_authenticate === -1) {
          this.toLogin()
        }
      } else {
        wx.showToast({
          title: res.message,
          icon: 'error'
        })
      }
    })
  },
  // 监听我的星球活动
  watchUserStaticInfo(value) {
    let { create_community, join_community, join_activity } = value
    let userStaticInfo = {
      community_num: Number(create_community) + Number(join_community),
      activity_num: Number(join_activity)
    }
    this.setData({
      userStaticInfo: userStaticInfo
    })
  },
  onPullDownRefresh: function () {},
  onReachBottom() {
    let { current_tab_id, myApplyFinish, myCollectFinish, myPublishFinish } = this.data
    if (current_tab_id == 1 && !myApplyFinish) {
      this.setData({
        'myApplyPage.page': this.data.myApplyPage.page + 1
      })
      this.getMyCalendarActivity()
    }
    if (current_tab_id == 2 && !myCollectFinish) {
      this.setData({
        'myCollectPage.page': this.data.myCollectPage.page + 1
      })
      this.getMyCollectList()
    }
    if (current_tab_id == 3 && !myPublishFinish) {
      this.setData({
        'myPublishPage.page': this.data.myPublishPage.page + 1
      })
      this.getMyPublishList()
    }
  },
  getTabType(event) {
    let { id } = event.detail
    this.setData({
      current_tab_id: id
    })
  },
  // 重置数据
  resetData() {
    this.setData({
      loading: true
    })
    this.setData({
      'myApplyPage.page': 1,
      'myCollectPage.page': 1,
      'myPublishPage.page': 1,
      myApplyFinish: false,
      myCollectFinish: false,
      myPublishFinish: false,
      myApplyList: [],
      myCollectList: [],
      myPublishList: []
    })
    this.getMyCalendarActivity()
    this.getMyCollectList()
    this.getMyPublishList()
  },
  // 我的日程
  getMyCalendarActivity() {
    let now = Math.ceil(new Date().getTime() / 1000)
    let obj = Object.assign({ gte_end_time: now }, this.data.myApplyPage)
    getMyCalendarActivity(obj).then(res => {
      if (res.code === 200) {
        let list = this.handleActivityList(res.data, 1)
        this.data.myApplyList = this.data.myApplyList.concat(list)
        this.setData({
          myApplyList: this.data.myApplyList,
          'activityTabOptions[0].count': res.data.length,
          myApplyFinish: true
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
      if (this.data.loading) {
        this.setData({
          loading: false
        })
      }
    })
  },
  // 我得收藏
  getMyCollectList() {
    let obj = Object.assign({}, this.data.myCollectPage)
    getMyCollectList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < this.data.myCollectPage.size) {
          this.setData({
            myCollectFinish: true
          })
        }
        let list = this.handleActivityList(res.data.list, 2)
        this.data.myCollectList = this.data.myCollectList.concat(list)
        this.setData({
          myCollectList: this.data.myCollectList,
          'activityTabOptions[1].count': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
      if (this.data.loading) {
        this.setData({
          loading: false
        })
      }
    })
  },
  // 我发布的
  getMyPublishList() {
    let obj = Object.assign({}, this.data.myPublishPage)
    getMyPublishList(obj).then(res => {
      if (res.code === 200) {
        if (res.data.list.length < this.data.myPublishPage.size) {
          this.setData({
            myPublishFinish: true
          })
        }
        let list = this.handleActivityList(res.data.list, 3)
        this.data.myPublishList = this.data.myPublishList.concat(list)
        this.setData({
          myPublishList: this.data.myPublishList,
          'activityTabOptions[2].count': res.data.count
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
      if (this.data.loading) {
        this.setData({
          loading: false
        })
      }
    })
  },
  //处理活动列表数据
  handleActivityList(data, type) {
    let list = []
    let now = new Date().getTime()
    data.map(e => {
      list.push({
        activity_id: e.activity_id,
        images: e.status != 3 ? e.images : app.globalData.weigui_activity_png,
        name: e.status != 3 ? e.name : '违规活动',
        date: formatActivityTime(e.start_time, e.end_time),
        address: e.address,
        apply_member: e.apply_member.slice(0, 3),
        apply_num: e.apply_num,
        tag: e.tag.slice(0, 3),
        show_end: Number(e.end_time) * 1000 < now,
        show_dismiss: e.status == 4 ? true : false,
        is_manager: app.judgeIsJoin(e.community_id, 3),
        is_free: e.is_free,
        order_no: e.order_no,
        status: e.status,
        show_tag: type != 2 ? true : false,
        activity_type: e.activity_type
      })
    })
    return list
  },
  // 查看更多我的日程
  viewMoreApplyList() {
    let url = '/subPages/activity/historyActivity/index'
    wx.navigateTo({
      url: url
    })
  },
  // 管理助手
  helper() {
    let { create_community } = app.globalData.userStaticInfo
    let { official_auth } = app.globalData
    if (official_auth != 1) {
      this.selectComponent('#officalAuthDialog').showDialog()
    } else if (official_auth == 1 && create_community === 0) {
      this.selectComponent('#helperDialog').showDialog()
    } else {
      wx.navigateTo({
        url: '/subPages/helper/login/index'
      })
    }
    return
    let { is_authenticate } = app.globalData.userInfo
    if (is_authenticate === -1) {
      wx.navigateTo({
        url: '/subPages/system/login/login?need_auth=1&page=index'
      })
      return
    }
    if (is_authenticate === 0) {
      this.selectComponent('#officalAuthDialog').showDialog()
      return
    }
    if (is_authenticate === 1 && create_community === 0) {
      this.selectComponent('#helperDialog').showDialog()
      return
    }
    if (is_authenticate === 1 && create_community > 0) {
      wx.navigateTo({
        url: '/subPages/helper/login/index'
      })
      return
    }
  },
  cancelHelper() {},
  confirmlHelper() {
    wx.navigateTo({
      url: '/subPages/circle/create/create'
    })
  },
  // 实名弹窗确认
  authConfirm() {
    wx.navigateTo({
      url: '/subPages/system/Authentication/index?page=mine'
    })
  },
  officeAuthConfirm() {
    if (app.globalData.userInfo.is_authenticate === -1) {
      wx.navigateTo({
        url: '/subPages/system/login/login?page=entrance'
      })
    } else {
      wx.navigateTo({
        url: '/accountPages/entrance/entrance'
      })
    }
  },
  // 点击添加活动星球按钮
  clickPlus() {
    if (app.globalData.official_auth != 1) {
      this.selectComponent('#officalAuthDialog').showDialog()
    } else {
      this.selectComponent('#joinBtn').showDialog()
    }
  },
  createCircleDialogConfirm() {
    let { community_id, community_name } = app.globalData.createCircleInfo
    if (community_id && community_name) {
      let url = '/subPages/activity/create/create'
      url = url.concat('?community_id=', community_id).concat('&community_name=', community_name).concat('&op=', 'add')
      wx.navigateTo({
        url: url
      })
      app.globalData.createCircleInfo.community_id = ''
      app.globalData.createCircleInfo.community_name = ''
    } else {
      wx.navigateTo({
        url: '/subPages/circle/selectCircle/index'
      })
    }
  },
  dataEmpty() {
    //  // 我的日程
    //  myApplyPage: {
    //   page: 1,
    //   size: 10
    // },
    // myApplyFinish: false,
    // myApplyList: [],
    // // 收藏活动
    // myCollectPage: {
    //   page: 1,
    //   size: 10
    // },
    // myCollectFinish: false,
    // myCollectList: [],
    // // 我发布的
    // myPublishPage: {
    //   page: 1,
    //   size: 10
    // },
    // myPublishFinish: false,
    this.setData({ myApplyList: [], myCollectList: [], myPublishList: [] })
  },
  // 获取站内信
  getWxMemberNoticeCount() {
    getWxMemberNoticeCount()
      .then(res => {
        if (res.code === 200) {
          this.setData({
            no_read: res.data.no_read
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        wx.showToast({
          title: err,
          icon: 'none'
        })
      })
  },
  onPageScroll(event) {
    var a = event.scrollTop
    var e = a / 180
    if (a < 50) {
      this.setData({
        'myProperty.backgroundColor': 'rgba(255, 255, 255, 0)',
        'myProperty.color': 'rgba(0, 0, 0, 0)',
        'myProperty.name': ''
      })
    } else {
      if (a < 180) {
        this.setData({
          'myProperty.backgroundColor': 'rgba(255, 255, 255, '.concat(e, ')'),
          'myProperty.color': 'rgba(0, 0, 0, '.concat(e, ')'),
          'myProperty.name': '我的'
        })
      } else {
        this.setData({
          'myProperty.backgroundColor': 'rgba(255, 255, 255, 1)',
          'myProperty.color': 'rgba(0, 0, 0, 1)',
          'myProperty.name': '我的'
        })
      }
    }
  },
  // 获取审核状态
  async getApplyStatus() {
    // 状态 0:审核中 1:审核通过 2:待签约 3:待验证 4:驳回 -1 未申请
    const { data } = await getWxDistributionAuth({})
    if (Object.values(data).length) {
      data.beneficiary_user_list = data.user_list
      wx.setStorageSync('wxDistributionAuth', JSON.stringify(data))
      this.setData({
        apply_status: data.status
      })
      if (data.status === 1) {
        this.getMyAccountInfo()
      }
    } else {
      wx.removeStorageSync('applyAccountForm')
      wx.removeStorageSync('wxDistributionAuth')
    }
  },
  getMyAccountInfo() {
    getMyAccountInfo({}).then(res => {
      if (res.code === 200) {
        this.setData({
          amount: res.data
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  }
})

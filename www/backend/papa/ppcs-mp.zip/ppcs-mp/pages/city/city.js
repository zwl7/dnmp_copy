var city = require('../../utils/city.js')
const { setLocationInfo } = require('./../../utils/storage')
var buttonClick = require('./../../utils/buttonClick')
const { qqmapKey } = require('./../../config')
var QQMapWX = require('./../../utils/qqmap-wx-jssdk')
const app = getApp()
var qqmapsdk
Page({
  data: {
    //城市下拉
    cityName: app.globalData.city,
    cityData: {},
    hotCityData: [],
    _py: ['hot', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'W', 'X', 'Y', 'Z'],
    tipHidden: true,
    showPy: '★',
    letterCitiesHeight: [],
    statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
    scrollIntoViewLetterLock: '',
    scrollIntoViewLetter: '',
    // 搜索参数
    inputValue: '',
    searchResponse: [],
    page: 'index'
  },
  onLoad: function (options) {
    if (options.page) {
      this.setData({
        page: options.page
      })
    }
    qqmapsdk = new QQMapWX({
      key: qqmapKey
    })

    this.setData({
      cityData: city.all,
      hotCityData: city.hot,
      cityName: app.globalData.city
    })
    this.handleCalculateHeight()
  },

  //选择城市
  selectCity: function (e) {
    var dataset = e.currentTarget.dataset
    let city_id = String(dataset.id).slice(0, 4)
    console.log(city_id)
    app.globalData.city = dataset.fullname
    app.globalData.latitude = dataset.lat
    app.globalData.longitude = dataset.lng
    app.globalData.city_id = city_id
    app.globalData.is_change_city = true
    let addressInfo = {
      latitude: dataset.lat,
      longitude: dataset.lng,
      city: dataset.fullname,
      city_id: city_id,
      date: new Date().getTime(),
      is_user_select: true
    }
    setLocationInfo(addressInfo)
    setTimeout(() => {
      wx.navigateBack({
        delta: 1
      })
    }, 10)
  },
  touchstart: function (e) {
    this.setData({
      index: e.currentTarget.dataset.index,
      Mstart: e.changedTouches[0].pageX
    })
  },
  touchmove: function (e) {},
  touchend: function (e) {},
  //获取文字信息
  getPy: function (e) {
    this.setData({
      tipHidden: false,
      showPy: e.target.id
    })
    this.setData({
      scrollIntoViewLetterLock: e.target.id
    })
  },

  setPy: function (e) {
    this.setData({
      tipHidden: true,
      scrollTopId: this.data.showPy,
      scrollIntoViewLetter: this.data.showPy
    })
  },

  //滑动选择城市
  tMove: function (e) {
    var y = e.touches[0].clientY,
      offsettop = e.currentTarget.offsetTop

    //判断选择区域,只有在选择区才会生效
    if (y > offsettop) {
      var num = parseInt((y - offsettop) / 12)
      this.setData({
        showPy: this.data._py[num]
      })
    }
  },

  //触发全部开始选择
  tStart: function () {
    this.setData({
      tipHidden: false
    })
  },

  //触发结束选择
  tEnd: function () {
    this.setData({
      tipHidden: true,
      scrollTopId: this.data.showPy
    })
  },
  // 滚动事件
  handleListenerScroll(e) {
    let scrollTop = e.detail.scrollTop
    let letterCitiesHeight = this.data.letterCitiesHeight
    let statusBarHeight = this.data.statusBarHeight
    try {
      for (let i = 0; i < letterCitiesHeight.length; i++) {
        const item = letterCitiesHeight[i]
        if (scrollTop >= item.top - (statusBarHeight + 50) && scrollTop <= item.bottom) {
          if (this.data.scrollIntoViewLetterLock) {
            this.setData({
              scrollIntoViewLetter: this.data.scrollIntoViewLetterLock
            })
            setTimeout(() => {
              this.setData({
                scrollIntoViewLetterLock: ''
              })
            }, 300)
            break
          } else {
            this.setData({
              scrollIntoViewLetter: item.id
            })
            break
          }
        }
      }
    } catch (t) {
      console.log(t)
    }
  },
  // 计算每一项的高度
  handleCalculateHeight() {
    var that = this
    wx.createSelectorQuery()
      .in(this)
      .selectAll('.city-box')
      .boundingClientRect(function (e) {
        that.setData({
          letterCitiesHeight: e
        })
      })
      .exec()
  },
  // 搜索框input  focus事件
  handleInput(e) {
    let value = e.detail.detail.value
    if (!value) {
      this.setData({
        searchResponse: []
      })
      return
    }
    buttonClick.debounce(this.getSearchList, 300, false, res => {
      this.setData({ searchResponse: res })
    })(value)
  },
  // 根据关键字筛选出匹配的城市列表
  getSearchList(keyword) {
    if (!keyword) {
      return
    }
    let cityData = city.all
    let list = []
    for (const k in cityData) {
      let item_list = cityData[k]
      item_list.map(e => {
        if (e.fullname.indexOf(keyword) != -1 || e.fullname.indexOf(keyword.name) != -1) {
          list.push(e)
        }
      })
    }
    return list
  },
  getLocation() {
    let _this = this
    wx.getFuzzyLocation({
      type: 'wgs84',
      success(res) {
        const latitude = res.latitude
        const longitude = res.longitude
        app.globalData.latitude = latitude
        app.globalData.longitude = longitude
        _this.getLocal(latitude, longitude)
      },
      fail(error) {
        console.log('首页wx.getFuzzyLocation失败,', error)
        if (app.globalData.latitude && app.globalData.longitude) {
          _this.getLocal(app.globalData.latitude, app.globalData.longitude)
        } else {
          wx.getSetting({
            success(res) {
              if ('undefined' == res.authSetting['scope.userLocation'] || res.authSetting['scope.userLocation']) {
                console.log('系统没有给定位权限=====================', res)
                _this.getDefaultLocation()
              } else {
                console.log('用户拒绝了授权=====================', res)
                _this.getDefaultLocation()
              }
            }
          })
        }
      }
    })
  },
  getDefaultLocation() {},
  getLocal(latitude, longitude) {
    let _this = this
    if (qqmapsdk) {
      qqmapsdk.reverseGeocoder({
        location: {
          latitude: latitude,
          longitude: longitude
        },
        success(res) {
          let city = res.result.ad_info.city
          let city_code = res.result.ad_info.city_code
          city_code = String(city_code).slice(3, 7)
          app.globalData.city = city
          app.globalData.is_change_city = true
          let addressInfo = {
            latitude: latitude,
            longitude: longitude,
            city: city,
            city_id: city_code,
            date: new Date().getTime(),
            is_user_select: false
          }
          setLocationInfo(addressInfo)
          _this.setData({
            cityName: city
          })
          setTimeout(() => {
            wx.navigateBack({
              delta: 1
            })
          }, 500)
        },
        fail(error) {
          console.error(error)
        }
      })
    }
  },
  resetLocation: buttonClick.buttonClicked(function () {
    app.globalData.city = ''
    app.globalData.latitude = ''
    app.globalData.longitude = ''
    app.globalData.city_id = ''
    this.setData({
      cityName: '正在定位'
    })
    if (this.data.page === 'index') {
      app.globalData.RefreshIndexPage = true
    }
    if (this.data.page === 'find') {
      app.globalData.RefreshFindPage = true
    }
    this.getLocation()
  })
})

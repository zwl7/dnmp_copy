const buttonClick = require('./../../utils/buttonClick')
const createRecycleContext = require('./../../components/miniprogram-recycle-view/index')
const config = require('./../../config')
const { map } = require('./../../utils/util')
var QQMapWX = require('./../../utils/qqmap-wx-jssdk')
const { getMyCircles, getSetting, getAdvListByIds, getTabListByIds } = require('../../apis/index')
const { setLocationInfo, getLocationInfo, clearLocationInfo } = require('./../../utils/storage')
const { getCirclesByTypeIds } = require('../../apis/circle')
const app = getApp()
var qqmapsdk
let customData = {
  hosts: [],
  scrollTop: 0,
  finished: false,
  lastTimeScrollTop: 0,
  circlePage: 1 // 请求星球页数
}
let activityList = []

Page({
  data: {
    refresherenabled: true,
    triggered: false,
    myProperty: {
      backgroundColor: '#ff7200',
      isHome: true
    },
    tabBackageColor: 'transparent',
    city: '',
    edmo_value: '',
    navBarHeight: 0,
    active: 2,
    swiperList: [],
    circleList: [],
    showFresh: false,
    tabs: [{ name: '推荐星球', resource_type_id: 0 }],
    tabActived: 0,
    scrollTop: 0,
    offsetTop: 0,
    hosts: [], // tab下方星球
    recycleList: [],
    isShowBackTop: false, //返回顶部按钮
    isShowBottom: true, //是否显示按钮
    loading: true, //加载中
    is_authenticate: 0, //实名认证
    is_first_load: true
  },
  activityList: [],
  hadnleClick() {
    wx.navigateTo({
      url: '/subPages/test/index'
    })
  },
  onReady: function () {},
  scrollBottom() {
    const that = this
    buttonClick.throttle(function () {
      customData.circlePage += 1
      that.getActivities()
    }, 1500)()
  },
  touchend() {
    // console.log('touchend', '13221')
    // if (this.ctx.getScrollTop() < -100) {
    //   console.log(1)
    //   customData.circlePage = 1
    //   customData.finished = false
    //   this.ctx.splice(0, 10000000)
    //   customData.hosts = []
    //   activityList = []
    //   this.getActivities()
    // }
  },
  onLoad() {
    qqmapsdk = new QQMapWX({
      key: config.qqmapKey
    })
    let { navBarHeight } = app.globalData
    customData = {
      hosts: [],
      scrollTop: 0,
      finished: false,
      lastTimeScrollTop: 0,
      circlePage: 1 // 请求星球页数
    }
    this.setData({
      is_first_load: true,
      navBarHeight: navBarHeight,
      city: app.globalData.city,
      is_authenticate: app.globalData.userInfo.is_authenticate
    })

    var ctx = createRecycleContext({
      id: 'recycleId',
      dataKey: 'recycleList',
      page: this,
      itemSize: {
        width: 100,
        height: 264
      }
    })
    this.ctx = ctx
    this.getLocation()
    app.globalData.RefreshIndexPage = false
    app.globalData.is_change_city = false
    app.watchGlobalData('city', 'index', this.watchCity.bind(this))
    app.watchGlobalData('is_authenticate', 'index', this.watchUserInfo.bind(this))
    app.watchGlobalData('is_change_city', 'index', this.watchChangeCity.bind(this))
    app.watchGlobalData('RefreshIndexMyCircle', 'index', this.resetMyCircles.bind(this))
  },
  onShow() {
    console.log('----index onShow,RefreshIndexPage', app.globalData.RefreshIndexPage, app.globalData.is_change_city)
    if (app.globalData.RefreshIndexPage) {
      app.globalData.RefreshIndexPage = false
      console.log('3213213123')
      this.resetData()
    }
  },
  resetData() {
    if (this.data.is_first_load) {
      this.setData({
        is_first_load: false
      })
      return
    }
    this.setData({
      circlePage: 1,
      tabs: [{ name: '推荐星球', resource_type_id: 0 }],
      swiperList: [],
      circleList: [],
      recycleList: [],
      finished: false,
      loading: true
    })
    if (!this.ctx || !this.ctx.page) {
      var ctx = createRecycleContext({
        id: 'recycleId',
        dataKey: 'recycleList',
        page: this,
        itemSize: {
          width: 100,
          height: 264
        }
      })
      this.ctx = ctx
    }
    this.ctx.splice(0, 10000000)
    customData = {
      hosts: [],
      scrollTop: 0,
      finished: false,
      lastTimeScrollTop: 0,
      circlePage: 1 // 请求星球页数
    }
    activityList = []
    this.indexSetting()
  },
  indexSetting() {
    this.setData({
      is_first_load: false
    })
    // 首页设置
    getSetting('index')
      .then(res => {
        if (res.code !== 200) {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
        console.log('-------------getSetting', res)
        let { adv, tab } = res.data
        let swiperList = this.data.swiperList
        let circleList = this.data.circleList
        let tabs = this.data.tabs
        adv = adv.join(',')
        tab = tab.join(',')
        //上方广告
        const p1 = new Promise((resolve, reject) => {
          getAdvListByIds(adv).then(res => {
            console.log('-------------getAdvListByIds', res)
            if (res.data.length === 0) {
              res.data = [{ image: 'https://cdn-static.papa.com.cn/ppcs_mp/banner.jpg' }]
            }
            swiperList = res.data
            resolve(1)
          })
        })
        //我的星球
        const p2 = new Promise((resolve, reject) => {
          getMyCircles({ page: 1, size: 1000 }).then(res => {
            circleList = res.data
            resolve(1)
          })
        })
        // 下方tab
        const p3 = new Promise((resolve, reject) => {
          getTabListByIds(tab).then(res => {
            let arrMap = map(res.data.list, null, 'resource_type_id')
            tab.split(',').map(item => {
              tabs.push(arrMap[item])
            })
            resolve(1)
          })
        })
        Promise.all([p1, p2, p3]).then(res => {
          console.log('----Promise', res)
          const tabActived = tabs.length > 0 ? tabs[0].resource_type_id : 0
          this.setData({
            swiperList,
            circleList,
            tabs,
            tabActived
          })

          this.getActivities()
        })
      })
      .catch(error => {
        wx.showToast({
          title: error,
          icon: 'none'
        })
      })
  },
  // 获取活动
  getActivities() {
    //tab下星球和活动
    if (customData && customData.finished) return
    this.setData({ loading: true })
    getCirclesByTypeIds({
      type_id: this.data.tabActived,
      page: customData.circlePage,
      status: 1,
      size: 5
    })
      .then(res => {
        this.setData({
          loading: false,
          triggered: false
        })
        if (res.data.list.length === 0) {
          customData.finished = true
          return
        }
        let now_time = new Date().getTime()
        res.data.list.map(e => {
          e.show_more = false
          if (e.activities && e.activities.length > 0) {
            e.activities.map(a => {
              a.show_end = Number(a.end_time) * 1000 < now_time
            })
          }
          if (e.activities && e.activities.length >= 5) {
            e.activities = e.activities.slice(0, 5)
            e.show_more = true
          }
        })
        activityList = activityList.concat(res.data.list)
        if (activityList.length <= 3) {
          // 解决 iphone6及以下高度recycle-item小于3显示不全的问题
          this.ctx.append(res.data.list.concat([{}, {}]))
        } else {
          this.ctx.append(res.data.list)
        }
        customData.hosts = customData.hosts.concat(res.data.list)
      })
      .catch(() => {
        this.setData({
          loading: false,
          triggered: false
        })
      })
  },
  // 刷新我的星球
  resetMyCircles(val) {
    if (val) {
      app.globalData.RefreshIndexMyCircle = false
      getMyCircles({ page: 1, size: 1000 }).then(res => {
        if (res.code === 200) {
          this.setData({
            circleList: res.data
          })
        }
      })
    }
  },
  // 切换tab
  changeTab(e) {
    // 设置length有问题
    this.ctx.splice(0, 10000000)
    customData.circlePage = 1
    customData.finished = false
    customData.hosts = []
    this.setData({
      tabActived: e.detail,
      hosts: [],
      loading: true
    })
    activityList = []
    this.getActivities()
  },
  watchCity(value) {
    console.log('watchCity', value)
    this.setData({
      city: value
    })
  },
  watchChangeCity(value) {
    if (value) {
      console.log('城市id选择', value)
      this.resetData()
    }
  },
  watchUserInfo(value) {
    console.log('watchUserInfo', value)
    this.setData({
      is_authenticate: value
    })
  },
  // 选择城市
  selectCity: buttonClick.buttonClicked(function () {
    wx.navigateTo({
      url: '/pages/city/city?page=index'
    })
  }, 1000),
  // 搜索页面
  tosearch: buttonClick.buttonClicked(function () {
    wx.navigateTo({
      url: '/pages/search/search'
    })
  }),
  // 回到首页
  uptoTop() {
    this.setData({
      scrollTop: 0
    })
    this.setData({ isShowBackTop: false })
  },
  pageScroll(event) {
    let scrollTop = event.detail.scrollTop
    if (scrollTop > 700) {
      this.data.isShowBackTop || this.setData({ isShowBackTop: true })
    } else {
      this.data.isShowBackTop && this.setData({ isShowBackTop: false })
    }
    customData.scrollTop = scrollTop
    if (scrollTop > customData.lastTimeScrollTop) {
      this.data.isShowBottom && this.setData({ isShowBottom: false })
    } else {
      !this.data.isShowBottom && this.setData({ isShowBottom: true })
    }
    customData.lastTimeScrollTop = scrollTop
    if (scrollTop == 0) {
      this.setData({ isShowBottom: true })
    }
    if (scrollTop < -50) {
      this.setData({
        showFresh: true
      })
    }
  },

  // 获取当前定位
  getLocation() {
    let _this = this
    try {
      wx.getFuzzyLocation({
        type: 'wgs84',
        success(res) {
          const latitude = res.latitude
          const longitude = res.longitude
          app.globalData.latitude = latitude
          app.globalData.longitude = longitude
          app.globalData.user_latitude = latitude
          app.globalData.user_longitude = longitude
          app.globalData.is_get_location = true
          if (app.globalData.city) {
            getLocationInfo().then(res => {
              if (res) {
                res.latitude = latitude
                res.longitude = longitude
                setLocationInfo(res).then(res => {
                  _this.indexSetting()
                })
              }
            })
          } else {
            _this.getLocal(latitude, longitude)
          }
        },
        fail(error) {
          console.log('首页wx.getFuzzyLocation失败,', error)
          if (app.globalData.latitude && app.globalData.longitude) {
            _this.getLocal(app.globalData.latitude, app.globalData.longitude)
          } else {
            wx.getSetting({
              success(res) {
                if ('undefined' == res.authSetting['scope.userLocation'] || res.authSetting['scope.userLocation']) {
                  console.log('系统没有给定位权限=====================', res)
                  _this.getDefaultLocation()
                } else {
                  console.log('用户拒绝了授权=====================', res)
                  _this.getDefaultLocation()
                }
              }
            })
          }
        }
      })
    } catch (error) {
      console.log('定位授权', error)
      _this.getLocal(app.globalData.latitude, app.globalData.longitude)
    }
  },
  getDefaultLocation() {},
  getLocal(latitude, longitude) {
    let _this = this
    if (qqmapsdk) {
      qqmapsdk.reverseGeocoder({
        location: {
          latitude: latitude,
          longitude: longitude
        },
        success(res) {
          let city = res.result.ad_info.city
          let city_code = res.result.ad_info.city_code
          city_code = String(city_code).slice(3, 7)
          app.globalData.city = city
          app.globalData.latitude = latitude
          app.globalData.longitude = longitude
          app.globalData.user_latitude = latitude
          app.globalData.user_longitude = longitude
          app.globalData.city_id = city_code
          let addressInfo = {
            latitude: latitude,
            longitude: longitude,
            city: city,
            city_id: city_code,
            date: new Date().getTime(),
            is_user_select: false
          }
          setLocationInfo(addressInfo).then(res => {
            _this.indexSetting()
          })
        },
        fail(error) {
          console.error(error)
          app.globalData.city = config.default_city_name
          app.globalData.latitude = config.default_latitude
          app.globalData.longitude = config.default_longitude
          app.globalData.city_id = config.default_city_id
          clearLocationInfo()
        }
      })
    }
  },
  bindscroll(e) {
    let { scrollTop, isFixed } = e.detail
    if (isFixed) {
      this.setData({
        tabBackageColor: '#f6f7f7'
      })
    } else {
      this.setData({
        tabBackageColor: 'transparent'
      })
    }
  },
  // 点击添加活动星球按钮
  clickPlus: buttonClick.buttonClicked(function () {
    // if (app.globalData.userInfo.is_authenticate !== 1) {
    //   this.selectComponent('#authDialog').showDialog()
    // } else {
    //   if (app.globalData.official_auth != 1) {
    //     this.selectComponent('#officalAuthDialog').showDialog()
    //   } else {
    //     this.selectComponent('#joinBtn').showDialog()
    //   }
    // }
    if (app.globalData.official_auth != 1) {
      this.selectComponent('#officalAuthDialog').showDialog()
    } else {
      this.selectComponent('#joinBtn').showDialog()
    }
  }, 1000),
  // 确认弹窗 回调
  authConfirm() {
    if (app.globalData.userInfo.is_authenticate === -1) {
      wx.navigateTo({
        url: '/subPages/system/login/login?need_auth=1&page=index'
      })
    }
    if (app.globalData.userInfo.is_authenticate === 0) {
      wx.navigateTo({
        url: '/subPages/system/Authentication/index?page=index'
      })
    }
  },
  officeAuthConfirm() {
    if (app.globalData.userInfo.is_authenticate === -1) {
      wx.navigateTo({
        url: '/subPages/system/login/login?page=entrance'
      })
    } else {
      wx.navigateTo({
        url: '/accountPages/entrance/entrance'
      })
    }
  },
  // 加入星球 认证
  checkCircleItem() {
    this.selectComponent('#loginDialog').showDialog()
  },
  // 转发给朋友
  onShareAppMessage() {
    return {
      title: '一起来寻找属于你的星球吧~',
      path: '/pages/index/index',
      // imageUrl:
      //   'http://quhuo-system-picture.oss-cn-shanghai.aliyuncs.com/MP3.10/home_share.png',
      success: function (t) {
        console.log('成功', t)
      },
      fail: function (t) {
        console.log('失败', t)
      }
    }
  },
  onRefresh(e) {
    customData.circlePage = 1
    customData.finished = false
    this.ctx.splice(0, 10000000)
    customData.hosts = []
    activityList = []
    this.getActivities()
    setTimeout(() => {
      this.setData({
        triggered: false
      })
    }, 500)
  }
  // // 分享朋友圈
  // onShareTimeline() {
  //   return {
  //     title: '一起来寻找属于你的星球吧~',
  //     query: 'a=1&b=2'
  //   }
  // }
})

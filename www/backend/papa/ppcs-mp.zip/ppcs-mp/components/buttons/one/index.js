const app = getApp()
Component({
  options: {
    addGlobalClass: true
  },
  properties: {
    color: {
      type: String,
      value: 'rgba(255, 114, 0, 1)' // 边框颜色
    },
    textColor: {
      type: String,
      value: 'white' //字体颜色
    },
    plain: {
      type: Boolean,
      value: false // 是否空心 空心则背景色为白色
    },
    text: {
      type: String,
      value: '我是你哥'
    },
    navigateUrl: {
      type: String, // 导航
      value: ''
    },

    size: {
      type: String,
      value: 'min' // min|normal|large 按钮大小
    }
  },
  data: { isIos: app.globalData.isIos, pdLR: '20rpx' },
  lifetimes: {
    attached() {
      this.setBtnWidth()
    }
  },
  methods: {
    setBtnWidth() {
      let pdLR = '40rpx'
      switch (this.properties.size) {
        case 'min':
          pdLR = '40rpx'
          break
        case 'normal':
          pdLR = '100rpx'
          break
        case 'large':
          pdLR = '120prx'
          break
      }
      this.setData({
        pdLR
      })
    },
    call() {
      if (this.properties.navigateUrl) {
        wx.navigateTo({
          url: this.properties.navigateUrl
        })
      }
    }
  }
})

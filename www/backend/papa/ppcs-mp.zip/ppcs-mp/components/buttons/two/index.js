Component({
  properties: {
    price: {
      type: String,
      value: '0'
    }
  },
  data: {},
  methods: {
    cancel() {
      this.triggerEvent('cancel')
    },
    confirm() {
      this.triggerEvent('confirm')
    }
  }
})

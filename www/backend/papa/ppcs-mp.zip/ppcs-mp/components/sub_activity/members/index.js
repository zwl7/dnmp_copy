Component({
  properties: {
    members: {
      type: Object,
      value: []
    },
    showMemberAll: {
      type: Boolean,
      value: false
    }
  },
  data: {},

  methods: {
    clickBtn() {
      console.log(this.properties.members)
      this.triggerEvent('clickAll')
    }
  }
})

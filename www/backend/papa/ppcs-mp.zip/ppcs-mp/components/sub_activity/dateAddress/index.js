const Location = require('../../../utils/wx/location')
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    time: {
      type: String, // 时间
      value: ''
    },
    address: {
      type: String, // 地点
      value: ''
    },
    alert: {
      type: String, // 须知
      value: ''
    },
    longitude: {
      type: Number,
      value: 0
    },
    latitude: {
      type: Number,
      value: 0
    },
    refundRuleStr: {
      type: String, //退款须知
      value: ''
    }
  },
  data: {
    showInfo: false,
    info: ``
  },
  methods: {
    openMap() {
      Location.longitude = this.properties.longitude
      Location.latitude = this.properties.latitude
      Location.address = this.properties.address
      Location.openLocation()
    },
    openinfo() {
      this.setData({
        showInfo: true
      })
    },
    onClose() {
      this.setData({
        showInfo: false
      })
    },
    onClickHide() {
      this.setData({
        showInfo: false
      })
    }
  }
})

const { tel, textCopy } = require('../../../utils/wx/basic')
Component({
  externalClasses: ['host-class', 'host-info-class'],
  properties: {
    host: {
      type: Object,
      value: {
        name: '',
        avatar: '',
        phone: '',
        wx: '',
        is_authenticate: 1
      }
    },
    hiddneConcat: {
      type: Boolean,
      value: false
    }
  },
  data: {},
  methods: {
    previewImages(e) {
      const images = e.currentTarget.dataset.images
      wx.previewImage({
        urls: images
      })
    },
    copyWx() {
      if (!this.properties.host.wx) {
        wx.showToast({
          title: '暂无微信号',
          icon: 'none'
        })
      } else {
        textCopy(this.properties.host.wx)
      }
    },
    call() {
      if (!this.properties.host.phone) {
        wx.showToast({
          title: '暂无手机号',
          icon: 'none'
        })
      } else {
        tel(this.properties.host.phone)
      }
    }
  }
})

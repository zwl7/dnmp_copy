Component({
  properties: {
    activityInfo: {
      type: Object,
      value: {
        images: '',
        start_time_str: '',
        name: '',
        address: '',
        activity_id: '',
        people_num: ''
      }
    }
  },
  data: {},
  methods: {
    handleClick() {
      let url = '/subPages/activity/detail/index'
      url = url.concat(
        '?activity_id=',
        this.properties.activityInfo.activity_id
      )
      wx.navigateTo({
        url: url
      })
    }
  }
})

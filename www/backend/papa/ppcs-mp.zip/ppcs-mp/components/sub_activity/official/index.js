Component({
  externalClasses: ['official-class', 'name-class', 'seps-class'],
  properties: {
    official: {
      type: Object,
      value: {
        images: '',
        name: '',
        member_num: 0,
        activity_num: 0,
        moment_num: 0
      },
      observer: function (res) {}
    }
  },
  data: {},
  methods: {}
})

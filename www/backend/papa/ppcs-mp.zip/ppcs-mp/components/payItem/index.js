Component({
  properties: {},
  data: {
    radio: 'wx'
  },
  methods: {
    onChange(event) {
      this.setData({
        radio: event.detail
      })
    }
  }
})

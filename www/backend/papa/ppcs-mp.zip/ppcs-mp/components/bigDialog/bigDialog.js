const app = getApp()
const buttonClick = require('./../../utils/buttonClick')
Component({
  properties: {
    disWrapClose: {
      type: Boolean,
      value: false
    },
    type: {
      type: Number,
      value: -1
    },
    cancelText: {
      type: String,
      value: '取消'
    },
    confirmText: {
      type: String,
      value: '确认'
    },
    title: {
      type: String,
      value: '提示'
    },
    tip: {
      type: String,
      value: ''
    },
    show_image: {
      type: Boolean,
      value: false
    },
    image_type: {
      type: String,
      value: 'info'
    }
  },
  data: {
    isShow: false,
    showMethod: false,
    hiddenMethod: false,
    updatePanelAnimationData: '',
    authNameIcon: app.globalData.config.host + '/dialog_icon_1.png'
  },
  methods: {
    hideDialog: function () {
      if (this.data.hiddenMethod || this.data.showMethod) {
        return
      }
      this.leavePupAnimation()
    },
    showDialog: function () {
      if (this.data.isShow || this.data.hiddenMethod || this.data.showMethod) {
        return
      }
      this.goIntoPupAnimation()
    },
    goIntoPupAnimation: function () {
      this.setData({
        isShow: true,
        showMethod: true
      })
      this.animate('.wx_dialog_container', [{ opacity: 0 }, { opacity: 1 }], 300, () => {
        this.setData({
          showMethod: false
        })
      })
      this.animate('.wx-dialog', [{ scale: [0.8, 0.8] }, { scale: [1, 1] }], 100)
    },
    leavePupAnimation: function () {
      this.setData({
        hiddenMethod: true
      })
      this.animate('.wx_dialog_container', [{ opacity: 1 }, { opacity: 0 }], 100)
      this.animate('.wx-dialog', [{ scale: [1, 1] }, { scale: [0.8, 0.8] }], 150, () => {
        this.setData({
          isShow: false,
          hiddenMethod: false
        })
      })
    },
    wrapClose: buttonClick.buttonClicked(function () {
      this.properties.disWrapClose || this.hideDialog()
    }, 800),
    _cancelEvent: buttonClick.buttonClicked(function () {
      this.triggerEvent('cancelEvent', '取消')
      this.hideDialog()
    }, 800),
    _confirmEvent: buttonClick.buttonClicked(function (event) {
      this.triggerEvent('confirmEvent', event)
      this.hideDialog()
    }, 800),
    preventEvent() {},
    bindcontact(e) {
      let errMsg = e.detail.errMsg
      if (errMsg != 'enterContact:ok') {
        wx.showToast({
          title: errMsg,
          icon: 'none'
        })
      }
    }
  }
})

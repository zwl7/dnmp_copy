const { wxCommunityGet, wxCommunityJoinList, wxCommunityUpdate } = require('./../../../apis/circle')
const { getCircleActivityList } = require('./../../../apis/activity')
const { getTagColor, uploadFile } = require('../../../utils/util')
const { processingActivities, historicalActivities } = require('./../../../apis/activity')
const buttonClick = require('../../../utils/buttonClick')
const createRecycleContext = require('./../../../components/miniprogram-recycle-view/index')
const app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    communityId: {
      type: String
    }
  },
  lifetimes: {
    attached: function () {
      this.wxCommunityGet(this.properties.communityId)
      this.setScrollCtx()
      this.reseData()
      const height = wx.getSystemInfoSync().windowHeight
      this.setData({
        scrollHeight: height
      })
    }
  },
  pageLifetimes: {
    show: function () {
      let { circleBackgroundImg } = app.globalData
      let { globalImg } = this.data
      if (globalImg == 'circleBackgroundImg' && circleBackgroundImg) {
        uploadFile(circleBackgroundImg)
          .then(res => {
            if (res.code == 200) {
              this.setData({
                'community_info.banner': res.data.imgUrl
              })
              app.globalData.circleBackgroundImg = ''
              wxCommunityUpdate({
                banner: res.data.imgUrl,
                member_id: this.data.community_info.member_id,
                community_id: this.data.community_info.community_id
              })
            }
          })
          .catch(error => {
            console.log(error)
          })
      }
    }
  },
  data: {
    scrollHeight: 0,
    tabActived: 'desc',
    name: '', // 名称
    des: '', // 简介
    nameAutoFocus: false, // 名称自动对焦
    desAutoFocus: false, // 简介自动对焦
    width: 0,
    // 星球详情
    community_info: {},
    member: {},
    joinListPage: {
      page: 1,
      size: 10
    },
    joinList: [],
    joinListFinish: false,
    joinCommonsList: [],
    joinCount: 0,
    activityList: [], //正在进行的活动
    activityCount: 0,
    historyActivityList: [], //历史活动
    page: 1,
    size: 5,
    showFresh: false,
    activityFinished: false,
    historyFinished: false,
    showUploadpopup: false, //选择背景图
    showchangeImgTypePopup: false,
    globalImg: '',
    historyActivityCount: 0 //历史活动数量
  },
  methods: {
    previewImages(e) {
      const images = e.currentTarget.dataset.images
      wx.previewImage({
        urls: images
      })
    },
    // 计算名称宽度
    calcWidth(str) {
      // 只计算汉字的
      const chineseWidth = 20 // 每个汉字35rpx
      const chineseCount = str.length
      this.setData({
        width: chineseCount * chineseWidth
      })
    },
    confirmDes() {
      this.setData({
        desAutoFocus: false
      })
    },
    colnfirmName() {
      this.setData({
        nameAutoFocus: false
      })
    },
    editState() {
      wx.navigateTo({
        url: `/subPages/helper/tagMg/index?community_id=${this.data.community_info.community_id}`
      })
    },
    editCircle(e) {
      wx.navigateTo({
        url: `/subPages/helper/circle/index?community_id=${this.data.communityId}`
      })
    },
    changeTab(e) {
      this.setData({
        tabActived: e.detail.name
      })
    },
    updateCircle() {
      const that = this
      buttonClick.debounce(function () {
        wxCommunityUpdate({
          name: that.data.name,
          des: that.data.des,
          member_id: that.data.community_info.member_id,
          community_id: that.data.community_info.community_id
        })
      }, 1500)()
    },
    changeDes(e) {
      this.updateCircle()
    },
    changeName(e) {
      // 改变内容
      this.calcWidth(e.detail)
      this.updateCircle()
    },
    // 星球详情
    wxCommunityGet(community_id) {
      let obj = {
        community_id: community_id
      }
      wxCommunityGet(obj).then(res => {
        if (res.code === 200) {
          console.log(res.data.signature)
          let community_info = {
            community_id: community_id,
            images: res.data.images,
            name: res.data.name,
            hot: res.data.hot,
            tag: res.data.tag,
            des: res.data.des,
            banner: res.data.banner,
            member_id: res.data.member_id,
            view_num: res.data.view_num || 0,
            signature: res.data.signature || '星球主暂未填写。。。'
          }

          community_info.tag.map((item, index) => {
            const { color, textColor } = getTagColor(index)
            item.color = color
            item.textColor = textColor
          })

          this.calcWidth(community_info.name)
          let memberInfo = res.data.member
          let member = {
            name: memberInfo.nick_name ? memberInfo.nick_name : memberInfo.name,
            avatar: memberInfo.avatar,
            phone: memberInfo.phone,
            wx: memberInfo.wx,
            is_authenticate: memberInfo.is_authenticate
          }
          this.setData({
            community_info: community_info,
            name: community_info.name,
            des: community_info.des,
            member: member
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    // 星球成员
    wxCommunityJoinList(community_id) {
      let obj = Object.assign({ community_id: community_id }, this.data.joinListPage)
      wxCommunityJoinList(obj).then(res => {
        if (res.code === 200) {
          if (res.data.list.length < 10) {
            this.setData({
              joinListFinish: true
            })
          }
          let list = []
          let joinCommonsList = []
          res.data.list.map(e => {
            e.city_name = ''
            let obj = {
              avatar: e.avatar,
              join_time_str: e.join_time_str,
              member_id: e.member_id,
              name: e.name,
              nick_name: e.nick_name,
              is_authenticate_str: e.is_authenticate_str,
              role: e.role,
              role_str: e.role_str,
              community_id: e.community_id,
              sex: e.sex,
              city_name: e.city_name,
              is_authenticate: e.is_authenticate
            }
            if (e.role === 0) {
              joinCommonsList.push(obj)
            } else {
              list.push(obj)
            }
          })
          let joinList = this.data.joinList
          joinList = joinList.concat(list)
          let joinCommonsListData = this.data.joinCommonsList
          joinCommonsListData = joinCommonsListData.concat(joinCommonsList)
          this.setData({
            joinList: joinList,
            joinCommonsList: joinCommonsList,
            joinCount: res.data.count
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },

    setScrollCtx() {
      var ctx = createRecycleContext({
        id: 'recycleId2',
        dataKey: 'recycleList',
        page: this,
        itemSize: {
          width: 100,
          height: 191
        }
      })
      this.ctx = ctx
    },
    // 获取活动
    getActivities() {
      if (!this.data.activityFinished) {
        this.processingList()
      } else if (!this.data.historyFinished) {
        this.historicalList()
      }
    },
    // 滚动条滚动到底部
    scrollBottom() {
      const that = this
      buttonClick.throttle(function () {
        that.setData({
          page: ++that.data.page
        })
        that.getActivities()
      }, 800)()
    },
    // 得到正在进行活动
    processingList() {
      const that = this
      getCircleActivityList({
        page: this.data.page,
        size: this.data.size,
        gte_end_time: Math.ceil(new Date().getTime() / 1000),
        community_id: this.properties.communityId,
        no_location: 1
      }).then(res => {
        this.setData({
          activityCount: res.data.count
        })
        if (res.data.list.length < this.data.size || (res.data.list.length < this.data.size && this.data.page == 1)) {
          // 有效活动结束 获取历史活动
          this.setData({
            activityFinished: true,
            activityList: that.data.activityList.concat(res.data.list),
            page: 1 // 重置page
          })
          this.historicalList()
        } else {
          this.setData({
            activityList: that.data.activityList.concat(res.data.list)
          })
        }
      })
    },
    // 得到历史活动
    historicalList() {
      const that = this
      getCircleActivityList({
        page: this.data.page,
        size: this.data.size,
        lte_end_time: Math.ceil(new Date().getTime() / 1000),
        community_id: this.properties.communityId,
        no_location: 1
      }).then(res => {
        if (res.data.list.length < this.data.size) {
          this.setData({
            historyFinished: true,
            historyActivityCount: res.data.count,
            historyActivityList: that.data.historyActivityList.concat(res.data.list)
          })
        } else {
          this.setData({
            historyActivityCount: res.data.count,
            historyActivityList: that.data.historyActivityList.concat(res.data.list)
            // page: ++that.data.page
          })
        }
      })
    },
    // 删除成员成功后回调
    delMemberCal(e) {
      let flag = 0
      const joinList = this.data.joinList
      const joinCommonsList = this.data.joinCommonsList
      joinList.map((item, index) => {
        if (item.member_id == e.detail) {
          joinList.splice(index, 1)
          flag = 1
        }
      })
      if (!flag) {
        joinCommonsList.map((item, index) => {
          if (item.member_id == e.detail) {
            joinCommonsList.splice(index, 1)
            flag = 1
          }
        })
      }
      this.setData({
        joinList,
        joinCommonsList
      })
    },
    // 重置活动
    reseData() {
      this.setScrollCtx()
      this.setData({
        joinList: [],
        joinCommonsList: [],
        historyActivityList: [],
        activityList: [],
        'joinListPage.page': 1,
        page: 1,
        activityFinished: false,
        historyFinished: false,
        joinListFinish: false
      })
      this.ctx.splice(0, 100000000)
      this.wxCommunityGet(this.properties.communityId)
      this.wxCommunityJoinList(this.properties.communityId)
      this.getActivities()
    },
    // 设置背景图  弹出层
    showUploadPopup() {
      this.setData({
        showUploadpopup: !this.data.showUploadpopup
      })
    },
    changeBackgroundImg() {
      this.setData({
        showUploadpopup: false,
        globalImg: 'circleBackgroundImg'
      })
      setTimeout(() => {
        this.showUpImgPopup('background')
      }, 300)
    },
    getBackgroundImg(event) {
      this.setData({
        'community_info.banner': event.detail
      })
      wxCommunityUpdate({
        banner: event.detail,
        member_id: this.data.community_info.member_id,
        community_id: this.data.community_info.community_id
      })
    },
    showUpImgPopup(event) {
      this.setData({
        showchangeImgTypePopup: !this.data.showchangeImgTypePopup
      })
    }
  }
})

const app = getApp()
const { delCommunityPerson } = require('../../../apis/helper')
Component({
  externalClasses: ['memeber-class', 'gutter-class', 'border-class'],
  properties: {
    rightIcon: {
      type: String,
      value: '/assets/images/add-user.png'
    },
    rightText: {
      type: String,
      value: ''
    },
    isBorder: {
      type: Boolean,
      value: false
    },
    plain: {
      type: Boolean,
      value: false
    },
    showOps: {
      type: Boolean,
      value: false
    },
    showRightLine: {
      type: Boolean,
      value: false
    },
    memberInfo: {
      type: Object,
      observer: function (val) {
        if (String(val.is_authenticate)) {
          let auth_map = {
            '-1': '未认证',
            0: '未实名',
            1: '已实名'
          }
          this.setData({
            is_authenticate_str: auth_map[val.is_authenticate]
          })
        }
      }
    }
  },

  data: {
    avatar: app.globalData.config.host + '/avatar_1.png',
    activity: app.globalData.config.host + '/activity_1.png',
    is_authenticate_str: '未实名'
  },

  methods: {
    delMember() {
      wx.showLoading({
        title: '移除中'
      })
      delCommunityPerson({
        community_id: this.properties.memberInfo.community_id,
        p_member_id: this.properties.memberInfo.member_id,
        no_location: 1
      })
        .then(res => {
          if (res.code == 200) {
            this.triggerEvent('delMember', this.properties.memberInfo.member_id)
            wx.hideLoading()
          } else {
            wx.hideLoading()
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
        .catch(err => {
          wx.hideLoading()
        })
    },
    previewImage(event) {
      let { iamge } = event.currentTarget.dataset
      if (iamge) {
        wx.previewImage({
          urls: [iamge]
        })
      }
    },
    handleClick(e) {
      let { avatar, nick_name, sex } = this.properties.memberInfo
      let userInfo = {
        avatar: avatar,
        nick_name: nick_name,
        sex: sex
      }
      try {
        wx.setStorageSync('registerUserInfo', userInfo)
        let { applicant_code } = this.properties.memberInfo
        let url = '/subPages/helper/registerInformation/registerInformation'
        url = url.concat('?applicant_code=', applicant_code)
        wx.navigateTo({
          url: url
        })
      } catch (e) {}
    }
  }
})

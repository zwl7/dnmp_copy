Component({
  properties: {
    activityInfo: {
      type: Object,
      value: {
        images: '',
        start_time_str: '',
        name: '',
        address: '',
        activity_id: '',
        people_num: ''
      }
    }
  },
  data: {},
  methods: {
    handleClick() {
      let url = '/subPages/activity/detail/index'
      url = url.concat(
        '?activity_id=',
        this.properties.activityInfo.activity_id
      )
      wx.navigateTo({
        url: url
      })
    },
    management(e) {
      wx.navigateTo({
        // url: `/subPages/helper/activityMg/index?activity_id=${this.properties.activityInfo.activity_id}`
        url: `/subPages/activity/detail/index?activity_id=${this.properties.activityInfo.activity_id}`
      })
    },
    createAgain() {
      wx.navigateTo({
        url: `/subPages/activity/create/create?re_create=1&activity_id=${this.properties.activityInfo.activity_id}&community_id=${this.properties.activityInfo.community_id}`
      })
    }
  }
})

const app = getApp()
Component({
  properties: {
    type: {
      type: Number,
      value: 1
    },
    title: {
      type: String,
      value: '暂无票据'
    },
    tip: {
      type: String,
      value: '请先创建票据吧～'
    }
  },
  externalClasses: ['empty-class', 'title-class', 'tip-class'],
  data: {
    no_ticket: './../../assets/images/no_ticket.png',
    no_activity: './../../assets/images/no_activity.png',
    no_community: './../../assets/images/no_community.png',
    no_search: './../../assets/images/no_search.png'
  },
  methods: {
    joinActivity() {
      app.globalData.RefreshFindPage = true
      wx.switchTab({
        url: '/pages/find/find?refresh=1'
      })
    }
  }
})

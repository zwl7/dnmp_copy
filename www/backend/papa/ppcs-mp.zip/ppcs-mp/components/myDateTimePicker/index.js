const dateTimePicker = require('./dateTimePicker')
const { formatTimeBase } = require('./../../utils/date')
Component({
  properties: {
    current: {
      type: Number,
      observer: function (val) {
        if (val) {
          let date = new Date(val)
          let str = formatTimeBase(date, '{y}-{m}-{d} {h}:{i}:{s}')
          let value = dateTimePicker.dateTimePicker(2022, 2025, str)
          this.setData({
            dateTime1: value.dateTime
          })
          this.yeartmp = value.dateTimeArray[0][value.dateTime[0]]
          this.monthtmp = value.dateTimeArray[1][value.dateTime[1]]
        }
      }
    }
  },
  lifetimes: {
    ready() {
      let date = dateTimePicker.dateTimePickertype('minute')
      this.setData({
        dateArray: date.dateTimeArray,
        // dateTime1: date.dateTime
      })
    }
  },
  data: {},
  yeartmp: '',
  monthtmp: '',
  methods: {
    changeDate(e) {
      let time = e.detail.value
      let year = this.data.dateArray[0][time[0]]
      let month = this.data.dateArray[1][time[1]]
      let day = this.data.dateArray[2][time[2]]
      let hour = this.data.dateArray[3][time[3]]
      let minute = this.data.dateArray[4][time[4]]

      let strtime = `${year}/${month}/${day} ${hour}:${minute}`
      this.setData({
        dateTime1: e.detail.value
      })
      let date = new Date(strtime).getTime()
      this.triggerEvent('confirm', date)
    },
    bindcolumnchange(e) {
      let { column, value } = e.detail
      let tmp = this.data.dateArray[column][value]
      if (column == 0) {
        this.yeartmp = tmp
      }
      if (column == 1) {
        this.monthtmp = tmp
      }
      let monthHaveDay = this.mGetDate(this.yeartmp, this.monthtmp)
      let currentMonthDay = this.data.dateArray[2].length
      if (monthHaveDay != currentMonthDay) {
        let monthDay = dateTimePicker.getMonthDay(this.yeartmp, this.monthtmp)
        this.setData({
          'dateArray[2]': monthDay
        })
      }
    },
    mGetDate(year, month) {
      var d = new Date(year, month, 0)
      return d.getDate()
    }
  }
})

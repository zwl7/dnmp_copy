const app = getApp()
Component({
  properties: {
    activity: {
      type: Object,
      value: {}
    },
    skuList: {
      type: Array,
      value: []
    }
  },
  data: {},
  methods: {
    openMap() {
      let { address, latitude, longitude } = this.properties.activity
      wx.openLocation({
        latitude: Number(latitude),
        longitude: Number(longitude),
        address,
        scale: 15,
        success: function (res) {},
        fail: function (error) {
          wx.showToast({
            title: error.errMsg,
            icon: 'none'
          })
        }
      })
    },
    toActivity() {
      let { activity_id } = this.properties.activity
      let url = '/subPages/activity/detail/index'
      url = url.concat('?activity_id=', activity_id)
      wx.navigateTo({
        url: url
      })
    },
    previewImage() {
      let { images } = this.properties.activity
      if (images) {
        wx.previewImage({
          current: images,
          urls: [images],
          success: function (res) {
            console.log(res)
          },
          fail: function (err) {
            console.log(err)
          }
        })
      }
    }
  }
})

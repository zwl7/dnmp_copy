Component({
  properties: {
    orderInfo: {
      type: Object,
      value: {}
    },
    titleValue: {
      type: String,
      value: ''
    },
    showBirdTicket: {
      type: Boolean,
      value: false
    },
    showTicketNum: {
      type: Boolean,
      value: false
    },
    showOrderNum: {
      type: Boolean,
      value: true
    },
    showPaidTime: {
      type: Boolean,
      value: true
    },
    skuList: {
      type: Array,
      value: []
    }
  },
  data: {},
  methods: {
    // 申诉
    handleAppeal() {
      console.log('申诉')
    },
    bindcontact(e) {
      let errMsg = e.detail.errMsg
      console.log(e)
      if (errMsg != 'enterContact:ok') {
        wx.showToast({
          title: errMsg,
          icon: 'none'
        })
      }
    }
  }
})

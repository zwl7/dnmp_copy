Component({
  properties: {
    content: {
      type: Object,
      value: {},
      observer: function (newVal, oldVal) {
        this.setBtnTitle(newVal)
      }
    }
  },
  data: {
    btnText: '',
    order_status: 0,
    navigateUrl: '',
    is_reject: false //是否违规活动
  },
  methods: {
    setBtnTitle(newVal) {
      let { order_status, status_str, order_no, activity } = newVal
      let btnText = '查看'
      if (order_status == 0) {
        btnText = '去支付'
      }
      if (order_no == '0' || status_str == '已占座，马上支付') {
        btnText = '去支付'
      }
      if (activity.status == 3) {
        this.setData({
          is_reject: true
        })
      }
      let url = '/subPages/order/waitPay/index'
      this.setData({
        order_status: order_status,
        btnText: btnText,
        navigateUrl: url
      })
    },
    handleClick(e) {
      let { order_no, sku_clice, status_str } = this.properties.content
      if (order_no == '0' || status_str == '已占座，马上支付') {
        this.triggerEvent('createOrder', { sku_clice: sku_clice })
      } else {
        let { navigateUrl } = this.data
        let { order_no } = this.properties.content
        let url = navigateUrl.concat('?order_no=', order_no)
        wx.navigateTo({
          url: url
        })
      }
    },
    toActivity() {
      let { activity } = this.properties.content
      if (activity.activity_id) {
        let url = '/subPages/activity/detail/index'
        url = url.concat('?activity_id=', activity.activity_id)
        wx.navigateTo({
          url: url
        })
      }
    }
  }
})

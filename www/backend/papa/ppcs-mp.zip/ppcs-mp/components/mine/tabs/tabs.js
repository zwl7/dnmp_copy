Component({
  properties: {
    tabs: {
      type: Array,
      value: []
    },
    backgroundColor: {
      type: String,
      value: ''
    }
  },
  data: {
    activited: 1,
    offsetLeft: 10
  },
  methods: {
    clickTab(e) {
      let id = e.currentTarget.dataset.id
      let offsetLeft = e.currentTarget.offsetLeft
      this.setData({
        activited: id,
        offsetLeft: offsetLeft
      })
      this.triggerEvent('changeType', { id: id })
    }
  }
})

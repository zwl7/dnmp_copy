const app = getApp()
Component({
  externalClasses: ['personal-class'],
  properties: {
    userInfo: {
      type: Object,
      value: {},
      observer(val) {
        let auth_map = {
          '-1': '未认证',
          0: '未实名',
          1: '已实名'
        }
        this.setData({
          is_authenticate_str: auth_map[val.is_authenticate]
        })
      }
    },
    userStaticInfo: {
      type: Object,
      value: {
        community_num: 0,
        activity_num: 0
      }
    },
    noRead: {
      type: Number,
      value: 0
    }
  },
  data: {
    is_authenticate_str: '未实名'
  },
  lifetimes: {
    ready() {}
  },
  methods: {
    previewImages(e) {
      const images = e.currentTarget.dataset.images
      wx.previewImage({
        urls: images
      })
    },
    toInformation() {
      wx.navigateTo({
        url: '/subPages/system/information/information'
      })
    },
    toSet() {
      wx.navigateTo({
        url: '/subPages/system/setupAccount/setupAccount'
      })
    },
    toMyCircle() {
      wx.navigateTo({
        url: '/subPages/circle/myCircle/myCircle'
      })
    },
    toActivity() {
      let url = `/subPages/activity/historyActivity/index?title=参与活动`
      wx.navigateTo({
        url: url
      })
    },
    toHistory() {
      let url = `/subPages/activity/viewHistory/index`
      wx.navigateTo({
        url: url
      })
    },
    // 实名认证
    handleAuth() {
      // let { is_authenticate } = this.properties.userInfo
      // if (is_authenticate == 0) {
      //   wx.navigateTo({
      //     url: '/subPages/system/Authentication/index'
      //   })
      // }
      // wx.showToast({
      //   title: this.data.is_authenticate_str,
      //   icon: 'none'
      // })
    }
  }
})

const app = getApp()
Component({
  externalClasses: ['activity-class'],
  options: {
    styleIsolation: 'shared'
  },
  properties: {
    activityInfo: {
      type: Object,
      value: {
        activity_id: '',
        images: '',
        name: '',
        date: '',
        address: '',
        apply_member: [],
        apply_num: 0,
        tag: [],
        is_free: '',
        order_no: '',
        show_end: false,
        status: 1
      },
      observer: function (newval, oldval) {
        if (newval.status === 3) {
          this.setData({
            is_reject: true
          })
        }
      }
    },
    jumpType: {
      type: String,
      value: 'detail'
    },
    showDistance: {
      type: Boolean,
      value: false
    },
    isGetLocation: {
      type: Boolean,
      value: false
    }
  },
  data: {
    is_reject: false //是否下架活动
  },
  methods: {
    toActivity() {
      if (this.properties.jumpType === 'detail') {
        let { activity_id } = this.properties.activityInfo
        let url = '/subPages/activity/detail/index'
        url = url.concat('?activity_id=', activity_id)
        wx.navigateTo({
          url: url
        })
      } else {
        let { order_no } = this.properties.activityInfo
        let url = '/subPages/order/waitPay/index'
        url = url.concat('?order_no=', order_no)
        wx.navigateTo({
          url: url
        })
      }
    }
  }
})

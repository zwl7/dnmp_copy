const app = getApp()
Component({
  properties: {
    disWrapClose: {
      type: Boolean,
      value: false
    },
    cancelText: {
      type: String,
      value: '取消'
    },
    confirmText: {
      type: String,
      value: '确认'
    },
    title: {
      type: String,
      value: '提示'
    },
    tip: {
      type: String,
      value: '提示'
    }
  },
  data: {
    isShow: false,
    updatePanelAnimationData: '',
    authNameIcon: app.globalData.config.host + '/dialog_icon_1.png'
  },
  methods: {
    hideDialog: function () {
      this.leavePupAnimation()
    },
    showDialog: function () {
      this.goIntoPupAnimation()
    },
    goIntoPupAnimation: function () {
      this.setData({
        isShow: true
      })
      this.animate('.wx_dialog_container', [{ opacity: 0 }, { opacity: 1 }], 300)
      this.animate('.wx-dialog', [{ scale: [0.8, 0.8] }, { scale: [1, 1] }], 100)
    },
    leavePupAnimation: function () {
      this.animate('.wx_dialog_container', [{ opacity: 1 }, { opacity: 0 }], 100)
      this.animate('.wx-dialog', [{ scale: [1, 1] }, { scale: [0.8, 0.8] }], 150, () => {
        this.setData({
          isShow: false
        })
      })
    },
    wrapClose() {
      this.properties.disWrapClose || this.hideDialog()
    },
    _cancelEvent: function () {
      this.triggerEvent('cancelEvent', '取消')
      this.hideDialog()
    },
    _confirmEvent: function (event) {
      this.triggerEvent('confirmEvent', event)
      this.hideDialog()
    },
    preventEvent() {}
  }
})

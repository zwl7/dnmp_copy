const app = getApp()
const statusOTypebj = {
  '-1': '开通账户发布收费活动 ~',
  0: '正在审核中',
  1: '审核通过',
  2: '待签约',
  3: '待验证',
  4: '已驳回，查看驳回原因',
  5: '待验证',
  6: '银行审核中'
}
Component({
  properties: {
    applyStatus: {
      value: -1,
      type: Number
    },
    amount: {
      value: {
        can_draw_amount: '0.00',
        has_draw_amount: '0.00'
      },
      type: Object
    }
  },
  data: {
    host: app.globalData.config.host,
    status_str: ''
  },
  observers: {
    applyStatus: function (value) {
      this.setData({
        status_str: statusOTypebj[value]
      })
    }
  },
  methods: {
    helper() {
      this.triggerEvent('helper')
    },
    toOrderPage() {
      wx.navigateTo({
        url: '/subPages/order/management/index'
      })
    },
    toManage() {
      wx.navigateTo({
        url: '/subPages/helper/login/index'
      })
    },
    bindcontact(e) {
      let errMsg = e.detail.errMsg
      if (errMsg != 'enterContact:ok') {
        wx.showToast({
          title: errMsg,
          icon: 'none'
        })
      }
    },
    toAccount() {
      if (this.data.applyStatus == 1) {
        wx.navigateTo({
          url: '/accountPages/myAccount/myAccount'
        })
        return
      }
      let url = '/accountPages/entrance/entrance'
      if (this.data.applyStatus == 2) {
        url = '/accountPages/signResult/index'
        url = url.concat('?applyStatus=', this.data.applyStatus)
        wx.navigateTo({
          url: url
        })
        return
      }
      if (this.data.applyStatus == 3 || this.data.applyStatus == 5) {
        url = '/accountPages/remit/index'
        url = url.concat('?applyStatus=', this.data.applyStatus)
        wx.navigateTo({
          url: url
        })
        return
      }
      wx.navigateTo({
        url: url
      })
    }
  },
  lifetimes: {
    attached() {
      console.log(this.data.applyStatus)
    }
  }
})

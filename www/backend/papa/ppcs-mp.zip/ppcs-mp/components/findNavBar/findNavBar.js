const buttonClick = require('./../../utils/buttonClick')
const app = getApp()
Component({
  options: {
    multipleSlots: true
  },
  properties: {
    myProperty: {
      type: Object,
      value: {
        backgroundColor: '#ff7200',
        color: '#ff7200',
        isFindPage: false,
        isHome: false,
        name: ''
      }
    },
    backgroundColor: {
      type: String,
      value: '#ff7200'
    }
  },
  data: {
    navBarHeight: 0,
    menuRight: 0,
    menuWidth: 0,
    menuTop: 0,
    menuHeight: 0,
    leftStyle: '',
    city: ''
  },
  lifetimes: {
    ready() {
      this.init()
      this.getLeftStyle()
    }
  },
  methods: {
    init() {
      let _this = this
      let { menuRight, menuTop, navBarHeight, menuHeight, menuWidth, city } = app.globalData
      this.setData({
        navBarHeight: navBarHeight,
        menuRight: menuRight,
        menuTop: menuTop,
        menuHeight: menuHeight,
        menuWidth: menuWidth,
        city: city ? city : ''
      })
      if (this.properties.myProperty.isFindPage) {
        app.watchGlobalData('city', 'navBar', _this.watchCityNavbar.bind(_this))
      }
    },
    watchCityNavbar(value) {
      this.setData({
        city: value
      })
    },
    // 获取左边style
    getLeftStyle() {
      let { menuHeight, menuRight, menuTop } = this.data
      let obj = {
        height: menuHeight * 2 + 'rpx',
        minHeight: menuHeight * 2 + 'rpx',
        lineHeight: menuHeight * 2 + 'rpx',
        left: menuRight * 2 + 'rpx',
        top: menuTop * 2 + 'rpx'
      }
      let str = ''
      for (let key in obj) {
        let item = key + ':' + obj[key] + ';'
        str += item
      }
      this.setData({
        leftStyle: str
      })
    },
    selectCity: buttonClick.buttonClicked(function () {
      let page = 'index'
      if (this.properties.myProperty.isFindPage) {
        page = 'find'
      }
      wx.navigateTo({
        url: '/pages/city/city?page=' + page
      })
    }, 1000)
  }
})

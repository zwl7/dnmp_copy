// components/pSearch/pSearch.js
Component({
  externalClasses: ['search-class'],
  properties: {
    value: {
      type: String,
      value: ''
    },
    placeholder: {
      type: String,
      value: ''
    },
    disabled: {
      type: Boolean,
      value: false
    },
    showLeftIcon: {
      type: Boolean,
      value: false
    },
    useLeftIconSlot: {
      type: Boolean,
      value: false
    },
    isSearch: {
      type: Boolean,
      value: true
    },
    isClear: {
      type: Boolean,
      value: false
    }
  },
  data: {
    keyword: ''
  },
  methods: {
    textInput: function (e) {
      this.setData({
        value: e.detail.value
      })
      this.triggerEvent('input', e)
    },
    textFoucs(e) {
      this.triggerEvent('focus', e)
    },
    bindconfirm(e) {
      this.triggerEvent('confirm', e.detail)
    },
    //搜索
    handleSearch() {
      let obj = {
        value: this.properties.value
      }
      this.triggerEvent('search', obj)
    },
    // 搜索
    handleClear() {
      this.setData({
        value: ''
      })
      this.triggerEvent('clear', '')
    }
  }
})

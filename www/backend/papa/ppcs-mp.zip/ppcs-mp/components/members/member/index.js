const app = getApp()
Component({
  externalClasses: ['memeber-class', 'role-class', 'auth-class', 'address-class', 'border-line'],
  properties: {
    rightIcon: {
      type: String,
      value: '/assets/images/add-user.png'
    },
    rightText: {
      type: String,
      value: ''
    },
    memberInfo: {
      type: Object,
      value: {
        avatar: '',
        join_time_str: '2022-12-29 14:46:33',
        member_id: 177,
        name: '',
        role: 1,
        role_str: '',
        city_name: '',
        sex: 0,
        is_authenticate: -1
      },
      observer: function (val) {
        if (String(val.is_authenticate)) {
          let auth_map = {
            '-1': '未认证',
            0: '未实名',
            1: '已实名'
          }
          this.setData({
            is_authenticate_str: auth_map[val.is_authenticate]
          })
        }
      }
    },
    active: {
      type: Boolean,
      value: false
    }
  },

  data: {
    avatar: app.globalData.config.host + '/avatar_1.png',
    activity: app.globalData.config.host + '/activity_1.png',
    is_authenticate_str: '未实名'
  },

  methods: {
    previewImages(e) {
      const images = e.currentTarget.dataset.images
      wx.previewImage({
        urls: images
      })
    }
  }
})

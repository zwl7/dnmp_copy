const app = getApp()
const areaList = require('./../../../utils/areadata')
Component({
  properties: {
    show: {
      type: Boolean,
      value: false,
      observer: function (newval) {
        this.setData({
          show_popup: newval
        })
      }
    }
  },
  lifetimes: {
    ready() {
      this.setData({
        areaList: areaList
      })
    }
  },
  data: {
    areaList: null,
    selectValue: '120105',
    picker: null
  },
  methods: {
    onClose() {
      this.setData({
        show: false
      })
    },
    cancel() {
      this.onClose()
      this.triggerEvent('cancel', value)
    },
    confirm() {
      let areaPick = this.getAreaPicker()
      let value = areaPick.getValues()
      this.triggerEvent('confirm', value)
      this.onClose()
    },
    getAreaPicker: function () {
      if (this.picker == null) {
        this.picker = this.selectComponent('#my_van_area')
      }
      return this.picker
    }
  }
})

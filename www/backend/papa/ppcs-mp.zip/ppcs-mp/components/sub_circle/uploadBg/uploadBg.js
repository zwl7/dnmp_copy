const app = getApp()
Component({
  properties: {
    show: {
      type: Boolean,
      value: false,
      observer: function (newval) {
        this.setData({
          show_popup: newval
        })
      }
    }
  },
  data: {
    selectImgList: [
      app.globalData.config.host + '/circle_1.png',
      app.globalData.config.host + '/circle_2.jpg',
      app.globalData.config.host + '/circle_3.jpg',
      app.globalData.config.host + '/circle_4.jpg',
      app.globalData.config.host + '/circle_5.jpg'
    ],
    radioSelect: '',
    activity: app.globalData.config.host + '/activity_1.png',
    upload_icon: '/assets/image/upload_image.png'
  },
  methods: {
    onClose() {
      this.setData({
        show: false
      })
    },
    onConfirm() {
      let { radioSelect, selectImgList } = this.data
      let img = selectImgList[radioSelect]
      if (img) {
        this.triggerEvent('getImg', img)
      }
      this.onClose()
    },
    onChange(event) {
      this.setData({
        radioSelect: event.detail
      })
    },
    // 从相册选择
    changeImage() {
      this.triggerEvent('change')
    },
    selectImg(event) {
      let { index } = event.currentTarget.dataset
      this.setData({
        radioSelect: index
      })
    }
  }
})

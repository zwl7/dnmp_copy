const app = getApp()
Component({
  externalClasses: ['circle-item-class'],
  properties: {
    circleInfo: {
      type: Object,
      value: {
        images: '',
        community_id: '',
        name: ' ',
        is_auth: 0,
        activity_num: 0,
        join_time: '',
        join_day: 0
      }
    },
    eventType: {
      type: String,
      value: 1 //1  跳转星球   2选择星球
    },
    // 显示右边操作按钮
    showOperate: {
      type: Boolean,
      value: false
    }
  },
  data: {
    tag_1: './../../../assets/image/gaungv.png',
    default_image: 'https://cdn-static.papa.com.cn/ppcs_mp/avatar.png'
  },
  methods: {
    handleClick() {
      if (this.data.eventType == 1) {
        let { community_id } = this.properties.circleInfo
        let url = '/subPages/circle/detail/index'
        url = url.concat('?community_id=', community_id)
        wx.navigateTo({
          url: url
        })
      } else {
        this.triggerEvent('sendData', this.properties.circleInfo)
      }
    },
    handleClickOperate() {
      this.triggerEvent('fnClick', this.properties.circleInfo)
    }
  }
})

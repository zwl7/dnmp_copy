const app = getApp()
Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    columns: {
      tyep: Array,
      value: []
    },
    title: {
      type: String,
      value: ''
    },
    defaultIndex:{
      type:Number,
      value:0
    }
  },
  observers:{
    
  },
  lifetimes: {
    ready() {}
  },
  data: {
    picker: null
  },
  methods: {
    onClose() {
      this.setData({
        show: false
      })
    },
    cancel() {
      this.onClose()
      this.triggerEvent('cancel')
    },
    confirm() {
      let areaPick = this.getAreaPicker()
      let value = areaPick.getValues()
      let form = value[0]
      this.triggerEvent('confirm', form)
      this.onClose()
    },
    getAreaPicker: function () {
      if (this.picker == null) {
        this.picker = this.selectComponent('#my_van_picker')
      }
      return this.picker
    }
  }
})

Component({
  properties: {
    tabs: {
      type: Array,
      value: [],
      observer: function (val) {
        console.log(val)
      }
    },
    backgroundColor: {
      type: String,
      value: ''
    },
    activited: {
      type: Number
    },
    typeName: {
      type: String,
      value: 'resource_type_id'
    }
  },
  data: {
    offsetLeft: 10,
    activited: 0
  },
  methods: {
    clickTab(e) {
      let id = e.currentTarget.dataset.id
      let offsetLeft = e.currentTarget.offsetLeft
      if (id === this.data.activited) {
        return
      }
      this.setData({
        activited: id,
        offsetLeft: offsetLeft
      })
      this.triggerEvent('changeTab', id)
    }
  }
})

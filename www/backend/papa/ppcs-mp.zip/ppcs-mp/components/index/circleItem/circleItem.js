const { wxCommunityJoin } = require('./../../../apis/circle')
const app = getApp()
Component({
  externalClasses: ['circle-class'],
  options: {
    styleIsolation: 'shared'
  },
  properties: {
    community: {
      type: Object,
      observer: function (val) {
        if (val.community_id) {
          let flag = app.judgeIsJoin(val.community_id, 1)
          this.setData({
            showJoinBtn: !flag
          })
        }
      }
    }
  },
  data: {
    showJoinBtn: true
  },
  methods: {
    toActivity(event) {
      let { activity_id } = event.currentTarget.dataset
      let url = '/subPages/activity/detail/index'
      url = url.concat('?activity_id=', activity_id)
      wx.navigateTo({
        url: url
      })
    },
    toCircle(event) {
      let { community_id } = event.currentTarget.dataset
      let url = '/subPages/circle/detail/index'
      url = url.concat('?community_id=', community_id)
      wx.navigateTo({
        url: url
      })
    },
    joinCommunity() {
      let flag = this.checkAuth()
      if (!flag) {
        return
      }
      let { community_id } = this.properties.community
      let obj = { community_id: community_id }
      wxCommunityJoin(obj).then(res => {
        if (res.code === 200) {
          wx.showToast({
            title: '加入成功'
          })
          app.globalData.RefreshIndexMyCircle = true
          app.changeJoinList(community_id, 1)
          app.getMemberStatistic()
          this.setData({
            showJoinBtn: false
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    // 判断是否登录
    checkAuth() {
      let flag = true
      if (app.globalData.userInfo.is_authenticate == -1) {
        this.triggerEvent('checkAuth')
        flag = false
      }
      return flag
    }
  }
})

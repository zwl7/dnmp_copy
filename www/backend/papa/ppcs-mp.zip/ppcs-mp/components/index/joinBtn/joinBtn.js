Component({
  properties: {
    showBtn: {
      type: Boolean,
      value: true,
      observer: function (newval, oldval) {}
    },
    pageType: {
      type: String,
      value: 'index' //index mine
    }
  },
  data: {
    icon: './../../../assets/image/plus.png',
    circle: './../../../assets/image/create_cricle.png',
    activity: './../../../assets/image/create_activity.png',
    create_event: './../../../assets/image/create_event.png',
    show: false
  },
  lifetimes: {
    ready() {}
  },
  methods: {
    handleClick() {
      this.triggerEvent('clickPlus')
    },
    showDialog() {
      this.setData({
        show: !this.data.show
      })
    },
    onClose() {
      this.setData({
        show: false
      })
    },
    handleCreate(e) {
      let type = e.currentTarget.dataset.type
      let obj = {
        0: '创建星球',
        1: '创建活动',
        2: '发布赛事'
      }
      setTimeout(() => {
        this.setData({
          show: false
        })
      }, 0)
      switch (type) {
        case '0':
          wx.navigateTo({
            url: '/subPages/circle/create/create'
          })
          break
        case '1':
        case '2':
          wx.navigateTo({
            url: '/subPages/circle/selectCircle/index?activity_type=' + type
          })
          break
      }
    }
  }
})

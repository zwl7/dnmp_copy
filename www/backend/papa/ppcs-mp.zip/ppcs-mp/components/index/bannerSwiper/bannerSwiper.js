const app = getApp()
Component({
  properties: {
    swiperList: {
      type: Array,
      value: [
        {
          image: app.globalData.config.host + '/index_banner.png',
          link: ''
        }
      ]
    }
  },
  data: {},
  methods: {
    handleClick(e) {
      let { link, type } = e.currentTarget.dataset.content
      if (link && type == 1) {
        let url = encodeURIComponent(link)
        wx.navigateTo({
          url: '/subPages/webview/index?url=' + url,
          fail(err) {
            console.log(err)
          }
        })
      }
      if (link && type == 2) {
        wx.navigateTo({
          url: link
        })
      }
    }
  }
})

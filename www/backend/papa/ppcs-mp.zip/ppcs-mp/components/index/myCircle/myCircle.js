const app = getApp()
Component({
  properties: {
    circleList: {
      type: Array,
      value: [],
      observer: function (val) {}
    }
  },
  data: {},
  methods: {
    toCircle(event) {
      let { communityid } = event.currentTarget.dataset
      let url = '/subPages/circle/detail/index'
      url = url.concat('?community_id=', communityid)
      wx.navigateTo({
        url: url
      })
    }
  }
})

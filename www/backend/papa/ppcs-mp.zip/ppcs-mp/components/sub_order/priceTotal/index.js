const app = getApp()
Component({
  externalClasses: ['custom-class'],
  options: {
    addGlobalClass: true
  },
  properties: {
    btnText: {
      type: String,
      value: '下一步'
    },
    leftText: {
      type: String,
      value: '总计'
    },
    price: {
      type: Number,
      value: 0
    },
    enableClick: {
      type: Boolean, // 按钮是否可点击  true 是 false 否
      value: false
    }
  },

  data: { isIos: app.globalData.isIos },
  methods: {
    next(e) {
      if (!this.properties.enableClick) return // 按钮不可点击
      // 传递事件
      // joinActivity:加入活动
      this.triggerEvent('clickBtn', e.target.dataset.event)
    }
  }
})

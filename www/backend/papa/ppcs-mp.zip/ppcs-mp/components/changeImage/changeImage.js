const app = getApp()
Component({
  properties: {
    show: {
      type: Boolean,
      value: false,
      observer: function (newval) {
        app.globalData.cropperHeight = newval
      }
    },
    sizeX: {
      optionalTypes: [String, Number],
      value: 300
    },
    sizeY: {
      optionalTypes: [String, Number],
      value: 300
    },
    globalImg: {
      type: String,
      value: ''
    },
    // 是否需要裁剪
    needClip: {
      type: Boolean,
      value: true
    },
    extaActions: {
      type: Array,
      value: []
    }
  },
  observers: {
    extaActions: function (val) {
      if (val) {
        this.setData({
          actions: this.data.actions.concat(val)
        })
      }
    }
  },
  data: {
    actions: [{
        name: '拍照',
        type: 'camera'
      },
      {
        name: '从相册选择',
        type: 'album'
      }
    ]
  },
  methods: {
    onClose() {
      this.setData({
        show: false
      })
    },
    onSelect(event) {
      let {
        name,
        type
      } = event.detail
      if (type == 'camera' || type == 'album') {
        this.chooseImage(type)
      }
      this.triggerEvent('select', event.detail)
    },
    closeAction() {
      this.setData({
        show: false
      })
    },
    // 选择图片
    chooseImage(type) {
      console.log('=======================图片type', type)
      let {
        sizeX,
        sizeY,
        globalImg,
        needClip
      } = this.properties
      let _this = this
      wx.chooseMedia({
        count: 1,
        mediaType: ['image'],
        sizeType: ['original'],
        sourceType: [type],
        success: function (e) {
          wx.showToast({
            icon: 'loading',
            mask: true,
            duration: 2500
          })
          let tempFile = e.tempFiles[0].tempFilePath
          if (needClip) {
            let url = '/subPages/picture/picture?'.concat('imgSrc=', tempFile).concat('&&size_x=', sizeX).concat('&&size_y=', sizeY).concat('&&globalImg=', globalImg)
            wx.navigateTo({
              url: url
            })
          } else {
            _this.triggerEvent('getImage', tempFile)
          }
          wx.hideToast()
        },
        fail: function (e) {
          console.log('ewqe', e)
        }
      })
    }
  }
})
Component({
  externalClasses: ['custom-class'],
  properties: {
    type: {
      type: String,
      value: '',
      observer: function (val) {
        this.setData({
          loading_type: val
        })
      }
    },
    title: {
      type: String,
      value: ''
    }
  },
  data: {
    loading_type: ''
  },
  methods: {}
})

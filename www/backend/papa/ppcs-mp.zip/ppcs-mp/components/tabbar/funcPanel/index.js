const { activityApplyVerify, collectActivity } = require('./../../../apis/activity')
const { buttonClicked } = require('./../../../utils/buttonClick')
const { formatTimeBase } = require('./../../../utils/date')
const app = getApp()
Component({
  properties: {
    statusMap: {
      type: Object,
      value: {
        is_manager: false, //是否管理员
        is_join: false, //是否加入
        activity_status: 0, // 活动状态 0  活动未开始  1  活动进行中  2  活动已结束  3 活动已解散  4  未开始售票  5 售票倒计时
        now_save_session: 0, //在售票数
        wait_pay_order: '', //待支付订单号
        can_apply_num: 0, //可购买总票数
        sku_clice: '',
        countdown_time: '',
        min_session_start_time: ''
      },
      observer: function (val) {
        if (val.min_session_start_time && val.activity_status == 4) {
          let str = formatTimeBase(val.min_session_start_time, '{m}月{d}日 {h}:{i}:{s}')
          this.setData({
            min_session_start_time_str: str
          })
        }
        if (val.countdown_time && val.activity_status == 5) {
          this.countdownTime(val.countdown_time)
        }
      }
    },
    activity_id: {
      type: Number,
      value: '',
      observer: function (val) {
        if (val) {
          let flag = app.judgeIsJoin(val, 4)
          if (flag) {
            this.setData({
              likeStatus: 2,
              likeStr: '取消'
            })
          } else {
            this.setData({
              likeStatus: 1,
              likeStr: '喜欢'
            })
          }
        }
      }
    },
    is_have_ticket: {
      type: Boolean,
      value: false
    }
  },
  lifetimes: {
    attached() {
      if (app.globalData.isIos) {
        this.setData({
          bottomHeight: '170rpx'
        })
      }
    }
  },
  data: {
    bottomHeight: '120rpx',
    likeStatus: 1, //1喜欢  2 取消
    likeStr: '喜欢',
    min_session_start_time_str: '',
    hour: '--',
    minutes: '--',
    seconds: '--'
  },
  methods: {
    call(e) {
      let { event, type } = e.currentTarget.dataset
      let is_reject = this.properties.statusMap.is_reject
      let reject_methods = ['joinActivity', 'share', 'normalShowTicket']
      if (is_reject && reject_methods.indexOf(event) != -1) {
        this.triggerEvent('illegal')
        return
      }

      let flag = this.checkAuth(event)
      if (!flag) {
        return
      }
      let _this = this
      if (type == 1) {
        let methods = {
          toCheckTicket: this.toCheckTicket,
          activityOver: this.activityOver,
          activityHappening: this.activityHappening,
          activityDismiss: this.activityDismiss,
          orderPay: this.orderPay
        }
        let func = methods[event]
        func.apply(_this)
      } else {
        this.triggerEvent('clickBtn', event)
      }
    },
    // 去验票
    toCheckTicket() {
      let _this = this
      wx.scanCode({
        success(res) {
          console.log(res)
          let result = res.result
          var res = result.split(',')
          let obj = {
            applicant_code: res[0],
            member_id: res[2],
            activity_id: res[1]
          }
          _this.checkTicket(obj.applicant_code)
        },
        fail(error) {
          if (error.errMsg != 'scanCode:fail cancel') {
            wx.showToast({
              title: '二维码识别失败',
              icon: 'none'
            })
          }
        }
      })
    },
    checkTicket(applicant_code) {
      let obj = { applicant_code: applicant_code }
      activityApplyVerify(obj).then(res => {
        if (res.code === 200) {
          let status_info = this.getStatusInfo(res.data.status, res.data.verify_status, res.data.status_str)
          let user_info = {
            avatar: res.data.avatar,
            name: res.data.nick_name ? res.data.nick_name : res.data.name,
            session_name: res.data.sku_info,
            price: res.data.pay_price,
            applicant_code: res.data.applicant_code,
            status: status_info.status,
            verify_status: res.data.verify_status,
            check_str: status_info.status_str
          }
          app.globalData.checkTicketInfo = user_info
          let url = '/subPages/order/checkTicket/index'
          wx.navigateTo({
            url: url
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    },
    getStatusInfo(status, verify_status, status_str) {
      let status_index = 3
      let status_new_str = status_str
      if (verify_status === 1) {
        status_index = 1
        status_new_str = '核销成功'
      } else {
        if (status == 7) {
          status_index = 3
        } else {
          status_index = 2
        }
      }
      return {
        status: status_index,
        status_str: status_new_str
      }
    },
    // 活动进行中
    activityHappening() {},
    // 活动已结束
    activityOver() {
      wx.showToast({
        title: '活动已结束',
        icon: 'none'
      })
    },
    // 活动已解散
    activityDismiss() {
      wx.showToast({
        title: '活动已解散',
        icon: 'none'
      })
    },
    // 存在待支付订单
    orderPay() {
      let { wait_pay_order } = this.properties.statusMap
      if (!wait_pay_order) {
        wx.showToast({
          title: '订单错误',
          icon: 'none'
        })
        return
      }
      this.triggerEvent('createOrder')
    },
    // 客服
    bindcontact(e) {
      console.log(e)
      let errMsg = e.detail.errMsg
      if (errMsg != 'enterContact:ok') {
        wx.showToast({
          title: errMsg,
          icon: 'none'
        })
      }
    },
    // 校验实名
    checkAuth(event) {
      let flag = true
      if (event == 'joinActivity' && app.globalData.userInfo.is_authenticate == -1) {
        flag = false
        this.selectComponent('#authDialog').showDialog()
        return flag
      }
      return flag
    },
    // 确认弹窗 回调
    authConfirm() {
      if (app.globalData.userInfo.is_authenticate === -1) {
        wx.navigateTo({
          url: '/subPages/system/login/login?page=activity_detail&activity_id=' + this.properties.activity_id
        })
      }
      // if (app.globalData.userInfo.is_authenticate === 0) {
      //   wx.navigateTo({
      //     url: '/subPages/system/Authentication/index'
      //   })
      // }
    },
    // 喜欢
    handleLike: buttonClicked(function () {
      let { likeStatus } = this.data
      let obj = {
        activity_id: this.properties.activity_id,
        status: likeStatus
      }
      collectActivity(obj).then(res => {
        if (res.code === 200) {
          this.setData({
            likeStatus: likeStatus == 1 ? 2 : 1,
            likeStr: likeStatus == 1 ? '取消' : '喜欢'
          })
          let handle = likeStatus == 1 ? 'add' : 'del'
          app.globalData.RefreshMinePage = true
          app.changeJoinList(this.properties.activity_id, 3, handle)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }),
    // 倒计时
    countdownTime(diff) {
      let h = Math.floor(diff / 60 / 60)
      let m = Math.floor((diff / 60) % 60)
      let s = Math.floor(diff % 60)
      this.setData({
        hour: String(h).padStart(2, '0'),
        minutes: String(m).padStart(2, '0'),
        seconds: String(s).padStart(2, '0')
      })
      diff -= 1
      let timer = setInterval(() => {
        h = Math.floor(diff / 60 / 60)
        m = Math.floor((diff / 60) % 60)
        s = Math.floor(diff % 60)

        if (diff == 0) {
          clearInterval(timer)
          timer = null
          this.setData({
            'statusMap.activity_status': 0
          })
        } else {
          this.setData({
            hour: String(h).padStart(2, '0'),
            minutes: String(m).padStart(2, '0'),
            seconds: String(s).padStart(2, '0')
          })
        }
        diff -= 1
      }, 1000)
    }
  }
})

// components/tabbar/funcPanel.js
const app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    is_quit: {
      type: Boolean,
      value: false
    }
  },
  options: {
    addGlobalClass: true
  },
  /**
   * 组件的初始数据
   */
  data: {
    isIos: app.globalData.isIos
  },

  /**
   * 组件的方法列表
   */
  methods: {
    call(e) {
      // 传递事件
      switch (e.currentTarget.dataset.event) {
        case 'left':
          this.triggerEvent('leftIconCal')
          break
        case 'middle':
          this.triggerEvent('middleIconCal')
          break
        case 'right':
          this.triggerEvent('rightIconCal')
          break
        case 'btn':
          this.triggerEvent('btnCal')
      }
    }
  }
})

Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    type: {
      type: String,
      value: 'activity'
    }
  },
  data: {
    showShare: true
  },
  methods: {
    clickModel: function () {
      this.setData({
        show: !this.data.show
      })
    },
    clickShare(event) {
      this.clickModel()
      let { type } = event.currentTarget.dataset
      this.triggerEvent('share', type)
    }
  }
})

const app = getApp()
Component({
  externalClasses: ['activity-class'],
  properties: {
    activity: {
      type: Object
    },
    get_success_location: {
      type: Boolean,
      value: true
    }
  },
  data: {},
  methods: {
    toActivity() {
      let { activity_id } = this.properties.activity
      let url = '/subPages/activity/detail/index'
      url = url.concat('?activity_id=', activity_id)
      wx.navigateTo({
        url: url
      })
    }
  }
})

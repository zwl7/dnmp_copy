const { formatTimeBase, formatActivityTime } = require('../../utils/date')
const { getAccountAmountRecord, getActivityPayCount, getCirlces } = require('./../../apis/helper')
Page({
  data: {
    cirlcesList: [{ text: '全部星球', value: 0 }],
    option2: [
      { text: '按活动查看', value: 1 },
      { text: '按明细查看', value: 2 }
    ],
    communityId: 0,
    viewType: 1,
    currentDate: new Date().getTime(),
    minDate: new Date('2022-12-31').getTime(),
    maxDate: new Date().getTime(),
    isSpin: false,
    dataList: {},
    time: '',
    page: 1,
    size: 10,
    finish: false,
    loading: false,
    showEmpty: false
  },
  onLoad(options) {
    console.log(options)
    if (options.viewType) {
      // 1  活动统计  2 流水统计
      this.setData({
        viewType: Number(options.viewType)
      })
    }
    if (options.communityId) {
      this.setData({
        communityId: Number(options.communityId)
      })
    }

    let { time } = this.getTimeStr()
    this.setData({
      time: time,
      showEmpty: true
    })
    this.getCirlcesList()
    this.getList()
  },
  jumpToPage() {
    let type = this.data.viewType === 1 ? 2 : 1
    let communityId = this.data.communityId
    wx.redirectTo({
      url: `/accountPages/billingDetails/billingDetails?viewType=${type}&communityId=${communityId}`
    })
  },
  changeDropDown(event) {
    let detail = event.detail
    let type = event.currentTarget.dataset.type
    this.setData({
      [type]: detail
    })
    if (type === 'communityId') {
      let { time } = this.getTimeStr()
      console.log('刷新')
      this.setData(
        {
          dataList: {},
          page: 1,
          loading: true,
          finish: false,
          showEmpty: true,
          time: time
        },
        () => {
          this.getList()
        }
      )
    }
    if (type === 'viewType') {
      this.setData({
        dataList: {}
      })
      this.getList()
    }
  },
  getTimeStr() {
    let now = new Date()
    let year = now.getFullYear()
    let month = now.getMonth() + 1
    month = String(month).padStart(2, '0')
    return {
      str: `${year}年${month}月`,
      time: `${year}-${month}`,
      year,
      month
    }
  },
  getLastMonth() {
    let now = new Date(this.data.time)
    var year = now.getFullYear()
    var month = now.getMonth()
    if (month == 0) {
      year -= 1
      month = 12
    }
    month = month < 10 ? '0' + month : month
    let lastYearMonth = year + '-' + month
    return lastYearMonth
  },
  judgeTime() {
    let now = new Date(this.data.time).getTime()
    let start_time = new Date('2022-12-01').getTime()
    console.log(now, start_time, now <= start_time)
    if (now <= start_time) {
      this.setData({
        finish: true
      })
    }
  },
  confirmTime(event) {
    const time = new Date(event.detail)
    let time_str = formatTimeBase(time, '{y}-{m}')
    this.setData({ time: time_str, isSpin: false, finish: false, dataList: {}, showEmpty: true })
    console.log(time)
    this.getList()
  },
  checkTime(event) {
    let time = event.currentTarget.dataset.time
    if (time) {
      let year = time.substring(0, 4)
      let month = time.substring(5, 7)
      let str = year + '-' + month
      let date = new Date(str).getTime()
      this.setData({
        currentDate: date
      })
    }
    this.setData({ isSpin: true })
  },
  onClose() {
    this.setData({ isSpin: false })
  },
  toBuillParticulars(event) {
    let activity_id = event.currentTarget.dataset.activity_id
    let url = `/accountPages/particulars/particulars?activity_id=${activity_id}`
    wx.navigateTo({
      url: url
    })
  },
  onReachBottom() {
    if (this.data.isSpin) {
      return
    }
    console.log('触底加载')
    if (this.data.finish) {
      console.log('加载完成')
      this.setData({
        loading: false
      })
      return
    }
    this.setData({
      page: this.data.page + 1
    })
    this.getList()
  },
  onPullDownRefresh() {
    if (this.data.isSpin) {
      return
    }
    let { time } = this.getTimeStr()
    console.log('刷新')
    this.setData(
      {
        dataList: {},
        page: 1,
        loading: true,
        finish: false,
        showEmpty: true,
        communityId: 0,
        time: time
      },
      () => {
        this.getList()
        wx.stopPullDownRefresh()
      }
    )
  },
  isFullScreen() {
    wx.createSelectorQuery()
      .selectViewport()
      .scrollOffset()
      .exec(async res => {
        const windowHeight = wx.getSystemInfoSync().windowHeight
        const scrollHeight = res[0].scrollHeight
        if (windowHeight + 40 >= scrollHeight) {
          this.onReachBottom()
        }
      })
  },
  async getList() {
    let params = {
      page: this.data.page,
      size: 10,
      community_id: this.data.communityId,
      time: this.data.time
    }
    if (!params.community_id) {
      delete params.community_id
    }
    this.setData({
      loading: true
    })
    let res = {}
    if (this.data.viewType === 1) {
      res = await getAccountAmountRecord(params)
    }
    if (this.data.viewType === 2) {
      res = await getActivityPayCount(params)
    }
    if (res.code === 200) {
      let time = this.data.time
      let dataList = this.data.dataList
      res.data.time_str = time.replace(/-/g, '年') + '月'
      if (this.data.viewType == 2) {
        let status_map = {
          1: '收费中',
          2: '已结束待打款',
          3: '已提现'
        }
        res.data.list.map(e => {
          // e.time_str = formatTimeBase(e.time, '{m}-{d} {h}:{i}')
          e.time_str = formatActivityTime(e.start_time, e.end_time)
          e.status_str = status_map[e.status]
        })
      }

      if (dataList[time]) {
        dataList[time].list = dataList[time].list.concat(res.data.list)
        this.setData({
          dataList: dataList,
          showEmpty: false
        })
      } else {
        // if (res.data.list.length > 0) {

        // }
        dataList[time] = res.data
        this.setData({
          dataList: dataList,
          showEmpty: false
        })
      }
      if (res.data.list.length === 0 && !this.data.finish) {
        this.setData({
          page: 1,
          time: this.getLastMonth()
        })
        this.getList()
      }
      if (!this.data.finish) {
        console.log('手动哦按段')
        this.isFullScreen()
      } else {
        this.setData({
          loading: false
        })
        console.log('haha')
      }
      this.judgeTime()
    } else {
      this.showToast(res.message)
    }
  },
  async getCirlcesList() {
    const { data } = await getCirlces({ role: 1 })
    let list = this.data.cirlcesList
    data.forEach(item => {
      list.push({
        text: item.name,
        value: item.community_id
      })
    })
    this.setData({ cirlcesList: list, community_id: data[0].value })
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  }
})

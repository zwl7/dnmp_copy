const app = getApp()
const { checkSign, sendSignMsmRequest } = require('../../apis/account')
Page({
  data: {
    apply_status: '00',
    apply_status_msg: '正在查询',
    url: '',
    phone: '',
    sign_no: ''
  },
  onLoad(options) {
    try {
      const wxDistributionAuth = wx.getStorageSync('wxDistributionAuth')
      if (wxDistributionAuth) {
        const info = JSON.parse(wxDistributionAuth)
        let phone = info.phone
        phone = phone.substr(phone.length - 4)
        this.setData({
          phone: phone,
          sign_no: info.sign_no
        })
      }
    } catch (error) {}
    this.checkSign()
  },
  // 签约检测
  checkSign() {
    checkSign({})
      .then(res => {
        let data = res.data
        let showDialogStatus = ['04', '05', '06', '28', '31', '32', '33', '34', '99']
        this.setData({
          apply_status: data.apply_status,
          apply_status_msg: data.apply_status_msg
        })
        if (showDialogStatus.indexOf(data.apply_status) != -1) {
          this.selectComponent('#errorDialog').showDialog()
        }
      })
      .catch(err => {
        wx.showToast({
          title: err.message,
          icon: 'none'
        })
      })
  },
  handleCopy() {
    let url = this.data.url
    wx.setClipboardData({
      data: url,
      success: function (res) {
        wx.showToast({
          title: '复制成功',
          icon: 'success'
        })
      }
    })
  },
  sendSignMsm() {
    try {
      let sendTime = wx.getStorageSync('sendSignMsm')
      let maxTime = 60 * 1000
      if (sendTime) {
        let now = new Date().getTime()
        let diff = now - sendTime
        if (diff < maxTime) {
          let cutdownTime = Math.ceil((maxTime + sendTime - now) / 1000)
          let message = `${cutdownTime}秒后重新发送`
          this.showToast(message)
        } else {
          this.submitSendSignMsm()
        }
      } else {
        this.submitSendSignMsm()
      }
    } catch (error) {
      this.submitSendSignMsm()
    }
  },
  submitSendSignMsm() {
    let _this = this
    wx.showModal({
      title: '提示',
      content: '重新发送签约短信',
      complete: res => {
        if (res.cancel) {
        }
        if (res.confirm) {
          sendSignMsmRequest({ sign_no: _this.data.sign_no }).then(res => {
            if (res.code == 200) {
              _this.showToast('发送成功')
              let sendTime = wx.setStorageSync('sendSignMsm', new Date().getTime())
            } else {
              _this.showToast(res.message)
            }
          })
        }
      }
    })
  },
  showToast(title) {
    wx.showToast({
      title: title,
      icon: 'none'
    })
  },
  bindcontact(e) {
    let errMsg = e.detail.errMsg
    if (errMsg != 'enterContact:ok') {
      wx.showToast({
        title: errMsg,
        icon: 'none'
      })
    }
  }
})

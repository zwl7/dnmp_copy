const { addWxDistributionAuth, updateWxDistributionAuth } = require('../../apis/account')
Page({
  data: {
    params: {}
  },
  onLoad(options) {
    const params = JSON.parse(wx.getStorageSync('applyAccountForm'))
    if (!params.is_worth) {
      try {
        let list = JSON.parse(params.beneficiary_user_list)
        list.map(e => {
          if (e.identity_card_end_date == '永久') {
            e.identity_card_end_date = '9999-12-31'
          }
        })
        params.user_list = JSON.stringify(list)
        delete params.beneficiary_user_list
      } catch (error) {}
    }
    this.bigDialog = this.selectComponent('#bigDialog')
    this.setData({ params })
  },
  showDialog() {
    if (this.submit()) {
      this.bigDialog.showDialog()
    }
  },
  submit() {
    const params = this.data.params
    if (params.identity_card_end_date == '永久') {
      params.identity_card_end_date = '9999-12-31'
    }
    let applyAccountForm = wx.getStorageSync('wxDistributionAuth') ? JSON.parse(wx.getStorageSync('wxDistributionAuth')) : ''
    let initFace = addWxDistributionAuth
    // 驳回
    if (applyAccountForm && applyAccountForm.status == 4) {
      initFace = updateWxDistributionAuth
      params['auth_id'] = applyAccountForm.auth_id
      params['member_id'] = applyAccountForm.member_id
    }
    initFace(params).then(res => {
      if (res.code == 200) {
        wx.removeStorageSync('applyAccountForm')
        wx.showToast({
          title: res.data
        })
        wx.switchTab({
          url: '/pages/mine/mine?apply=' + applyAccountForm.status
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none',
          duration: 2000
        })
      }
    })
  }
})

const app = getApp()
const { getCirlces, getMyCommunityCountInfo } = require('../../apis/helper')
Page({
  data: {
    host: app.globalData.config.host,
    cirlcesList: [{ text: '全部星球', value: '0' }], // 星球列表
    community_id: '0',
    amountInfo: {
      amount: '0.00',
      has_draw_amount: '0.00',
      wait_amount: '0.00',
      freeze_amount: '0.00'
    },
    bank_no_str: '', //银行
    enterprise_type: ''
  },
  async onLoad(options) {
    await this.getCirlcesList()
    this.getMyCommunityCountInfo()
    this.handleDistributionAuthStorage()
  },
  toBillingDetails() {
    wx.navigateTo({
      url: '/accountPages/billingDetails/billingDetails'
    })
  },
  jumpToPage(event) {
    let page = event.currentTarget.dataset.page
    let pageMap = {
      1: '/accountPages/billingDetails/billingDetails?viewType=2&communityId=' + this.data.community_id,
      2: '/accountPages/bankInfo/bankInfo',
      3: `/accountPages/applyRecord/applyRecord?enterprise_type=${this.data.enterprise_type}`,
      4: '/accountPages/entrance/entrance?hiddenFooter=1',
      5: '/accountPages/viewAggrement/index',
      6: '/accountPages/billingDetails/billingDetails?viewType=1&communityId=' + this.data.community_id
    }
    console.log(this.data.enterprise_type)
    wx.navigateTo({
      url: pageMap[page]
    })
  },
  async getCirlcesList() {
    const { data } = await getCirlces({ role: 1 })
    let list = this.data.cirlcesList
    data.forEach(item => {
      list.push({
        text: item.name,
        value: item.community_id
      })
    })
    this.setData({ cirlcesList: list })
  },
  dropdownChange(e) {
    this.setData({ community_id: e.detail })
    this.getMyCommunityCountInfo()
  },
  // 钱包详情
  async getMyCommunityCountInfo() {
    let parmas = {
      community_id: this.data.community_id
    }
    if (!parmas.community_id) {
      delete parmas.community_id
    }
    const res = await getMyCommunityCountInfo(parmas)
    if (res.code === 200) {
      let amountInfo = {
        amount: res.data.wallet_amount,
        has_draw_amount: res.data.has_draw_amount,
        wait_amount: res.data.pending_amount,
        freeze_amount: res.data.freeze_amount
      }
      this.setData({ amountInfo: amountInfo })
    } else {
      wx.showToast({
        title: res.message,
        icon: 'none'
      })
    }
  },
  handleDistributionAuthStorage() {
    try {
      let info = wx.getStorageSync('wxDistributionAuth')
      if (info) {
        let distribution = JSON.parse(info)
        console.log(distribution)
        this.setData({
          bank_no_str: distribution.bank_no_str,
          enterprise_type: distribution.enterprise_type
        })
      }
    } catch (error) {}
  }
})

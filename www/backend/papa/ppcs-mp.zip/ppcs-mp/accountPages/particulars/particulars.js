const { getActivityBillInfo } = require('../../apis/helper')
const { formatActivityTime } = require('./../../utils/date')
const app = getApp()
Page({
  data: {
    activity_id: '',
    isIos: app.globalData.isIos,
    detail: {
      name: '',
      amount: '',
      images: '',
      planner: '',
      time_str: '',
      addr: '',
      activity_time_str: ''
    },
    bill: {
      pay_amount: '0.00',
      has_draw_amount: '0.00',
      not_draw_amount: '0.00',
      freeze_amount: '0.00',
      fee_amount: '0.00'
    }
  },
  onLoad(options) {
    let activity_id = options.activity_id
    this.setData({
      activity_id: activity_id
    })
    this.getActivityBillInfo()
  },
  async getActivityBillInfo() {
    let params = {
      activity_id: this.data.activity_id
    }
    let res = await getActivityBillInfo(params)
    if (res.code === 200) {
      let detail = res.data.detail
      res.data.detail.activity_time_str = formatActivityTime(detail.start_time, detail.end_time)
      this.setData({
        detail: res.data.detail,
        bill: res.data.bill
      })
    } else {
      wx.showToast({
        title: res.message,
        icon: 'none'
      })
    }
  },
  jumpToPage() {
    wx.navigateTo({
      url: '/accountPages/activityBillingDetail/index?activity_id=' + this.data.activity_id
    })
  }
})

import { saveImageToAlbum, uploadFile } from './../../utils/util'
import buttonClick from './../../utils/buttonClick'
Page({
  data: {
    image: 'https://cdn-static.papa.com.cn/ppcs_mp/yinlianPng.png'
  },
  onLoad() {
    this.handleDistributionAuthStorage()
  },
  previewImage() {
    let _this = this
    let image = this.data.image
    wx.previewImage({
      current: image,
      urls: [image]
    })
  },
  saveImage: buttonClick.buttonClicked(function () {
    let image = this.data.image
    if (image && typeof image === 'string') {
      wx.getImageInfo({
        src: image,
        success: function (sres) {
          saveImageToAlbum(sres.path)
        }
      })
    }
  }, 1000),
  handleDistributionAuthStorage() {
    try {
      let info = wx.getStorageSync('wxDistributionAuth')
      if (info) {
        let distribution = JSON.parse(info)
        let agreement_images = distribution.agreement_images
        if (agreement_images) {
          this.setData({
            image: agreement_images
          })
        }
      }
    } catch (error) {}
  }
})

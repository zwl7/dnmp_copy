let mustField = {
  identity_name: '身份证名字未填',
  identity_card_num: '身份证号码未填',
  identity_address: '户籍地未填',
  identity_card_start_date: '身份证起始日期未填',
  identity_card_end_date: '身份证截止日期未填',
  bank_account_name: '银行账号名未填',
  bank_account_num: '银行卡账号未填',
  bank_name: '银行名未填',
  bank_city: '银行开户城市未选择',
  show_name: '收款方名字未填',
  phone: '手机号未填',
  email: '邮箱未填',
  enterprise_images: '企业营业执照未上传',
  bank_images: '银行卡正面照',
  enterprise_date: '企业名称成立日期未填',
  enterprise_name: '企业名称未填',
  enterprise_type: '企业类型未选择',
  identity_images: '身份认证图片未上传',
  identity_images_r: '身份认证图片反面未上传',
  social_credit_code: '社会信用代码未填',
  sms_code: '验证码不能为空',
  bank_no: '开户银行所在地未选择',
  enterprise_address: '企业地址未填写',
  enterprise_country_str: '企业所在地区未选择'
}

const statusOTypebj = {
  0: '审核中',
  1: '审核通过',
  2: '待签约',
  3: '待验证',
  4: '点击查看驳回理由',
  6: '银行审核中'
}
Page({
  data: {
    flag: '', // enterprise 企业认证 my个人认证
    presentIndex: 0,
    isCheck: '1', // 1 申请 2 查看
    status: '',
    type_str: '',
    isUpdate: 0,
    reject_str: '驳回个什么我也不知道，应该也没人看吧',
    mustFieldList: [] //必传字段数组
  },

  onLoad(options) {
    const { flag, check, status } = options
    console.log(options)
    this.setData({ flag, isCheck: check, presentIndex: check == 1 ? 1 : 3, status, type_str: statusOTypebj[status] })
    this.bigDialog = this.selectComponent('#bigDialog')
    let applyAccountForm = wx.getStorageSync('wxDistributionAuth') || ''
    if (applyAccountForm) {
      applyAccountForm = JSON.parse(applyAccountForm)
      console.log(applyAccountForm)
      this.setData({
        reject_str: applyAccountForm.reason || ''
      })
      if (!options.status) {
        this.setData({
          type_str: statusOTypebj[applyAccountForm.status]
        })
      }
    }
    this.getMustFieldList()
  },
  next() {
    if (this.data.presentIndex == 3) {
      this.setData({ presentIndex: 1 })
    } else {
      this.setData({ presentIndex: this.data.presentIndex + 1 })
    }
    this.goTop()
  },
  up() {
    this.setData({ presentIndex: 2 })
    this.goTop()
  },
  showDialog() {
    if (this.data.status == 4) {
      this.bigDialog.showDialog()
    }
  },
  goTop() {
    wx.createSelectorQuery()
      .select('#authApply')
      .boundingClientRect(res => {
        console.log(res, 'res')
        wx.pageScrollTo({
          duration: 0,
          scrollTop: res.top
        })
      })
      .exec()
  },
  // 校验字段
  verify() {
    // flag enterprise 企业认证 my个人认证
    const {
      accountForm,
      bank_account_name,
      bank_account_num,
      bank_city,
      social_credit_code,
      enterprise_name,
      bank_name,
      bank_no_str,
      email,
      identity_address,
      identity_card_num,
      identity_des,
      identity_name,
      is_worth,
      media_account,
      phone,
      show_namem,
      show_name,
      bank_city_name,
      enterprise_address,
      enterprise_country_str,
      sms_code,
      wx_num,
      enterprise_type,
      enterprise_type_name,
      bank_no,
      firmCity_id,
      bank_city_str,
      bank_id,
      enterprise_country_id,
      pid,
      beneficiary_user_list,
      agreement_images
    } = this.selectComponent('#information').data
    const { images, bank_images, enterprise_images, enterprise_date, identity_images, identity_images_r, identity_card_start_date, identity_card_end_date } = accountForm
    let form = {
      bank_account_name,
      bank_account_num,
      bank_city,
      bank_name,
      bank_no_str,
      bank_no,
      show_name,
      email,
      identity_address,
      identity_card_num,
      identity_des,
      bank_city_name,
      identity_name,
      bank_city_str,
      is_worth,
      media_account,
      phone,
      show_namem,
      sms_code,
      wx_num,
      identity_images,
      identity_images_r,
      identity_card_start_date,
      identity_card_end_date,
      firmCity_id,
      bank_id,
      pid,
      identity_type: this.data.flag == 'enterprise' ? '2' : '1',
      images,
      bank_images,
      enterprise_address,
      enterprise_country_id,
      enterprise_country_str,
      agreement_images
    }

    // 企业认证字段
    let enterpriseForm = {
      images,
      bank_images,
      enterprise_images,
      enterprise_date,
      enterprise_name,
      social_credit_code,
      enterprise_type,
      enterprise_type_name,
      enterprise_address,
      enterprise_country_id,
      enterprise_country_str
    }
    // 校验日期
    const defaultStr = '请选择'
    // 企业认证字段
    if (this.data.flag == 'enterprise') {
      form = { ...form, ...enterpriseForm }
      if (enterprise_date == defaultStr) {
        wx.showToast({
          title: mustField['enterprise_date'],
          icon: 'none',
          duration: 2000
        })
        this.selectComponent('#information').pageScrollToBottom('enterprise_date')
        return
      }
    } else {
      mustField['agreement_images'] = '请签署用户协议'
      mustField['images'] = '手持身份证照片未上传'
    }
    if (identity_card_start_date == defaultStr) {
      wx.showToast({
        title: mustField['identity_card_start_date'],
        icon: 'none',
        duration: 2000
      })
      this.selectComponent('#information').pageScrollToBottom('identity_card_start_date')
      return
    }
    if (identity_card_end_date == defaultStr) {
      wx.showToast({
        title: mustField['identity_card_end_date'],
        icon: 'none',
        duration: 2000
      })
      this.selectComponent('#information').pageScrollToBottom('identity_card_end_date')
      return
    }
    // 校验长度
    if (identity_address) {
      if (identity_address.length < 10) {
        wx.showToast({
          title: '户籍地址字数不能小于10位',
          icon: 'none',
          duration: 2000
        })
        this.selectComponent('#information').pageScrollToBottom('identity_address')
        return
      }
    }

    // 校验必填表单是否填写
    Object.keys(form).forEach(item => {
      if (!form[item] && mustField[item]) {
        if (item === 'enterprise_address') {
          mustField[item] = '居住地址不存在'
        }
        if (item === 'enterprise_country_str') {
          mustField[item] = '居住的确未选择'
        }
        if (item === 'bank_images' && this.data.flag == 'enterprise') {
          mustField[item] = '开户许可证未填写'
        }
        wx.showToast({
          title: mustField[item],
          icon: 'none',
          duration: 2000
        })
        this.selectComponent('#information').pageScrollToBottom(item)
        throw new Error(mustField[item])
      }
    })

    // 校验收件人信息
    if (!is_worth && beneficiary_user_list.length > 0) {
      beneficiary_user_list.forEach((item, index) => {
        Object.keys(item).forEach(c => {
          if (item && !item[c] && mustField[c]) {
            wx.showToast({
              title: `[股东${index + 1}]${mustField[c]}`,
              icon: 'none',
              duration: 2000
            })
            throw new Error(mustField[c])
          }
        })
      })
    }
    console.log(this.data.flag, is_worth)
    if (this.data.flag == 'enterprise' && !is_worth && beneficiary_user_list.length === 0) {
      wx.showToast({
        title: '请添加一个受益人',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (!is_worth) {
      form['beneficiary_user_list'] = JSON.stringify(beneficiary_user_list)
    }
    // 校验邮箱 微信号
    wx.setStorageSync('applyAccountForm', JSON.stringify(form))
    this.next()
  },
  // 修改信息
  updateInfo() {
    this.setData({ presentIndex: 1, isCheck: 1, status: 5, isUpdate: 1 })
  },
  // 获取必传字段数组
  getMustFieldList() {
    let list = Object.keys(mustField)
    if (this.data.flag === 'my') {
      list.push('agreement_images', 'images')
    }
    this.setData({
      mustFieldList: list
    })
  }
})

const { getAuthApplyList } = require('./../../apis/helper')
const { formatTimeBase } = require('./../../utils/date')
Page({
  data: {
    enterprise_type: '',
    show: false,
    list: [],
    comment: ''
  },
  onLoad(options) {
    let enterprise_type = options.enterprise_type
    this.setData({
      enterprise_type: enterprise_type
    })
    this.getAuthApplyList()
  },
  toPages(event) {
    let { index } = event.currentTarget.dataset
    console.log(index)
    let item = this.data.list[index]
    if (item.status == 3) {
      this.setData({
        comment: item.comment,
        show: true
      })
      return
    }
    const flag = this.data.enterprise_type == 1 ? 'my' : 'enterprise'
    wx.navigateTo({
      url: `/accountPages/authentications/index?flag=${flag}&check=${2}`
    })
  },
  onClose() {
    this.setData({ show: false })
  },
  getAuthApplyList() {
    let parmas = {
      page: 1,
      size: 100
    }
    getAuthApplyList(parmas).then(res => {
      if (res.code === 200) {
        let status_map = {
          1: '已通过',
          2: '审核中',
          3: '已驳回'
        }
        res.data.list.map(e => {
          e.c_time_str = formatTimeBase(e.c_time, '{y}-{m}-{d} {h}:{i}:{s}')
          e.status_str = status_map[e.status]
        })
        this.setData({
          list: res.data.list
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  }
})

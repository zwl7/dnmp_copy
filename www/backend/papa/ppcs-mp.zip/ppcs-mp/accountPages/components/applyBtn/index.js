const app = getApp()
import { throttle } from '../../../utils/util'
Component({
  properties: {
    presentIndex: {
      type: Number,
      value: 1
    },
    type: {
      type: Number,
      value: -1
    },
    status: {
      type: Number
    }
  },
  options: {
    addGlobalClass: true
  },
  data: { isIos: app.globalData.isIos, checked: false },
  methods: {
    handel: throttle(function () {
      if (!this.data.checked) {
        wx.showToast({
          title: '需要同意协议哦~',
          icon: 'none',
          duration: 2000
        })
        return
      }
      // 表单校验
      if (this.data.presentIndex == 2) {
        this.triggerEvent('verify')
        return
      }
      // type 1 银联协议提交
      if (this.data.type !== 1) {
        this.triggerEvent('next')
      }
      this.triggerEvent('showDialog')
    }, 500),
    up() {
      this.triggerEvent('up')
    },
    submit() {
      wx.navigateTo({
        url: '/accountPages/unionpay/unionpay'
      })
    },
    showDialog() {
      this.bigDialog.showDialog()
    },
    onChange(e) {
      this.setData({ checked: e.detail })
    },
    updateInfo() {
      this.triggerEvent('updateInfo')
    }
  },
  lifetimes: {
    attached: function () {
      this.bigDialog = this.selectComponent('#bigDialog')
    }
  }
})

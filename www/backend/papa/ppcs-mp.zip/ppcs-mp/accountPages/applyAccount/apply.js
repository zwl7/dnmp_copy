const app = getApp()
Page({
  data: {
    host: app.globalData.config.host,
    communityInfo: {}
  },

  onLoad(options) {
    this.setData({ communityInfo: options })
  },

  onShow() {},
  toPages(e) {
    // enterprise 企业认证   my 个人
    const flag = e.currentTarget.dataset.path || ''
    wx.navigateTo({
      url: `/accountPages/authentications/index?flag=${flag}&community_id=${this.data.communityInfo.community_id}&check=1&status=5`
    })
  },
  downloadFile() {
    wx.showToast({
      title: '暂无文件可下载...',
      icon: 'none'
    })
    return
    wx.downloadFile({
      url: 'https://cdn-static.papa.com.cn/ppos_json/业务办理授权函.docx',
      success(res) {
        wx.openDocument({
          filePath: res.tempFilePath,
          fileType: 'docx',
          showMenu: true,
          fail: res => {
            console.log('文件下载失败')
          }
        })
      }
    })
  }
})

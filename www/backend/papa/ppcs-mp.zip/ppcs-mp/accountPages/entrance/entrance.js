const app = getApp()
const statusOTypebj = {
  '-1': '立即申请',
  0: '入驻审核中',
  1: '审核通过',
  2: '待签约',
  3: '待验证',
  4: '已驳回，查看驳回原因',
  6: '银行审核中'
}
Page({
  data: {
    isIos: app.globalData.isIos,
    host: app.globalData.config.host,
    cardList: [
      {
        title: '小程序功能',
        isActiveStyle: false,
        list: [
          {
            name: '管理员',
            url: '/auth_5.png',
            des: '多用户共同管理星球',
            pagePath: ''
          },
          {
            name: '验票功能',
            url: '/auth_7.png',
            des: '一票一码,快速核验',
            pagePath: ''
          },
          {
            name: '付费功能',
            url: '/auth_4.png',
            des: '实现线上收费',
            pagePath: ''
          },
          {
            name: '多票种',
            url: '/auth_2.png',
            des: '可设置不同价位的票种',
            pagePath: ''
          }
        ]
      },
      {
        title: '专业星球(俱乐部)助手功能',
        isActiveStyle: true,
        list: [
          {
            name: '数据管理',
            url: '/auth_3.png',
            des: '数据查看与数据导出',
            pagePath: ''
          },
          {
            name: '数据分析',
            url: '/auth_12.png',
            des: '不同维度数据图表分析',
            pagePath: ''
          },
          {
            name: '成员管理',
            url: '/auth_1.png',
            des: '查询管理一目了然',
            pagePath: ''
          },
          {
            name: '一键创办',
            url: '/auth_8.png',
            des: '快速创办同类型活动',
            pagePath: ''
          }
        ]
      },
      {
        title: '专业星球(俱乐部)助手功能',
        isActiveStyle: true,
        list: [
          {
            name: '优先展示',
            url: '/auth_9.png',
            des: '首页排序优先位置',
            pagePath: ''
          },
          {
            name: '资源对接',
            url: '/auth_11.png',
            des: '平台资源匹配',
            pagePath: ''
          },
          {
            name: '专属运营',
            url: '/auth_10.png',
            des: '一对一专业服务',
            pagePath: ''
          }
        ]
      }
    ],
    wxDistributionAuth: {
      status: -1
    },
    status_str: '',
    hiddenFooter: false
  },

  onLoad(options) {
    if (options.hiddenFooter) {
      this.setData({
        hiddenFooter: true
      })
    }
    const wxDistributionAuth = wx.getStorageSync('wxDistributionAuth')
    if (wxDistributionAuth) {
      const info = JSON.parse(wxDistributionAuth)
      this.setData({
        wxDistributionAuth: info,
        status_str: statusOTypebj[info.status]
      })
    } else {
      this.setData({
        status_str: statusOTypebj[this.data.wxDistributionAuth.status]
      })
    }
  },

  onShow() {},
  toApply() {
    if (this.data.wxDistributionAuth.status != '-1') {
      let check = 2
      wx.navigateTo({
        url: `/accountPages/authentications/index?check=${check}&status=${this.data.wxDistributionAuth.status}&flag=${this.data.wxDistributionAuth.enterprise_images ? 'enterprise' : 'my'}`
      })
    } else {
      wx.navigateTo({
        url: '/accountPages/applyAccount/apply'
      })
    }
  }
})

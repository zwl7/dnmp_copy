const app = getApp()
Page({
  data: {
    bg_img: app.globalData.config.host + '/bank_bg.png',
    bank_account_name: '',
    bank_account_name_last: '',
    bank_no_str: '',
    bank_icon_url: ''
  },
  onLoad(options) {
    this.handleDistributionAuthStorage()
  },
  bindcontact(e) {
    let errMsg = e.detail.errMsg
    if (errMsg != 'enterContact:ok') {
      wx.showToast({
        title: errMsg,
        icon: 'none'
      })
    }
  },
  handleDistributionAuthStorage() {
    try {
      let info = wx.getStorageSync('wxDistributionAuth')
      if (info) {
        let distribution = JSON.parse(info)
        let bank_icon = distribution.bank_icon
        let bank_icon_url = ''
        if (bank_icon) {
          bank_icon_url = `https://cdn-static.papa.com.cn/ppcs_mp/ban_icon/${bank_icon}.png`
        }
        this.setData({
          bank_no_str: distribution.bank_no_str,
          bank_account_name: this.nameConvert(distribution.bank_account_name),
          bank_account_num: distribution.bank_account_num,
          bank_account_name_last: distribution.bank_account_num.substr(-4),
          bank_icon_url: bank_icon_url
        })
      }
    } catch (error) {}
  },
  nameConvert(name) {
    let length = name.length
    let last = name.substring(length - 1, length)
    return ' • '.repeat(length - 1) + last
  }
})

const { sendVerifyAmount, verifyAmount } = require('./../../apis/account')
Page({
  data: {
    trans_amt: '',
    loading: false,
    applyStatus: '',
    errorMsg: '错误提示'
  },
  async onLoad(options) {
    let { applyStatus } = options
    if (applyStatus == 5) {
      this.setData({ loading: true })
      wx.showLoading({
        title: '验证中'
      })
      let res_1 = await sendVerifyAmount({})
      wx.hideLoading()
      this.setData({ loading: false })
      if (res_1.code !== 200) {
        wx.showToast({
          title: res_1.message,
          icon: 'none'
        })
      }
    }
  },
  inputValue(event) {
    let { value } = event.detail
    this.setData({
      trans_amt: value
    })
  },
  handleSubmit() {
    if (this.data.loading) {
      return
    }
    if (!this.data.trans_amt) {
      wx.showToast({
        title: '请输入金额',
        icon: 'none'
      })
    }
    let trans_amt = this.data.trans_amt * 100
    wx.showLoading({
      title: '验证中'
    })
    this.setData({ loading: true })
    verifyAmount({ trans_amt: trans_amt }).then(res => {
      wx.hideLoading({})
      this.setData({ loading: false })
      if (res.code == 200) {
        wx.redirectTo({
          url: '/accountPages/entrance/entrance'
        })
      } else {
        this.setData(
          {
            errorMsg: res.message
          },
          () => {
            this.selectComponent('#errorDialog').showDialog()
          }
        )
      }
    })
  },
  errorCancel() {
    wx.reLaunch({
      url: '/pages/mine/mine'
    })
  }
})

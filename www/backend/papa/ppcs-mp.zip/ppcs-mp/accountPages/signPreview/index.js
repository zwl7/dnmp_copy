import Card from './painter'
import { saveImageToAlbum, uploadFile } from './../../utils/util'
import buttonClick from './../../utils/buttonClick'
const app = getApp()
Page({
  imagePath: '',
  history: [],
  future: [],
  isSave: false,
  data: {
    loading: false,
    template: {},
    isIos: app.globalData.isIos,
    printData: {
      year: '2022',
      month: '12',
      day: '01',
      percent: '/',
      serviceMoney: '/',
      signImg: ''
    }
  },

  previewImage() {
    let _this = this
    wx.previewImage({
      current: _this.imagePath,
      urls: [_this.imagePath]
    })
  },
  onImgOK(e) {
    this.imagePath = e.detail.path
    this.setData({
      loading: false,
      image: this.imagePath
    })
    if (this.isSave) {
      saveImageToAlbum(this.imagePath)
    }
  },

  saveImage: buttonClick.buttonClicked(function () {
    if (this.imagePath && typeof this.imagePath === 'string') {
      this.isSave = false
      saveImageToAlbum(this.imagePath)
    }
  }, 1000),

  touchEnd({ detail }) {
    let needRefresh = detail.index >= 0 && detail.index <= this.data.template.views.length
    if (needRefresh) {
      this.history.push({
        ...detail
      })
      if (this.data.template.views[detail.index].id === detail.view.id) {
        this.data.template.views.splice(detail.index, 1)
      } else {
        this.data.template.views.splice(detail.index, 0, detail.view)
      }
    } else {
      if (!this.data.template || !this.data.template.views) {
        return
      }
      for (let view of this.data.template.views) {
        if (view.id === detail.view.id) {
          this.history.push({
            view: {
              ...detail.view,
              ...view
            }
          })
          view.css = detail.view.css
          break
        }
      }
    }
    this.future.length = 0
    const props = {
      paintPallette: this.data.template
    }
    if (needRefresh) {
      props.template = this.data.template
    }
    this.setData(props)
  },
  onLoad: function () {
    if (!app.globalData.userSignTemPath) {
      wx.showToast({
        title: '协议签署失败，请重试',
        icon: 'none'
      })
      wx.navigateBack()
    }
    let now = new Date()
    let year = now.getFullYear()
    let month = String(now.getMonth() + 1).padStart(2, '0')
    let day = String(now.getDate()).padStart(2, '0')
    this.setData({
      loading: true,
      'printData.signImg': app.globalData.userSignTemPath,
      'printData.year': year,
      'printData.month': month,
      'printData.day': day
    })
  },
  onShow: function () {
    this.setData({
      paintPallette: new Card(this.data.printData).palette()
    })
  },
  handleBack() {
    wx.navigateBack()
    app.globalData.userSignTemPath = ''
  },
  handleNext: buttonClick.buttonClicked(async function () {
    wx.showLoading({
      title: '图片上传中'
    })
    let res = await uploadFile(this.imagePath)
    if (res.code !== 200) {
      wx.showToast({
        title: '协议上传失败,请重试',
        icon: 'none'
      })
    } else {
      app.globalData.userServiceAgreement = res.data.imgUrl
    }
    wx.hideLoading()
    wx.navigateBack()
    app.globalData.userSignTemPath = ''
  }, 1000)
})

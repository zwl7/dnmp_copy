export default class LastMayday {
  constructor(obj = {}) {
    this.year = obj.year
    this.month = obj.month
    this.day = obj.day
    this.percent = obj.percent
    this.serviceMoney = obj.serviceMoney
    this.signImg = obj.signImg
  }
  palette() {
    return {
      width: '1587px',
      height: '2317px',
      background: '#fff',
      views: [this.getSignAgreement(), ...this.getDate(), this.getPercent(), this.getServiceMoney(), this.getUserSign()]
    }
  }
  getSignAgreement() {
    return {
      id: 'signAgreement',
      type: 'image',
      url: 'https://cdn-static.papa.com.cn/ppcs_mp/yinlianPng.png',
      css: {
        top: '0px',
        height: '0px',
        width: '1587px',
        height: '2317px'
      }
    }
  }

  getDate() {
    let top = 1682
    let left = [990, 1120, 1225]
    let list = []
    let text_map = {
      0: this.year,
      1: this.month,
      2: this.day
    }
    left.map((e, index) => {
      list.push({
        type: 'text',
        text: text_map[index],
        css: {
          fontSize: '26px',
          fontWeight: '400',
          top: top + 'px',
          left: e + 'px'
        }
      })
    })
    return list
  }

  getPercent() {
    return {
      type: 'text',
      text: this.percent,
      css: {
        fontSize: '26px',
        fontWeight: '400',
        top: '1350px',
        left: '794px'
      }
    }
  }

  getServiceMoney() {
    return {
      type: 'text',
      text: this.serviceMoney,
      css: {
        fontSize: '26px',
        fontWeight: '400',
        top: '1392px',
        left: '638px'
      }
    }
  }

  getUserSign() {
    return {
      id: 'signAgreement',
      type: 'image',
      url: this.signImg,
      css: {
        top: '1536px',
        left: '1248px ',
        height: '152px',
        width: 'auto',
        rotate: -90
      }
    }
  }
}

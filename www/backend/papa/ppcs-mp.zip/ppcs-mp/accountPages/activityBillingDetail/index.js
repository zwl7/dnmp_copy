const { getActivityDealRecord } = require('../../apis/helper')
Page({
  data: {
    dataList: [],
    page: 1,
    size: 10,
    loading: false,
    finish: false,
    activity_id: ''
  },
  onLoad(options) {
    let activity_id = options.activity_id

    this.setData({
      activity_id: activity_id
    })
    this.getList()
  },
  async getList() {
    this.setData({
      loading: true
    })
    let params = {
      page: this.data.page,
      size: 10,
      activity_id: this.data.activity_id
    }
    let res = await getActivityDealRecord(params)
    if (res.code === 200) {
      let dataList = this.data.dataList
      dataList = dataList.concat(res.data.list)
      this.setData({
        dataList: dataList
      })
      if (res.data.list.length === 0) {
        this.setData({
          finish: true
        })
      }
      if (!this.data.finish) {
        this.isFullScreen()
      }
      this.setData({
        loading: false
      })
    } else {
      wx.showToast({
        title: res.message,
        icon: 'none'
      })
    }
  },
  onReachBottom() {
    console.log('触底加载')
    if (this.data.finish) {
      console.log('加载完成')
      this.setData({
        loading: false
      })
      return
    }
    this.setData({
      page: this.data.page + 1
    })
    this.getList()
  },
  onPullDownRefresh() {
    this.setData(
      {
        dataList: [],
        page: 1,
        loading: false,
        finish: false
      },
      () => {
        wx.stopPullDownRefresh()
        this.getList()
      }
    )
  },
  onReachBottom() {
    console.log('触底加载')
    if (this.data.finish) {
      this.setData({
        loading: false
      })
      return
    }
    this.setData({
      page: this.data.page + 1
    })
    this.getList()
  },
  isFullScreen() {
    wx.createSelectorQuery()
      .selectViewport()
      .scrollOffset()
      .exec(async res => {
        const windowHeight = wx.getSystemInfoSync().windowHeight
        const scrollHeight = res[0].scrollHeight
        console.log(windowHeight, scrollHeight)
        if (windowHeight + 160 >= scrollHeight) {
          console.log(312312312)
          this.onReachBottom()
        }
      })
  }
})

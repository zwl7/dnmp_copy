var config = require('./config')
const { getToken, setToken, setLocationInfo, getLocationInfo, clearLocationInfo, setViewActivityIds, getViewActivityIds, clearToken } = require('./utils/storage')
const { login, getMemberStatistic } = require('./apis/login')
App({
  onLaunch() {
    console.log('---app onLaunch')

    clearToken(true)
    this.parseLocationInfo()
    this.handleLogin()
    this.autoUpdate()
    this.getNavBarInfo()
    this.setBaseConfig()
    this.getMemberStatistic()
    // this.loadFontFace()
  },
  onHide() {
    let { view_activity_ids } = this.globalData.userStaticInfo
    if (view_activity_ids && view_activity_ids.length > 0) {
      setViewActivityIds(view_activity_ids)
        .then(res => {
          console.log('----浏览活动id储存成功')
        })
        .catch(err => {
          console.error('----浏览活动id储存失败', err)
        })
    }
  },
  globalData: {
    navBarHeight: 0,
    menuTop: 0,
    menuHeight: 0,
    menuRight: 0,
    menuWidth: 0,
    config: {
      host: ''
    },
    isIos: false,
    token: '', //全局token
    circleBackgroundImg: '', //创建星球图片
    avatarImg: '', //创建星球图片
    activityImg: '', //创建活动照片
    activityBackgroundImage: '', //活动详情页背景
    activityDes: '', //活动描述
    activityImgList: [], //活动描述中图片
    ticketConcatList: [], //门票报名表单
    UserAvatar: '', //用户头像
    city: '', //所选城市
    city_id: config.default_city_id, //中国标准城市区域码 前4位 默认
    latitude: config.default_latitude, //经纬度
    longitude: config.default_longitude,
    user_latitude: config.default_latitude, //用户当前定位
    user_longitude: config.default_longitude,
    is_change_city: false, //是否切换城市
    is_get_location: false, //是否获取经纬度成功
    is_get_loginInfo: false, //是否登录获取用户信息
    userInfo: {
      avatar_url: '',
      first_login: '',
      signature: '',
      name: '',
      nick_name: '',
      phone: '',
      token: '',
      account_id: '',
      is_authenticate: -1,
      sex: 0
    },
    is_authenticate: -1,
    official_auth: 0, //是否官方授权
    RefreshMinePage: false, //刷新我的页面
    RefreshIndexPage: false, //刷新首页
    RefreshFindPage: false, //刷新发现页面
    RefreshRegisterInfoPage: false, //刷新报名信息页
    RefreshIndexMyCircle: false, //刷新首页我的星球列表
    createCircle: false, //当前操作是否创建了星球
    createCircleInfo: {
      community_id: '',
      community_name: '',
      op: 'add'
    },
    userStaticInfo: {
      is_request: false, //判断当前数据时请求接口而来
      create_community: 0, //我创建的星球数
      join_activity: 0, //我加入的活动数
      join_activity_ids: [], //我加入的活动id
      join_community: 0, //我加入的星球数
      join_community_ids: [], //我加入的星球id
      manage_join_community_ids: [], //可管理的星球
      collect_activity_ids: [], //收藏的活动id
      view_activity_ids: [] //浏览的活动id  存本地
    },
    // 首次核销票种时的用户信息  暂存
    checkTicketInfo: {
      avatar: '',
      name: '',
      session_name: '',
      price: 0,
      applicant_code: '',
      status: 3, //状态    1 成功  2 失败  3 提示,
      check_str: '等待核验',
      verify_status: 1 //1成功  2失败
    },
    shareActivityId: '', //扫码进来获取的活动id
    userSignTemPath: '', //用户签名临时缓存的canvas路径
    userServiceAgreement: '', //用户签署协议
    env: '', //环境版本
    currentActivityInfo: {}, //当前编辑活动的信息
    currentTicketInfo: {}, //当前编辑票种信息
    ticketSortList: [], //票种编辑后的排序数组
    applyFieldInfo: '', //赛事报名 填写报名信息
    // 分享活动信息
    shareActivity: {},
    // 分享海报
    sharePoster: {},
    // 星球码信息
    circleQrcode: {},
    weigui_activity_png: 'https://cdn-static.papa.com.cn/ppcs_mp/weigui.png', //违规图片
    input_invite_code: '', //用户号输入的邀请码
    buy_limit_type: 0, //购买票种类型数量
    show_apply_member: '1', //是否展示报名人员 1 开启  2 关闭
    ticket_warning: '1', //票量警示
    refreshActivitySetting: false //票种高级设置
  },
  // 菜单按钮的布局位置信息
  getNavBarInfo() {
    const systemInfo = wx.getSystemInfoSync()
    if (systemInfo.system.indexOf('Android') > -1) {
      this.globalData.isIos = false
    } else {
      this.globalData.isIos = true
    }
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect()
    this.globalData.navBarHeight = systemInfo.statusBarHeight + 44
    this.globalData.menuWidth = menuButtonInfo.width
    this.globalData.menuTop = menuButtonInfo.top
    this.globalData.menuHeight = menuButtonInfo.height
    this.globalData.menuRight = systemInfo.screenWidth - menuButtonInfo.right
  },
  // 基础设置
  setBaseConfig() {
    const env = wx.getAccountInfoSync()
    const envVersion = env.miniProgram.envVersion
    config.env = envVersion
    this.globalData.env = envVersion
    switch (envVersion) {
      case 'develop':
        config.company_id = 421
        config.baseUrl = 'https://apitest.wesais.cn'
        config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        this.globalData.config.host = config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        // config.company_id = 421
        // config.baseUrl = 'https://api.wesais.com'
        // config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        // this.globalData.config.host = config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        break

      case 'trial':
        config.company_id = 421
        config.baseUrl = 'https://apitest.wesais.cn'
        config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        this.globalData.config.host = config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        break

      case 'release':
        config.company_id = 421
        config.baseUrl = 'https://api.wesais.com'
        config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        this.globalData.config.host = config.host = 'https://cdn-static.papa.com.cn/ppcs_mp'
        break
    }
  },
  // 检测更新
  autoUpdate() {
    if (wx.canIUse('getUpdateManager')) {
      var manager = wx.getUpdateManager()
      manager.onCheckForUpdate(function (t) {
        if (t.hasUpdate) {
          manager.onUpdateReady(function () {
            wx.showModal({
              title: '更新提示',
              content: '新版本已经准备好，请重启应用',
              showCancel: false,
              success: function (t) {
                if (t.confirm) {
                  manager.applyUpdate()
                  console.log('新版本已经下载好')
                }
              }
            })
          })
          manager.onUpdateFailed(function () {
            wx.showModal({
              title: '已经有新版本了哟~',
              content: '新版本已经上线啦，请您删除当前小程序，重新搜索打开哟',
              showCancel: !1,
              success: function (e) {}
            })
          })
        }
      })
    } else
      wx.showModal({
        title: '温馨提示',
        concent: '当前微信版本过低，无法使用该功能，请升级至最新微信版本后重试。'
      }),
        console.log('微信版本过低，更新微信')
  },
  // 监听全局数据
  watchMethods: {},
  watchGlobalData: function (key, methodKey, method) {
    const _this = this
    let obj = this.globalData
    let ori = obj[key]
    if (!this.watchMethods[key]) {
      this.watchMethods[key] = []
    }
    // if (this.watchMethods[key].indexOf(method) === -1) {
    //   this.watchMethods[key].push(method)
    // }
    let isExit = false
    this.watchMethods[key].map((e, index) => {
      if (e.name == method.name) {
        this.watchMethods[key][index] = method
        isExit = true
      }
    })
    if (!isExit) {
      this.watchMethods[key].push(method)
    }

    if (ori) {
      const methods = _this.watchMethods[key]
      methods.map(item => item(ori))
    }
    Object.defineProperty(obj, key, {
      configurable: true,
      enumerable: true,
      set: function (value) {
        console.log('setting ' + key + '  value ')
        this['__' + key] = value
        const methods = _this.watchMethods[key]
        console.log('key', key, methods)
        methods.map(item => item(value))
      },
      get: function () {
        if (typeof this['__' + key] == 'undefined') {
          if (ori) {
            this['__' + key] = JSON.parse(JSON.stringify(ori))
            return ori
          } else {
            return undefined
          }
        } else {
          return this['__' + key]
        }
      }
    })
  },
  // 登录 获取token
  handleLogin() {
    login()
      .then(res => {
        if (res.code === 200) {
          this.globalData.is_get_loginInfo = true
          this.globalData.is_authenticate = res.data.is_authenticate
          this.globalData.official_auth = res.data.official_auth
          this.setUserInfo(res.data)
          setToken(res.data.token, true).then(c => {})
          let user_info = {
            member_id: res.data.account_id,
            business_id: res.data.business_id,
            latitude: String(this.globalData.latitude),
            longitude: String(this.globalData.longitude),
            city_id: this.globalData.city_id
          }
          wx.setStorageSync('user_info', JSON.stringify(user_info))
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
      .catch(error => {
        console.log('errror', error)
        wx.showToast({
          title: '登录获取token失败',
          icon: 'none'
        })
      })
  },
  // 设置用户信息
  setUserInfo(obj) {
    for (const key in this.globalData.userInfo) {
      if (Object.hasOwnProperty.call(obj, key)) {
        this.globalData.userInfo[key] = obj[key]
      }
    }
  },
  // 获取用户统计信息
  getMemberStatistic() {
    return new Promise((reslove, reject) => {
      getMemberStatistic({}).then(res => {
        if (res.code === 200) {
          let view_activity_ids = []
          let userStaticInfo = {
            create_community: res.data.create_community,
            join_activity: res.data.join_activity,
            join_activity_ids: res.data.join_activity_ids,
            join_community: res.data.join_community,
            join_community_ids: res.data.join_community_ids,
            manage_join_community_ids: res.data.manage_join_community_ids,
            collect_activity_ids: res.data.collect_activity_ids,
            view_activity_ids: view_activity_ids,
            is_request: true
          }
          this.globalData.userStaticInfo = userStaticInfo
          getViewActivityIds(true).then(res => {
            if (res && res.length > 0) {
              if (res.length > 300) {
                res.splice(0, 150)
              }
              this.globalData.userStaticInfo.view_activity_ids = res
            }
          })
          reslove(1)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
          reject(res.message)
        }
      })
    })
  },
  // 解析本地缓冲的用户经纬度信息
  parseLocationInfo() {
    getLocationInfo(true).then(res => {
      if (res) {
        console.log(res)
        let now = new Date().getTime()
        let diff = now - Number(res.date)
        if (diff <= 12 * 60 * 60 * 1000 && !res.is_user_select) {
          this.globalData.city = res.city
          this.globalData.latitude = res.latitude
          this.globalData.longitude = res.longitude
          if (res.city_id) {
            this.globalData.city_id = res.city_id
          }
        }
      }
    })
  },
  // 判断用户是否加入当前活动或星球   type 1   星球 2  活动  3是否可管理  4  是否为喜欢的活动
  judgeIsJoin(id, type) {
    let userStaticInfo = this.globalData.userStaticInfo
    if (!userStaticInfo.is_request) {
      this.getMemberStatistic()
    }
    let join_activity_ids = userStaticInfo.join_activity_ids
    let join_community_ids = userStaticInfo.join_community_ids
    let collect_activity_ids = userStaticInfo.collect_activity_ids
    let manage_join_community_ids = userStaticInfo.manage_join_community_ids
    let index = -1
    if (type == 1) {
      index = join_community_ids.indexOf(id)
    }
    if (type == 2) {
      index = join_activity_ids.indexOf(id)
    }
    if (type == 3) {
      index = manage_join_community_ids.indexOf(id)
    }
    if (type == 4) {
      index = collect_activity_ids.indexOf(id)
    }
    return index === -1 ? false : true
  },
  // 用户加入星球活动  改变join_community_ids 加入活动id  type 1   星球 2  活动 3喜欢的活动  4浏览过的活动id
  // handle  add del 添加删除
  changeJoinList(id, type, handle) {
    let { join_activity_ids, join_community_ids, collect_activity_ids, view_activity_ids } = this.globalData.userStaticInfo
    if (type == 1 && join_community_ids.indexOf(id) === -1) {
      join_community_ids.push(id)
      console.log(join_community_ids)
    }
    if (type == 2 && join_activity_ids.indexOf(id) === -1) {
      join_activity_ids.push(id)
    }
    if (type == 3) {
      let index = collect_activity_ids.indexOf(id)
      if (handle === 'add' && index === -1) {
        collect_activity_ids.push(id)
      }
      if (handle === 'del' && index != -1) {
        collect_activity_ids.splice(index, 1)
      }
    }
    if (type == 4 && view_activity_ids.indexOf(id) === -1) {
      view_activity_ids.push(id)
    }
  },
  // 加载字体
  loadFontFace() {
    wx.loadFontFace({
      global: true,
      family: 'YouSheBiaoTiHei',
      source: 'https://cdn-static.papa.com.cn/ppcs_mp/YouSheBiaoTiHei-2.ttf',
      scopes: ['webview', 'native'],
      success: function (e) {
        console.log('字体加载成功', e)
      },
      fail: function (e) {
        console.log('字体加载失败', e)
      }
    })
  }
})

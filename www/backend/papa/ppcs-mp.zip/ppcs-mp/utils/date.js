var t = function (t) {
  return (t = t.toString())[1] ? t : '0' + t
}
function judgeDate(time) {
  let date
  if (typeof time === 'object' && time instanceof Date) {
    date = time
  } else {
    if (typeof time === 'string' && /^[0-9]+$/.test(time)) {
      time = parseInt(time)
    }
    if (typeof time === 'number' && time.toString().length === 10) {
      time = time * 1000
    }
    date = new Date(time)
  }
  return date
}

module.exports = {
  formatTime: function (e) {
    var n = e.getFullYear(),
      o = e.getMonth() + 1,
      r = e.getDate(),
      u = e.getHours(),
      g = e.getMinutes(),
      i = e.getSeconds()
    return [n, o, r].map(t).join('/') + ' ' + [u, g].map(t).join(':')
  },
  formatStartTime: function (date) {
    let time = date.getTime() + 3600000
    let e = new Date(time)
    var n = e.getFullYear(),
      o = e.getMonth() + 1,
      r = e.getDate(),
      u = e.getHours(),
      g = e.getMinutes(),
      i = e.getSeconds()

    if (g < 15 && g >= 0) {
      g = 0
    }
    if (g >= 15 && g <= 45) {
      g = 30
    }
    if (g > 45 && g <= 59) {
      g = 0
      u += 1
    }
    if (u == 24) {
      u = u - 24
    }
    let format =
      [n, o, r].map(t).join('/') + ' ' + [u, g].map(t).join(':')
    let timestamp = new Date(format).getTime()
    return {
      timestamp: timestamp,
      format: format
    }
  },
  formatActivityTime: function (time1, time2) {
    let startDate = judgeDate(time1)
    let endDate = judgeDate(time2)
    let nowDate = new Date()
    let nowDateObj = {
      d: nowDate.getDay(),
      r: startDate.getDate()
    }
    let startObj = {
      n: startDate.getFullYear(),
      o: startDate.getMonth() + 1,
      r: startDate.getDate(),
      d: startDate.getDay(),
      u: startDate.getHours(),
      g: startDate.getMinutes(),
      i: startDate.getSeconds()
    }
    let endObj = {
      n: endDate.getFullYear(),
      o: endDate.getMonth() + 1,
      r: endDate.getDate(),
      d: startDate.getDay(),
      u: endDate.getHours(),
      g: endDate.getMinutes(),
      i: endDate.getSeconds()
    }
    let isSameDay =
      startDate.toDateString() === endDate.toDateString()
    let differDay =
      (startDate.getTime() - nowDate.getTime()) / 1000 / 60 / 60 / 24
    let differWeek = 7 - nowDateObj.d
    if (isSameDay) {
      if (
        differDay <= differWeek &&
        endDate.getTime() > nowDate.getTime()
      ) {
        let week = [
          '周日',
          '周一',
          '周二',
          '周三',
          '周四',
          '周五',
          '周六'
        ]
        return (
          [startObj.o, startObj.r].map(t).join('.') +
          ' ' +
          week[startObj.d] +
          ' ' +
          [startObj.u, startObj.g].map(t).join(':') +
          '-' +
          [endObj.u, endObj.g].map(t).join(':')
        )
      } else {
        return (
          [startObj.o, startObj.r].map(t).join('.') +
          ' ' +
          [startObj.u, startObj.g].map(t).join(':') +
          '-' +
          [endObj.u, endObj.g].map(t).join(':')
        )
      }
    } else {
      let start =
        [startObj.o, startObj.r].map(t).join('-') +
        ' ' +
        [startObj.u, startObj.g].map(t).join(':')
      let end =
        [endObj.o, endObj.r].map(t).join('-') +
        ' ' +
        [endObj.u, endObj.g].map(t).join(':')

      return start + ' 至 ' + end
    }
  },
  formatTimeBase: function (time, cformat) {
    if (arguments.length == 0) {
      return null
    }
    const format = cformat || '{y}-{m}-{d} {h}:{i}:{s} 星期{a}'
    let date
    if (typeof time === 'object' && time instanceof Date) {
      date = time
    } else {
      if (typeof time === 'string' && /^[0-9]+$/.test(time)) {
        time = parseInt(time)
      }
      if (typeof time === 'number' && time.toString().length === 10) {
        time = time * 1000
      }
      date = new Date(time)
    }
    const formatObj = {
      y: date.getFullYear(),
      m: date.getMonth() + 1,
      d: date.getDate(),
      h: date.getHours(),
      i: date.getMinutes(),
      s: date.getSeconds(),
      a: date.getDay()
    }

    const time_str = format.replace(
      /{([ymdhisa])+}/g,
      (result, key) => {
        let value = formatObj[key]
        if (key === 'a') {
          return ['日', '一', '二', '三', '四', '五', '六'][value]
        }
        return value.toString().padStart(2, '0')
      }
    )
    return time_str
  }
}

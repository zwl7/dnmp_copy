var config = require('./../config')
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}

const getTagColor = function (index) {
  const tagColors = [
    {
      color: 'rgba(255, 233, 214, 1)',
      textColor: 'rgba(255, 114, 0, 1)'
    },
    {
      color: 'rgba(217, 255, 248, 1)',
      textColor: 'rgba(41, 204, 174, 1)'
    },
    {
      color: 'rgba(219, 236, 255, 1)',
      textColor: 'rgba(42, 130, 228, 1)'
    },
    {
      color: 'rgba(255, 233, 214, 1)',
      textColor: 'rgba(255, 114, 0, 1)'
    }
  ]
  const len = tagColors.length
  return tagColors[index % len]
}

const uploadFile = function (filePath) {
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      filePath: filePath,
      name: 'image',
      url: config.baseUrl + '/img/upload',
      header: {
        'Content-Type': 'multipart/form-data'
      },
      success: res => {
        console.log(res)
        if (res.statusCode == 200) {
          let data = JSON.parse(res.data)
          if (data.code !== 200) {
            wx.showToast({
              title: data.message,
              icon: 'none'
            })
          } else {
            resolve(data)
          }
        } else {
          reject(res.data)
        }
      },
      fail: reject
    })
  })
}
// 统计非汉字字数
function checkUnChineseNum(chars) {
  var sum = 0
  for (var i = 0; i < chars.length; i++) {
    var c = chars.charCodeAt(i)
    if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
      sum++
    }
  }
  return sum
}

// 去掉字符串前后空格
function trim(s) {
  return s.replace(/(^\s*)|(\s*$)/g, '')
}

function money(price) {
  price = price.replace(/[^\d.]/g, '')
  price = price.replace(/\.{2,}/g, '.')
  price = price.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.')
  price = price.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3')
  if (price.indexOf('.') < 0 && price != '') {
    price = parseFloat(price)
  }
  return price
}

const map = (arr, value1 = null, value2 = null) => {
  if (!value1 && !value2) {
    return arr
  }
  let arrMap = {}
  if (value1 != null) {
    if (value2 != null) {
      arr.map(item => {
        const key = item[value2]
        arrMap[key] = item[value1]
      })
    } else if (value2 == null) {
      arrMap = []
      arr.map(item => {
        arrMap.push(item[value1])
      })
    }
  } else if (value1 == null && value2 != null) {
    arr.map(item => {
      const key = item[value2]
      arrMap[key] = item
    })
  }
  return arrMap
}

// 获取退款规则
function getRefundRuleStr(list) {
  let res = ''
  if (list) {
    try {
      list = JSON.parse(list)
      let item = list[0]
      let key = Object.keys(item)[0]
      let value = item[key]
      if (key == 0 && value == 100) {
        res = '活动开始前随时可退'
      } else if (key == 0 && value == 0) {
        res = '活动费用不可退'
      } else {
        res = `活动开始前${key}小时可退`
      }
    } catch (error) {}
  }
  return res
}

//判断输入文字长度
function judgeInputLength(str, max, title) {
  const len = parseInt(str.length)
  if (len > max) {
    str = str.substr(0, max)
    wx.showToast({
      title: `${title}不得超过${max}个字符`,
      icon: 'none'
    })
  }
  return str
}

// 根据对象的value值获取key
function getFindKey(value, obj) {
  let objlist = JSON.parse(JSON.stringify(obj))
  return Object.keys(objlist).find(k => obj[k] == value)
}

function handleQrcodeScene(scene) {
  let str = decodeURIComponent(scene)
  let obj = {}
  if (str) {
    str.split('&').forEach(function (param) {
      var arr = param.split('=')
      obj[arr[0]] = arr[1]
    })
  }
  return obj
}

// 保存图片处理
function saveImageToAlbum(filePath, successFun, failFunc) {
  wx.saveImageToPhotosAlbum({
    filePath: filePath,
    success: function (t) {
      wx.showToast({
        title: '保存成功',
        icon: 'none',
        duration: 2e3
      })
      try {
        if (successFun) {
          if (typeof successFun === 'function') {
            successFun()
          } else {
            console.error('successFun不是函数')
          }
        }
      } catch (error) {}
    },
    fail: function (t) {
      console.log(t)
      if (t.errMsg == 'saveImageToPhotosAlbum:fail cancel') {
        return
      }
      wx.showModal({
        title: '提示',
        content: '需要您授权保存相册',
        showCancel: false,
        success: function (t) {
          wx.openSetting({
            success: function (t) {
              t.authSetting['scope.writePhotosAlbum']
                ? wx.showModal({
                    title: '提示',
                    content: '获取权限成功,再次点击按钮即可保存',
                    showCancel: false
                  })
                : wx.showModal({
                    title: '提示',
                    content: '获取权限失败，将无法保存到相册哦~',
                    showCancel: false
                  })
            },
            fail: function (t) {
              try {
                if (failFunc) {
                  if (typeof failFunc === 'function') {
                    failFunc()
                  } else {
                    console.error('failFunc不是函数')
                  }
                }
              } catch (error) {}
            },
            complete: function (t) {
              console.log('finishData', t)
            }
          })
        }
      })
    }
  })
}
/*函数节流*/
function throttle(fn, interval) {
  var enterTime = 0 //触发的时间
  var gapTime = interval || 500 //间隔时间，如果interval不传，则默认300ms
  return function () {
    var context = this
    var backTime = new Date() //第一次函数return即触发的时间
    if (backTime - enterTime > gapTime) {
      fn.call(context, arguments)
      enterTime = backTime //赋值给第一次触发的时间，这样就保存了第二次触发的时间
    }
  }
}

/*函数防抖*/
function debounce(fn, interval) {
  var timer
  var gapTime = interval || 1000 //间隔时间，如果interval不传，则默认1000ms
  return function () {
    clearTimeout(timer)
    var context = this
    var args = arguments //保存此处的arguments，因为setTimeout是全局的，arguments不是防抖函数需要的。
    timer = setTimeout(function () {
      fn.call(context, args)
    }, gapTime)
  }
}

module.exports = {
  formatTime,
  uploadFile,
  getTagColor,
  checkUnChineseNum,
  trim,
  money,
  map,
  getRefundRuleStr,
  judgeInputLength,
  getFindKey,
  throttle,
  debounce,
  saveImageToAlbum,
  handleQrcodeScene
}

const { Get, Set, Clear } = require('./storageUtil')

// TOKEN
let tokenKey = 'token'
export function setToken(data, isSync = false) {
  return Set(tokenKey, data, isSync)
}
export function getToken(isSync = false) {
  return Get(tokenKey, isSync)
}
export function clearToken(data, isSync = false) {
  return Clear(tokenKey, isSync)
}

// 全局搜索字段存储
let globalSearchKey = 'globalSearchKey'
export function setGlobalSearchKey(data, isSync = true) {
  return Set(globalSearchKey, data, isSync)
}
export function getGlobalSearchKey(isSync = true) {
  return Get(globalSearchKey, isSync)
}
export function clearGlobalSearchKey(data, isSync = true) {
  return Clear(globalSearchKey, isSync)
}

// 我的经纬度信息
let locationInfoKey = 'locationInfo'
export function setLocationInfo(data, isSync = true) {
  try {
    if (data.city_id && wx.getStorageSync('user_info')) {
      let user_info = JSON.parse(wx.getStorageSync('user_info'))
      user_info.city_id = data.city_id
      user_info.latitude = String(data.latitude)
      user_info.longitude = String(data.longitude)
      wx.setStorageSync('user_info', JSON.stringify(user_info))
    }
  } catch (error) {
    console.log('error', error)
  }

  return Set(locationInfoKey, data, isSync)
}
export function getLocationInfo(isSync = true) {
  return Get(locationInfoKey, isSync)
}
export function clearLocationInfo(data, isSync = true) {
  return Clear(locationInfoKey, isSync)
}

// 创建活动时 联系方式暂存
let activityContactKey = 'activityContact'
export function setActivityContact(data, isSync = true) {
  return Set(activityContactKey, data, isSync)
}
export function getActivityContact(isSync = true) {
  return Get(activityContactKey, isSync)
}
export function clearActivityContact(data, isSync = true) {
  return Clear(activityContactKey, isSync)
}

// 创建活动时 票种报名数据
let ticketRegisterKey = 'ticketRegister'
export function setTicketRegister(data, isSync = true) {
  return Set(ticketRegisterKey, data, isSync)
}
export function getTicketRegister(isSync = true) {
  return Get(ticketRegisterKey, isSync)
}
export function clearTicketRegister(data, isSync = true) {
  return Clear(ticketRegisterKey, isSync)
}

// 创建活动时 票种报名数据
let viewActivityIdsKey = 'viewActivityIds'
export function setViewActivityIds(data, isSync = true) {
  return Set(viewActivityIdsKey, data, isSync)
}
export function getViewActivityIds(isSync = true) {
  return Get(viewActivityIdsKey, isSync)
}
export function clearViewActivityIds(data, isSync = true) {
  return Clear(viewActivityIdsKey, isSync)
}

// 创建活动时缓存
let createActivityStorageKey = 'createActivityStorage'
export function setCreateActivityStorage(data, isSync = false) {
  return Set(createActivityStorageKey, data, isSync)
}
export function getCreateActivityStorage(isSync = true) {
  return Get(createActivityStorageKey, isSync)
}
export function clearCreateActivityStorage(data, isSync = true) {
  return Clear(createActivityStorageKey, isSync)
}

// 创建活动时退款政策
let refundRuleStorageKey = 'refundRuleStorageKey'
export function setRefundRuleStorage(data, isSync = false) {
  return Set(refundRuleStorageKey, data, isSync)
}
export function getRefundRuleStorage(isSync = true) {
  return Get(refundRuleStorageKey, isSync)
}
export function clearRefundRuleStorage(data, isSync = true) {
  return Clear(refundRuleStorageKey, isSync)
}

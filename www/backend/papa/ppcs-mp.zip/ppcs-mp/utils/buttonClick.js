/*函数节流*/
function throttle(fn, interval) {
  var enterTime = 0
  var gapTime = interval || 300
  return function () {
    var context = this
    var backTime = new Date()
    if (backTime - enterTime > gapTime) {
      fn.call(context, arguments)
      enterTime = backTime
    }
  }
}

let debounceTimer = null
function debounce(
  fn,
  delay = 1000,
  immdiate = false,
  resultCallback
) {
  let isInvoke = false
  function _debounce(...arg) {
    if (debounceTimer) clearTimeout(debounceTimer)
    if (immdiate && !isInvoke) {
      const result = fn.apply(this, arg)
      if (resultCallback && typeof resultCallback === 'function')
        resultCallback(result)
      isInvoke = true
    } else {
      debounceTimer = setTimeout(() => {
        const result = fn.apply(this, arg)
        if (resultCallback && typeof resultCallback === 'function')
          resultCallback(result)
        isInvoke = false
        debounceTimer = null
      }, delay)
    }
  }

  _debounce.cancel = function () {
    if (debounceTimer) clearTimeout(debounceTimer)
    debounceTimer = null
    isInvoke = false
  }

  return _debounce
}

function buttonClicked(fn, n = 1500) {
  var u = null
  return function () {
    var e = +new Date()
    if (e - u > n || !u) {
      fn.apply(this, arguments)
      u = e
    }
  }
}

module.exports = {
  throttle,
  debounce,
  buttonClicked
}

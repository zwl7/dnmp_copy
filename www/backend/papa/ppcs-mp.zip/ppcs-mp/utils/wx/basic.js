// 文本复制
const textCopy = text => {
  return wx.setClipboardData({
    data: text
  })
}
// 拨打电话
const tel = number => {
  return wx.makePhoneCall({
    phoneNumber: number
  })
}
module.exports = {
  textCopy,
  tel
}

class Location {
  static longitude = 0
  static latitdue = 0
  static scale = 18
  static name = ''
  static address = ''
  // 打开位置
  static openLocation() {
    const that = this
    return wx.openLocation({
      latitude: that.latitude,
      longitude: that.longitude,
      name: that.name,
      address: that.address,
      scale: 18
    })
  }
}
module.exports = Location

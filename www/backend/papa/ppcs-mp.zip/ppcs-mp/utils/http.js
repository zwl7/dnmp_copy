var config = require('./../config')
const { getToken, setToken, clearToken, getLocationInfo } = require('./storage')
const {} = require('./../apis/login')
let isRefreshing = true
let loginCompelete = false
let subscribers = []
let loginCount = 0

function onAccessTokenFetched() {
  console.log('----回调函数', subscribers)
  subscribers.forEach(callback => {
    callback()
  })
  subscribers = []
}

function addSubscriber(callback) {
  subscribers.push(callback)
}

function getUrl(url) {
  let reg = new RegExp('http')
  let flag = reg.test(url)
  if (flag) {
    return url
  } else {
    return config.baseUrl + url
  }
}

async function request({ url, data = {}, header, callback = '' } = {}) {
  let method = 'POST'
  let isLogin = data.is_login === 1
  let token = ''
  try {
    token = await getToken(true)
  } catch (error) {}
  url = getUrl(url)
  var user_info = {}
  try {
    if (wx.getStorageSync('user_info')) {
      user_info = JSON.parse(wx.getStorageSync('user_info'))
    }
  } catch (error) {}

  data = Object.assign({ company_id: config.company_id }, user_info, data)
  if (data.latitude) {
    data.latitude = Number(data.latitude).toFixed(4)
  }
  if (data.longitude) {
    data.longitude = Number(data.longitude).toFixed(4)
  }
  if (!data.city_id) {
    data.city_id = '4403'
  }
  // 有些接口不需要城市id  经纬度等等
  if (data.no_location == 1) {
    try {
      delete data.city_id
      delete data.latitude
      delete data.longitude
    } catch (error) {}
  }
  if (data.no_city_id == 1) {
    try {
      data.no_city_id = data.city_id
      delete data.city_id
    } catch (error) {}
  }
  return new Promise((resolve, reject) => {
    // console.log('----进入', Boolean(token), !isLogin && !token)
    if (!isLogin && !token) {
      addSubscriber(() => {
        request({
          url,
          data,
          method,
          header,
          callback: resolve
        })
      })
      return
    }
    wx.request({
      url,
      data,
      method,
      header: {
        Authorization: token,
        // Authorization:
        //   'Signature-ppos-pro/9ZwFiE9cbyvfoHnXuib2UUaEseoCnAnW',
        'content-type': 'application/x-www-form-urlencoded;charset=utf-8',
        Origin: config.baseUrl.split('://')[1]
      },
      callback,
      fail(res) {
        reject(res)
      },
      complete: res => {
        if ((callback && res.data.code === 200) || (callback && loginCount > 10)) {
          return callback(res.data)
        }
        let statusCode = res.statusCode
        if (statusCode == 404) {
        } else if (statusCode == 401) {
        } else if (statusCode == 200) {
          if (isLogin) {
            loginCompelete = true
            console.log('---定时器')
            let user_info = {
              member_id: res.data.data.account_id,
              business_id: res.data.data.business_id
            }
            setToken(res.data.data.token, true).then(c => {})
            getLocationInfo(true)
              .then(res => {
                if (res) {
                  user_info.city_id = res.city_id
                  user_info.latitude = res.latitude
                  user_info.longitude = res.longitude
                }
                wx.setStorageSync('user_info', JSON.stringify(user_info))
                onAccessTokenFetched()
              })
              .catch(err => {
                wx.setStorageSync('user_info', JSON.stringify(user_info))
                onAccessTokenFetched()
              })
          }
          if (res.data.code === 40114 || res.data.code === 40101) {
            console.log('http1')
            if (data.city_id) {
              delete data.city_id
            }
            loginCount += 1
            addSubscriber(() => {
              request({
                url,
                data,
                method,
                header,
                callback: resolve
              })
            })
            clearToken()
            if (isRefreshing) {
              getNewToken().then(() => {
                onAccessTokenFetched()
                isRefreshing = true
              })
            }
            isRefreshing = false
            return
          }
          resolve(res.data)
        } else if (statusCode.startsWith('5')) {
          wx.showModal({
            content: '服务器报错，请重试！',
            showCancel: false
          })
        }
      }
    })
  })
}

function getWxCode() {
  return new Promise((resolve, reject) => {
    wx.login({
      success(res) {
        resolve(res)
      },
      fail() {
        reject('faily get wxcode')
      }
    })
  })
}
// 获取token
const getNewToken = () => {
  return new Promise(async (resolve, reject) => {
    let res = await getWxCode()
    console.log('----获取token1', res)
    let { code } = res
    request({
      url: '/activityPlatform/wxMember/miniLogin',
      data: { code, company_id: config.company_id, is_login: 1 }
    }).then(res => {
      if (res.code === 200) {
        setToken(res.data.token, true).then(c => {
          console.log('----获取token2', c)
          resolve(res)
        })
      } else {
        console.log('----获取token3', res)
        reject(res)
      }
    })
  })
}

module.exports = request

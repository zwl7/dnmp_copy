class OCRMethod {
  constructor() {
    this.data_type = 3213
    this.service = 'wx79ac3de8be320b71'
    this.api = 'OcrAllInOne'
  }
  async businessLicenseOCR(img_url) {
    let _this = this
    return new Promise(async (resolve, reject) => {
      try {
        let res = await wx.serviceMarket.invokeService({
          service: _this.service,
          api: _this.api,
          data: {
            img_url: img_url,
            data_type: _this.data_type,
            ocr_type: 7
          }
        })
        resolve(res.data)
      } catch (error) {
        reject(error)
      }
    })
  }
  bankCardOCR(img_url) {
    let _this = this
    return new Promise(async (resolve, reject) => {
      try {
        let res = await wx.serviceMarket.invokeService({
          service: _this.service,
          api: _this.api,
          data: {
            img_url: img_url,
            data_type: _this.data_type,
            ocr_type: 2
          }
        })
        resolve(res.data)
      } catch (error) {
        reject(error)
      }
    })
  }
  idCardOCR(img_url) {
    let _this = this
    return new Promise(async (resolve, reject) => {
      try {
        let res = await wx.serviceMarket.invokeService({
          service: _this.service,
          api: _this.api,
          data: {
            img_url: img_url,
            data_type: _this.data_type,
            ocr_type: 1
          }
        })
        resolve(res.data)
      } catch (error) {
        reject(error)
      }
    })
  }
}

module.exports = OCRMethod

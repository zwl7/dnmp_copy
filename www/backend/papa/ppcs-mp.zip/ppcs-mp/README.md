## scss 使用

```js
https://blog.csdn.net/qq_39549013/article/details/124735282
```

## 项目结构

```
assets     //静态资源
components   //全局组件
pages    //主包
subPages   //分包页面
utils      //公用
```

## 注意事项

1. 项目使用了 `scss`方便快速编写小程序样式 ，根据上述配置微信开发者工具

2. 项目依赖

   ```js
   yarn add @vant/weapp --production
   ```

3. 文件格式化工具`.prettierrc`,需要安装 `Prettier - Code formatter`

4. npx iconfont-wechat 更新 iconfont 图标
   <iconfont name="PC_wode-zhushou" size="22" />

活动改期提醒 bGf_7nJD1RZ3ZNiO1rh7gqgKUcLK2Ptc-5WJF2V7osI

活动开始提醒 2rcOnqUHT0vLhXYu3IEvjZkJYPoigS5AY98EZscTyvE

活动即将开始提醒 sJaleyD7jpWqd5UcaieOT-AMPIhd_00ezWOQpcEBK-Q

活动已解散通知 S1sEZLEBw_JSuEz9XVpnWkwS7FzHNdyS7yq2zhAueWc

退款申请通知 USgisDbqOYuG8lEY_aKEGeqo1qiIG9ahEmb6qI2k-j0

活动退出通知 094vUk9m6ZDNRhnjFm3CbPRc-uA20x8Cm8dMBf5Jf04

活动成员加入提醒 TOGnnVRW-HKaKuPI-BLuXQrSGNmw74EV7ea17Y04_Yw

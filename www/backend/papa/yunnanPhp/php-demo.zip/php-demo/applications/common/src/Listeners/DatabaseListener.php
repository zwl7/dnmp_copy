<?php

namespace Common\Listeners;

use Mix\Database\ExecuteListenerInterface;

/**
 * Class DatabaseListener
 * @package Common\Listeners
 * @author liu,jian <coder.keda@gmail.com>
 */
class DatabaseListener implements ExecuteListenerInterface
{

    /**
     * 监听
     * @param array $data
     */
    public function listen($data)
    {
        $data["sql"] = str_replace("?", "'%s'", $data["sql"]);
        $data["sql"] = vsprintf($data["sql"], $data["bindings"]);
        foreach ($data["bindings"] as $k=>$v){
            $data["sql"] = str_replace(':'.$k, $v, $data["sql"]);
        }
        app()->log->info($data["sql"]."   ".$data["time"]/1000);
        // TODO: Implement listen() method.
    }

}

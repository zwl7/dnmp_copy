<?php

/**
 * 用户助手函数
 * @author liu,jian <coder.keda@gmail.com>
 */

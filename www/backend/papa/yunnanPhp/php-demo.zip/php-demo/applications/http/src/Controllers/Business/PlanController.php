<?php

namespace Http\Controllers\Business;

use PPOSLib\Controllers\BusinessBaseController;
use PPOSLib\Helpers\ServiceData;
use PPOSLib\Logic\Plan ;
use PPOSLib\Exception\PPosException;
use Http\Validator\PlanForm;

class PlanController extends BusinessBaseController
{
    /**
     *
     * @api {post} /eventActivity/plan/list 计划信息表列表*
     * @apiDescription 计划信息表列表
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionList()
    {
        $data = $this->request_data;

        $page = isset($data["page"]) ? $data["page"] : 1;
        $size = isset($data["size"]) ? $data["size"] : 10;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('list');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        $data = $logic->listDataHandle($data);
        return $logic ->getList($page,$size,$data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/completeQueryList
     * @apiDescription 综合查询列表
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionCompleteQueryList()
    {
        $data = $this->request_data;

        $page = isset($data["page"]) ? $data["page"] : 1;
        $size = isset($data["size"]) ? $data["size"] : 10;
        $logic = new Plan();

        //可以查询全部区域的计划，
        return $logic->getList($page,$size,$data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/FillList 计划填报信息表列表*
     * @apiDescription 计划填报信息表列表
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionFillList()
    {
        $data = $this->request_data;

        $page = isset($data["page"]) ? $data["page"] : 1;
        $size = isset($data["size"]) ? $data["size"] : 10;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('list');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        $data['list_type']=1;
        $data = $logic->listDataHandle($data);
        return $logic ->getList($page,$size,$data);
    }


    /**
     *
     * @api {post} /eventActivity/plan/syncCheckList
     * @apiDescription 计划的同步审核列表
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionSyncCheckList()
    {
        $data = $this->request_data;

        $page = isset($data["page"]) ? $data["page"] : 1;
        $size = isset($data["size"]) ? $data["size"] : 10;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('list');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();

        //只需要状态为 通过的
        $data['statuss'] = [3,5];

        //只需要同步审核状态为 待审核和审核通过的
        $data['sync_check_statuss'] = [1,2];
        return $logic ->getList($page,$size,$data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/add 计划信息表添加*
     * @apiDescription 计划信息表添加
     * @apiGroup 赛事模块
     * @apiParam {Number} [company_id] 公司id
     * @apiParam {Number} [operator] 操作人id
     * @apiParam {Number} [organ_unit_id] 机构单位id
     * @apiParam {String} [name] 赛事名称
     * @apiParam {String} [first_hold_name] 第一主办单位
     * @apiParam {String} [notes] 备注
     * @apiParam {Number} [tag_group_id] 活动项目(标签分类组id)
     * @apiParam {Number} [tag_id] 标签id
     * @apiParam {Number} [is_community_sport] 是否属于社区运动会
     * @apiParam {Number} [year] 赛事年份
     * @apiParam {Number} [province] 省
     * @apiParam {Number} [city] 市
     * @apiParam {Number} [county] 区县
     * @apiParam {Number} [area_level] 赛事等级:1省级，2市级，3县级
     * @apiParam {Number} [about_match_num] 预计比赛场次
     * @apiParam {Number} [about_join_num] 预计参加人数
     * @apiParam {Number} [plan_start_time] 计划开始时间
     * @apiParam {Number} [plan_end_time] 计划结束时间
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * @return bool
     * @throws PPosException
     */
    public function actionAdd()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('create');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        $data["dec"] = isset($data["dec"])?$data["dec"]:"";
        $data["operator"] =app()->request->accountInfo['personnel_id'];
        $data["organ_unit_id"] = $data["jwt_organ_unit_id"];
        return $logic ->add($data);
    }
    /**
     *
     * @api {post} /eventActivity/plan/review 项目信息审核
     * @apiDescription 项目信息表获取编号
     * @apiGroup 项目模块
     * @apiParam {Number} review_id 审核ID
     * @apiParam {Number} resource_id 资源ID
     * @apiParam {Number} reviewer_id 审核人
     * @apiParam {Number} next_reviewer_id 下一审核人 为0则为终审
     * @apiParam {Number} status 状态 3通过，4驳回
     * @apiParam {String} action 动作 add(新建审核)|review(审核)
     * @apiParam {String} des 备注原因
     * @apiParam {Number} is_auto 是否自动审核
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":"删除成功"}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * @return string
     * @throws PPosException
     */
    public function actionReview()
    {
        $data = $this->request_data;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('review');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        if ($data['action']=="add"){
            return $logic ->addReview($data);
        }else{
            return $logic ->Review($data);
        }
    }
    /**
     *
     * @api {post} /eventActivity/plan/reviewList 计划信息表列表*
     * @apiDescription 计划信息表列表
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionReviewList()
    {
        $data = $this->request_data;

        $page = isset($data["page"]) ? $data["page"] : 1;
        $size = isset($data["size"]) ? $data["size"] : 10;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('list');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        //数据隔离，添加搜索条件
        return $logic ->reviewList($page,$size,$data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/reviewData
     * @apiDescription c
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionReviewData()
    {
        $data = $this->request_data;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('reviewData');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        //数据隔离，添加搜索条件
        $data['list_type'] = $data['list_type']??2;
        return $logic ->reviewData($data);
    }


    /**
     *
     * @api {post} /eventActivity/plan/areaList
     * @apiDescription 首页
     * @apiGroup 赛事模块
     * @apiParam {Number} [page] 页码 默认1
     * @apiParam {Number} [size] 分页 默认10
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"page":1,"size":"10","list":[{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}],"count":"10"}}
     *
     * @apiVersion 1.0.0
     *
     */
     /**
     * Notes:计划信息表列表
     * @return mixed
     * @throws PPosException
     */
    public function actionAreaList()
    {
        $data = $this->request_data;
        $validator = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('reviewData');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic ->areaList($data);
    }
    /**
     *
     * @api {post} /eventActivity/plan/update 计划信息表更新*
     * @apiDescription 计划信息表更新
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiParam {Number} [company_id] 公司id
     * @apiParam {Number} [operator] 操作人id
     * @apiParam {Number} [organ_unit_id] 机构单位id
     * @apiParam {String} [name] 赛事名称
     * @apiParam {String} [first_hold_name] 第一主办单位
     * @apiParam {String} [notes] 备注
     * @apiParam {Number} [tag_group_id] 活动项目(标签分类组id)
     * @apiParam {Number} [tag_id] 标签id
     * @apiParam {Number} [is_need_check] 是否需要备案，1需批复，2仅备案
     * @apiParam {Number} [is_community_sport] 是否属于社区运动会
     * @apiParam {Number} [year] 赛事年份
     * @apiParam {Number} [province] 省
     * @apiParam {Number} [city] 市
     * @apiParam {Number} [county] 区县
     * @apiParam {Number} [status] 状态：1草稿，2审核中，3通过，4驳回
     * @apiParam {Number} [area_level] 赛事等级:1省级，2市级，3县级
     * @apiParam {Number} [about_match_num] 预计比赛场次
     * @apiParam {Number} [about_join_num] 预计参加人数
     * @apiParam {Number} [plan_start_time] 计划开始时间
     * @apiParam {Number} [plan_end_time] 计划结束时间
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * @return string
     * @throws PPosException
     */
    public function actionUpdate()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('update');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic ->update($data);
    }


    /**
     *
     * @api {post} /eventActivity/plan/syncCheck
     * @apiDescription 计划审核
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiParam {Number} [status] 状态：3通过，4驳回
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * @return string
     * @throws PPosException
     */
    public function actionSyncCheck()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('syncCheck');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic ->SyncCheck($data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/checkProgressList
     * @apiDescription 审核进度列表
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiParam {Number} [status] 状态：3通过，4驳回
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}}
     *
     * @apiVersion 1.0.0
     *
     */
    public function actionCheckProgressList()
    {
        return (new Plan())->CheckProgressList($this->request_data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/get 计划信息表获取*
     * @apiDescription 计划信息表获取
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * @return mixed
     * @throws PPosException
     */
    public function actionGet()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('get');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic ->Get($data["plan_id"]);
    }

    /**
     *
     * @api {post} /eventActivity/plan/del 计划信息表删除*
     * @apiDescription 计划信息表删除
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":"删除成功"}
     *
     * @apiVersion 1.0.0
     *
     */
    public function actionDel()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('get');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic ->del($data["plan_id"]);
    }

    /**
     *
     * @api {post} /eventActivity/plan/GetAllByIds
     * @apiDescription 根据id获取对应的名称
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":"删除成功"}
     *
     * @apiVersion 1.0.0
     *
     */
    public function actionGetAllByIds()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('GetAllById');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic ->GetAllById($data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/revoke
     * @apiDescription 计划撤回
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":{"plan_id":"表id","operator":"操作人id","organ_unit_id":"机构单位id","name":"赛事名称","first_hold_name":"第一主办单位","notes":"备注","tag_group_id":"活动项目(标签分类组id)","tag_id":"标签id","is_need_check":"是否需要备案，1需批复，2仅备案","is_community_sport":"是否属于社区运动会","year":"赛事年份","province":"省","city":"市","county":"区县","status":"状态：1草稿，2审核中，3通过，4驳回","area_level":"赛事等级:1省级，2市级，3县级","about_match_num":"预计比赛场次","about_join_num":"预计参加人数","plan_start_time":"计划开始时间","plan_end_time":"计划结束时间"}}
     *
     * @apiVersion 1.0.0
     *
     */
    /**
     * @return string
     * @throws PPosException
     */
    public function actionRevoke()
    {
        $data = $this->request_data;
        $validator             = new PlanForm();
        $validator->attributes = $data;
        $validator->setScenario('get');
        if (!$validator->validate()) {
            throw new PPosException($validator->getError(), 4000500000);
        }
        $logic = new Plan();
        return $logic->Revoke($data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/checkTotal
     * @apiDescription 审核统计信息接口
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":"删除成功"}
     *
     * @apiVersion 1.0.0
     *
     */
    public function actionCheckTotal()
    {
        $data = $this->request_data;

        $logic = new Plan();
        return $logic ->CheckTotal($data);
    }

    /**
     *
     * @api {post} /eventActivity/plan/getAllStatus
     * @apiDescription 列表页面的状态信息
     * @apiGroup 赛事模块
     * @apiParam {Number} plan_id 计划信息表ID
     * @apiSuccess {String} code 响应码
     * @apiSuccess {String} message 相应消息
     * @apiSuccess {String} data 数据
     * @apiSuccessExample {json} 正确返回值:
     * {"code":200,"message":"","data":"删除成功"}
     *
     * @apiVersion 1.0.0
     *
     */
    public function actionGetAllStatus()
    {
        $data = $this->request_data;

        $logic = new Plan();
        return $logic->GetAllStatus($data);
    }


}

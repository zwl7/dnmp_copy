<?php

namespace Http\Controllers;


use PPOSLib\DB\Center\Business;
use PPOSLib\DB\Center\BusinessInfo;
use PPOSLib\Helpers\ElasticSearchService;

/**
 * Class IndexController
 * @package Http\Controllers
 * @author liu,jian <coder.keda@gmail.com>
 */
class PingController extends \PPOSLib\Controllers\BaseController
{

    /**
     * 默认动作
     * @return string
     */
    public function actionIndex()
    {
        $es = new ElasticSearchService();
        return $es->getDocInfo();
    }


}

<?php

namespace Http\Middleware;

use Mix\Core\Middleware\MiddlewareInterface;
use PPOSLib\Exception\PPosException;

/**
 * Class BeforeMiddleware
 * @package Http\Middleware
 * @author liu,jian <coder.keda@gmail.com>
 */
class BeforeMiddleware implements MiddlewareInterface
{

    public $check_organ_url_array = [

        //计划
        '/eventActivity/plan/checkList',
        '/eventActivity/plan/check',
        '/eventActivity/plan/syncCheckList',
        '/eventActivity/plan/syncCheck',

        //活动
        '/eventActivity/activity/checkList',
        '/eventActivity/activity/check',
        '/eventActivity/activity/syncCheckList',
        '/eventActivity/activity/syncCheck',

        //同步管理页面
        '/eventActivity/syncActivity/list',
        '/eventActivity/syncActivity/sync',
        '/eventActivity/syncActivity/recordList',
        '/eventActivity/syncActivity/recordSync',
        '/eventActivity/syncActivity/detailList',
        '/eventActivity/syncActivity/detailSync',
    ];

    //操作页面
    public $check_super_url_array = [

        //计划
        '/eventActivity/plan/check',
        '/eventActivity/plan/add',
        '/eventActivity/plan/update',
        '/eventActivity/plan/syncCheck',
        '/eventActivity/plan/del',


        //活动
        '/eventActivity/activity/del',
        '/eventActivity/activity/add',
        '/eventActivity/activity/check',
        '/eventActivity/activity/update',
        '/eventActivity/activity/syncCheck',

        //同步管理页面
        '/eventActivity/syncActivity/sync',
        '/eventActivity/syncActivity/recordSync',
        '/eventActivity/syncActivity/detailSync',
    ];


    /**
     * 处理
     * @param callable $callback
     * @param \Closure $next
     * @return mixed
     */
    public function handle(callable $callback, \Closure $next)
    {

        // 添加中间件执行代码
        list($controller, $action) = $callback;

        // ...
        //判断url,使用有权限访问

        $path = \Mix::$app->request->path();
        $data = \Mix::$app->request->request_data;


        if (
            in_array($path, $this->check_organ_url_array) &&
            isset($data['jwt_organ_unit_type']) &&
            $data['jwt_organ_unit_type'] == 2
        ) {

            //如果不是机构类型的用户访问，就不能访问
            throw new PPosException("无权限访问此模块功能", 4000040050);

        }


        if (
            in_array($path, $this->check_super_url_array) &&
            isset($data['jwt_organ_unit_id']) &&
            $data['jwt_organ_unit_id'] == 0
        ) {

            //如果超管，不能操作业务数据
            throw new PPosException("超管无权限操作业务数据", 4000040050);

        }



        // 执行下一个中间件
        return $next();
    }

}

<?php

namespace Http\Middleware;

use Mix\Core\Middleware\MiddlewareInterface;
use PPOSLib\Exception\PPosException;
use PPOSLib\Exception\ErrorCode;
use PPOSLib\Helpers\GateLock;

/**
 * Class BeforeMiddleware
 * @package Http\Middleware
 * @author liu,jian <coder.keda@gmail.com>
 */
class GateMiddleware implements MiddlewareInterface
{

    /**
     * 处理
     * @param callable $callback
     * @param \Closure $next
     * @throws PPosException
     * @return mixed
     */
    public function handle(callable $callback, \Closure $next)
    {
        $this->setIsolationFillable();
        app()->dbBasePool;
        $route = app()->request->path();
        $post = app()->request->request_data;
        $request_info = "\n\n 请求路径:".$route."\n\n 请求参数".var_export($post, true);
        try
        {

            app()->log->info($request_info);
            $response = $next();
            list($controller, $action) = $callback;
            $request_info="\n\n 响应: ".var_export($response, true);
            app()->log->log("gate",$request_info);
            return $response;
        } catch (\Exception $e)
        {

            $debug_error = $e->getMessage();
            $error_info['error_line'] = $e->getLine();
            $error_info['error_file'] = $e->getFile();
            $error_info['error_info'] = $debug_error;
            $error_info['error_path'] = $route;
            $log = "";
            switch (get_class($e))
            {
                case "PPOSLib\Exception\PPosException":
                    if($e->getLog()){
                        $log = implode("\n",$e->getLog());
                        $log.="\n".$debug_error;
                        $error_info['gate_log'] = $e->getLog();
                    }
                    $error_str = var_export(($error_info), true);
                    break;
                default:
                    $error_str = var_export(($error_info+["Trace" => $e->getTraceAsString()]), true);
            }
            $request_info .= "\n 错误信息:".$error_str;
            app()->log->log("gateError",$request_info);
            $gate['msg'] = $debug_error;
            $gate['log'] = $log;
            $gate["record"] = [];
            $gate["record_no"] = 0;
            $gate['success'] = false;
            $gate['pass'] = false;
            $gate["acs_res"] = 1;
            $gate["open_time"] = 5;
            $gate['user_name'] = "";
            $gate['need_confirm'] = 0;
            $gate["voucher_str"] = $debug_error;
            $rs['code'] = 200;
            $rs['message'] = $gate['msg'];
            $rs['data'] = $gate;
            return $rs;
        }
    }

    //隔离字段
    private function setIsolationFillable()
    {
        app()->request->isolation_fillable = [

        ];
    }
}

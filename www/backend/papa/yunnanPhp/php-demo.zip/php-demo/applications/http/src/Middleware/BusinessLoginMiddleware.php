<?php

namespace Http\Middleware;

use Mix\Core\Middleware\MiddlewareInterface;
use PPOSLib\Exception\PPosException;
use Ppospro\PAGE\Middleware\Http;

/**
 * Class BeforeMiddleware
 * @package Http\Middleware
 * @author liu,jian <coder.keda@gmail.com>
 */
class BusinessLoginMiddleware implements MiddlewareInterface
{

    /**
     * 处理
     * @param callable $callback
     * @param \Closure $next
     * @throws PPosException
     * @return mixed
     */
    public function handle(callable $callback, \Closure $next)
    {
        $middleware = new Http();
        $middleware->checkBusinessLogin();

        return $next();
    }
}

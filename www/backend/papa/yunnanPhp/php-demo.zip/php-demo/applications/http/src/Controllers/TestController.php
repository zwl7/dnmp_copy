<?php

namespace Http\Controllers;


use PPOSLib\DB\Center\Business;
use PPOSLib\DB\Center\BusinessInfo;

/**
 * Class IndexController
 * @package Http\Controllers
 * @author liu,jian <coder.keda@gmail.com>
 */
class TestController extends \PPOSLib\Controllers\BaseController
{

    /**
     * 默认动作
     * @return string
     */
    public function actionIndex()
    {
        $db = app()->dbPool->getConnection();
        var_dump($db->business_id);
        $db->release();
        return  app()->dbPool->getStats();
    }

    public function actionInfo()
    {
        $db = app()->dbPool->getConnection();

        $db->release();
        return  app()->dbPool->getStats();
    }
    public function  actionLock() {
        $strMutex = "php_lock";
        $intTimeout = 10;
        $redis = app()->redisPool->getConnection();
        //使用setnx操作加锁，同时设置过期时间
        $strRet  = $redis->set($strMutex, 10, 'ex', $intTimeout, 'nx');
        if ($strRet === 'OK') {
            var_dump($strRet);
        }else{
            var_dump("noLock");
        }
        $strRet  = $redis->set($strMutex, 10, 'ex', $intTimeout, 'nx');
        if ($strRet === 'OK') {
            var_dump($strRet);
        }else{
            var_dump("noLock");
        }
        return $strRet;
    }
    public function actionPool()
    {
        $start_time = microtime(true);
        $s_m = memory_get_usage();
        $db = app()->dbPool->getConnection();
        $db->beginTransaction();
        $set =[
            "info_name"=>microtime(true),
        ];
        $re = $db->update("ppts_business_info",$set,["business_id","=",1000001])->execute();
        echo "\n".($db->getLastSql())."\n";
        $db->commit();

        $end_time = microtime(true);
        $e_m = memory_get_usage();
        $cat_time = round($end_time - $start_time, 4);
        $m = round(($e_m - $s_m) / 1024 / 1024, 4) . "M";
        print_r(app()->dbPool->getStats());
        app()->log->info("时间--------------".$cat_time);
        app()->log->info("内存--------------".$m);
        $db->release();
        return  $re;
    }

    private function update($db){
        $Business = Business::mode($db);
        //var_dump($Business);
        $set =[
            "business_name"=>microtime(true),
        ];
        $Business->update($set)->execute();
        echo "\n".($db->getLastSql())."\n";
    }

}

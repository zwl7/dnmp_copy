<?php

namespace Http\Controllers;


use PPOSLib\Exception\PPosException;

/**
 * Class IndexController
 * @package Http\Controllers
 * @author liu,jian <coder.keda@gmail.com>
 */
class NotFoundController extends \PPOSLib\Controllers\BaseController
{

    /**
     * 默认动作
     * @return string
     */
    public function actionIndex()
    {
        throw new PPosException("接口不存在",404);

    }
}

<?php

namespace Http\Middleware;

use Mix\Core\Middleware\MiddlewareInterface;
use PPOSLib\Exception\PPosException;
use Ppospro\PAGE\Middleware\Http;

/**
 * Class BeforeMiddleware
 * @package Http\Middleware
 * @author liu,jian <coder.keda@gmail.com>
 */
class SignMiddleware implements MiddlewareInterface
{

    public function handle(callable $callback, \Closure $next)
    {
        $middleware = new Http();
        $middleware->checkSign();

        return $next();
    }






}

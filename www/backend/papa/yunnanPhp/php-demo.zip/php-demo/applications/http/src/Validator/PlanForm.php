<?php

namespace Http\Validator;

use Mix\Validate\Validator;
class PlanForm extends Validator
{

    /**
     * 规则
     * @return array
     */
    public function rules()
    {
        return [
            'integer_type'  => ['integer', 'unsigned' => true],
            'in_type' => ['in', 'range' => ['1', '2'], 'strict' => true],
            'date_type'  => ['date'],
            'string_type'  => ['string', 'maxLength' => 255],
            'match_type'  => ['match', 'pattern' => '/^[0-9\.]+$/'],
            'page'  => ['integer', 'unsigned' => true,'max'=>1000000],
            'size'  => ['integer', 'unsigned' => true,'max'=>1000],
            'plan_id'  => ['integer'],
            'plan_ids'  => ['string'],
            'company_id'  => ['integer'],
            'operator'  => ['integer'],
            'organ_unit_id'  => ['integer'],
            'name'  => ['string'],
            'first_hold_name'  => ['string'],
            'notes'  => ['string'],
            'review_comments'  => ['string'],
            'tag_group_id'  => ['integer'],
            'tag_id'  => ['integer'],
            'is_community_sport'  => ['integer'],
            'year'  => ['integer'],
            'province'  => ['integer'],//
            'city'  => ['integer'],
            'county'  => ['integer'],
            'status'  => ['integer'],
            'area_level'  => ['integer'],
            'about_match_num'  => ['integer'],
            'about_join_num'  => ['integer'],
            'plan_start_time'  => ['integer'],
            'plan_end_time'  => ['integer'],
            'data' => ['string'],
            'import_id'  => ['integer', 'unsigned' => true],
            'review_id'  => ['integer'],
            'resource_id'  => ['integer'],
            'reviewer_id'  => ['integer'],
            'next_reviewer_id'  => ['integer'],
            'is_auto'  => ['integer'],
            'action'  => ['string'],
        ];
    }

    /**
     * 场景
     * @return array
     */
    public function scenarios()
    {
        return [
            'create' => ['required' => ["name","area_level","year","first_hold_name","is_community_sport","province","city","county","about_match_num","about_join_num"],'optional' => ["plan_id","company_id","operator","organ_unit_id","name","first_hold_name","notes","tag_group_id","tag_id","is_community_sport","year","province","city","county","status","area_level","about_match_num","about_join_num","plan_start_time","plan_end_time"] ],
            'update' => ['required' => ["plan_id"],'optional' => ["plan_id","company_id","operator","organ_unit_id","name","first_hold_name","notes","tag_group_id","tag_id","is_community_sport","year","province","city","county","status","area_level","about_match_num","about_join_num","plan_start_time","plan_end_time"]],
            'check' => ['required' => ["plan_ids",'status','review_comments']],
            'syncCheck' => ['required' => ["plan_ids",'status']],
            'get' => ['required' => ["plan_id"]],
            'review' => ['required' => ["review_id",'resource_id','reviewer_id','next_reviewer_id','is_auto','action']],
            'GetAllById' => ['required' => ["plan_ids"]],
            'list' => ['required' => ["page","size"],'optional' => ["plan_id","company_id","operator","organ_unit_id","name","first_hold_name","notes","tag_group_id","tag_id","is_community_sport","year","province","city","county","status","area_level","about_match_num","about_join_num","plan_start_time","plan_end_time"]],
            'reviewData' => ['required' => [],'optional' => ["plan_id","company_id","operator","organ_unit_id","name","first_hold_name","notes","tag_group_id","tag_id","is_community_sport","year","province","city","county","status","area_level","about_match_num","about_join_num","plan_start_time","plan_end_time"]],
            'import' => ['required' => ["data","import_id"] ],
        ];
    }

    /**
     * 消息
     * @return array
     */
    public function messages()
    {
        return [
            'status.required'    => '状态不能为空.',
            'status.range'    => '状态值不正确.',
            'plan_id.required'    => 'plan_id不能为空.',
            'plan_id.integer'    => 'plan_id必须是数字.',
            'plan_id.unsigned'    => 'plan_id必须是正整数.',
        ];
    }

}

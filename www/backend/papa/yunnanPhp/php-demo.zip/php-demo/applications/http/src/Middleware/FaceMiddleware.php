<?php

namespace Http\Middleware;

use Mix\Core\Middleware\MiddlewareInterface;
use PPOSLib\Exception\PPosException;
use PPOSLib\Exception\ErrorCode;
use PPOSLib\Helpers\GateLock;

/**
 * Class BeforeMiddleware
 * @package Http\Middleware
 * @author liu,jian <coder.keda@gmail.com>
 */
class FaceMiddleware implements MiddlewareInterface
{

    /**
     * 处理
     * @param callable $callback
     * @param \Closure $next
     * @throws PPosException
     * @return mixed
     */
    public function handle(callable $callback, \Closure $next)
    {
        $this->setIsolationFillable();
        app()->dbBasePool;
        $route = app()->request->path();
        $post = app()->request->request_data;
        $request_info = "\n\n 请求路径:".$route."\n\n 请求参数".var_export($post, true);
        try
        {
            if(!isset($post['device_id'])||!$post['device_id']){
                throw new PPosException("设备ID为空", 4000010000);
            }
            app()->log->info($request_info);
            $response = $next();
            list($controller, $action) = $callback;
            $request_info="\n\n 响应: ".var_export($response, true);
            app()->log->log("gate",$request_info);
            return $response;
        } catch (\Exception $e)
        {

            $debug_error = $e->getMessage();
            $error_info['error_line'] = $e->getLine();
            $error_info['error_file'] = $e->getFile();
            $error_info['error_info'] = $debug_error;
            $error_info['error_path'] = $route;
            switch (get_class($e))
            {
                case "PPOSLib\Exception\PPosException":
                    $error_str = var_export(($error_info), true);
                    if($e->getLog()){
                        $log = implode("\n",$e->getLog());
                        $log.="\n".$debug_error;
                        app()->log->log("gateLog",$log);
                    }
                    break;
                default:
                    $error_str = var_export(($error_info+["Trace" => $e->getTraceAsString()]), true);
            }
            $request_info .= "\n 错误信息:".$error_str;
            app()->log->log("gateError",$request_info);
            $rs['Success'] = false;
            $rs['Pass'] = false;
            $rs['Msg'] = $rs['UserName'] = $debug_error;
            return $rs;
        }
    }


    //隔离字段
    private function setIsolationFillable()
    {
        app()->request->isolation_fillable = [

        ];
    }
}

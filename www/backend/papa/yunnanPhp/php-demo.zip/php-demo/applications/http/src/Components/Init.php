<?php
namespace Http\Components;

use Mix\Core\Component\AbstractComponent;
/**
 * Created by PhpStorm.
 * User: PGF
 * Email: pgf@fealive.com
 * Date: 19-11-12
 * Time: 上午9:49
 */
class Init extends AbstractComponent
{

}
<?php

namespace Http\Middleware;

use Mix\Core\Middleware\MiddlewareInterface;
use PPOSLib\Exception\PPosException;
use PPOSLib\Exception\ErrorCode;
/**
 * Class BeforeMiddleware
 * @package Http\Middleware
 * @author liu,jian <coder.keda@gmail.com>
 */
class First2Middleware implements MiddlewareInterface
{

    /**
     * 处理
     * @param callable $callback
     * @param \Closure $next
     * @throws PPosException
     * @return mixed
     */
    public function handle(callable $callback, \Closure $next)
    {
        app()->dbBasePool;
        $route = app()->request->path();
        $token = app()->request->header('authorization');
        $post = app()->request->request_data;
        $request_info = "\n\n 请求路径:".$route."\n\n 请求token:".$token."\n\n 请求参数".var_export($post, true);
        try
        {
            $method = app()->request->method();

            if($method == "POST"||$method == "GET") {
                app()->response->setHeaders([
                    'Access-Control-Allow-Methods'=>'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers'=>'X-Token,token,authorization,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type',
                ]);
            }
            if($method == "OPTIONS") {
                app()->response->setHeaders(['Content-Type' => 'application/json;charset=utf-8']);
                app()->response->setHeaders([
                    'Access-Control-Allow-Methods'=>'GET, POST, OPTIONS',
                    'Access-Control-Allow-Origin'=>'*',
                    'Access-Control-Allow-Headers'=>'X-Token,token,authorization,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type',
                    'Access-Control-Max-Age'=>'1728000',
                    'Content-Type'=>'text/plain charset=UTF-8',
                    'Content-Length'=>'0',
                ]);
                return null;
            }
            app()->log->info($request_info);
            app()->response->setHeader('Access-Control-Allow-Origin','*');


            $response = $next();
            list($controller, $action) = $callback;
            // 返回响应内容
//            $rs = [
//                'code'    => 200,
//                'message' => "",
//                "data"=> $response,
//            ];

			$rs = [
				'code'    => 1,
				"msg"=> $response,
			];
            return $rs;
            //return $response;
        } catch (\Exception $e)
        {
            $code = $e->getCode();
            $debug_error = $e->getMessage();
            $error_info['error_line'] = $e->getLine();
            $error_info['error_file'] = $e->getFile();
            $error_info['error_info'] = $debug_error;
            $error_info['error_path'] = $route;
            $data =ErrorCode::mode()->getMessage($code);
            if (strpos($debug_error, 'SQLSTATE') !== false)
            {
                $data = "系统繁忙,请稍后重试!";
            }
            if ($data == "")
            {
                $data = $debug_error;
            }
            //$re = ['code' => $code, 'message' => $data, "data" => null,];
            $re = ['code' => 0, 'msg' => $data];

            switch (get_class($e))
            {
                case "PPOSLib\Exception\PPosException":
                    $error_str = var_export(($re+$error_info), true);
                    break;
                default:
                    $error_str = var_export(($re + $error_info+["Trace" => $e->getTraceAsString()]), true);


            }
            app()->log->error("\n 错误信息:".$error_str);
            return $re;
        }
    }



}

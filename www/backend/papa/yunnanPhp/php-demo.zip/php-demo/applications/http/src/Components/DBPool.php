<?php
/**
 * Created by PhpStorm.
 * User: PGF
 * Email: pgf@fealive.com
 * Date: 19-11-12
 * Time: 上午9:58
 */

namespace Http\Components;

use Mix\Database\Pool\ConnectionPool;
use Ppospro\PAGE\Utils\Dbdriver\MixphpEngine;

class DBPool extends ConnectionPool
{

    public $dbName = null;

    /**
     * 初始化事件
     */
    public function onInitialize()
    {
        parent::onInitialize();
        MixphpEngine::setPool($this->dbName,$this);
    }
}
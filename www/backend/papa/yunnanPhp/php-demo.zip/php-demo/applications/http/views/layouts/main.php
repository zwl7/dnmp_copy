<html>
<head>
    <title><?= $this->title ?></title>
</head>
<body>

<?= $content ?>

</body>
</html>
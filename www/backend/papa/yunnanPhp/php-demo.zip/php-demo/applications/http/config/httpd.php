<?php

// http 服务配置
return [

    // 服务器
    'server' => [// 主机
        'host' => env("APP_HOST"), // 端口
        'port' => env("APP_PORT"),
        ],

    // 应用
    'application' => [// 配置信息
        'config' => require __DIR__ . '/main_coroutine.php',],

    // 运行参数：https://wiki.swoole.com/wiki/page/274.html
    'setting' => [// 开启协程
        'enable_coroutine' => true, // 主进程事件处理线程数
        'worker_num' => 8, // PID 文件
        'pid_file' => __DIR__.'/../runtime/mix-httpd.pid', // 日志文件路径
        'log_file' => __DIR__.'/../runtime/mix-httpd.log', // 子进程运行用户
        /* 'user'             => 'www', */
        // 最大数据包尺寸
        'package_max_length' => 2 * 1024 * 1024,
        // 主进程启动事件回调
        'hook_start' => function (\Swoole\Http\Server $server)
        {

            echo "注册服务...".PHP_EOL;
            $consul = new \PPOSLib\Helpers\ConsulTool(env('CONSUL_IP'),env('CONSUL_PORT'));
            $data = array(
                "ID" => env('CONSUL_ID'),
                "Name" => env('CONSUL_NAME'),
                "Tags" =>explode(",",env('CONSUL_TAGS')),
                "Address" => $server->host,
                "Port" => $server->port,
                "HTTP" => "http://".$server->host.":".$server->port."/check/consul",
                "Interval" => "5s"
            );
            $consul->registerService(json_encode($data)); //往Consul里注册服务
            echo "注册成功,参数:".PHP_EOL;
            echo var_export($data).PHP_EOL;
        },

        'hook_shutdown' => function (\Swoole\Http\Server $server)
        {
            echo "注销服务...".PHP_EOL;
            $consul = new \PPOSLib\Helpers\ConsulTool(env('CONSUL_IP'),env('CONSUL_PORT'));
            $consul->deregisterService(env('CONSUL_ID')); //往Consul里注册服务
            echo "注销成功".PHP_EOL;
        },
    ],

];

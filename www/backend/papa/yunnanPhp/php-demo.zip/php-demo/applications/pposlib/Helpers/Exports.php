<?php

namespace PPOSLib\Helpers;



use PPOSLib\DB\Stadia\TaskList;
use PPOSLib\Exception\PPosException;

class Exports
{
    private static $_mode = null;

    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {


    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    /**
     * Notes:单例
     * @return $this
     */
    public static function mode()
    {
        if (!self::$_mode) {
            self::$_mode =new self();
        }
        return self::$_mode;
    }



    public function ToTask($data,$task_path){
        $task_code = md5($task_path);
        $now = Functions::mode()->time();
        $task_list_mod = new TaskList();
        $s["task_code"]=$task_code;
        $s["gte_c_time"]=$now - 24*3600*7;
        $task_list = $task_list_mod->gets($s);
        foreach ($task_list as $t){
            if($t["status"]==2){
                throw new PPosException("有任务正在执行中！", 40113);
            }
            if($t["status"]==0){
                throw new PPosException("有任务正在等待执行中！", 40114);
            }
        }
        $task["task_code"]=$task_code;
        $task["type"]=1;
        $task["status"]=0;
        $task["rate"]=0;
        $task["param"]= json_encode($data);
        $task["result"]= '';
        $task["env"]= env("APP_ENV");
        $rs = $task_list_mod->createOne($task);
        if($rs){
            return $rs["task_id"];
        }else{
            throw new PPosException("任务创建失败！", 40115);
        }
    }

    public function DelTask($task_id){
        $task_list_mod = new TaskList();
        $s["task_id"]=$task_id;
        $u["status"]=3;
        $flag = $task_list_mod->update($s,$u);
        if($flag){
            return true;
        }else{
            throw new PPosException("任务删除失败！", 40115);
        }
    }

    public function TaskRate($task_path){
        $task_code = md5($task_path);
        $now = Functions::mode()->time();
        $task_list_mod = new TaskList();
        $s["task_code"]=$task_code;
        $s["type"]=1;
        $s["gte_c_time"]= $now - 24*3600*7;
        $task_list = $task_list_mod->gets($s);

        $rs["waiting"]=[];
        $rs["processing"]=[];
        $rs["completed"]=[];
        $rs["status"] = 1;  //允许导出
        foreach ($task_list as &$t){
            $t["c_time"] = date("Y-m-d H:i",$t["c_time"]);
            if(!$rs["processing"]&&$t["status"]==2){
                $rs["processing"] = $t;
                $rs["status"] = 2;//进行中 不能导出
            }
            if(!$rs["completed"]&&$t["status"]==1){
                $rs["completed"] = $t;
                $result = json_decode($t["result"],true);
                $rs["completed"]["path"] = $result["file_path"];
                unset($t["result"]);
            }
            if(!$rs["waiting"]&&$t["status"]==0){
                $rs["waiting"] = $t;
                $rs["status"] = 3;//等待中 不能导出
            }
        }
        return $rs;
    }

}
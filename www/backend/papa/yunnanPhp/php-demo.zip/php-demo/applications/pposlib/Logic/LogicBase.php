<?php
namespace PPOSLib\Logic;
use PPOSLib\Exception\PPosException;
use PPOSLib\Helpers\Functions;
use PPOSLib\Helpers\ServiceData;

class LogicBase extends \Ppospro\PAGE\Logic\LogicBase {

    //赛事等级:1省级，2市级，3县级 4国家级，5跨省赛事活动
    protected $areaLevel = ['1'=>'省级','2'=>'市级','3'=>'县级','4'=>"国家级",'5'=>'跨省赛事活动'];

    //赛事状态
    protected $matchStatus = ['1'=>'计划中','2'=>'报名中','3'=>'进行中','4'=>'已结束'];

    //1草稿，2核查中，3通过，4驳回，5自动核查通过
    //const STATUS = ['1'=>"草稿","2"=>"核查中","3"=>"人工核查通过","4"=>"驳回",'5'=>"自动核查通过"];
    //后期 人工核查通过 和 自动核查通过 都该为通过 8:为通过后可驳回操作
    const STATUS = ['0'=>'待确认','1'=>"草稿","2"=>"核查中","3"=>"通过","4"=>"驳回",'5'=>"通过",'7'=>"核查中",'8'=>"通过"];

    const SOURCE_OF_FUNDS = ['1'=>"中央体彩公益金","2"=>"省级补助"];


    const SYNC_CHECK_STATUS = ['1'=>"待核查","2"=>"核查通过","3"=>"驳回"];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Notes: 处理images
     * User: 闻铃
     * DateTime: 2023/8/22 15:45
     * @param $images
     * @return string
     */
    public function getFullImages($images): string
    {
        if (strpos($images, "http") === 0) {
            return $images;
        }
        return env('APP_IMAGES_PATH') . $images;
    }



    /**
     * Notes: 验证权限
     * User: 闻铃
     * DateTime: 2023/10/28 18:21
     * @param $status
     * @throws PPosException
     */
    public function checkWriteAuth($status,$limitStatus = [2])
    {
        //
        if (in_array($status,$limitStatus)) {
            //throw new PPosException("当前状态下不允许编辑或者新增");
            throw new PPosException("当前状态下不允许修改");
        }
    }

    public function getAreaLevelStr($area_level): string
    {
        return $this->areaLevel[$area_level] ?? "--";
    }

    public function getMatchStatus($startTime,$endTime): array
    {
        if ($startTime == 0 || $endTime == 0) {

            //没设置好时间

            return ['match_status'=>1,'match_status_str'=>"计划中"];
        }

        $time = Functions::mode()->time();

        //
        if ($time < $startTime) {
            $status = 2;
        } elseif ($time <= $endTime) {
            $status = 3;
        } else {
            $status = 4;
        }
        return ['match_status'=>$status,'match_status_str'=>$this->matchStatus[$status] ?? ""];
    }

    public function getEsSearchByMatchStatus($matchStatus,$search = [],$suffixField = '')
    {

        $time = Functions::mode()->time();

        if ($matchStatus == 1) {

            //计划中的，只有计划，没有赛事活动的
//            $ActivityBase = new \PPOSLib\DB\Base\Activity();
//            $ActivityData = $ActivityBase->getAll(['gte_plan_id'=>1],['plan_id']);
//            if (!$ActivityData) {
//                return $search;
//            }
//            $search["not_in_plan_ids"] = array_column($ActivityData,'plan_id');

            //计划中的活动 新增了赛事基本信息，但是没有填举办情况的赛事活动
            $search["{$suffixField}start_time"] = 0;

        }elseif ($matchStatus == 2) {
            //报名中
            //now < start_time
            $search["gte_{$suffixField}start_time"] = $time;

        } elseif ($matchStatus == 3) {
            //进行中

            $search["lte_{$suffixField}start_time"] = $time;
            $search["gte_{$suffixField}end_time"] = $time;

        } else {

            //已结束
            $search["lte_{$suffixField}end_time"] = $time;

            //防止为0的情况
            $search["gte_{$suffixField}end_time"] = 1;
        }
        return $search;
    }

    public function getSearch(array $search = [],$suffixField = ''): array
    {

        if (isset($search['match_status']) && !empty($search['match_status'])) {
            $search = $this->getEsSearchByMatchStatus($search['match_status'],$search,$suffixField);
        }

        if (isset($search['company_area_id']) && !empty($search['company_area_id'])) {
            $search = $this->getAreaSearch($search);
        }

        return $search;
    }

    //带上搜索的区域条件
    public function getAreaSearch($search):array
    {

        //$company_area_id = $search['company_area_id'] ?? $search['jwt_company_area_id'];
        $company_area_id = $search['company_area_id'];
        if ($company_area_id < 100) {
            //53
            $search['province'] = $company_area_id;
        } elseif ($company_area_id < 10000) {
            //5301
            $search['city'] = $company_area_id;
        } elseif ($company_area_id < 10000000) {
            //5301444
            $search['county'] = $company_area_id;
        } else {
            //后续扩展
        }

        return $search;
    }

    //1,2,3 tag_id_str,tag_group_id,tag_group_id_str
    public function getTagShowInfo($tagIdsStr,$TagIdsInfo): array
    {
        if (!$tagIdsStr) {
            return [];
        }

        $tagData = [];
        $tag_ids = explode(",",$tagIdsStr);
        //1,2,3
        foreach ($tag_ids as $v) {
            if (!$v) {
                continue;
            }
            if (!isset($TagIdsInfo[$v])) {
                continue;
            }
            //235
            if (isset($tagData[$TagIdsInfo[$v]['tag_group_id']])) {
                //如果有，则追加

                $tagData[$TagIdsInfo[$v]['tag_group_id']]['tag_ids'][] = [
                    'tag_id'=>$v,
                    'tag_id_str'=>$TagIdsInfo[$v]['tag_id_str'],
                ];
            } else {
                //如果没有则新增
                $tagData[$TagIdsInfo[$v]['tag_group_id']] = [
                    'tag_group_id'=>$TagIdsInfo[$v]['tag_group_id'],
                    'tag_group_id_str'=>$TagIdsInfo[$v]['tag_group_id_str'],
                    'tag_ids'=>[
                        [
                            'tag_id'=>$v,
                            'tag_id_str'=>$TagIdsInfo[$v]['tag_id_str']
                        ]
                    ],
                ];
            }
        }
        return array_values($tagData);
    }

    public function getTagMap(string $tag_ids): array
    {
        $tag_ids = explode(',',$tag_ids);
        if (!$tag_ids) {
            return [];
        }

        //tag_group_id,tag_group_id_str,tag_id_str,tag_id
        //$TagOrm = new \PPOSLib\DB\Orm\Tag();
        //$TagData = $TagOrm->getAll(['tag_ids'=>$tag_ids],['name as tag_id_str','tag_id','tag_group_id']);

        $ServiceData = new ServiceData();
        $TagData = $ServiceData->sendByParams('getAllTag',['search'=>['tag_ids' => $tag_ids],'select'=>['tag_id', 'name as tag_id_str', 'tag_group_id']]);
        if (!$TagData) {
            return [];
        }

        $tag_group_ids = array_column($TagData,'tag_group_id');

        //$TagGroup = new \PPOSLib\DB\Orm\TagGroup();
        //$TagGroupData = $TagGroup->getAll(['tag_group_ids'=>$tag_group_ids],['name','tag_group_id']);
        //getAllTagGroup
        if ($tag_group_ids) {
            $TagGroupData = $ServiceData->sendByParams('getAllTagGroup',['search'=>['tag_group_ids'=>$tag_group_ids],'select'=>['name','tag_group_id']]);

        } else {
            $TagGroupData = [];
        }

        $TagGroupData = array_column($TagGroupData,'name','tag_group_id');

        $tmp = [];
        foreach ($TagData as $v) {
            $v['tag_group_id_str'] = $TagGroupData[$v['tag_group_id']];
            $tmp[$v['tag_id']] = $v;
        }

        return $tmp;
    }

    public function getNextCheckInfo($PlanData, $endData, $endDataLevel): array
    {
        if ($endData['status'] == 2) {
            //下一级别一定是区
            $next_company_area_id = $PlanData['county'];
        } else {

            //2 //拿到计划的province 。根据区域id，找到对应的机构id，此机构id对应的机构名称
            if ($endDataLevel == 3) {
                //区县级，下一级别 市
                $next_company_area_id = $PlanData['city'];
            } elseif ($endDataLevel == 2) {
                //市级，下一级别 省
                $next_company_area_id = $PlanData['province'];
            } else {
                // 省，没有必要下一级别
                $next_company_area_id = 0;
            }
        }
        return ['next_company_area_id' => $next_company_area_id, 'area_level' => $PlanData['area_level']];
    }

    public function getCompanyAreaIdLevel($company_area_id): array
    {

        if ($company_area_id < 100) {
            //53
            $level = "省级";
            $search = ['province'=>$company_area_id];
        } elseif ($company_area_id < 10000) {
            //5301
            $level = "市级";
            $search = ['city'=>$company_area_id];
            //
        } elseif ($company_area_id < 1000000) {
            //530102
            $level = "区县级";
            $search = ['county'=>$company_area_id];
            //
        } elseif ($company_area_id < 1000000000) {
            //后续扩展
            $level = "街道级";
            $search = ['street'=>$company_area_id];
        } else {
            $level = "--";
            $search = [];
        }

        return ['level' => $level, 'search' => $search];
    }

    public function getTotalRate($rs)
    {
        if ($rs['count'] == 0) {

            //
            $rs['count_rate'] = $rs['review_rate'] = $rs['pass_rate'] = $rs['reject_rate'] = 0;

        } else {

            $rs['count_rate'] = 100;
            $rs['review_rate'] = $rs['review'] != 0 ? Functions::mode()->keep(($rs['review'] / $rs['count'])*100) : 0;
            $rs['pass_rate'] = $rs['pass'] != 0 ? Functions::mode()->keep(($rs['pass'] / $rs['count'])*100) : 0;
            $rs['reject_rate'] = $rs['reject'] != 0 ? Functions::mode()->keep(($rs['reject'] / $rs['count'])*100) : 0;
        }
        return $rs;
    }

    /**
     * Notes: 获取tag 数组的str
     * User: 闻铃
     * DateTime: 12/13/23 2:27 下午
     * @param array $tag_ids_arr
     * @return false|string
     */
    public function getTagStr(array $tag_ids_arr)
    {
        if (!$tag_ids_arr) {
            return '';
        }

        $tag_ids_str = '';
        foreach ($tag_ids_arr as $tag) {
            //tag_id_str
            $tag_ids_str .= ($tag['tag_id_str'] . ',');
        }
        return substr($tag_ids_str,0,-1);
    }

    public function getTagGroupAndTagStr($tagGroupArr)
    {

        if (!$tagGroupArr) {
            return '';
        }

        $str = '';
        foreach ($tagGroupArr as $tagGroup) {
            //tag_id_str
            $str .=  $tagGroup['tag_group_id_str'] . ':';
            foreach ($tagGroup['tag_ids'] as $tag) {
                //
                $str .= ($tag['tag_id_str'] . ',');
            }
            $str = substr($str,0,-1);

        }
        return $str;
    }

    /**
     * Notes: 统一处理时间格式
     * User: 闻铃
     * DateTime: 12/13/23 2:28 下午
     * @param int $time
     * @param string $format
     * @return false|string
     */
    public function getFormatTimeStr(int $time, string $format = 'Y-m-d')
    {

        if (!$time) {
            return '';
        }
        return date($format, $time);
    }

}

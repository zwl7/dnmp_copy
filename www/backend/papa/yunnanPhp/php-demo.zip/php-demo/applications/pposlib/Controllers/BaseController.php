<?php
/**
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-14
 * Time: 下午4:25
 */
namespace PPOSLib\Controllers;

use PPOSLib\Helpers\ServiceData;

class BaseController extends \Ppospro\PAGE\Controllers\BaseController {

    public function __construct()
    {
       parent::__construct();

        $this->request_data = app()->request->request_data;
        if(isset($this->request_data["images"])&&$this->request_data["images"]){
            if (strpos($this->request_data["images"],"http") === 0){
                $this->request_data["images"] = str_replace(env('APP_IMAGES_PATH'),"",$this->request_data["images"]);
            }
        }

    }
}

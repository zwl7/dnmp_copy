<?php

/**
 *  公共函数库
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-19
 * Time: 下午6:16
 */

namespace PPOSLib\Helpers;


class Config
{
    private static $_mode = null;
    private  $_config = array();

    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {


    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    /**
     * Notes:单例
     * @return $this
     */
    public static function mode()
    {
        if (!self::$_mode) {
            self::$_mode =new self();
        }
        return self::$_mode;
    }

    public function ConfigInfo($codes=[],$company_id,$business_id=0,$stadium_id=0,$time=0){
        $data=[];
        $need_get=[];
        foreach ($codes as $c){
            $key = $company_id."_".$business_id."_".$stadium_id."_".$c;
            if(!isset($this->_config[$key])){
                $this->_config[$key]["time"] = time();
            }
            $c_time = time() - $this->_config[$key]["time"];
            //隔天也要刷新
            $diff_date = (date("Y-m-d",time()) == date("Y-m-d",$this->_config[$key]["time"]))?false:true;
            if(!isset($this->_config[$key]["data"]) || $c_time > env("APP_CONF_CACHE_TIME",0)||$diff_date){
                $this->_config[$key]["time"] = time();
                $need_get[] = $c;
            }else{
                $data[$c]["value"] = $this->_config[$key]["data"]["value"];
                $data[$c]["id"] = $this->_config[$key]["data"]["id"];
            }
        }

        if($need_get||$time>0){
            $s = new ServiceData();
            $cfgs =  $s->ConfigInfo(implode(",",$need_get),$company_id,$business_id,$stadium_id,$time);
            foreach ($cfgs as $c){
                $key = $company_id."_".$business_id."_".$stadium_id."_".$c["cfg_code"];
                $data[$c["cfg_code"]]["value"] = $c["cfg_value"];
                $this->_config[$key]["data"]["value"] = $c["cfg_value"];
                $data[$c["cfg_code"]]["id"] = $c["cfg_id"];
                $this->_config[$key]["data"]["id"] = $c["cfg_id"];
            }
        }
        return $data;
    }

    public function clearCfg($codes=[],$company_id,$business_id=0,$stadium_id=0){
        if($codes){
            foreach ($codes as $c){
                $key = $company_id."_".$business_id."_".$stadium_id."_".$c;
                if(isset($this->_config[$key])){
                    echo "\n清除配置$key\n";
                    unset($this->_config[$key]);
                }
            }
        }else{
            foreach ($this->_config as $k=>$v){
                $key = $company_id."_".$business_id."_".$stadium_id;
                if(strpos($k,$key)!==false){
                    echo "\n清除配置$k\n";
                    unset($this->_config[$k]);
                }
            }
        }
        return $this->_config;
    }
}



<?php

namespace PPOSLib\DB;

use Matrix\Exception;
use \Mix\Pool\ConnectionTrait;
use PPOSLib\Exception\PPosException;
use PPOSLib\Helpers\Functions;

/**
 * PDOCoroutine 组件普通模式
 */
class PDOPerConnection extends \Mix\Database\Persistent\PDOConnection
{


    public $prefix = null;

    /**
     * @var \PPOSLib\DB\Base\ModelBase
     */
    protected $model;
    protected $isolation_fillable = null;

    public function __construct($config = [])
    {
        $config['dsn'] = "mysql:host=".$config['host'].";port=".$config['port'].";charset=".$config['charset'].";dbname=".$config['prefix'].$config['dbname'];

        parent::__construct($config);
    }



    /**
     * @param $model
     * @param bool $isolation
     * @return $this
     * @throws PPosException
     */
    public function setModel($model,$isolation = true){
        $this->model = $model;
        //$this->switchDB($this->model->connection);
        $this->setIsolation($isolation);
        return $this;
    }

    /**
     * Notes:开启字段隔离
     * @param bool $isolation
     * @return $this
     * @throws PPosException
     */
    public function setIsolation($isolation = true){
        if($isolation){
            foreach (app()->request->isolation_fillable as $k=>$v){
                if(in_array($k,$this->model->isolation_fillable)){
                    $this->isolation_fillable[$k] = $v;
                }
            }

        }else{
            $this->isolation_fillable = null;
        }
        return $this;
    }
    /**
     * @param string|null $table
     * @return \Mix\Database\QueryBuilder
     */
    public function query($model = null)
    {
        if($model){
            $this->setModel($model);
        }
        $table = $this->getTable();
        $q = parent::table($table);
        if($this->isolation_fillable!==null){
            foreach ($this->isolation_fillable as $k=>$v){
                $q->where([$k,"=",$v]);
            }
        }
        return $q;
    }


    /**
     * @param array $data
     * @param array $where
     * @param string|null $table
     * @return bool
     */

    public function save(array $data, array $where = [], $model = null)
    {
        if($model){
            $this->setModel($model);
        }
        if($this->isolation_fillable!==null){
            foreach ($this->isolation_fillable as $k=>$v){
                $where[] = [$k,"=",$v];
            }
        }else{
            $where[] =["1","=",1];
        }
        if($this->model->timestamps){
           
            $data[$this->model->updated_at]= Functions::mode()->time();
        }
        $table = $this->getTable();
        try{
            $bool = parent::update( $table, $data, $where)->execute();
        }catch (\Exception $e){
            $Sql =  parent::update( $table, $data, $where)->getLastSql();
            var_dump(parent::update( $table, $data, $where)->getLastLog());
            app()->log->error($Sql."\n".$e->getMessage());
            throw new PPosException("系统繁忙,请稍后重试!", 40108);
        }
        return $bool?$this->getRowCount():$bool;
    }


    /**
     * Notes:
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 19-10-24
     * Time: 上午10:55
     * @param array $where
     * @param null $table
     * @return bool|int
     */
    public function del(array $where = [], $model = null)
    {
        if($model){
            $this->setModel($model);
        }
        if($this->isolation_fillable!==null){
            foreach ($this->isolation_fillable as $k=>$v){
                $where[] = [$k,"=",$v];
            }
        }else{
            $where[] =["1","=",1];
        }
        $table = $this->getTable();
        $bool = parent::delete( $table, $where)->execute();
        return $bool?$this->getRowCount():$bool;
    }

    public function  __get($name){
        return $this->$name;
    }

    public function release()
    {
        $this->model=null;
        $this->isolation_fillable=null;
        if (isset($this->connectionPool)) {
            return $this->connectionPool->release($this);
        }
        return false;
    }

    public function create(array $data,$model = null)
    {
        if($model){
            $this->setModel($model);
        }

        if($this->isolation_fillable!==null){
            foreach ($this->isolation_fillable as $k=>$v){
                $data[$k]=$v;
            }
        }
        if($this->model->timestamps){
            $data[$this->model->create_at]=Functions::mode()->time();
            $data[$this->model->updated_at]=0;
        }
        $table = $this->getTable();
        try{
            $bool = parent::insert($table, $data)->execute();
        }catch (\Exception $e){
            $Sql =  parent::insert($table, $data)->getLastSql();
            var_dump(parent::insert($table, $data)->getLastLog());
            app()->log->error($Sql."\n".$e->getMessage());
            throw new PPosException("系统繁忙,请稍后重试!", 40108);
        }

        return $bool?$this->getRowCount():$bool;
    }

    public function creates(array $data,$model = null)
    {
        if($model){
            $this->setModel($model);
        }
        $time = Functions::mode()->time();
        foreach ($data as $k=>$v){

            if($this->isolation_fillable!==null){
                foreach ($this->isolation_fillable as $f=>$val){
                    $data[$k][$f]=$val;
                }
            }
            if($this->model->timestamps){
                $data[$k][$this->model->create_at]=$time;
                $data[$k][$this->model->updated_at]=0;
            }
        }
        $table = $this->getTable();
        $bool = parent::batchInsert($table, $data)->execute();
        return $bool?$this->getRowCount():$bool;

    }

    public function getTable(){
        return $this->prefix.$this->model->table;
    }
}

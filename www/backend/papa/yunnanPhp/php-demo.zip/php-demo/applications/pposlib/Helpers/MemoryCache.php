<?php

/**
 *  公共函数库
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-19
 * Time: 下午6:16
 */

namespace PPOSLib\Helpers;


class MemoryCache
{
    private static $_mode = null;
    //格式 array("key1"=>array("over_time"=>1657102787,"data"=>"json"))
    private  $_cache = array();//
    private  $_u_lock = array();//
    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {


    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    /**
     * Notes:单例
     * @return $this
     */
    public static function mode()
    {
        if (!self::$_mode) {
            self::$_mode =new self();
        }
        return self::$_mode;
    }

    public function GetUpdateCacheLock($key,$over_time = 10){
        $time =  Functions::mode()->time();
        if(isset($this->_u_lock[$key])&&$this->_u_lock[$key]>$time){
            return false;
        }else{
            $this->_u_lock[$key]= $time+$over_time;
            return true;
        }
    }
    public function DelUpdateCacheLock($key){
       unset($this->_u_lock[$key]);
    }
    public function GetCache($key){
        if(!isset($this->_cache[$key])){
            return false;
        }
        $time = Functions::mode()->time();
        if ($this->_cache[$key][0]<$time){
            return false;
        }
        //\Mix::$app->log->debug($log);
        return $this->_cache[$key][1];
    }

    public function SetCache($key,$over_time,$data){
        $time = Functions::mode()->time();
        $this->_cache[$key] = array($time+$over_time,$data);
        return true;
    }
}



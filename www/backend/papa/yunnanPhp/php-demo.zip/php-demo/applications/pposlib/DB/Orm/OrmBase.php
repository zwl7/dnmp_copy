<?php
/**
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-13
 * Time: 上午10:52
 */
namespace PPOSLib\DB\Orm;


use PPOSLib\DB\Base\BaseMode;

class OrmBase
{
    /**
     * @var BaseMode
     */
    public $dbBaseObj;

    public function getSrcDb(): BaseMode
    {
        return $this->dbBaseObj;
    }

}

<?php
/**
 * Created by PhpStorm.
 * Note:隔离字段组件,适合非http请求使用,如命令行模式
 * User: PGF
 * Email: pgf@fealive.com
 * Date: 19-12-16
 * Time: 下午4:15
 */


namespace PPOSLib\Helpers;

use Mix\Core\Component\AbstractComponent;

class IsolationFillable extends AbstractComponent
{

    protected $_fillable =[];
    public function setFillable($fillable){
        $this->_fillable = $fillable;
    }
    public function getFillable(){
        return $this->_fillable;
    }
}

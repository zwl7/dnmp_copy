<?php
/**
 * Created by PhpStorm.
 * User: PGF
 * Email: pgf@fealive.com
 * Date: 23-1-4
 * Time: 下午5:44
 */
namespace PPOSLib\Helpers;


use Ppospro\PAGE\Exception\PPosException;

class CheckIdentity{
    // $num为身份证号码，$checkSex：1为男，2为女，不输入为不验证
    public function CheckIdentity($num,$checkSex=''){
        // 不是15位或不是18位都是无效身份证号
        if(strlen($num) != 15 && strlen($num) != 18){
            throw new PPosException("身份证号无效", 4000500000);
        }
        // 是数值
        if(is_numeric($num)){
            // 如果是15位身份证号
            if(strlen($num) == 15 ){
                // 省市县（6位）
                $areaNum = substr($num,0,6);
                // 出生年月（6位）
                $dateNum = substr($num,6,6);
                // 性别（3位）
                $sexNum = substr($num,12,3);
            }else{
                // 如果是18位身份证号
                // 省市县（6位）
                $areaNum = substr($num,0,6);
                // 出生年月（8位）
                $dateNum = substr($num,6,8);
                // 性别（3位）
                $sexNum = substr($num,14,3);
                // 校验码（1位）
                $endNum = substr($num,17,1);
            }
        }else{
            // 不是数值
            if(strlen($num) == 15){
                throw new PPosException("身份证号无效", 4000500000);
                return false;
            }else{
                // 验证前17位为数值，且18位为字符x
                $check17 = substr($num,0,17);
                if(!is_numeric($check17)){
                    throw new PPosException("身份证号无效", 4000500000);
                    return false;
                }
                // 省市县（6位）
                $areaNum = substr($num,0,6);
                // 出生年月（8位）
                $dateNum = substr($num,6,8);
                // 性别（3位）
                $sexNum = substr($num,14,3);
                // 校验码（1位）
                $endNum = substr($num,17,1);
                if($endNum != 'x' && $endNum != 'X'){
                    throw new PPosException("身份证号无效", 4000500000);
                    return false;
                }
            }
        }
        if(isset($areaNum)){
            if(!$this ->checkArea($areaNum)){
                throw new PPosException("身份证地区无效", 4000500000);
                return false;
            }
        }

        if(isset($dateNum)){
            if(!$this ->checkDate($dateNum)){
                throw new PPosException("出生日期错误", 4000500000);
                return false;
            }
        }

        // 性别1为男，2为女
        if($checkSex == 1){
            if(isset($sexNum)){
                if(!$this ->checkSex($sexNum)){
                    throw new PPosException("性别错误", 4000500000);
                    return false;
                }
            }
        }else if($checkSex == 2){
            if(isset($sexNum)){
                if($this ->checkSex($sexNum)){
                    throw new PPosException("性别错误", 4000500000);
                    return false;
                }
            }
        }

        if(isset($endNum)){
            if(!$this ->checkEnd($num)){
                throw new PPosException("身份证号校验错误", 4000500000);
                return false;
            }
        }
        return true;
    }

    public function getAge($num,int $now_data){
        $date = substr($num, 6, 8);
        $y =  substr($date, 0, 4);
        $ny =  intval(floor($now_data/10000));
        if ($ny<$y){
            return 0;
        }
        $age = $ny - $y;
        if(intval(substr($date, 4, 4)) <= ($now_data%10000)){
            $age -= 1;
        }
        return $age;
    }
    // 验证城市
    private function checkArea($area){
        //$area = Gb2260::mode()->getArea($area);
        if($area){
            return true;
        }else{
            return false;
        }
        //============
        // 对市 区进行验证
        //============
    }

    // 验证出生日期
    private function checkDate($date){
        if(strlen($date) == 6){
            $date1 = substr($date,0,2);
            $date2 = substr($date,2,2);
            $date3 = substr($date,4,2);
            $statusY = $this ->checkY('19'.$date1);
        }else{
            $date1 = substr($date,0,4);
            $date2 = substr($date,4,2);
            $date3 = substr($date,6,2);
            $nowY = date("Y",time());
            if(1900 < $date1 && $date1 <= $nowY){
                $statusY = $this ->checkY($date1);
            }else{
                return false;
            }
        }
        if(0<$date2 && $date2 <13){
            if($date2 == 2){
                // 润年
                if($statusY){
                    if(0 < $date3 && $date3 <= 29){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    // 平年
                    if(0 < $date3 && $date3 <= 28){
                        return true;
                    }else{
                        return false;
                    }
                }
            }else{
                $maxDateNum = $this ->getDateNum($date2);
                if(0<$date3 && $date3 <=$maxDateNum){
                    return true;
                }else{
                    return false;
                }
            }
        }else{
            return false;
        }
    }

    // 验证性别
    private function checkSex($sex){
        if($sex % 2 == 0){
            return false;
        }else{
            return true;
        }
    }

    // 验证18位身份证最后一位
    private function checkEnd($idcard){
        $idcard = strtoupper($idcard); # 如果是小写x,转化为大写X
        if(strlen($idcard) != 18 && strlen($idcard) != 15){
            return false;
        }
        # 如果是15位身份证，则转化为18位
        if(strlen($idcard) == 15){
            # 如果身份证顺序码是996 997 998 999，这些是为百岁以上老人的特殊编码
            if (array_search(substr($idcard, 12, 3), array('996', '997', '998', '999')) !== false) {
                $idcard = substr($idcard, 0, 6) . '18' . substr($idcard, 6, 9);
            } else {
                $idcard = substr($idcard, 0, 6) . '19' . substr($idcard, 6, 9);
            }
            # 加权因子
            $factor = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
            # 校验码对应值
            $code = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
            $checksum = 0;
            for ($i = 0; $i < strlen($idcard); $i++) {
                $checksum += substr($idcard, $i, 1) * $factor[$i];
            }
            $idcard = $idcard . $code[$checksum % 11];
        }
        # 验证身份证开始
        $IDCardBody = substr($idcard, 0, 17); # 身份证主体
        $IDCardCode = strtoupper(substr($idcard, 17, 1)); # 身份证最后一位的验证码

        # 加权因子
        $factor = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
        # 校验码对应值
        $code = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
        $checksum = 0;
        for ($i = 0; $i < strlen($IDCardBody); $i++) {
            $checksum += substr($IDCardBody, $i, 1) * $factor[$i];
        }
        $validateIdcard = $code[$checksum % 11];    # 判断身份证是否合理
        if($validateIdcard != $IDCardCode){
            return false;
        }else{
            return true;
        }
    }

    // 验证平年润年，参数年份,返回 true为润年  false为平年
    private function checkY($Y){
        if(getType($Y) == 'string'){
            $Y = (int)$Y;
        }
        if($Y % 100 == 0){
            if($Y % 400 == 0){
                return true;
            }else{
                return false;
            }
        }else if($Y % 4 ==  0){
            return true;
        }else{
            return false;
        }
    }

    // 当月天数 参数月份（不包括2月）  返回天数
    private function getDateNum($month){
        if($month == 1 || $month == 3 || $month == 5 || $month == 7 || $month == 8 || $month == 10 || $month == 12){
            return 31;
        }else if($month == 2){
        }else{
            return 30;
        }
    }

}
<?php

namespace PPOSLib\DB\Orm;

use PPOSLib\DB\Base\Plan as SrcDb;
use PPOSLib\Helpers\ServiceData;
use Swoole\Coroutine;


class Plan extends OrmBase
{

    public function __construct()
    {
        $this->dbBaseObj = new SrcDb();
    }

    public function get($search=[],$select=[]){
        return $this->dbBaseObj->getOne($search,$select);
    }

    public function getCount($search=[]){
        return $this->dbBaseObj->getCount($search);
    }

    public function getList($start,$size,array $search = [],array $select =[],array $orderBy =["id"=>"desc"]){

        return $this->dbBaseObj->getList($start, $size, $search,$select,$orderBy);
    }

    public function getAll(array $search = [], array $select = [], array $orderBy = ["id" => "desc"]): array
    {
        return $this->dbBaseObj->getAll($search, $select, $orderBy);
    }

    public function createOne($data){
        return $this->dbBaseObj->createOne($data);
    }

    public function update($search,$data){
        $res =  $this->dbBaseObj->update($search,$data);
        //Coroutine::sleep(2);
        return $res;

    }

    public function del($search){
        return $this->dbBaseObj->del($search);
    }

    //导入检验
    public function importVerification($data, $info, $psaInfo, $tagInfo)
    {
        $levelMap = ["省级"=>1,"州市级"=>2,"区县及以下"=>3,"国家级"=>4,"跨省赛事活动"=>5];
        $levelArr = array_keys($levelMap);
        $levelStr = implode(',', $levelArr);
        $isCommunitySportArr = ["是","否"];
        $isCommunitySportStr = implode(',', $isCommunitySportArr);
        $rs = [];
        foreach ($data as $k => $d) {
            $rs[$k] = $d;
            $rs[$k]["status"] = "success";
            $rs[$k]["message"] = "核验成功";
            if (!isset($psaInfo[$d['province']])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行归属区域(省)非法值";
                continue;
            }
            if (!isset($psaInfo[$d['city']])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行归属区域(州市)非法值";
                continue;
            }
            if (!isset($psaInfo[$d['county']])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行归属区域(区县)非法值";
                continue;
            }
            //验证账号归属区域和导入填写的区域
            if($info['jwt_company_area_id'] !=0 ){
                //省份
                if(strlen($info['jwt_company_area_id']) == 2) {
                    if ( $psaInfo[$d['province']] != $info['jwt_company_area_id']){
                        $rs[$k]["status"] = "fail";
                        $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行归属区域与当前账号区域不符";
                        continue;
                    }
                }
                if(strlen($info['jwt_company_area_id']) == 4) {
                    if ( $psaInfo[$d['city']] != $info['jwt_company_area_id']){
                        $rs[$k]["status"] = "fail";
                        $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行归属区域与当前账号区域不符";
                        continue;
                    }
                }
                if(strlen($info['jwt_company_area_id']) == 6) {
                    if ( $psaInfo[$d['county']] != $info['jwt_company_area_id']){
                        $rs[$k]["status"] = "fail";
                        $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行归属区域与当前账号区域不符";
                        continue;
                    }
                }
            }
            if (empty($d['name'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行赛事活动计划名称不能为空";
                continue;
            }
            if (empty($d['year'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行举办年份不能为空";
                continue;
            }
            if (empty($d['about_join_num'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行预计参加人数不能为空";
                continue;
            }
            if (empty($d['about_match_num'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行预计比赛场次不能为空";
                continue;
            }
            if (empty($d['first_hold_name'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行主办单位不能为空";
                continue;
            }
            if (empty($d['is_community_sport'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行是否属于社区运动会不能为空";
                continue;
            }
            if(isset($d['area_level'])  && !in_array($d['area_level'],$levelArr)){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第".$d["ID"]."行等级只能是:".$levelStr;
                continue;
            }
            if(isset($d['is_community_sport'])  && !in_array($d['is_community_sport'],$isCommunitySportArr)){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第".$d["ID"]."行是否属于社区运动会只能是:".$isCommunitySportStr;
                continue;
            }
            $notFindTagArr = [];
            if (isset($d['type_tag_ids'])){
                $tagArr = explode(",",$d['type_tag_ids']);
                foreach ($tagArr as $tag){
                    if(!isset($tagInfo[$tag])){
                        $notFindTagArr[] = $tag;
                    }
                }
            }
            if (empty($d['type_tag_ids'])){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行项目分类不能为空";
                continue;
            }
            if(count($notFindTagArr) > 0){
                $notFindTagStr = implode(',', $notFindTagArr);
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "核验失败！失败原因：第" . $d["ID"] . "行项目分类不存在:".$notFindTagStr;
                continue;
            }
        }
        $log = $rs;
        // 记录日志
        $import = [];
        $param = [];
        $param['company_id'] = $info['company_id'] ?? 0;
        $param['business_id'] = $info['business_id'] ?? 0;
        $param['stadium_id'] = $info['stadium_id'] ?? 0;
        $param['verification_id'] = $info['import_id'] ?? 0;
        $param['verification_type'] = $info['import_type'] ?? 0;
        $param['operator'] = $info['operator'] ?? 0;
        foreach ($rs as $v){
            $param['verification_line'] = $v['ID'];
            $param['verification_result'] = $v['message'];
            $param['verification_status'] = $v['status'] == 'success' ? 1 : 2;
            $import[] = $param;
        }
        $s = new ServiceData();
        $s->dataVerificationLogAdd($import);
        unset($rs);
        $count = array_column($log,"status");
        $count = array_count_values($count);
        $rs["success"] = isset($count["success"])?$count["success"]:0;
        $rs["fail"] = isset($count["fail"])?$count["fail"]:0;
        $rs["result"] = "共尝试导入".count($data)."条数据，成功".$rs["success"]."条，失败".$rs["fail"]."条！";
        $rs["list"] =$log;
        return $rs;
    }


    /** 导入
     * @param array $data
     * @param array $info
     * @param array $psaInfo 省市区
     * @param array $psaLatLng 省市区经纬度
     * @param array $tagInfo 项目ids
     * @return mixed
     * @throws \PPOSLib\Exception\PPosException
     */
    public function import($data, $info,$psaInfo,$psaLatLng,$tagInfo)
    {
        $isCommunitySportMap = ["是"=>1,"否"=>2];
        $levelMap = ["省级"=>1,"州市级"=>2,"区县及以下"=>3,"国家级"=>4,"跨省赛事活动"=>5];
        $levelArr = array_keys($levelMap);
        $levelStr = implode(',', $levelArr);
        $isCommunitySportArr = array_keys($isCommunitySportMap);
        $isCommunitySportStr = implode(',', $isCommunitySportArr);
        $mode = new SrcDb();
        $rs = [];
        foreach ($data as $k => $d) {
            $rs[$k] = $d;
            $rs[$k]["status"] = "success";
            $rs[$k]["message"] = "导入成功";
            if (!isset($psaInfo[$d['province']])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行归属区域(省)非法值";
                continue;
            }
            if (!isset($psaInfo[$d['city']])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行归属区域(州市)非法值";
                continue;
            }
            if (!isset($psaInfo[$d['county']])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行归属区域(区县)非法值";
                continue;
            }
            if (empty($d['name'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行赛事活动计划名称不能为空";
                continue;
            }
            if (empty($d['year'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行举办年份不能为空";
                continue;
            }
            if (empty($d['about_join_num'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行预计参加人数不能为空";
                continue;
            }
            if (empty($d['about_match_num'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行预计比赛场次不能为空";
                continue;
            }
            if (empty($d['first_hold_name'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行主办单位不能为空";
                continue;
            }
            if (empty($d['is_community_sport'])) {
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行是否属于社区运动会不能为空";
                continue;
            }
            if(isset($d['area_level'])  && !in_array($d['area_level'],$levelArr)){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第".$d["ID"]."行等级只能是:".$levelStr;
                continue;
            }
            if(isset($d['is_community_sport'])  && !in_array($d['is_community_sport'],$isCommunitySportArr)){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第".$d["ID"]."行是否属于社区运动会只能是:".$isCommunitySportStr;
                continue;
            }
            $tagIds=[];
            $notFindTagArr = [];
            if (isset($d['type_tag_ids'])){
                $tagArr = explode(",",$d['type_tag_ids']);
                foreach ($tagArr as $tag){
                    if(isset($tagInfo[$tag])){
                        $tagIds[] = $tagInfo[$tag];
                    }else{
                        $notFindTagArr[] = $tag;
                    }
                }
            }
            if (empty($d['type_tag_ids'])){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行项目分类不能为空";
                continue;
            }
            if(count($notFindTagArr) > 0){
                $notFindTagStr = implode(',', $notFindTagArr);
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第" . $d["ID"] . "行项目分类不存在:".$notFindTagStr;
                continue;
            }

            if(isset($d['plan_start_time'])){
                $dateTime = $d['plan_start_time'];
                $dateTime = str_replace("年","-",$dateTime);
                $dateTime = str_replace("月","-",$dateTime);
                $dateTime = str_replace("日","",$dateTime);
                $dateTime = str_replace("/","-",$dateTime);
                $d['plan_start_time'] = $dateTime;
            }
            if(isset($d['plan_end_time'])){
                $dateTime = $d['plan_end_time'];
                $dateTime = str_replace("年","-",$dateTime);
                $dateTime = str_replace("月","-",$dateTime);
                $dateTime = str_replace("日","",$dateTime);
                $dateTime = str_replace("/","-",$dateTime);
                $d['plan_end_time'] = $dateTime;
            }
            if($d['plan_start_time'] == ""){
                $d['plan_start_time'] = 0;
            }else{
                $d['plan_start_time'] = strtotime($d['plan_start_time']);
            }
            if($d['plan_end_time'] == ""){
                $d['plan_end_time'] = 0;
            }else{
                $d['plan_end_time'] = strtotime($d['plan_end_time']);
            }
            $params = $info;
            $params['province'] = isset($d['province']) ? $psaInfo[$d['province']] : 0;
            $params['city'] = isset($d['city']) ? $psaInfo[$d['city']] : 0;
            $params['county'] = isset($d['county']) ? $psaInfo[$d['county']] : 0;
            if(!empty($params['county'])){
                $params['lat'] = $psaLatLng[$params['county']]["lat"];
                $params['lng'] = $psaLatLng[$params['county']]["lng"];
            }
            $params['name'] = isset($d['name']) ? $d['name'] : "";
            $params['year'] = isset($d['year']) ? $d['year'] : "";
            $params['about_join_num'] = isset($d['about_join_num']) ? $d['about_join_num'] : 0;
            $params['about_match_num'] = isset($d['about_match_num']) ? $d['about_match_num'] : 0;
            $params['area_level'] = $levelMap[$d['area_level']]?? 0;
            $params['type_tag_ids'] = isset($d['type_tag_ids']) ? implode(",",$tagIds) : 0;
            $params['plan_start_time'] = $d['plan_start_time'];
            $params['plan_end_time'] = $d['plan_end_time'];
            $params['first_hold_name'] = isset($d['first_hold_name']) ? $d['first_hold_name'] : "";
            $params['is_community_sport'] = $isCommunitySportMap[$d['is_community_sport']]??0;
            $params['organ_unit_id'] = isset($info['jwt_organ_unit_id']) ? $info['jwt_organ_unit_id'] : 0;
            $params['organ_unit_company_area_id'] = isset($info['jwt_company_area_id']) ? $info['jwt_company_area_id'] : 0;
            $params['status'] = 0;
            $new_mode = $mode->createOne($params);
            if(!$new_mode){
                $rs[$k]["status"] = "fail";
                $rs[$k]["message"] = "导入失败！失败原因：第".$d["ID"]."行新增赛事计划失败";
                continue;
            }
        }
        $log = $rs;
        // 记录日志
        $import = [];
        $param = [];
        $param['company_id'] = $info['company_id'] ?? 0;
        $param['business_id'] = $info['business_id'] ?? 0;
        $param['stadium_id'] = $info['stadium_id'] ?? 0;
        $param['import_id'] = $info['import_id'] ?? 0;
        $param['import_type'] = $info['import_type'] ?? 0;
        $param['operator'] = $info['operator'] ?? 0;
        foreach ($rs as $v){
            $param['import_line'] = $v['ID'];
            $param['import_result'] = $v['message'];
            $param['import_status'] = $v['status'] == 'success' ? 1 : 2;
            $import[] = $param;
        }
        $s = new ServiceData();
        $s->dataImportLogAdd($import);
        unset($rs);
        $count = array_column($log,"status");
        $count = array_count_values($count);
        $rs["success"] = isset($count["success"])?$count["success"]:0;
        $rs["fail"] = isset($count["fail"])?$count["fail"]:0;
        $rs["result"] = "本次共导入".count($data)."条数据，成功".$rs["success"]."条，失败".$rs["fail"]."条！";
        $rs["list"] =$log;
        return $rs;
    }
}

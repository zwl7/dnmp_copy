<?php

namespace PPOSLib\DB\Base;

use PPOSLib\Helpers\Functions;
use PPOSLib\Exception\PPosException;
use Ppospro\PAGE\Utils\Dbdriver\ParseQuery;

class Plan extends BaseMode
{

    protected $_table = "plan";

    protected $_fillable = [
        "plan_id",    //表id
        "company_id",    //公司id
        "operator",    //操作人id
        "organ_unit_id",    //机构单位id
        "name",    //赛事名称
        "first_hold_name",    //第一主办单位
        "notes",    //备注
        "type_tag_ids",    //标签id
        "is_community_sport",    //是否属于社区运动会
        "year",    //赛事年份
        "province",    //省
        "city",    //市
        "county",    //区县
        "status",    //状态：1草稿，2审核中，3通过，4驳回,5:自动通过
        "review_id",    //关联审核id
        "reviewer_id",    //当前审核人
        "over_reviewer_list",    //已审核人列表

        "sync_check_status",    //同步审核状态：1待审核，2审核通过，3驳回
        "sync_review_id",    //关联审核id
        "sync_reviewer_id",    //当前审核人
        "sync_over_reviewer_list",    //已审核人列表

        "area_level",    //赛事等级:1省级，2市级，3县级
        "about_match_num",    //预计比赛场次
        "about_join_num",    //预计参加人数
        "plan_start_time",    //计划开始时间
        "plan_end_time",    //计划结束时间
        "activity_start_time",    //比赛开始时间
        "activity_end_time",    //比赛结束时间
        "is_del",
    ];

    public function getList($start, $size, array $search = [], array $select = [], array $orderBy = ["id" => "desc"])
    {
        $db    = $this->db();
        $query = $db->createQuery();
        $query = $this->getSrcSearch($query, $search);
        foreach ($orderBy as $k => $v) {
            if ($v == 'desc') {
                $query->setDesc($k);
            } else {
                $query->setAsc($k);
            }
        }
        //
        if ($select) {
            $query->setQueryFileds($select);
        }
        $data = $query->setQueryLimit($size, $start)->findAll($this->getTableName());
        return $data;
    }

    public function getAll(array $search = [], array $select = [], array $orderBy = ["id" => "desc"])
    {
        $db    = $this->db();
        $query = $db->createQuery();
        $query = $this->getSrcSearch($query, $search);
        foreach ($orderBy as $k => $v) {
            if ($v == 'desc') {
                $query->setDesc($k);
            } else {
                $query->setAsc($k);
            }
        }
        //
        if ($select) {
            $query->setQueryFileds($select);
        }
        $data = $query->findAll($this->getTableName());
        return $data;
    }


    public function getCount(array $search = [])
    {
        $db    = $this->db();
        $query = $db->createQuery();

        $query = $this->getSrcSearch($query, $search);
        $data  = $query->findCount($this->getTableName());
        return $data;
    }


    public function getOne($search = [], array $select = [])
    {
        $db    = $this->db();
        $query = $db->createQuery();

        $query = $this->getSrcSearch($query, $search);
        if ($select) {
            $query->setQueryFileds($select);
        }
        $data = $query->findOne($this->getTableName());
        return $data;
    }


    public function update(array $search, array $data)
    {
        $db    = $this->db();
        $query = $db->createWriter();
        $query = $this->getSrcSearch($query, $search);
        foreach ($data as $k => $v) {
            if (in_array($k, $this->_fillable)) {
                $query->setUpdate($k, $v);
            }
        }

        if (!$query->getQueryCondition()) {
            throw new PPosException("更新条件不能为空", 40105);
        }
        $rs = $query->update($this->getTableName());

        //更新索引
        //$data 如果改了索引字段的话，需要重建索引。如果没有，不需要修改索引
        $data_key = array_keys($data);
        if (array_intersect($data_key,array_keys($this->_es_field))) {
            //有交集，说明需要重建索引
            $this->esIndex($search,'update');
        }

        return $rs;
    }


    public function del(array $search)
    {

        $db    = $this->db();
        $query = $db->createWriter();
        $query = $this->getSrcSearch($query, $search);

        if (!$query->getQueryCondition()) {
            throw new PPosException("删除条件不能为空", 40105);
        }
        $rs = $query->remove($this->getTableName());
        return $rs;
    }


    public function createOne($data)
    {


        $data["plan_id"] = Functions::mode()->getAddID($this->_dbName . "_" . $this->_table);
        $db              = $this->db();
        $query           = $db->createWriter();
        foreach ($data as $k => $v) {
            if (in_array($k, $this->_fillable)) {

                $query->addNew($k, $v);
            }
        }
        $rs = $query->insert($this->getTableName());


        //
        $this->esIndex(['plan_id'=>$data["plan_id"]],'add');

        return $rs ? $data : $rs;
    }

    public function creates($data)
    {
        $db    = $this->db();
        $list  = [];
        $count = count($data);
        $u_ids = Functions::mode()->getAddID($this->_dbName . "_" . $this->_table, $count);
        if ($count == 1) {
            $u_ids = [$u_ids];
        }
        $i = 0;
        foreach ($data as $d) {
            $query = $db->createWriter();
            $query->addNew("plan_id", $u_ids[$i]);
            foreach ($d as $k => $v) {
                if (in_array($k, $this->_fillable)) {
                    $query->addNew($k, $v);
                }
            }
            $list[] = $query;
            $i++;
        }
        $rs = $db->batchInsert($this->getTableName(), $list);
        return $rs ? $u_ids : $rs;
    }

    public function getSrcSearch(ParseQuery $query, array $search): ParseQuery
    {

        //只查询未删除的
        if (isset($search["is_del"]) && !empty($search["is_del"])) {
            $query->setAnd("is_del", $search["is_del"]);
        }
        if (isset($search["status"]) && !empty($search["status"])) {
            $query->setAnd("status", $search["status"]);
        }

        if (isset($search["province"]) && !empty($search["province"])) {
            $query->setAnd("province", $search["province"]);
        }
        if (isset($search["city"]) && !empty($search["city"])) {
            $query->setAnd("city", $search["city"]);
        }
        if (isset($search["county"]) && !empty($search["county"])) {
            $query->setAnd("county", $search["county"]);
        }

        if (isset($search["sync_check_status"]) && !empty($search["sync_check_status"])) {
            $query->setAnd("sync_check_status", $search["sync_check_status"]);
        }

        if (isset($search["statuss"]) && !empty($search["statuss"])) {
            $query->setIn("status", $search["statuss"]);
        }

        if (isset($search["sync_check_statuss"]) && !empty($search["sync_check_statuss"])) {
            $query->setIn("sync_check_status", $search["sync_check_statuss"]);
        }

        if (isset($search["status_gte"]) && !empty($search["status_gte"])) {
            $query->setAnd("status", $search["status_gte"], ParseQuery::TAG_GTE);
        }

        if (isset($search["lte_plan_start_time"]) && !empty($search["lte_plan_start_time"])) {
            $query->setAnd("plan_start_time", $search["lte_plan_start_time"],ParseQuery::TAG_LTE);
        }
        if (isset($search["gte_plan_start_time"]) && !empty($search["gte_plan_start_time"])) {
            $query->setAnd("plan_start_time", $search["gte_plan_start_time"],ParseQuery::TAG_GTE);
        }

        if (isset($search["like_organ_unit_company_area_id"]) && !empty($search["like_organ_unit_company_area_id"])) {
            $query->setAnd("organ_unit_company_area_id", $search["like_organ_unit_company_area_id"] . "%", ParseQuery::TAG_LIKE);
        }

        if (isset($search["plan_id"]) && !empty($search["plan_id"])) {
            $query->setAnd("plan_id", $search["plan_id"]);
        }
        if (isset($search["year"]) && !empty($search["year"])) {
            $query->setAnd("year", $search["year"]);
        }
        if (isset($search["plan_ids"]) && !empty($search["plan_ids"])) {
            $query->setIn("plan_id", $search["plan_ids"]);
        }
        if (isset($search["keyword"]) && !empty($search["keyword"])) {
            $query->setQueryLike("name", "%{$search["keyword"]}%");
        }
        return $query;
    }

    protected $_esDoc = 'zw_event_plan';

    protected $_es_field = array(
        'plan_id'            => ['type' => 'integer'],
        'company_id'         => ['type' => 'integer'],
        'organ_unit_id'      => ['type' => 'integer'],
        'operator'           => ['type' => 'integer'],
        'name'               => ['type' => 'text', "analyzer" => "ik_max_word"],
        'area_level'         => ['type' => 'byte'],
        'type_tag_ids'       => ['type' => 'text', "analyzer" => "whitespace"],
        'is_community_sport' => ['type' => 'byte'],
        'is_del'             => ['type' => 'byte'],
        'year'               => ['type' => 'short'],
        'province'           => ['type' => 'integer'],
        'city'               => ['type' => 'integer'],
        'county'             => ['type' => 'integer'],

        'plan_start_time'    => ['type' => 'integer'],
        'plan_end_time'      => ['type' => 'integer'],

        'activity_start_time'    => ['type' => 'integer'],
        'activity_end_time'      => ['type' => 'integer'],
        'about_match_num'      => ['type' => 'integer'],
        'about_join_num'      => ['type' => 'integer'],

        'status'             => ['type' => 'byte'],
        'review_id'      => ['type' => 'integer'],
        'reviewer_id'      => ['type' => 'integer'],
        'over_reviewer_list'      => ['type' => 'text', "analyzer" => "whitespace"],

        'sync_check_status'      => ['type' => 'byte'],
        'sync_review_id'      => ['type' => 'integer'],
        'sync_reviewer_id'      => ['type' => 'integer'],
        'sync_over_reviewer_list'      => ['type' => 'text', "analyzer" => "whitespace"],
    );

    public function getESQuery(array $search): array
    {
        $query=[];
        if (isset($search["organ_unit_company_area_id"]) && !empty($search["organ_unit_company_area_id"])){
            $query['bool']['filter'][] = array('term'=>['organ_unit_company_area_id'=>$search["organ_unit_company_area_id"]]);
        }

        if (isset($search["plan_id"]) && !empty($search["plan_id"])){
            $query['bool']['filter'][] = array('term'=>['plan_id'=>$search["plan_id"]]);
        }

        if (isset($search["province"]) && !empty($search["province"])){
            $query['bool']['filter'][] = array('term'=>['province'=>$search["province"]]);
        }
        if (isset($search["city"]) && !empty($search["city"])){
            $query['bool']['filter'][] = array('term'=>['city'=>$search["city"]]);
        }
        if (isset($search["county"]) && !empty($search["county"])){
            $query['bool']['filter'][] = array('term'=>['county'=>$search["county"]]);
        }
        if (isset($search["over_reviewer_list"]) && !empty($search["over_reviewer_list"])){
            $block['bool']['should'][] = array('match'=>['over_reviewer_list'=>$search["over_reviewer_list"]]);
            $block['bool']['should'][] = array('term'=>['reviewer_id'=>$search["over_reviewer_list"]]);
            $block['bool']['should'][] = array('term'=>['organ_unit_id'=>$search["over_reviewer_list"]]);
            $query['bool']['filter'][] = $block;
        }
        if (isset($search["reviewer_id"]) && !empty($search["reviewer_id"])){
            $query['bool']['filter'][] = array('term'=>['reviewer_id'=>$search["reviewer_id"]]);
        }
        if (isset($search["sync_reviewer_id"]) && !empty($search["sync_reviewer_id"])){
            $query['bool']['filter'][] = array('terms'=>['sync_check_status'=>[2,4]]);
            $block['bool']['should'][] = array('match'=>['sync_over_reviewer_list'=>$search["sync_reviewer_id"]]);
            $block['bool']['should'][] = array('term'=>['sync_reviewer_id'=>$search["sync_reviewer_id"]]);
            $query['bool']['filter'][] = $block;
        }
        if (isset($search["plan_ids"]) && !empty($search["plan_ids"])){
            $query['bool']['filter'][] = array('terms'=>['plan_id'=>$search["plan_ids"]]);
        }
        if (isset($search["organ_unit_id"]) && !empty($search["organ_unit_id"])){
            $query['bool']['filter'][] = array('term'=>['organ_unit_id'=>$search["organ_unit_id"]]);
        }

        if (isset($search["operator"]) && !empty($search["operator"])){
            $query['bool']['filter'][] = array('term'=>['operator'=>$search["operator"]]);
        }

        if (isset($search["organ_unit_ids"]) && !empty($search["organ_unit_ids"])){
            $query['bool']['filter'][] = array('terms'=>['organ_unit_id'=>$search["organ_unit_ids"]]);
        }
        if (isset($search["keyword"]) && !empty($search["keyword"])){
            $query['bool']['must'][] = array('match'=>['name'=>$search["keyword"]]);
        }
        if (isset($search["area_level"]) && $search["area_level"]){
            $query['bool']['filter'][] = array('term'=>['area_level'=>$search["area_level"]]);
        }

        //
        if (isset($search["type_tag_id"]) && !empty($search["type_tag_id"])){
            $query['bool']['filter'][] = array('match'=>['type_tag_ids'=>$search["type_tag_id"]]);
        }
        if (isset($search["type_tag_ids"]) && !empty($search["type_tag_ids"])) {
            $query['bool']['filter'][] = array('match' => ['type_tag_ids' => str_replace(",", " ", $search["type_tag_ids"])]);
        }
        if (isset($search["type_tag_ids_and"]) && !empty($search["type_tag_ids_and"])) {
            $query['bool']['filter'][] = array('match_phrase' => ['type_tag_ids' =>str_replace(",", " ", $search["type_tag_ids_and"])]);
        }
        if (isset($search["is_community_sport"]) && $search["is_community_sport"]){
            $query['bool']['filter'][] = array('term'=>['is_community_sport'=>$search["is_community_sport"]]);
        }

        if (isset($search["status"])){
            $query['bool']['filter'][] = array('term'=>['status'=>$search["status"]]);
        }

        //
        if (isset($search["status_in"]) && $search["status_in"]){
            $query['bool']['filter'][] = array('terms'=>['status'=>$search["status_in"]]);
        }
        //
        if (isset($search["statuss"]) && $search["statuss"]){
            $query['bool']['filter'][] = array('terms'=>['status'=>$search["statuss"]]);
        }

        if (isset($search["year"]) && $search["year"]){
            $query['bool']['filter'][] = array('term'=>['year'=>$search["year"]]);
        }

        if (isset($search["bet_plan_start_time"]) && !empty($search["bet_plan_start_time"])){
            $query['bool']['filter'][] = array('range'=>['plan_start_time'=>['gte'=>$search["bet_plan_start_time"][0],'lte'=>$search["bet_plan_start_time"][1]]]);
        }
        if (isset($search["gte_plan_start_time"])){
            $query['bool']['filter'][] = array('range'=>['plan_start_time'=>['gte'=>$search["gte_plan_start_time"]]]);
        }
        if (isset($search["lte_plan_start_time"])){
            $query['bool']['filter'][] = array('range'=>['plan_start_time'=>['lte'=>$search["lte_plan_start_time"]]]);
        }
        if (isset($search["bet_plan_end_time"])){
            $query['bool']['filter'][] = array('range'=>['plan_end_time'=>['gte'=>$search["bet_plan_end_time"][0],'lte'=>$search["bet_plan_end_time"][1]]]);
        }
        if (isset($search["gte_plan_end_time"])){
            $query['bool']['filter'][] = array('range'=>['plan_end_time'=>['gte'=>$search["gte_plan_end_time"]]]);
        }
        if (isset($search["lte_plan_end_time"])){
            $query['bool']['filter'][] = array('range'=>['plan_end_time'=>['lte'=>$search["lte_plan_end_time"]]]);
        }

        if (isset($search["gte_activity_end_time"])){
            $query['bool']['filter'][] = array('range'=>['activity_end_time'=>['gte'=>$search["gte_activity_end_time"]]]);
        }
        if (isset($search["lte_activity_end_time"])){
            $query['bool']['filter'][] = array('range'=>['activity_end_time'=>['lte'=>$search["lte_activity_end_time"]]]);
        }


        if (isset($search["activity_start_time"])){
            $query['bool']['filter'][] = array('term'=>['activity_start_time'=>$search["activity_start_time"]]);
        }

        if (isset($search["gte_activity_start_time"])){
            $query['bool']['filter'][] = array('range'=>['activity_start_time'=>['gte'=>$search["gte_activity_start_time"]]]);
        }
        if (isset($search["lte_activity_start_time"])){
            $query['bool']['filter'][] = array('range'=>['activity_start_time'=>['lte'=>$search["lte_activity_start_time"]]]);
        }

        //
        $query['bool']['filter'][] = array('term'=>['is_del'=>2]);
        return $query;
    }

    public function esIndex(array $search, $action = "update")
    {
        $db     = $this->db();
        $query  = $db->createQuery();
        $query  = $this->getSrcSearch($query, $search);
        $select = array_keys($this->_es_field);
        if ($select) {
            $query->setQueryFileds($select);
        }
        $page = 1;
        $size = 1000;
        while (true) {
            $start = ($page - 1) * $size;
            $data  = $query->setQueryLimit($size, $start)->findAll($this->getTableName());
            if (!$data) {
                return;
            }

            foreach ($data as $d) {

                $d['type_tag_ids'] = str_replace(","," ",$d['type_tag_ids']);
                $d['over_reviewer_list'] = str_replace(","," ",$d['over_reviewer_list']);
                $d['sync_over_reviewer_list'] = str_replace(","," ",$d['sync_over_reviewer_list']);

                if ($action == 'update') {
                    $this->esUpdateDocInfo($d, $d['plan_id']);
                } else {
                    $this->esAddDocInfo($d, $d['plan_id']);
                }
            }
            if ($page > 10000 || count($data) < $size) {
                break;
            }
            $page++;
        }
    }

    public function delIndex(array $plan_ids = [])
    {
        foreach ($plan_ids as $plan_id) {
            $this->esDelDocInfo($plan_id);
        }
    }
}

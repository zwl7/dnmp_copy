<?php

namespace PPOSLib\Helpers;

use PPOSLib\Exception\PPosException;
use Swoole\Exception;

/**
 * Class ServiceData
 * @package PPOSLib\Helpers
 */
class ElasticSearchService
{

    private $host = "https://14.17.80.133:9200/";
    private $authName = "elastic";
    private $authPassword = "Papa#20140924";



    public function __construct()
    {
        $this->host = env('ES_HOST', $this->host);
        $this->authName = env('ES_AUTH_NAME', $this->authName);
        $this->authPassword = env('ES_AUTH_PASSWORD', $this->authPassword);
    }

    public function searchDocByJson(string $doc,array $json){
        return $this->_SwooleHttp($this->host."{$doc}/_search",json_encode($json),"GET");
    }
    /**
     * Notes:文档数据搜索
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 下午3:15
     * @param string $doc
     * @param array $query
     * @param array $select
     * @param int $start
     * @param int $size
     * @param array $sort
     * @return mixed
     */
    public function searchDocInfo(string $doc,array $query ,array $select =array(),int $start = 0,int $size = 10,array $sort=[]){
        if (!empty($select)){
          $body['_source'] = $select;
        }
        if ($size){
            $body['from'] = $start;
            $body['size'] = $size;
        }
        if (empty($query)){
            $query['match_all'] = (object)array();
        }
        $body['query'] = $query;
        if (!empty($sort)){
          $body['sort'] = $sort;
        }
        return $this->_SwooleHttp($this->host."{$doc}/_search",json_encode($body),"GET");
    }
    /**
     * Notes:文档数据删除
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 下午2:02
     * @param string $doc
     * @param int $id
     * @return mixed
     */
    public function delDocInfo(string $doc,int $id){
        return $this->_SwooleHttp($this->host."{$doc}/_doc/{$id}",null,"DELETE");
    }

    /**
     * Notes:文档数据更新
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 下午1:59
     * @param string $doc
     * @param int $id
     * @param array $data
     * @return mixed
     */
    /*public function updateDocInfo(string $doc,int $id, array $data = array()){
        return $this->_SwooleHttp($this->host."{$doc}/_doc/{$id}",json_encode($data),"PUT");
    }*/

    /**
     * Notes:文档数据更新
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 下午1:59
     * @param string $doc
     * @param int $id
     * @param array $data
     * @return mixed
     */
    public function updateDocInfo(string $doc,int $id, array $data = array()){
        return $this->_SwooleHttp($this->host."{$doc}/_update/{$id}",json_encode(['doc'=>$data]),"POST");
    }
    /**
     * Notes:文档添加数据
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 下午1:52
     * @param string $doc
     * @param int $id
     * @param array $data
     * @return mixed
     */
    public function addDocInfo(string $doc,int $id, array $data = array()){
        return $this->_SwooleHttp($this->host."{$doc}/_doc/{$id}",json_encode($data),"PUT");
    }
    /**
     * Notes:查看文档基础信息
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 上午11:55
     * @param string $doc
     * @return mixed
     */
    public function getDocInfo(string $doc=""){
        return $this->_SwooleHttp($this->host.$doc,null,"GET");
    }

    /**
     * Notes:创建文档 无法修改mapping中已有的字段，但是却允许添加新的字段到mapping中
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 上午11:44
     * @param string $doc
     * @param array $field_info
     * $field_info['id']['type']='keyword'; id字段 字符型
     * $field_info['name']=array("type"=>"text","analyzer"=>"ik_max_word"); name字段 字符型 分词规则 ik_max_word
     * $field_info['address']=array("type"=>"keyword","index"=>false);  address字段 字符型 不索引
     * $field_info['price']['type']="integer"; price字段 数值型
     * $field_info['location']['type']="geo_point" location字段 位置型
     * @return mixed
     */
    public function createDoc(string $doc,array $field_info = array()){

        $body['mappings']['properties']=$field_info;
         return $this->_SwooleHttp($this->host.trim($doc,"/"),json_encode($body),"PUT");
    }

    /**
     * Notes:删除索引
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-11-2
     * Time: 上午11:57
     * @param string $doc
     * @return mixed
     */
    public function delDoc(string $doc){
         return $this->_SwooleHttp($this->host.$doc,null,"DELETE");
    }

    protected function _SwooleHttp($url, $body=null,$method = "POST",$heard=[],$timeout=5) {
        $log = "------------ESService-------------" . "\n";
        $log .= "url:" . $url ."  ". $method."\n";
        $log .= "参数:" . var_export($body, true);
        app()->log->info($log);
        $url_info = parse_url($url);
        $scheme = $url_info['scheme']??"http";
        if(!isset($url_info['port'])){
            $port = $scheme=="https"?443:80;
        }else{
            $port = $url_info['port'];
        }
        $host = $url_info['host'];
        $path = $url_info['path'];
        $ssl =  $scheme=="https"?true:false;
        //$host= "api.linksports.com.cn";
        //$port= 9095;
        $client = new \Swoole\Coroutine\Http\Client($host, $port,$ssl);
        $heard['Host']=$host;
        $heard['User-Agent']='PPOSPRO-Service';
        $heard['Content-Type']='application/json';
        $heard['Connection']='Keep-Alive';
        if ($this->authName){
            $heard['Authorization']='Basic '.base64_encode("$this->authName:$this->authPassword");
        }
        $client->setHeaders($heard);
        $client->set(['timeout' => $timeout]);
        $client->setData($body);
        $client->setMethod($method);
        $start_time = microtime(true);
        $client->execute($path);
        $client->close();
        //$response['headers'] = $client->getHeaders();
        $end_time = microtime(true);
        $cat_time = round($end_time - $start_time, 4);
        $log = "耗时:" . $cat_time . "\n";
        $log .= "返回结果({$client->getStatusCode()}):" . $client->getBody();
        app()->log->info($log);
        if (!in_array($client->getStatusCode(),[200,201,404])){
            throw new PPosException("ES错误({$client->getStatusCode()}):".$client->getBody(), 40105);
        }
        $response['body'] = json_decode($client->getBody(),true);
        $response['http_code'] = $client->getStatusCode();
        return $response;
    }

}

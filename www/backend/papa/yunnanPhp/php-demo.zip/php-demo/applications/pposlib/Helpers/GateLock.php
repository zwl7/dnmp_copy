<?php

/**
 *  公共函数库
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-19
 * Time: 下午6:16
 */

namespace PPOSLib\Helpers;

use PPOSLib\Exception\PPosException;

class GateLock
{

    private static $lock_list = array();

    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {

    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    private static function  checkLock($id){
        if(!isset(self::$lock_list[$id])){
            throw new PPosException("Gate锁不存在", 4000010000);
        }
        return true;
    }
    public static function getLock($id){
        return self::$lock_list[$id];
    }
    public static function setLock($id){
        self::$lock_list[$id] = new \Swoole\Lock(SWOOLE_MUTEX);
    }
    public static function getLockStatus(){
        return self::$lock_list;
    }
    public static function Lock($id){
        self::checkLock($id);
        return self::$lock_list[$id]->lock();
    }

    public static function tryLock($id){
        self::checkLock($id);
        return self::$lock_list[$id]->trylock();
    }

    public static function unLock($id){
        if(!isset(self::$lock_list[$id])){
            return true;
        }
        return self::$lock_list[$id]->unLock();
    }
}



<?php

/**
 *  公共函数库
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-19
 * Time: 下午6:16
 */

namespace PPOSLib\Helpers;


class Cache
{
    private static $_mode = null;
    private  $_config = array();

    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {


    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    /**
     * Notes:单例
     * @return $this
     */
    public static function mode()
    {
        if (!self::$_mode) {
            self::$_mode =new self();
        }
        return self::$_mode;
    }

    public function personnel($personnel_ids=[],$time=0){
        $data=[];
        $need_get=[];

        foreach ($personnel_ids as $c){
            $key = "personnel_id_".$c;
            if(!isset($this->_config[$key])){
                $this->_config[$key]["time"] = time();
            }
            $c_time = time() - $this->_config[$key]["time"];
            //隔天也要刷新
            $diff_date = (date("Y-m-d",time()) == date("Y-m-d",$this->_config[$key]["time"]))?false:true;

            if(!isset($this->_config[$key]["data"]) || $c_time > env("APP_CONF_CACHE_TIME",0)||$diff_date){
                $this->_config[$key]["time"] = time();
                $need_get[] = $c;
            }else{
                $data[$c] = $this->_config[$key]["data"];
            }
        }


        if($need_get||$time>0){
            $s = new ServiceData();
            $operators =  $s->operator($need_get,'width_branch');
            if(!$operators){
                return[];
            }
            foreach ($operators as $c){
                $key = "personnel_id_".$c["personnel_id"];
                $this->_config[$key]["data"]= $c;
                $data[$c["personnel_id"]] = $c;
            }
        }
        return $data;
    }

    public function clearCfg($codes=[],$company_id,$business_id=0,$stadium_id=0){
        foreach ($codes as $c){
            $key = $company_id."_".$business_id."_".$stadium_id."_".$c;
            if(isset($this->_config[$key])){
                unset($this->_config[$key]);
            }
        }
        return $this->_config;
    }
}



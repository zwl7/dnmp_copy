<?php

/**
 * @desc		 异常类
 * ---------------------------------------------------------------------
 * @author	unphp <unphp@qq.com>
 * @date		2014-03-05
 * @copyright	UnPHP 1.1
 * ---------------------------------------------------------------------
 */
namespace PPOSLib\Exception;



class PPosException extends \Ppospro\PAGE\Exception\PPosException
{
	private $_log = "";
	public function getLog (){
		return $this->_log;
	}

	public function __construct($message, $code = 0, $log = null, $previous = null)
	{
		$this->_log = $log;
		parent::__construct($message, $code, $previous);
	}

}

<?php
namespace PPOSLib\Helpers;
use PPOSLib\Exception\PPosException;
use Ppospro\PAGE\Helpers\HttpService;

/**
 * Class WarningServiceData
 * @package PPOSLib\Helpers
 */
class WarningServiceData extends HttpService {


	protected $host="";
	protected $app_id=10101;
	protected $app_key="";
	protected $async = false;
    protected $zones = [
        'earlyWarningGet' => '/api/v1/earlyWarning/confGet',
        'earlyWarningSend' => '/api/v1/earlyWarning/send',
    ];

    public function __construct()
    {
        $this->host = env('WARNING_API');
    }

    /**
     * Notes:获取配置
     * User: zouqin
     * Email: zouqin@papa.com.cn
     * Date: 2023-03-24
     * Time: 下午4:58
     * @return array
     * @throws PPosException
     */
    public function earlyWarningGet($code)
    {
        $url = $this->host.$this->zones['earlyWarningGet'];
        $body["code"] = $code;
        return $this->sendRequest($url,"POST",$body);
    }

    /**
     * Notes:发送信息
     * User: zouqin
     * Email: zouqin@papa.com.cn
     * Date: 2023-03-24
     * Time: 下午4:58
     * @return array
     * @throws PPosException
     */
    public function earlyWarningSend($param)
    {
        $url = $this->host.$this->zones['earlyWarningSend'];
        $body["code"] = $param['code'];
        $body["info_json"] = json_encode($param['info_json']);
        return $this->sendRequest($url,"POST",$body);
    }



}

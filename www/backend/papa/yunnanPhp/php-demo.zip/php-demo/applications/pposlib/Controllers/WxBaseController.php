<?php


namespace PPOSLib\Controllers;


class WxBaseController extends BaseController
{

    public function __construct()
    {
        parent::__construct();

        if (isset($this->request_data["city_id"])&&$this->request_data["city_id"]){
            $this->request_data['mim_street_id'] = $this->request_data["city_id"]*100000;
            $this->request_data['max_street_id'] = $this->request_data["city_id"]*100000+99999;
        }
    }

}

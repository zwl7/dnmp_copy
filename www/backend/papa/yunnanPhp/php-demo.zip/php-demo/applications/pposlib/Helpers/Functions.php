<?php

/**
 *  公共函数库
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-19
 * Time: 下午6:16
 */

namespace PPOSLib\Helpers;

use Mix\Validate\Validate;
use PPOSLib\Exception\PPosException;

class Functions extends \Ppospro\PAGE\Helpers\Functions
{

    protected static $_mode = null;
    //手续费比例 万分比
    const HandleScale = 23;
    private $_business_info = array();

    const ACTIVITY_SESSIONS = 'sessions:';

    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {


    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    /**
     * Notes:单例
     * @return $this
     */
    public static function mode()
    {
        if (!self::$_mode)
        {
            self::$_mode = new self();
        }
        return self::$_mode;
    }

    public function BusinessInfo($company_id)
    {
        if (!isset($this->_business_info[$company_id]["time"]))
        {
            $this->_business_info[$company_id]["time"] = time();
        }
        $c_time = time() - $this->_business_info[$company_id]["time"];
        if (!isset($this->_business_info[$company_id]["data"]) || $c_time > 0 * 3600)
        {
            $s = new ServiceData();
            $this->_business_info[$company_id]["data"] = $s->BusinessInfo($company_id);
            $this->_business_info[$company_id]["time"] = time();
        }
        return $this->_business_info[$company_id]["data"];
    }

    public function filterEmoji($str)
    {
        $str = preg_replace_callback('/./u', function (array $match)
        {
            return strlen($match[0]) >= 4 ? '' : $match[0];
        }, $str);
        return $str;
    }

    /**
     *生成订单号
     * @param type int
     * 30：入库
     * 31：调拨
     * 32：出库
     * 33：盘点
     * @return int OrderNo
     */

    public function GetOrderNo($type)
    {
        $date = date("YmdHis", time());
        $date = substr($date, 2);
        $rndString = rand(10000, 99999);
        return $type . $date . $rndString;
    }


    //订单的支付方式（10:现金，20:会员卡支付：60:微信，70:支付宝）
    public function PaymentType($payment_type)
    {
        switch ($payment_type)
        {
            case 10:
                return "现金支付";
                break;
            case 20:
                return "会员卡支付";
                break;
            case 40:
                return "转结支付";
                break;
            case 60:
                return "微信支付";
                break;
            case 70:
                return "支付宝";
                break;
            case 110:
                return "微信支付";
                break;
            default:
                return "未知";
        }
    }

    //凭证类型 1:场地订单 2:门票 3:会员
    public function RuleType($trade_type)
    {
        switch ($trade_type)
        {
            case 1:
                return "场地订单";
                break;
            case 2:
                return "门票";
                break;
            case 3:
                return "会员";
                break;
            case 4:
                return "课程";
                break;
            default:
                return "未知";
        }
    }

    //订单状态（0:待支付，1:已付清，2:取消，3：退款，4:未付清，5：待审核，6：审核通过 7:审核不通过）
    public function GetOrderStatus($status)
    {
        switch ($status)
        {
            case 0:
                return "待支付";
                break;
            case 1:
                return "已付清";
                break;
            case 2:
                return "取消";
                break;
            case 3:
                return "退款";
                break;
            case 4:
                return "未付清";
                break;
            case 5:
                return "待审核";
                break;
            case 6:
                return "审核通过";
                break;
            case 7:
                return "审核不通过";
                break;
            default:
                return "未知";
        }
    }

    //卡状态 0 => "未激活",1 => "正常",2 => "停用",3 => "已挂失",4 => "过期", 5=>"旧卡", 6=>"注销",10=>"待支付",
    public function GetCardStatus($status)
    {
        switch ($status)
        {
            case 0:
                return "未激活";
                break;
            case 1:
                return "正常";
                break;
            case 2:
                return "停用";
                break;
            case 3:
                return "已挂失";
                break;
            case 4:
                return "过期";
                break;
            case 5:
                return "旧卡";
                break;
            case 6:
                return "注销";
                break;
            case 10:
                return "待支付";
                break;
            default:
                return "未知状态:" . $status;
        }
    }

    //普通状态（0:待支付，1:可用，2:不可用)
    public function GetInfoStatus($status)
    {
        switch ($status)
        {
            case 1:
                return "可用";
                break;
            case 2:
                return "不可用";
                break;
            default:
                return "不可用";
        }
    }

    public function TicketStatus($status)
    {
        $status_str = "";
        //门票状态（1：未出票；2：已出票；3：已检票；4：已退票；5：已过期）
        switch ($status)
        {
            case 1:
                $status_str = "未出票";
                break;
            case 2:
                $status_str = "已出票";
                break;
            case 3:
                $status_str = "已检票";
                break;
            case 4:
                $status_str = "已退票";
                break;
            case 5:
                $status_str = "已过期";
                break;
            default:
                $status_str = "未知";
        }
        return $status_str;
    }

    //卡类型（2:金额卡，3:次数卡，4:期限卡)
    public function GetCardType($status)
    {
        switch ($status)
        {
            case 2:
                return "金额卡";
                break;
            case 3:
                return "次数卡";
                break;
            case 4:
                return "期限卡";
                break;
            default:
                return "金额卡";
        }
    }

    //业务类型:1:开卡-一卡通,2:开卡-专项卡,3:充值,4:充值退款,5:延期,6:补卡,7:换卡,8:冻卡,9:解卡,10:密码修改
    public function GetType($status)
    {
        switch ($status)
        {
            case 1:
                return "开卡-一卡通";
                break;
            case 2:
                return "开卡-专项卡";
                break;
            case 3:
                return "充值";
                break;
            case 4:
                return "充值退款";
                break;
            case 5:
                return "延期";
                break;
            case 6:
                return "补卡";
                break;
            case 7:
                return "换卡";
                break;
            case 8:
                return "冻卡";
                break;
            case 9:
                return "解卡";
                break;
            case 10:
                return "密码修改";
                break;
            default:
                return "未知状态:" . $status;
        }
    }

    public function getAddID($name, $count = 1)
    {
        $cooper = new CooperServiceData();
        return $cooper->Uid($name, $count);
    }


    /**
     * 无限极分类
     * @param $arr 数组
     * @param $id   id
     * @param $level  层级
     * @return array
     */

    public function demo($arr, $id, $level)
    {
        $list = array();
        foreach ($arr as $k => $v)
        {
            if ($v['p_cate_id'] == $id)
            {
                $v['levell'] = $level;
                $v['son'] = $this->demo($arr, $v['product_cate_id'], $level + 1);
                $list[] = $v;
            }
        }
        return $list;
    }


    /**
     * 获取商品sku
     */
    public function getGoodsSku($id, $key)
    {
        $sku = "4" . str_pad($id, 10, '0', STR_PAD_LEFT) . str_pad($key, 3, '0', STR_PAD_LEFT);
        return $sku;
    }

    /**
     * 获取商品sku最后一个item
     */
    public function getGoodsItem($skus)
    {
        if (empty($skus))
        {
            return 0;
        }
        foreach ($skus as $k => $v)
        {
            $item[] = substr($v, -1, 3);
        }

        return max($item);
    }


    /**
     * Notes:卡价值转换(前端展示)
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 20-5-16
     * Time: 上午10:35
     * @param $worth int //卡价值
     * @param $type int //卡种类
     * @param $status int //卡状态
     * @param $end_data string //卡到期时间
     * @return float|int|string
     */
    public function GetCardWorth($worth, $type, $status, $end_data, $with_unit = false, $is_pretest_card = false)
    {
        if ($type <= 2)
        {
            $worth = $this->GetPrice($worth);
        } else if ($type == 4)
        {
            $worth = (strtotime($end_data) - strtotime(date("Y-m-d", time()))) / 24 / 3600 + 1;
            $worth = $worth < 0 ? 0 : $worth;
            if ($status == 0 && $is_pretest_card == false)
            {
                $worth = "--";
            }
        }
        if ($with_unit)
        {
            switch ($type)
            {
                case 2:
                    $worth .= '元';
                    break;
                case 3:
                    $worth .= '次';
                    break;
                case 4:
                    $worth .= '天';
                    break;
                default:
                    $worth .= '元';
            }
        }
        return $worth;
    }

    function buildToken($company_id)
    {
        $app_id = 10101;
        $jwt["ct"] = $this->time();
        $jwt["id"] = str_replace(".", "0", microtime(true));
        $jwt["aid"] = $app_id;
        $jwt["mid"] = 5;
        $jwt["tid"] = 2;
        $jwt["params"]["company_id"] = $company_id;
        $jwt["params"]["account_id"] = 10;
        $jwt["params"]["account_type"] = 31;
        $jwt["params"]["personnel_id"] = 10;
        $jwt["params"] = json_encode($jwt["params"]);
        return Jwt::mode()->getToken($jwt);
    }

    /**
     * 反向解析sku，返回场馆、场区、场地、时间段
     * @param type $sku
     * @return type
     */
    public function parseFieldSku($sku)
    {
        $sku = strval($sku);
        $product_id = intval(substr($sku, 2, 14));
        $stadium_id = intval(substr($sku, 2, 5));
        $ground_id = intval(substr($sku, 2, 8));
        $field_id = intval(substr($sku, 2, 11));
        $time_id = substr($sku, 13, 3);
        $date_str = substr($sku, 16, 8);
        return array('product_id' => $product_id, 'stadium_id' => $stadium_id, 'ground_id' => $ground_id, 'field_id' => $field_id, 'time_id' => $time_id, 'date_str' => $date_str,);
    }

    //凭证类型(1:门票入场,2:场地订单入场,3:会员卡门票入场,4:会员卡场地订单入场,5:会员卡买门票入场,
    //6:会员(刷脸)门票入场,7:会员(刷脸)场地订单入场,8:会员(刷脸)买门票入场),9:会员码门票入场,10:会员码场地订单入场,11:会员码买门票入场
    public function GetVoucherType($voucher_type)
    {
        switch ($voucher_type)
        {
            case 1:
                $name = "门票入场";
                break;
            case 2:
                $name = "场地订单入场";
                break;
            case 3:
                $name = "会员卡门票入场";
                break;
            case 4:
                $name = "会员卡场地订单入场";
                break;
            case 5:
                $name = "会员卡买门票入场";
                break;
            case 6:
                $name = "会员(刷脸)门票入场";
                break;
            case 7:
                $name = "会员(刷脸)场地订单入场";
                break;
            case 8:
                $name = "会员(刷脸)买门票入场";
                break;
            case 9:
                $name = "会员码门票入场";
                break;
            case 10:
                $name = "会员码场地订单入场";
                break;
            case 11:
                $name = "会员码买门票入场";
                break;
            case 12:
                $name = "课程签到入场";
                break;
            case 13:
                $name = "会员卡课程签到入场";
                break;
            case 14:
                $name = "会员(刷脸)课程签到入场";
                break;
            case 15:
                $name = "会员码课程签到入场";
                break;
            case 16:
                $name = "管理员卡入场";
                break;
            case 17:
                $name = "管理员(刷脸)入场)";
                break;
            default:
                $name = "";
                break;
        }
        return $name;
    }

    /**
     * 中英混合的字符串截取
     * @param unknown_type $sourcestr
     * @param unknown_type $cutlength
     */
    public function cut_str($sourcestr, $cutlength)
    {
        $returnstr = '';
        $i = 0;
        $n = 0;
        $str_length = strlen($sourcestr); //字符串的字节数
        while (($n < $cutlength) and ($i <= $str_length))
        {
            $temp_str = substr($sourcestr, $i, 1);
            $ascnum = Ord($temp_str); //得到字符串中第$i位字符的ascii码
            if ($ascnum >= 224) //如果ASCII位高与224，
            {
                $returnstr = $returnstr . substr($sourcestr, $i, 3); //根据UTF-8编码规范，将3个连续的字符计为单个字符
                $i = $i + 3; //实际Byte计为3
                $n++; //字串长度计1
            } elseif ($ascnum >= 192) //如果ASCII位高与192，
            {
                $returnstr = $returnstr . substr($sourcestr, $i, 2); //根据UTF-8编码规范，将2个连续的字符计为单个字符
                $i = $i + 2; //实际Byte计为2
                $n++; //字串长度计1
            } elseif ($ascnum >= 65 && $ascnum <= 90) //如果是大写字母，
            {
                $returnstr = $returnstr . substr($sourcestr, $i, 1);
                $i = $i + 1; //实际的Byte数仍计1个
                $n++; //但考虑整体美观，大写字母计成一个高位字符
            } else //其他情况下，包括小写字母和半角标点符号，
            {
                $returnstr = $returnstr . substr($sourcestr, $i, 1);
                $i = $i + 1; //实际的Byte数计1个
                $n = $n + 0.5; //小写字母和半角标点等与半个高位字符宽...
            }
        }
        return $returnstr;
    }

    //数值进制为字符串
    public function numHexStr($num)
    {
        $base = 'nq01Bo45cd67KLghPQyRiNO9abeVYZfjkpCGHlmr2AIJDEU_F3stuwzvWXxM8ST';
        $result = '';
        $size = strlen($base);
        do
        {
            $num = floor($num);
            $result = $base[intval(fmod($num, $size))] . $result;
            $num = $num / $size;
        } while ($num >= 1);
        return $result;
    }

    //字符串进制为数值
    public function strHexNum($code)
    {
        $base = 'nq01Bo45cd67KLghPQyRiNO9abeVYZfjkpCGHlmr2AIJDEU_F3stuwzvWXxM8ST';
        $base = str_split($base);
        $result = 0;
        $size = count($base);
        $atnum = str_split($code); //将字符串分割为单个字符数组
        $atlen = count($atnum);
        $i = 1;
        foreach ($atnum as $tv)
        {
            $bk = array_search($tv, $base);
            if ($bk === false)
            {
                return false;
            }
            if ($bk != 0)
            {
                //$result = bcadd(bcmul($k,bcpow ($size,$atlen-$i,20)),$result);
                $result += $bk * pow($size, $atlen - $i);
            }
            $i++;
        }
        return $result;
    }

    //课时凭证加密
    public function enClassCode($student_id, $class_time_id = 0, $class_id = 0)
    {
        $student_id = rand(1, 9) . sprintf("%09s", $student_id);
        $code = "C" . $this->numHexStr($student_id);
        if ($class_time_id)
        {
            $class_time_id = rand(1, 9) . sprintf("%09s", $class_time_id);
            $code .= "T" . $this->numHexStr($class_time_id);
        }
        if ($class_id && !$class_time_id)
        {
            $class_id = rand(1, 9) . sprintf("%09s", $class_id);
            $code .= "C" . $this->numHexStr($class_id);
        }
        return $code;
    }

    //课时凭证解密
    public function deClassCode($code)
    {
        if (strlen($code) != 14 || substr($code, 0, 1) != "C")
        {
            return false;
        }
        $rs['student_id'] = $this->strHexNum(substr($code, 1, 6));
        $rs['student_id'] = intval(fmod($rs['student_id'], 10000 * 10000));
        $rs['class_id'] = 0;
        $rs['class_time_id'] = 0;
        if (substr($code, 7, 1) == "T")
        {
            $rs['class_time_id'] = $this->strHexNum(substr($code, 8, 6));
            $rs['class_time_id'] = intval(fmod($rs['class_time_id'], 10000 * 10000));
        } else
        {
            $rs['class_id'] = $this->strHexNum(substr($code, 8, 6));
            $rs['class_id'] = intval(fmod($rs['class_id'], 10000 * 10000));
        }
        return $rs;
    }

    //动态码加密
    public function enDynamicCode($code)
    {
        //订单类 O开头21位
        if (strlen($code) == "19" && is_numeric($code))
        {
            $d = $this->numHexStr(rand(10, 99) . date("dH", $this->time()) . substr($code, 0, 4));
            $i = $this->numHexStr(rand(10, 99) . date("is", $this->time()) . substr($code, 4, 4));
            $o = $this->numHexStr(rand(50, 99) . substr($code, 8));
            $code = "O" . $d . $i . $o;
        }
        //门票 T开头18位
        if (substr($code, 0, 1) == "T")
        {
            $d = $this->numHexStr(rand(100, 999) . date("dH", $this->time()));
            $i = $this->numHexStr(rand(100, 999) . date("is", $this->time()));
            $code = substr($code, 0, 5) . $d . substr($code, 5) . $i;
        }
        return $code;
    }

    //动态码解密
    public function deDynamicCode($code)
    {
        $rs["time"] = 0;
        $rs["code"] = "";
        if (substr($code, 0, 1) == "T")
        {
            $d_hex = substr($code, 5, 4);
            $i_hex = substr($code, -4);
            $d = substr($this->strHexNum($d_hex), 3);
            $i = substr($this->strHexNum($i_hex), 3);
            $rs["time"] = $d . $i;
            $rs["code"] = str_replace($d_hex, "", substr($code, 0, -4));
        }
        if (substr($code, 0, 1) == "O")
        {
            $d_hex = substr($code, 1, 6);
            $i_hex = substr($code, 7, 6);
            $o_hex = substr($code, 13);
            $d = $this->strHexNum($d_hex);
            $i = $this->strHexNum($i_hex);
            $o = $this->strHexNum($o_hex);
            $rs["time"] = substr($d, 2, 4) . substr($i, 2, 4);
            $rs["code"] = substr($d, 6) . substr($i, 6) . substr($o, 2);
        }
        return $rs;
    }

    // 检测微信收款码
    function checkWxAuthcode($str)
    {
        $pattern = "/^(10|11|12|13|14|15)\d{16}$/"; //微信用户付款码

        if (preg_match($pattern, $str))
        {
            return true;
        } else
        {
            return false;
        }
    }

    // 检测支付宝收款码
    function checkAlipayAuthcode($str)
    {
        $pattern = "/^(25|26|27|28|29|30)\d{14,22}$/";  //支付宝用户付款码

        if (preg_match($pattern, $str))
        {
            return true;
        } else
        {
            return false;
        }
    }

    function checkAuthcode($str)
    {
        $isWx = "/^(10|11|12|13|14|15)\d{16}$/";     //微信用户付款码
        $isAlipay = "/^(25|26|27|28|29|30)\d{14,22}$/";   //支付宝用户付款码
        if (preg_match($isWx, $str) || preg_match($isAlipay, $str))
        {
            return true;
        } else
        {
            return false;
        }
    }

    //订单来源（1:后台，2：微信，3:自助一体机，4：阿里体育，5：手持终端 6:安徽省平台，7:手环机）
    public function getOrderFrom($from)
    {
        switch ($from)
        {
            case 1:
                return "后台";
                break;
            case 2:
                return "微信";
                break;
            case 3:
                return "自助一体机";
                break;
            case 4:
                return "阿里体育";
                break;
            case 5:
                return "手持终端";
                break;
            case 6:
                return "安徽省平台";
                break;
            case 7:
                return "手环机";
                break;
            default:
                return "未知";
        }
    }

    public function timesList()
    {
        $time = array('00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30',//0-11
            '06:00', '06:30', '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',//12-23
            '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30',//24-35
            '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30',//36-47
        );
        return $time;
    }

    public function timesList2()
    {
        $time = array('00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', //0-11
            '06:30', '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00',  //12-23
            '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', //24-35
            '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30', '24:00', //36-47
        );
        return $time;
    }

    public function getFieldTimeStr($new_time_id, $type = 1)
    {
        $time = $this->timesList();
        $time2 = $this->timesList2();
        if (strlen($new_time_id) == 3)
        {
            $time_id = substr($new_time_id, 0, 2);
            $time_span = substr($new_time_id, 2, 1);
        } else
        {
            $time_id = $new_time_id;
            $time_span = 0;
        }
        $time_id = intval($time_id);
        if ($type == 1)
        {
            $rs = isset($time[$time_id]) ? $time[$time_id] : '00:00';
        } else
        {
            $rs = isset($time2[$time_id + $time_span]) ? $time2[$time_id + $time_span] : '24:00';
        }
        return $rs;
    }

    /*
        * 根据身份证号码获取年龄
        * inupt $code = 完整的身份证号
        * return $age : 年龄
        */
    public function ageVerification($code){
        $age_time = strtotime(substr($code, 6, 8));
        if($age_time === false){
            return false;
        }
        list($y1,$m1,$d1) = explode("-",date("Y-m-d",$age_time));

        $now_time = $this->time();

        list($y2,$m2,$d2) = explode("-",date("Y-m-d",$now_time));
        $age = $y2 - $y1;
        if((int)($m2.$d2) < (int)($m1.$d1)){
            $age -= 1;
        }
        return $age;
    }

    public function sexVerification($idcard){
        return substr($idcard, (strlen($idcard)==18 ? -2 : -1), 1) % 2 ? '1' : '2';    //18位身份证取性别，倒数第二位奇数是男，偶数是女；
    }
    function getTimeWeek($time)
    {
        $weekarray = array("日", "一", "二", "三", "四", "五", "六");
        return "周" . $weekarray[date("w", $time)];

    }

    public function GetPrice($price)
    {
        return number_format(intval($price) / 100, 2);
    }

    public function keep($price,$num = 2)
    {
        return is_int($price) ? $price : number_format($price, $num);
    }

    public function getAge($birthday){
        $nowDate = date("Y-m-d",Functions::mode()->time());
        list($y,$m,$d)=explode("-",$birthday);
        list($ny,$nm,$nd)=explode("-", $nowDate);
        $age = $ny -$y;
        if($nm > $m || $nm == $m && $nd > $d){
            $age +=1;
        }
        return $age;
    }

    /**
     * Notes: 判断两个索引数组，是否一样
     * User: 闻铃
     * DateTime: 2023/5/6 上午10:15
     * @param $arrOne ['440400','440401']
     * @param $arrTwo ['440400','440401']
     * @return bool
     */
    public function arrayIsSame($arrOne,$arrTwo): bool
    {
        //如果有差异，说明不一样返回false
        return array_diff($arrOne,$arrTwo) ? false : true;
    }

    /**
     * Notes: 获取星球流水金额的符号
     * User: 闻铃
     * DateTime: 2023/5/10 下午4:38
     * @param $type
     * @return mixed
     * @throws PPosException
     */
    public function getCommunityAmountType($type)
    {
        $typeStr = ['1'=>'+','2'=>'-','3'=>'-'];
        if (!isset($typeStr[$type])) {
            throw new PPosException("类型错误");
        }
        return $typeStr[$type];
    }

    public function getChineseWeek($number)
    {
        $w = [0=> "周日", 1 => "周一", 2 => "周二", 3 => "周三", 4 => "周四", 5 => "周五", 6 => "周六"];
        if (!isset($w[$number])) {
            throw new PPosException("日期错误");
        }
        return $w[$number];
    }

    /**
     * csv_get_lines 读取CSV文件中的某几行数据
     * @param $csvfile csv文件路径
     * @param $lines 读取行数
     * @param $offset 起始行数
     * @return array
     * */
    public function csvGetLines($csvfile, $lines, $offset = 0, $head_arr)
    {
        if (!file_exists($csvfile)) {
            return false;
        }
        if (!$fp = fopen($csvfile, 'r')) {
            return false;
        }
        $i = $j = 0;
        while (false !== ($line = fgets($fp))) {
            if ($i++ < $offset) {
                continue;
            }
            break;
        }
        $data = array();
        while (($j++ < $lines) && !feof($fp)) {
            if ($row_Data = fgetcsv($fp)) {
                $data[] = array_combine($head_arr, $row_Data);
            }
        }
        fclose($fp);
        return $data;
    }
    /**
     * Notes:判断是否在区域父集内
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-10-18
     * Time: 下午6:27
     * @param $area_id
     * @param $p_area_id
     * @return bool
     */
    public function checkAreaAuth($area_id,$p_area_id){
        if ($area_id==$p_area_id){
            return true;
        }
        $area = strval($this->twoZeroDeal($area_id));
        $group_area = strval($this->twoZeroDeal($p_area_id));
        $area_l = strlen($area);
        $group_area_l = strlen($group_area);
        //$area_id 比$group_area_id级别高返回false
        if ($area_l < $group_area_l){
            return false;
        }
        //$area_id 比$group_area_id同级但是不一致返回false
        if ($area_l == $group_area_l&&$area!=$group_area){
            return false;
        }
        //$group_area_id 比 $area_id级别高判断是否父集
        if ($area_l > $group_area_l&&substr($area,0,$group_area_l)!=$group_area){
            return false;
        }
        return true;
    }
    /**
     * Notes: 双0抹除
     * User: 闻铃
     * DateTime: 2023/6/27 下午5:12
     * @param $company_area_id 数据的company_area_id
     * @return int|void 如果company_area_id需要抹0，则返回抹0后的company_area_id。不需要抹0则返回$company_area_id
     */
    public function twoZeroDeal($company_area_id)
    {
        if ($company_area_id == 0){
            return $company_area_id;
        }
        while ($company_area_id % 100 == 0){
            $company_area_id = intval($company_area_id / 100);
        }
        return $company_area_id;
    }
}



<?php

namespace PPOSLib\Helpers;

use PPOSLib\Exception\PPosException;
use Swoole\Exception;

/**
 * Class ServiceData
 * @package PPOSLib\Helpers
 */
class XapiandService
{

    private $host = "http://xapian.linksports.com.cn:8180/";
    private $retry_times = 1;
    //标识前缀 26个字母，先大写后小写
    const TAG= ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];

    const TIME_ACCURACY = [1000000000];


    public function __construct()
    {
        $this->host = env('XAPIAND_SERVICE_API', $this->host);
    }


    /**
     * Notes:查找索引,参考Xapiand https://kronuz.io/Xapiand/docs/exploration/
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 20-10-29
     * Time: 下午7:25
     * @param int $page
     * @param int $size
     * @param $search
     * @param array $select
     * @param array $orderBy //常规["c_time"=>"desc"] 距离排序["coordinate"=>['lat'=>22.534611,'lon'=>113.93517,'by'=>'asc']]
     * @return mixed
     * @throws PPosException
     */
    public function Search($page = 1, $size = 10, $search = [], $select = [], array $orderBy = ["c_time" => "desc"])
    {
        $url = $this->host . 'sportOnlinePlatform/info/';
        if (app()->isRegistered('request'))
        {
            $account_key = ["company_id"];
            foreach ($account_key as $v)
            {
                if (isset(app()->request->accountInfo[$v]))
                {
                    $search[$v] = app()->request->accountInfo[$v];
                }
            }
        }
        if ($search)
        {

            $body['_query'] = $search;
        }
        if ($select)
        {
            $body['_selector'] = '{' . implode(",", $select) . '}';
        }
        $body['_offset'] = ($page - 1) * $size;
        $body['_limit'] = intval($size);
        foreach ($orderBy as $k => $v)
        {
            if ($k == "coordinate")
            {
                $body['_sort']["coordinate"]['_point']['_latitude'] = floatval($v["lat"]);
                $body['_sort']["coordinate"]['_point']['_longitude'] = floatval($v["lon"]);
                $body['_sort']["coordinate"]['_order'] = $v["by"];
            } else
            {
                $body['_sort'][$k]['_order'] = $v;
            }

        }
        /*
     * {
    "_selector": "{topic_id,name}",
    "_query": {
        "name": "*白露*",
        "coordinate": {
            "_in": {
                "_circle": {
                    "_latitude": 22.534611,
                    "_longitude": 113.93517,
                    "_radius": 50000
                }
            }
        }
    },
    "_sort": {
        "coordinate": {
            "_point": {
                "_latitude": 22.534611,
                "_longitude": 113.93517
            },
            "_order": "asc"
        }
    },
    "_limit": 10,
    "_offset": 0
}
     */
        $body = json_encode($body);
        $rs = $this->sendRequest($url, "SEARCH", $body);
        return $rs;
    }

    public function SearchCircleTheme($page = 1, $size = 10, $search = [], $select = [], array $orderBy = ["c_time" => "desc"])
    {
        $url = $this->host . 'sportOnlinePlatform/wxCircleTheme/';
        if (app()->isRegistered('request'))
        {
            $account_key = ["company_id"];
            foreach ($account_key as $v)
            {
                if (isset(app()->request->accountInfo[$v]))
                {
                    $search[$v] = app()->request->accountInfo[$v];
                }
            }
        }
        if ($search)
        {

            $body['_query'] = $search;
        }
        if ($select)
        {
            $body['_selector'] = '{' . implode(",", $select) . '}';
        }
        $body['_offset'] = ($page - 1) * $size;
        $body['_limit'] = intval($size);
        foreach ($orderBy as $k => $v)
        {
            if ($k == "coordinate")
            {
                $body['_sort']["coordinate"]['_point']['_latitude'] = floatval($v["lat"]);
                $body['_sort']["coordinate"]['_point']['_longitude'] = floatval($v["lon"]);
                $body['_sort']["coordinate"]['_order'] = $v["by"];
            } else
            {
                $body['_sort'][$k]['_order'] = $v;
            }

        }
        $body = json_encode($body);
        $rs = $this->sendRequest($url, "SEARCH", $body);
        return $rs;
    }

    public function SearchHistory($page = 1, $size = 10, $search = [], $select = [], array $orderBy = ["c_time" => "desc"], $group_by = null)
    {
        $url = $this->host . 'sportOnlinePlatform/searchHistory/';
        if (app()->isRegistered('request'))
        {
            $account_key = ["company_id"];
            foreach ($account_key as $v)
            {
                if (isset(app()->request->accountInfo[$v]))
                {
                    $search[$v] = app()->request->accountInfo[$v];
                }
            }
        }
        if ($search)
        {
            $body['_query'] = $search;
        }
        if ($select)
        {
            $body['_selector'] = '{' . implode(",", $select) . '}';
        }
        if ($group_by)
        {
            $body['_aggregations']['group_by_' . $group_by]['_values']['_field'] = $group_by;
            $body['_aggregations']['group_by_' . $group_by]['_values']['_keyed'] = true;
        }
        $body['_offset'] = ($page - 1) * $size;
        $body['_limit'] = intval($size);
        foreach ($orderBy as $k => $v)
        {
            $body['_sort'][$k]['_order'] = $v;
        }
        /*
     * {
    "_selector": "{topic_id,name}",
    "_query": {
        "name": "*白露*",
        "coordinate": {
            "_in": {
                "_circle": {
                    "_latitude": 22.534611,
                    "_longitude": 113.93517,
                    "_radius": 50000
                }
            }
        }
    },
    "_sort": {
        "coordinate": {
            "_point": {
                "_latitude": 22.534611,
                "_longitude": 113.93517
            },
            "_order": "asc"
        }
    },
    "_limit": 10,
    "_offset": 0
}
     */
        $body = json_encode($body);
        $rs = $this->sendRequest($url, "SEARCH", $body);
        return $rs;
    }

    public function topSearch($search = [])
    {
        $url = $this->host . 'sportOnlinePlatform/searchHistory/';
        if (app()->isRegistered('request'))
        {
            $account_key = ["company_id"];
            foreach ($account_key as $v)
            {
                if (isset(app()->request->accountInfo[$v]))
                {
                    $search[$v] = app()->request->accountInfo[$v];
                }
            }
        }

        if ($search)
        {
            $body['_query'] = $search;
        }

        $body['_aggregations']['group_by_keyword']['_values']['_field'] = "keyword";
        $body['_aggregations']['group_by_keyword']['_values']['_sort']['_doc_count'] = "desc";
        $body['_limit'] = 0;
        $body = json_encode($body);
        $rs = $this->sendRequest($url, "SEARCH", $body);
        return $rs;
    }

    public function areaSearch($page = 1, $size = 10, $search = [], $select = [], array $orderBy = ["c_time" => "desc"])
    {
        $url = $this->host . 'sportOnlinePlatform/companyArea/';
        if (app()->isRegistered('request'))
        {
            $account_key = ["company_id"];
            foreach ($account_key as $v)
            {
                if (isset(app()->request->accountInfo[$v]))
                {
                    $search[$v] = app()->request->accountInfo[$v];
                }
            }
        }
        if ($search)
        {

            $body['_query'] = $search;
        }
        if ($select)
        {
            $body['_selector'] = '{' . implode(",", $select) . '}';
        }
        $body['_offset'] = ($page - 1) * $size;
        $body['_limit'] = intval($size);
        foreach ($orderBy as $k => $v)
        {
            if ($k == "coordinate")
            {
                $body['_sort']["coordinate"]['_point']['_latitude'] = floatval($v["lat"]);
                $body['_sort']["coordinate"]['_point']['_longitude'] = floatval($v["lon"]);
                $body['_sort']["coordinate"]['_order'] = $v["by"];
            } else
            {
                $body['_sort'][$k]['_order'] = $v;
            }

        }
        $body = json_encode($body);
        $rs = $this->sendRequest($url, "SEARCH", $body);
        return $rs;
    }

    public function putResource($data)
    {
        $id = $this::TAG[$data['resource_type']] . sprintf("%09s", $data['resource_id']);
        $url = $this->host . 'sportOnlinePlatform/info/' . $id;
        $body = json_encode($data);
        $rs = $this->sendRequest($url, "PUT", $body);
        return $rs;
    }

    public function updateResource($data)
    {
        $id = $this::TAG[$data['resource_type']] . sprintf("%09s", $data['resource_id']);
        $url = $this->host . 'sportOnlinePlatform/info/' . $id;
        $body = json_encode($data);
        try{
            $rs = $this->sendRequest($url, "UPDATE", $body);
        }catch (\Exception $e){
            if (strpos($e->getMessage(),"Not Found: Document not found")!==false){
                $rs = $e->getMessage();
            }else{
                throw new PPosException($e->getMessage(), 400);
            }
        }

        return $rs;
    }

    public function del($id)
    {
        $url = $this->host . 'sportOnlinePlatform/info/' . $id;
        $rs = $this->sendRequest($url, "DELETE");
        return $rs;
    }


    public function delActive($activity_id,$resource_type)
    {
        $id = self::TAG[$resource_type] . sprintf("%09s", $activity_id);
        return $this->del($id);
    }

    public function delResource($resource_id,$resource_type)
    {
        $id = self::TAG[$resource_type] . sprintf("%09s", $resource_id);
        return $this->del($id);
    }



    public function putHistory(array $d)
    {
        $index['keyword'] = $d['keyword'];
        $index['company_id'] = intval($d['company_id']);
        $index['c_time']['_value'] = $d['c_time'];
        $index['c_time']['_accuracy'] = self::TIME_ACCURACY;
        $index['member_id'] = $d['member_id'];
        $index['total'] = $d['total'];
        $url = $this->host . 'sportOnlinePlatform/searchHistory/';
        $body = json_encode($index);
        $rs = $this->sendRequest($url, "POST", $body);
        return $rs;
    }

    public function putCompanyArea(array $d)
    {
        $id = 'C' . sprintf("%04s", $d['company_id']) . sprintf("%09s", $d['company_area_id']);
        $index['company_id'] = $d['company_id'];
        $index['name'] = $this->pullWord($d['name']);
        $index['area_id'] = $d['company_area_id'];
        $index['sort'] = $d['sort'];
        $index['coordinate']['_point']['_latitude'] = floatval($d['lat']);
        $index['coordinate']['_point']['_longitude'] = floatval($d['lng']);
        $url = $this->host . 'sportOnlinePlatform/companyArea/' . $id;
        $body = json_encode($index);
        $rs = $this->sendRequest($url, "PUT", $body);
        return $rs;
    }

    public function pullWord($content,$is_search = false)
    {
        $len = strlen($content);
        if ($len < 4)
        {
            return $content;
        }
        $cooper = new  CooperServiceData();
        $work = $cooper->pullWord($content);
        $work['searchList'] = array_filter($work['searchList'], function ($val)
        {
            return trim($val);
        });
        $work['allList'] = array_filter($work['allList'], function ($val)
        {
            return trim($val);
        });
        $work['cutList'] = array_filter($work['cutList'], function ($val)
        {
            return trim($val);
        });
        if ($is_search){
            $rs = array_merge([$content],$work['searchList'], $work['allList'], $work['cutList']);
        }else{
            $rs = array_merge([$content],$work['searchList'], $work['allList'], $work['cutList']);
        }
        $rs = array_unique($rs);
        $rs = implode(" ",$rs);
        return $rs;
    }

    private function sendRequest($url, $method, $body = null, $times = 1)
    {
        $log = "------------XapiandService-------------" . "\n";
        $log .= "url:" . $url ."  ". $method."\n";
        $log .= "参数:" . var_export($body, true) . "\n";
        app()->log->info($log);
        $start_time = microtime(true);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "PPOSPRO-Service");
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);  // 连接建立最长耗时
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);  // 请求最长耗时
        // 设置SSL版本 1=CURL_SSLVERSION_TLSv1, 不指定使用默认值,curl会自动获取需要使用的CURL版本
        // curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // 如果报证书相关失败,可以考虑取消注释掉该行,强制指定证书版本
        //curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'TLSv1');
        // 设置Basic认证
        //curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        //curl_setopt($ch, CURLOPT_USERPWD, $this->appKey . ":" . $this->masterSecret);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

        // 设置Post参数
        if ($method === "POST")
        {
            curl_setopt($ch, CURLOPT_POST, true);
        } else
        {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        }
        if (!is_null($body))
        {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));

        $output = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $response = array();
        $errorCode = curl_errno($ch);
        $body = $output;
        if ($errorCode)
        {
            $retries = $this->retry_times;
            if ($times < $retries)
            {
                return self::sendRequest($url, $method, $body, ++$times);
            } else
            {
                if ($errorCode === 28)
                {

                    throw new PPosException("Response timeout. Your request has probably be received by JPush Server,please check that whether need to be pushed again.", 4000606019);
                } elseif ($errorCode === 56)
                {
                    // resolve error[56 Problem (2) in the Chunked-Encoded data]
                    throw new PPosException("Response timeout, maybe cause by old CURL version. Your request has probably be received by JPush Server, please check that whether need to be pushed again.", 4000606019);
                } else
                {
                    throw new PPosException("Connect timeout. Please retry later. Error:" . $errorCode . " " . curl_error($ch), 4000606019);
                }
            }
        } else
        {
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $header_text = substr($output, 0, $header_size);
            $body = substr($output, $header_size);
            /*$headers = array();
            foreach (explode("\r\n", $header_text) as $i => $line) {
                if (!empty($line)) {
                    if ($i === 0) {
                        $headers[0] = $line;
                    } else if (strpos($line, ": ")) {
                        list ($key, $value) = explode(': ', $line);
                        $headers[$key] = $value;
                    }
                }
            }
            $response['headers'] = $headers;
            $response['body'] = $body;
            $response['http_code'] = $httpCode;*/
        }
        curl_close($ch);
        $body = mb_convert_encoding($body, "UTF-8", "UTF-8");
        $rs = json_decode($body, true);
        if ($status_code != 200 && $status_code != 204)
        {
            throw new PPosException($rs['message']??$rs['type'], $rs['status']);
        }
        $end_time = microtime(true);
        $cat_time = round($end_time - $start_time, 4);
        $log = "耗时:" . $cat_time . "\n";
        $charlist =[" ","\t","\n","\r","\x0B"];
        $log .= "返回结果:" . str_replace($charlist,["","","","",""],$body) . "\n";
        app()->log->info($log);
        return $rs;
    }

}

<?php
namespace PPOSLib\Console;

use PPOSLib\DB\Base\Activity;
use PPOSLib\DB\Base\CircleTheme;
use PPOSLib\DB\Base\Coach;
use PPOSLib\DB\Base\CoachSportTag;
use PPOSLib\DB\Base\Community;
use PPOSLib\DB\Base\CompanyArea;
use PPOSLib\DB\Base\Course;
use PPOSLib\DB\Base\CourseSportTag;
use PPOSLib\DB\Base\Field;
use PPOSLib\DB\Base\Goods;
use PPOSLib\DB\Base\Health;
use PPOSLib\DB\Base\News;
use PPOSLib\DB\Base\Organization;
use PPOSLib\DB\Base\Plan;
use PPOSLib\DB\Base\ResourceTagRelated;
use PPOSLib\DB\Base\Site;
use PPOSLib\DB\Base\Stadium;
use PPOSLib\DB\Base\StadiumSportTag;
use PPOSLib\Helpers\Functions;
use PPOSLib\Helpers\XapiandService;

/**
 * Class Des3
 * @package des3
 */
class EsAction{

    public function buildActivityIndex($company_id=0){

        $mode = new Activity();
        if($company_id){
            $mode->setCutField(['company_id'=>$company_id]);
        }
        $rs = $mode->esGetDocInfo();
        if ($rs['http_code']==404){
            $mode->esCreateDoc();
        }

        $mode->esIndex(['activity_ids'=>[]],"add");
    }

    public function buildPlanIndex($company_id=0){
        $mode = new Plan();
        if($company_id){
            $mode->setCutField(['company_id'=>$company_id]);
        }
        $rs = $mode->esGetDocInfo();
        if ($rs['http_code']==404){
            $mode->esCreateDoc();
        }

        $mode->esIndex([],"Add");
    }

    public function delActivityIndex(){
        $mode = new Activity();
        $mode->esClearDoc();

    }

    public function delPlanIndex(){
        $mode = new Plan();
        $mode->esClearDoc();
    }

    public function searchTest($company_id=0){

        $mode = new Activity();
        if($company_id){
            $mode->setCutField(['company_id'=>$company_id]);
        }
        $search=[];
        //$search['activity_id']=1;
        $search['keyword']='赛事';
        $query = $mode->getESQuery($search);
        $rs = $mode->esSearchDocInfo($query,0,2);
        var_dump($rs);
    }

}

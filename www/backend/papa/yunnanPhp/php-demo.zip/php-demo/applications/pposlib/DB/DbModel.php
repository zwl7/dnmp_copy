<?php
/**
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-13
 * Time: 上午10:52
 */
namespace PPOSLib\DB;

class DbModel
{
    protected  $connection = "base";
    protected  $updated_at = "u_time";
    protected  $create_at = "c_time";
    protected  $timestamps = true;
    protected  $fillable = array();


    /**
     * @var string
     */
    protected  $table = '';


    private static $_mode = null;

    /**
     * 构造函数声明为私有，防止外部程序new类
     */

    protected function __construct()
    {


    }

    //克隆函数声明为私有，防止克隆对象
    protected function __clone()
    {
    }

    /**
     * Notes:单例
     * @return $this
     */
    public static function mode()
    {
        $name =  get_called_class();
        if (!isset(self::$_mode[$name])) {
            self::$_mode[$name] = new $name();
        }
        return self::$_mode[$name];
    }
    public function getModes(){
        return self::$_mode;
    }
    public function __get($name){
        return $this->$name ;
    }


}
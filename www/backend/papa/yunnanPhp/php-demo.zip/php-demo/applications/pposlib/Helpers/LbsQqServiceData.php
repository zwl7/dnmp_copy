<?php
namespace PPOSLib\Helpers;
use PPOSLib\Exception\PPosException;

/**
 * Class ServiceData
 * @package PPOSLib\Helpers
 */
class LbsQqServiceData {

    private $host="https://apis.map.qq.com";
    private $app_id=10101;
    private $api_key="3IBBZ-SAGWU-KWCV5-25E7B-TWFTF-TFBFL";

    private $retry_times=1;


    private $zones = [
        'districtChildren' => '/ws/district/v1/getchildren/',
        'geocoder' => '/ws/geocoder/v1/',
        //https://apis.map.qq.com/ws/geocoder/v1/?address=
    ];

    public function __construct()
    {

        $this->host = env('LBSQQ_SERVICE_API');
        $this->api_key = env('LBSQQ_SERVICE_API_KEY');

    }



    public function districtChildren($id){
        $url = $this->host.$this->zones['districtChildren'];
        $body["id"] = $id;

        return $this->sendRequest($url,"GET",$body);
    }
    public function geocoder($lat,$lon){
        $url = $this->host.$this->zones['geocoder'];
        $body["location"] =$lat.",".$lon;
        return $this->sendRequest($url,"GET",$body);
    }
    //地址转经纬度
    public function addressToLocation($address){
        $url = $this->host.$this->zones['geocoder'];
        $body["address"] = $address;
        return $this->sendRequest($url,"GET",$body);
    }


    private function sendRequest($url, $method, $body=null, $times=1) {
        $body['key'] = $this->api_key;
        $log = "------------LbsQqServiceData-------------"."\n";
        $log .= "url:".$url."\n";
        $log .= "参数:".var_export($body, true)."\n";
        $start_time = microtime(true);
        app()->log->info($log);
        $ch = curl_init();
        if ($method=="GET"){
            $url = $url."?".http_build_query($body);
        }
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "PPOSPRO-Service");
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);  // 连接建立最长耗时
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);  // 请求最长耗时
        // 设置SSL版本 1=CURL_SSLVERSION_TLSv1, 不指定使用默认值,curl会自动获取需要使用的CURL版本
        // curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // 如果报证书相关失败,可以考虑取消注释掉该行,强制指定证书版本
        //curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'TLSv1');
        // 设置Basic认证
        //curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        //curl_setopt($ch, CURLOPT_USERPWD, $this->appKey . ":" . $this->masterSecret);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

        // 设置Post参数
        if ($method === "POST") {
            curl_setopt($ch, CURLOPT_POST, true);
            if (!is_null($body)) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($body));
            }
        } else if ($method === "DELETE" || $method === "PUT"|| $method === "GET") {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        }


        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/x-www-form-urlencoded',
            'Connection: Keep-Alive',
        ));

        $output = curl_exec($ch);
        $response = array();
        $errorCode = curl_errno($ch);
        $body = $output;
        if ($errorCode) {
            $retries = $this->retry_times;
            if ($times < $retries) {
                return self::sendRequest($url, $method, $body, ++$times);
            } else {
                if ($errorCode === 28) {

                    throw new PPosException("Response timeout. Your request has probably be received by JPush Server,please check that whether need to be pushed again." ,4000606019);
                } elseif ($errorCode === 56) {
                    // resolve error[56 Problem (2) in the Chunked-Encoded data]
                    throw new PPosException("Response timeout, maybe cause by old CURL version. Your request has probably be received by JPush Server, please check that whether need to be pushed again.",4000606019);
                } else {
                    throw new PPosException("Connect timeout. Please retry later. Error:" . $errorCode . " " . curl_error($ch),4000606019);
                }
            }
        } else {
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $header_text = substr($output, 0, $header_size);
            $body = substr($output, $header_size);
            /*$headers = array();
            foreach (explode("\r\n", $header_text) as $i => $line) {
                if (!empty($line)) {
                    if ($i === 0) {
                        $headers[0] = $line;
                    } else if (strpos($line, ": ")) {
                        list ($key, $value) = explode(': ', $line);
                        $headers[$key] = $value;
                    }
                }
            }
            $response['headers'] = $headers;
            $response['body'] = $body;
            $response['http_code'] = $httpCode;*/
        }
        curl_close($ch);
        $rs = json_decode($body,true);
        if($rs['status']!==0){
            throw new PPosException($rs['message'],$rs['status']);
        }
        $end_time = microtime(true);
        $cat_time = round($end_time - $start_time, 4);
        $log = "耗时:".$cat_time."\n";
        app()->log->info($log);
        return $rs["result"];
    }

    private function getRandom($param){
        $str="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $key = "";
        for($i=0;$i<$param;$i++)
        {
            $key .= $str[mt_rand(0,32)];    //生成php随机数
        }
        return $key;
    }

    private function signMd5($params,$secretKey=null){
        $stringToBeSigned = urldecode(http_build_query($params));
        $pList = explode("&", $stringToBeSigned);
        foreach ($pList as $key =>$value)
        {
            $v = explode("=", $value);
            if(count($v)<2 || strlen($v[1])==0)
            {
                unset($pList[$key]);
            }
        }
        sort($pList);
        $stringToBeSigned = implode("&", $pList);
        if($secretKey){
            $stringToBeSigned .= '&key='.$secretKey;
        }
        $stringToBeSigned = trim($stringToBeSigned,"&");
        $stringToBeSigned = substr(md5($stringToBeSigned),5,15);
        return strtoupper($stringToBeSigned);
    }

}

<?php

namespace PPOSLib\Logic;

use PPOSLib\DB\Orm\Plan as srcOrm;
use PPOSLib\DB\Base\Plan as srcDb;
use PPOSLib\Exception\PPosException;
use PPOSLib\Helpers\Functions;
use PPOSLib\Helpers\ServiceData;
use Swoole\Coroutine;


class Plan extends LogicBase
{

    public function addReview($data){
        $orm = new srcOrm();
        $search["plan_id"]=$data['resource_id'];
        $project = $orm->get($search,['county','status','area_level','organ_unit_id']);
        if (!$project){
            throw new PPosException("计划不存在", 4000050010);
        }
        if ($project['organ_unit_id']!=$data['jwt_organ_unit_id']){
            throw new PPosException("无权限提交审核", 4000050100);
        }
        //状态：1草稿，2审核中，3人工审核通过，4驳回，5自动审核通过
        if ($project['status']!=1){
            throw new PPosException("计划状态不正确", 4000050011);
        }
        if ($project['county']==0){
            throw new PPosException("计划所属地不正确", 4000050016);
        }
        $s = new ServiceData();
        //获取区域机构树
        $organs = $s->getParentOrganByArea($project['county']);
        if (empty($organs)){
            throw new PPosException("无审核人", 4000050012);
        }
        if ($organs[0]['company_area_id']!=$project['county']){
            //throw new PPosException("审核部门不存在", 4000050018);
        }

        $reviewer_list=[];
        $max_area = 0;
        //是否提交下级信息，高级别提交下级别信息，只需下级别机构审核  省级提交市级信息只需市级审核
        $down_level = 0;
        //赛事活动级别:1省级，2市级，3县级,4国家级，5跨省赛事活动活动
        switch ($project['area_level']){
            case 1:
                $max_area = 0;
                break;
            case 4:
                $max_area = 0;
                break;
            case 5:
                //53
                $max_area = 0;
                break;
            case 2:
                //5301
                $max_area = 100;
                if (in_array($data['organ_unit_id_level'],[1,4,5])){
                    $down_level = true;
                }
                break;
            case 3:
                //530102
                $max_area = 10000;
                if ($data['organ_unit_id_level']!=3){
                    $down_level = true;
                }
                break;
        }
        //只需对应赛事活动级别的机构审核 company_area_id由大到小
        foreach ( $organs as $organ){
            //区域位数小于$max_area  市区域4位数最大值9999 小于 10000
            if($organ['company_area_id'] < $max_area){
                break;
            }
            if ($down_level){
                //是否提交下级信息，高级别提交下级别信息，只需下级别机构审核
                if($max_area==0){
                    if ($organ['company_area_id']<100){
                       $reviewer_list[] = $organ['organ_unit_id'];
                        break;
                    }
                }elseif (intval(floor($organ['company_area_id'] / $max_area))<=100){
                    $reviewer_list[] = $organ['organ_unit_id'];
                    break;
                }
            }else{
                //市级发的由市级开始审核  company_area_id 量级应该比 jwt_company_area_id小或同等
                if(intval(floor($organ['company_area_id'] / $data['jwt_company_area_id']))>1){
                    continue;
                }
                $reviewer_list[] = $organ['organ_unit_id'];
            }

        }
        if (empty($reviewer_list))
        {
            throw new PPosException("计划无审核人", 4000050000);
        }
        $u['review_id'] = $data['review_id'];
        if ($data['is_auto']==1){
            //自动通过
            $u['status'] = 5;
            $u['over_reviewer_list'] = implode(",",$reviewer_list);
            $u['reviewer_id'] = end($reviewer_list);
        }else{
            $u['status'] = 2;
            $u['reviewer_id'] = $reviewer_list[0];
        }
        $u_rs = $orm->update($search,$u);
        if (!$u_rs){
            throw new PPosException("计划不存在", 4000050015);
        }

        $u['reviewer_list'] = implode(",",$reviewer_list);
        return $u;
    }

    public function review($data){
        $orm = new srcOrm();
        $search["plan_id"]=$data['resource_id'];
        $project = $orm->get($search,['county','status','area_level','reviewer_id','review_id','over_reviewer_list']);
        if (!$project){
            throw new PPosException("计划不存在", 4000050010);
        }
        if ($project['review_id']!=$data['review_id']){
            throw new PPosException("审核单错误", 4000050014);

        }
        //状态：1草稿，2审核中，3人工审核通过，4驳回，5自动审核通过
        if (in_array($project['status'],[1,4])){
            throw new PPosException("赛事计划状态不正确", 4000050011);
        }
        if ($project['reviewer_id']!=$data['reviewer_id']){
            throw new PPosException("审核人错误", 4000050013);
        }
        $u=[];
        //通过后最高级可以驳回
        if (in_array($project['status'],[3,5])){
            if ($data['status']!=4){
                throw new PPosException("通过后只能驳回", 4000050000);
            }
            $u['status'] = 4;
            $u['reviewer_id'] = 0;
        }else{
            if ($data['next_reviewer_id'] == 0){
                //终审
                $u['status'] = $data['status'];
                if (!in_array($u['status'],[3,5])){
                    //终审除通过外终结审核
                    $u['reviewer_id'] = 0;
                }
            }else{
                $u['reviewer_id'] = $data['next_reviewer_id'];
            }
        }
        $u['over_reviewer_list'] = $project['over_reviewer_list']?$project['over_reviewer_list'].",{$data['reviewer_id']}":$data['reviewer_id'];
        $u_rs = $orm->update($search,$u);
        if (!$u_rs){
            throw new PPosException("项目信息修改失败", 4000050015);
        }
        return $u;
    }
    //列表数据隔离
    public function listDataHandle(array $search = []){
        //数据隔离，列表类型 1：填报列表(本级发布) 2:审核列表(本级发布或本级审核或审核过的) 3:普通(区域)列表(机构区域内,单位自己填报的)
        $list_type = $search['list_type']??3;
        switch ($list_type){
            case 1:
                $search['organ_unit_id'] = $search['jwt_organ_unit_id'];
                break;
            case 2:
                $search['over_reviewer_list'] = $search['jwt_organ_unit_id'];
                break;
            case 3:
                if($search["jwt_organ_unit_type"] == 1){
                    if ($search['down_unit_ids']!="ALL"){
                        $search['organ_unit_ids'] = explode(',',$search['down_unit_ids']);
                        $search['organ_unit_ids'][] = $search['jwt_organ_unit_id'];
                    }
                    $search['statuss']=[2,3,4,5,6];

                }else{
                    $search['organ_unit_id'] = $search['jwt_organ_unit_id'];
                }
                break;
        }
        return $search;
    }

    public function statusHandle(array $search = []){
        //处理状态
        if (isset($search["statuss"])) {
            if (is_string($search["statuss"])){
               $search["statuss"] = explode(",", $search["statuss"]);
            }
            //7待本级审核
            if (in_array(7,$search["statuss"] )){
                $search['reviewer_id'] = $search['jwt_organ_unit_id'];
            }
        }
        //7待本级审核
        if (isset($search["status"])){
            if (7==$search["status"]){
               $search['reviewer_id'] = $search['jwt_organ_unit_id'];
            }
            if (3==$search["status"]||5==$search["status"]){
                unset($search["status"]);
               $search["statuss"] = [3,5];
            }
        }
        return $search;
    }

     public function reviewList($page, $size, array $search = [])
    {
        $search['list_type']=2;
        $search = $this->listDataHandle($search);
        $search = $this->statusHandle($search);

        $rs["page"]  = $page;
        $rs["size"]  = $size;
        $rs["count"] = 0;
        $start       = ($page - 1) * $size;

        //举办时间
        if (isset($search['hold_time']) && !empty($search['hold_time'])) {
            //
            $search["lte_plan_start_time"] = $search['hold_time'];
            $search["gte_plan_end_time"] = $search['hold_time'];
        }


        $search = $this->getSearch($search,'plan_');

        $srcDB         = new srcDb();

        $es_rs = $srcDB->esSearchDocInfo($srcDB->getESQuery($search),$start,$size,['plan_id'],['plan_id'=>"desc"]);
        $rs["count"] = $es_rs['count'];
        if ($rs["count"] == 0) {
            $rs["list"] = [];
            return $rs;
        }
        $plan_ids = [];
        foreach ($es_rs["list"] as $v) {
            $plan_ids[]=$v['_source']['plan_id'];

        }
        $rs["list"]   = $srcDB->getAll(['plan_ids'=>$plan_ids], []);
        $operator_ids = array_column($rs["list"], "operator");
        $s            = new ServiceData();
        $operators    = $s->operator($operator_ids, "personnel_name,personnel_id");
        $operators    = array_unique(array_column($operators, "personnel_name", "personnel_id"));

        $ActivityOrm  = new \PPOSLib\DB\Orm\Activity();
        $ActivityData = $ActivityOrm->getAll(['plan_ids' => $plan_ids], ['activity_id', 'plan_id']);

        $mapPlanIdToActivityId = array_column($ActivityData, 'activity_id', 'plan_id');

        if (!$ActivityData) {
            $match_status_arr = [];
        } else {
            //不为空，
            $activity_ids = array_column($ActivityData, 'activity_id');

            $ActivityHoldSituationOrm  = new \PPOSLib\DB\Orm\ActivityHoldSituation();
            $ActivityHoldSituationData = $ActivityHoldSituationOrm->getAll(['activity_ids' => $activity_ids], ['start_time', 'end_time', 'activity_id']);

            $match_status_arr = array_column($ActivityHoldSituationData, null, 'activity_id');
        }

        //name tag_group_ids
        //---start tag---
        $tag_ids_all_arr   = [];
        $tag_ids_str_array = array_column($rs["list"], 'type_tag_ids');
        foreach ($tag_ids_str_array as $vv) {
            $tag_ids_arr = explode(',', $vv);
            if (is_array($tag_ids_arr)) {
                $tag_ids_all_arr = array_merge($tag_ids_all_arr, $tag_ids_arr);
            }
        }
        $tag_ids_all_arr = array_unique($tag_ids_all_arr);

        if ($tag_ids_all_arr) {
            $TagData = $s->sendByParams('getAllTag',['search'=>['tag_ids' => $tag_ids_all_arr],'select'=>['tag_id', 'name as tag_id_str', 'tag_group_id']]);

        } else {
            $TagData = [];
        }

        $tag_group_ids = array_column($TagData, 'tag_group_id');
        $TagData       = array_column($TagData, null, 'tag_id');

       // $TagGroupOrm  = new  \PPOSLib\DB\Orm\TagGroup();
        //$TagGroupData = $TagGroupOrm->getAll(['tag_group_ids' => $tag_group_ids], ['tag_group_id', 'name']);
        if ($tag_group_ids) {
            $TagGroupData = $s->sendByParams('getAllTagGroup',['search'=>['tag_group_ids' => $tag_group_ids],'select'=>['tag_group_id', 'name']]);

        } else {
            $TagGroupData = [];
        }

        $TagGroupData = array_column($TagGroupData, 'name', 'tag_group_id');
        //---end tag---

        //要求当前条件下，全部的记录
        $province_ids   = array_unique(array_column($rs["list"], 'province'));
        $city_ids       = array_unique(array_column($rs["list"], 'city'));
        $county_ids     = array_unique(array_column($rs["list"], 'county'));
        $total_area_ids = array_merge($province_ids, $city_ids, $county_ids);

        $ServiceData = new ServiceData();
        //根据company—area-id 找到对应的城市id名称
        $CompanyAreaIdInfo = $ServiceData->sendByParams('getCompanyAreaIdInfo', ['search' => ['company_area_ids' => $total_area_ids], 'select' => ['company_area_id', 'name']]);
        $CompanyAreaIdInfo = array_column($CompanyAreaIdInfo, 'name', 'company_area_id');
        //单位名称
        $organUnitIds = [];
        foreach ($rs["list"] as $k=>$v){
            $organUnitIds[$v['reviewer_id']]=$v['reviewer_id'];
            //驳回状态时驳回人要取最后一个审核人
            if ($v['status']==4){
                $over_reviewer_list = explode(",",$v['over_reviewer_list']);
                $rs["list"][$k]['reviewer_id'] = end($over_reviewer_list);
                $organUnitIds[$rs["list"][$k]['reviewer_id']] = $rs["list"][$k]['reviewer_id'];
            }
        }
        $organUnitMap = [];
        if(!empty($organUnitIds)) {
            $organUnits = $s->getOrganUnitInfo($organUnitIds);
            if (!empty($organUnits)) {
                $organUnitMap =  array_column($organUnits, "name", "organ_unit_id");
            }
        }
        foreach ($rs["list"] as &$v) {
            $v["operator"] = $operators[$v["operator"]] ?? "--";

            $v["province_str"] = $CompanyAreaIdInfo[$v['province']] ?? "--";
            $v["city_str"]     = $CompanyAreaIdInfo[$v['city']] ?? "--";
            $v["county_str"]   = $CompanyAreaIdInfo[$v['county']] ?? "--";

            $v["area_level_str"]   = $this->getAreaLevelStr($v["area_level"]);
            $v["status_str"]       = self::STATUS[$v['status']] ?? "--";
            $v["sync_check_status_str"]       = self::SYNC_CHECK_STATUS[$v['sync_check_status']] ?? "--";

            if (isset($mapPlanIdToActivityId[$v["plan_id"]]) && isset($match_status_arr[$mapPlanIdToActivityId[$v["plan_id"]]])) {
                //拿到对应的状态就
                $activityId = $mapPlanIdToActivityId[$v["plan_id"]];
                $matchStatus = $this->getMatchStatus($match_status_arr[$activityId]['start_time'],$match_status_arr[$activityId]['end_time']);
                $v["match_status"]     = $matchStatus['match_status'];
                $v["match_status_str"] = $matchStatus['match_status_str'];
            } else {
                $v["match_status"]     = 1;
                $v["match_status_str"] = "计划中";
            }

            //type_tag_ids 分类id 找到所以的tag_group_id
            //项目分类标签，赛事主题
            if (!empty($v['type_tag_ids'])) {
                $type_tag_ids_arr = [];
                foreach (explode(',', $v['type_tag_ids']) as $vv) {
                    $type_tag_ids_arr[$vv]                     = $TagData[$vv];
                    $type_tag_ids_arr[$vv]['tag_group_id_str'] = $TagGroupData[$TagData[$vv]['tag_group_id']] ?? '--';
                }

                $tagAndGroupInfo       = $this->getTagShowInfo($v['type_tag_ids'], $type_tag_ids_arr);
                $v['tag_group_id_str'] = array_column($tagAndGroupInfo, 'tag_group_id_str');
                $v['type_tag_ids_arr'] = $tagAndGroupInfo;
            } else {
                $v['tag_group_id_str'] = "";
                $v['type_tag_ids_arr'] = [];
            }
            $v['review_progress']="未知";
             switch ($v["status"]){
                 case 0:
                    $v['review_progress'] = "待确认";
                    break;
                case 1:
                    $v['review_progress'] = "草稿";
                    break;
                case 2:
                    if ($v['reviewer_id']!=$search['jwt_organ_unit_id']){
                         $v["status"] = 7;
                    }
                    $v['review_progress'] = $organUnitMap[$v['reviewer_id']]??"未知".'审核中';
                    break;
                case 3:
                    $v['review_progress'] = "审核完成";
                    if ($v['reviewer_id']==$search['jwt_organ_unit_id']){
                         $v["status"] = 8;
                    }
                    break;
                case 4:
                    $v['review_progress'] = $organUnitMap[$v['reviewer_id']]??"未知".'驳回';
                    break;
                case 5:
                    $v['review_progress'] = "自动审核完成";
                    if ($v['reviewer_id']==$search['jwt_organ_unit_id']){
                         $v["status"] = 8;
                    }
                    break;
            }
        }
        return $rs;
    }

     public function reviewData( array $search = [])
    {

        $search = $this->listDataHandle($search);
        $search = $this->statusHandle($search);

        //举办时间
        if (isset($search['hold_time']) && !empty($search['hold_time'])) {
            //
            $search["lte_plan_start_time"] = $search['hold_time'];
            $search["gte_plan_end_time"] = $search['hold_time'];
        }

        $search = $this->getSearch($search,'plan_');

        $key = "street";
        $company_area_id = $search['company_area_id']??$search['jwt_company_area_id'];
        if ($company_area_id < 100) {
            $key = "city";
        } elseif ($company_area_id < 10000) {
            $key = "county";
        } elseif ($company_area_id < 10000000) {
            $key = "county";
        }

        $srcDB         = new srcDb();

        $es_rs = $srcDB->esSearchDocInfo($srcDB->getESQuery($search),0,10000,['status','reviewer_id',$key]);
        $rs["count"] = $es_rs['count'];

        $rs['review'] = 0;
        $rs['pass'] = 0;
        $rs['reject'] = 0;
        $rs['draft'] = 0;

        //待我审核
        $rs['audit'] = 0;

        $rs['area_data'] = [];

        if ($rs["count"] == 0) {
            //
            return $rs;
        }

        $area_ids = [];
        foreach ($es_rs["list"] as $v) {
            $v = $v['_source'];
            $rs['area_data'][$v[$key]] = array('count'=>0,'review'=>0,'pass'=>0,'reject'=>0,'audit'=>0,'draft'=>0);
            $area_ids[] = $v[$key];
        }
        $area_ids = array_unique($area_ids);
        $ServiceData = new ServiceData();

        if ($area_ids) {

            $area = $ServiceData->sendByParams('getCompanyAreaIdInfo',['search'=>['company_area_ids'=>$area_ids]]);
            $area = array_column($area,'name','company_area_id');
        } else {
            $area = [];
        }

        foreach ($es_rs["list"] as $v) {
            $v = $v['_source'];

            $rs['area_data'][$v[$key]]['area'] = $area[$v[$key]] ?? '--';
            $rs['area_data'][$v[$key]]['count'] ++;

            //"status",    //状态：1草稿，2审核中，3人工审核通过，4驳回，5自动审核通过
            if ($v['status']==2){
                $rs['review'] ++;
                $rs['area_data'][$v[$key]]['review'] ++;
            }else if(in_array($v['status'],[3,5])){
                $rs['pass'] ++;
                $rs['area_data'][$v[$key]]['pass'] ++;
            }else if ($v['status']==4){
                $rs['reject'] ++;
                $rs['area_data'][$v[$key]]['reject'] ++;
            }else if ($v['status']==1){
                $rs['draft'] ++;
                $rs['area_data'][$v[$key]]['draft'] ++;
            }
            if ($v['reviewer_id']&&$search['jwt_organ_unit_id']==$v['reviewer_id']){
                $rs['audit']++;
                $rs['area_data'][$v[$key]]['audit'] ++;
            }
        }

        return $this->getTotalRate($rs);
    }

    public function areaList(array $search = [])
    {
        $srcDB = new srcDb();
        //拼装搜索字段
        $search['is_del'] = 2;
        $search['list_type'] = 3;
        $search = $this->listDataHandle($search);
        $search = $this->statusHandle($search);
        $search = $this->getSearch($search);
        $es_rs = $srcDB->esSearchDocInfo($srcDB->getESQuery($search),0,10000,['plan_id','name','location']);
        $rs=[];
        foreach ($es_rs["list"] as $v) {
            $rs[]=$v['_source'];
        }
        return $rs;
    }
    /**
     * @param $page
     * @param $size
     * @param array $search
     * @return mixed
     * @throws \PPOSLib\Exception\PPosException
     */
    public function getList($page, $size, array $search = [])
    {

        //找出需要当前账号等级核查的所有核查记录。
        //后面需要用 elasticSearch

        //
        $rs["page"]  = $page;
        $rs["size"]  = $size;
        $rs["count"] = 0;
        $start       = ($page - 1) * $size;

        //举办时间
        if (isset($search['hold_time']) && !empty($search['hold_time'])) {
            //
            $search["lte_activity_start_time"] = $search['hold_time'];
            $search["gte_activity_end_time"] = $search['hold_time'];
        }

        $search = $this->statusHandle($search);

        $search = $this->getSearch($search,'activity_');

        $srcDB         = new srcDb();

        $es_rs = $srcDB->esSearchDocInfo($srcDB->getESQuery($search),$start,$size,['plan_id'],['plan_id'=>"desc"]);
        $rs["count"] = $es_rs['count'];
        if ($rs["count"] == 0) {
            $rs["list"] = [];
            return $rs;
        }
        $plan_ids = [];
        foreach ($es_rs["list"] as $v) {
            $plan_ids[]=$v['_source']['plan_id'];

        }
        $rs["list"]   = $srcDB->getAll(['plan_ids'=>$plan_ids], []);
        if (!$rs["list"]) {
            return $rs;
        }
        $operator_ids = array_column($rs["list"], "operator");
        $s            = new ServiceData();
        $operators    = $s->operator($operator_ids, "personnel_name,personnel_id");
        $operators    = array_unique(array_column($operators, "personnel_name", "personnel_id"));

        $ActivityOrm  = new \PPOSLib\DB\Orm\Activity();
        $ActivityData = $ActivityOrm->getAll(['plan_ids' => $plan_ids], ['activity_id', 'plan_id']);


        $mapPlanCountActivity = [];
        $mapPlanIdToActivityId = array_column($ActivityData, 'activity_id', 'plan_id');

        if (!$ActivityData) {
            $match_status_arr = [];
        } else {
            //不为空，
            $activity_ids = array_column($ActivityData, 'activity_id');

            $ActivityHoldSituationOrm  = new \PPOSLib\DB\Orm\ActivityHoldSituation();
            $ActivityHoldSituationData = $ActivityHoldSituationOrm->getAll(['activity_ids' => $activity_ids], ['start_time', 'end_time', 'activity_id']);

            $match_status_arr = array_column($ActivityHoldSituationData, null, 'activity_id');

            //统计对应的活动数量
            foreach ($ActivityData as $activity) {
                if (isset($mapPlanCountActivity[$activity['plan_id']])) {
                    $mapPlanCountActivity[$activity['plan_id']]++;
                } else {
                    $mapPlanCountActivity[$activity['plan_id']] = 1;
                }
            }
        }

        //name tag_group_ids
        //---start tag---
        $tag_ids_all_arr   = [];
        $tag_ids_str_array = array_column($rs["list"], 'type_tag_ids');
        foreach ($tag_ids_str_array as $vv) {
            $tag_ids_arr = explode(',', $vv);
            if (is_array($tag_ids_arr)) {
                $tag_ids_all_arr = array_merge($tag_ids_all_arr, $tag_ids_arr);
            }
        }
        $tag_ids_all_arr = array_unique($tag_ids_all_arr);

        if ($tag_ids_all_arr) {
            $TagData = $s->sendByParams('getAllTag',['search'=>['tag_ids' => $tag_ids_all_arr],'select'=>['tag_id', 'name as tag_id_str', 'tag_group_id']]);

        } else {
            $TagData = [];
        }

        $tag_group_ids = array_column($TagData, 'tag_group_id');
        $TagData       = array_column($TagData, null, 'tag_id');

       // $TagGroupOrm  = new  \PPOSLib\DB\Orm\TagGroup();
        //$TagGroupData = $TagGroupOrm->getAll(['tag_group_ids' => $tag_group_ids], ['tag_group_id', 'name']);
        if ($tag_group_ids) {
            $TagGroupData = $s->sendByParams('getAllTagGroup',['search'=>['tag_group_ids' => $tag_group_ids],'select'=>['tag_group_id', 'name']]);

        } else {
            $TagGroupData = [];
        }

        $TagGroupData = array_column($TagGroupData, 'name', 'tag_group_id');
        //---end tag---

        //要求当前条件下，全部的记录
        $province_ids   = array_unique(array_column($rs["list"], 'province'));
        $city_ids       = array_unique(array_column($rs["list"], 'city'));
        $county_ids     = array_unique(array_column($rs["list"], 'county'));
        $total_area_ids = array_merge($province_ids, $city_ids, $county_ids);

        $ServiceData = new ServiceData();
        //根据company—area-id 找到对应的城市id名称
        if ($total_area_ids) {
            $CompanyAreaIdInfo = $ServiceData->sendByParams('getCompanyAreaIdInfo', ['search' => ['company_area_ids' => $total_area_ids], 'select' => ['company_area_id', 'name']]);
            $CompanyAreaIdInfo = array_column($CompanyAreaIdInfo, 'name', 'company_area_id');
        } else {
            $CompanyAreaIdInfo = [];
        }
        //单位名称
        $organUnitIds = [];
        foreach ($rs["list"] as $k=>$v){
            $organUnitIds[$v['reviewer_id']]=$v['reviewer_id'];
            //驳回状态时驳回人要取最后一个审核人
            if ($v['status']==4){
                $over_reviewer_list = explode(",",$v['over_reviewer_list']);
                $rs["list"][$k]['reviewer_id'] = end($over_reviewer_list);
                $organUnitIds[$rs["list"][$k]['reviewer_id']] = $rs["list"][$k]['reviewer_id'];
            }
        }
        $organUnitMap = [];
        if(!empty($organUnitIds)) {
            $organUnits = $s->getOrganUnitInfo($organUnitIds);
            if (!empty($organUnits)) {
                $organUnitMap =  array_column($organUnits, "name", "organ_unit_id");
            }
        }

        foreach ($rs["list"] as &$v) {
            $v["operator"] = $operators[$v["operator"]] ?? "--";

            $v["province_str"] = $CompanyAreaIdInfo[$v['province']] ?? "--";
            $v["city_str"]     = $CompanyAreaIdInfo[$v['city']] ?? "--";
            $v["county_str"]   = $CompanyAreaIdInfo[$v['county']] ?? "--";

            $v["area_level_str"]   = $this->getAreaLevelStr($v["area_level"]);
            $v["status_str"]       = self::STATUS[$v['status']] ?? "--";
            $v["sync_check_status_str"]       = self::SYNC_CHECK_STATUS[$v['sync_check_status']] ?? "--";

            if (isset($mapPlanIdToActivityId[$v["plan_id"]]) && isset($match_status_arr[$mapPlanIdToActivityId[$v["plan_id"]]])) {
                //拿到对应的状态就
                $activityId = $mapPlanIdToActivityId[$v["plan_id"]];
                $matchStatus = $this->getMatchStatus($match_status_arr[$activityId]['start_time'],$match_status_arr[$activityId]['end_time']);
                $v["match_status"]     = $matchStatus['match_status'];
                $v["match_status_str"] = $matchStatus['match_status_str'];
            } else {
                $v["match_status"]     = 1;
                $v["match_status_str"] = "计划中";
            }

            //管理活动数量
            $v['activity_count'] = $mapPlanCountActivity[$v["plan_id"]] ?? 0;

            //type_tag_ids 分类id 找到所以的tag_group_id
            //项目分类标签，赛事主题
            if (!empty($v['type_tag_ids'])) {
                $type_tag_ids_arr = [];
                foreach (explode(',', $v['type_tag_ids']) as $vv) {
                    if (isset($TagData[$vv])){
                        $type_tag_ids_arr[$vv]                     = $TagData[$vv];
                        $type_tag_ids_arr[$vv]['tag_group_id_str'] = $TagGroupData[$TagData[$vv]['tag_group_id']] ?? '--';
                    }
                }

                $tagAndGroupInfo       = $this->getTagShowInfo($v['type_tag_ids'], $type_tag_ids_arr);
                $v['tag_group_id_str'] = implode(',',array_column($tagAndGroupInfo, 'tag_group_id_str'));
                $v['type_tag_ids_arr'] = $tagAndGroupInfo;
            } else {
                $v['tag_group_id_str'] = "";
                $v['type_tag_ids_arr'] = [];
            }
            $v['review_progress']="未知";
            switch ($v["status"]){
                 case 0:
                    $v['review_progress'] = "待确认";
                    break;
                case 1:
                    $v['review_progress'] = "草稿";
                    break;
                case 2:
                    if ($v['reviewer_id']!=$search['jwt_organ_unit_id']){
                         $v["status"] = 7;
                    }
                    $v['review_progress'] = $organUnitMap[$v['reviewer_id']]??"未知".'审核中';
                    break;
                case 3:
                    $v['review_progress'] = "审核完成";
                    if ($v['reviewer_id']==$search['jwt_organ_unit_id']){
                         $v["status"] = 8;
                    }
                    break;
                case 4:
                    $v['review_progress'] = $organUnitMap[$v['reviewer_id']]??"未知".'驳回';
                    break;
                case 5:
                    $v['review_progress'] = "自动审核完成";
                    if ($v['reviewer_id']==$search['jwt_organ_unit_id']){
                         $v["status"] = 8;
                    }
                    break;
            }

            //导入字段
            $v["area_str"]         = $v["province_str"] . $v["city_str"] . $v["county_str"];
            $v['type_tag_ids_str'] = $this->getTagGroupAndTagStr($v['type_tag_ids_arr']);
            $v['plan_start_time_str'] = $this->getFormatTimeStr($v['plan_start_time']);
            $v['c_time_str'] = $this->getFormatTimeStr($v['c_time']);


        }
        return $rs;
    }


    public function getNeedCheckList($data): array
    {
        $CheckDb = new \PPOSLib\DB\Base\Check();
        $db          = $CheckDb->db();
        $PlanBase    = new \PPOSLib\DB\Base\Plan($db);

        $plan_id_data = $PlanBase->getAll(['status'=>2], ['plan_id', 'county', 'city', 'province', 'area_level', 'name', 'status']);
        if (!$plan_id_data) {
            return [];
        }

        $plan_id_arr = array_column($plan_id_data,'plan_id');

        //拿到plan——id最新的一条记录
        $CheckData = $CheckDb->getAll(['type_ids' => $plan_id_arr,'type'=>1]);

//        var_dump($plan_id_data);
//        var_dump($PlanCheckData);
        $mapPlanCheck = [];
        foreach ($CheckData as $vv) {
            //
            if ((isset($mapPlanCheck[$vv['type_id']]) && $mapPlanCheck[$vv['type_id']]['check_id'] < $vv['check_id']) ||
                !isset($mapPlanCheck[$vv['type_id']])) {


                $mapPlanCheck[$vv['type_id']] = [
                    'type_id'       => $vv['type_id'],
                    'check_id' => $vv['check_id'],
                    'status'        => $vv['status'],
                    'organ_unit_id' => $vv['organ_unit_id'],
                ];
            }
        }

        $organ_unit_ids = array_unique(array_column($mapPlanCheck, 'organ_unit_id'));
        $ServiceData    = new ServiceData();
        $OrganUnitInfo  = $ServiceData->sendByParams('getOrganUnitInfo', ['search' => ['organ_unit_ids' => implode(',', $organ_unit_ids)], 'field' => 'organ_unit_id,name,level_id']);
        $OrganUnitInfo  = array_column($OrganUnitInfo, null, 'organ_unit_id');

        //var_dump($OrganUnitInfo);


        $needCheckPlanIds = [];
        foreach ($plan_id_data as $v) {

            //是否有权限核查 //有报错的话就是数据错误
            $endDataLevel = $OrganUnitInfo[$mapPlanCheck[$v['plan_id']]['organ_unit_id']]['area_level'];

            //next_company_area_id，$PlanData['area_level']
            $nextCheck                  = $this->getNextCheckInfo($v, $mapPlanCheck[$v['plan_id']], $endDataLevel);

            if ($nextCheck['next_company_area_id'] == $data['jwt_company_area_id']) {
                $needCheckPlanIds[] = $v['plan_id'];
            }
        }
        return $needCheckPlanIds;
    }

    /**
     * @param $data
     * @return bool
     * @throws PPosException
     */
    public function add($data)
    {

        $data['status'] = 1;
        $orm                                = new srcOrm();
        $rs                                 = $orm->createOne($data);
        if (!$rs) {
            throw new PPosException("添加失败", 400050006);
        }
        return ['plan_id'=>$rs['plan_id']];
    }

    /**
     * @param $data
     * @return string
     * @throws PPosException
     */
    public function update($data)
    {

        //判断状态，只有是草稿或者驳回的状态下，才能编辑
        $orm = new srcOrm();
        $plan = $orm->get(['plan_id' => $data['plan_id']], ['status']);
        if (!$plan) {
            throw new PPosException("无效的plan_id");
        }

        $this->checkWriteAuth($plan['status']);

        $update_field = $orm->dbBaseObj->getFillAble();
        $u            = [];
        foreach ($update_field as $v) {
            if (isset($data[$v])) {
                $u[$v] = $data[$v];
            }
        }
        $u['status'] = 1;
        $rs = $orm->update(['plan_id' => $data['plan_id']], $u);
        if (!$rs) {
            throw new PPosException("修改失败", 400050002);
        }

        return "修改成功";
    }


    /**
     * @param $plan_id
     * @return mixed
     * @throws PPosException
     */
    public function get($plan_id)
    {

        $orm               = new srcOrm();
        $search["plan_id"] = $plan_id;
        $rs                = $orm->get($search, []);
        if (!$rs) {
            return [];
        }
        $rs["area_level_str"] = $this->getAreaLevelStr($rs["area_level"]);
        $rs["status_str"]     = self::STATUS[$rs["status"]] ?? "--";

        $ServiceData = new ServiceData();
        //根据company—area-id 找到对应的城市id名称
        $CompanyAreaIdInfo  = $ServiceData->sendByParams('getCompanyAreaIdInfo', ['search' => ['company_area_ids' => [$rs['province'],$rs['city'],$rs['county']]], 'select' => ['company_area_id', 'name']]);
        $CompanyAreaIdInfo  = array_column($CompanyAreaIdInfo, 'name', 'company_area_id');
        $rs["province_str"] = $CompanyAreaIdInfo[$rs['province']] ?? "--";
        $rs["city_str"]     = $CompanyAreaIdInfo[$rs['city']] ?? "--";
        $rs["county_str"]   = $CompanyAreaIdInfo[$rs['county']] ?? "--";


        //
        $tagData = $this->getTagMap($rs['type_tag_ids']);
        $rs['type_tag_ids_array'] = $this->getTagShowInfo($rs['type_tag_ids'],$tagData);

        //详情页面不展示赛事状态
//        $match_status          = $this->getMatchStatus($rs["plan_start_time"], $rs["plan_end_time"]);
//        $rs["match_status"]     = $match_status['match_status'];
//        $rs["match_status_str"] = $match_status['match_status_str'];

        return $rs;
    }

    /**
     * @param $plan_id
     * @return string
     * @throws PPosException
     */
    public function del($plan_id)
    {


        $orm               = new srcOrm();
        $search["plan_id"] = $plan_id;

        //
        $activity = $orm->get($search,['status']);
        if (!$activity) {
            throw new PPosException("无效的计划id");
        }


        if (in_array($activity['status'],[3,5])) {
            throw new PPosException("审核通过的计划不可删除");
        }

        //软删除
        return $orm->update($search,['is_del' =>1]);
    }


    public function SyncCheck($data)
    {
        //批量核查
        //核查权限控制，什么人才能点击同步核查的操作 ,只有省级机构的人，才能点击同步核查
        if ($data['jwt_company_area_id'] >= 100) {
            //非省级的账号，不能核查
            throw new PPosException("省级机构账号才允许操作同步核查功能");
        }

        //核查为对应的状态
        $plan_id_arr = $this->checkStatus($data);

        $PlanBase    = new \PPOSLib\DB\Base\Plan();

        $plan_id_data = $PlanBase->getAll(['plan_ids' => $plan_id_arr], ['sync_check_status','plan_id', 'county', 'city', 'province', 'area_level', 'name', 'status']);
        if (!$plan_id_data) {
            throw new PPosException("无效的plan_ids");
        }

        foreach ($plan_id_data as $v) {

            if (!in_array($v['status'],[3,5])) {
                //此计划不是核查通过的状态，不能核查
                throw new PPosException("({$v['name']})计划未核查通过，不能同步核查该计划,计划id为{$v['plan_id']}']}");
            }

            if ($v['sync_check_status'] != 1) {
                //此计划不是待同步核查状态，不能核查
                throw new PPosException("({$v['name']})计划不是待同步核查状态，不能同步核查该计划,计划id为{$v['plan_id']}']}");
            }
        }

        //可以同步核查了
        $db = $PlanBase->db();
        $PlanDb = new \PPOSLib\DB\Base\Check($db);

        $db->begin();
        foreach ($plan_id_data as $v) {

            $update = ['sync_check_status' => $data['status']];
            if ($data['status'] == 3) {
                //驳回了，需要打回重新核查
                $update['status'] = 4;
            }

            $PlanBase->update(['sync_check_status' => 1,'plan_id' => $v['plan_id']],$update);

            //写入核查进度表
            $PlanDb->createOne([
                'plan_id'         => $v['plan_id'],
                'operator'        => $data['personnel_id'],
                'organ_unit_id'   => $data['jwt_organ_unit_id'],
                //$data['status'] = 2是通过的意思，但是plan_check3才是通过，所以做一层转化。
                'status'          => $data['status'] == 2 ? 3 : 4,
                'check_time'      => Functions::mode()->time(),
                'review_comments' => $data['review_comments'] ?? "",
            ]);
        }
        return $db->commit();
    }

    public function checkStatus($data)
    {
        if ($data['jwt_organ_unit_type'] != 1) {
            //不等于1，就不是机构，没有核查权限
            throw new PPosException("只有机构账号才有核查权限");
        }

        $plan_id_arr = explode(',', $data['plan_ids']);
        if (!is_array($plan_id_arr)) {
            throw new PPosException("plan_ids格式错误");
        }
        return $plan_id_arr;
    }

    public function GetAllById($data)
    {

        //根据ByPersonnelIds找到对应的机构单位名称
        if (empty($data['plan_ids'])) {
            throw new PPosException("plan_ids不可为空");
        }

        $plan_ids = explode(',', $data['plan_ids']);
        if (!is_array($plan_ids)) {
            throw new PPosException("plan_ids格式错误");
        }

        //
        $PlanOrm = new \PPOSLib\DB\Orm\Plan();
        return $PlanOrm->getAll(['plan_ids'=>$plan_ids],['plan_id','name']);
    }

    public function CheckTotal($data): array
    {

        $tableData = [];
        $statuss = [2,3,4];
        $company_area_data = $this->getCompanyAreaIdLevel($data['company_area_id']);
        if ($data['type'] == 1) {


            $company_area_data['search']['statuss'] = $statuss;
            $tableData = (new \PPOSLib\DB\Orm\Plan())->getAll($company_area_data['search'],['status']);
        } elseif($data['type'] == 2) {

            $ActivityOrm = new \PPOSLib\DB\Orm\Activity();
            $ActivityData = $ActivityOrm->getAll($company_area_data['search'],['activity_id']);
            $activity_ids = array_column($ActivityData,'activity_id');

            $ActivityHoldPlanOrm = new \PPOSLib\DB\Orm\ActivityHoldPlan();
            $tableData = $ActivityHoldPlanOrm->getAll(['activity_ids'=>$activity_ids,'statuss'=>$statuss],['status']);
        } else {
            //
        }
        $needCheck = $reject = $pass = 0;
        foreach ($tableData as $v) {
            if ($v['status'] == 2) {
                $needCheck++;
            } elseif ($v['status'] == 3) {
                $pass++;
            } elseif ($v['status'] == 4) {
                $reject++;
            } else {

            }
        }
        $total = count($tableData);
        $fun = Functions::mode();
        return [
            'number'=>['total'=>$total,'needCheck'=>$needCheck,'reject'=>$reject,'pass'=>$pass],
            'percent'=>['total'=>"100%",'needCheck'=>$fun->keep(($needCheck/$total)*100).'%','reject'=>$fun->keep(($reject/$total)*100).'%','pass'=>$fun->keep(($pass/$total)*100).'%'],
        ];

    }


    public function GetAllStatus($data): array
    {
        //找对应记录的审核中，通过，驳回，草稿的记录条数

        $draft = $reject = $pass = $checking = 0;


        if (isset($data['type']) && $data['type'] == 1) {
            $base = new \PPOSLib\DB\Orm\Plan();
            $all = $base->getAll([],['status','plan_id']);

            foreach ($all as $v) {
                //
                if ($v['status'] == 1) {
                    $draft++;
                } elseif ($v['status'] == 2) {
                    $checking++;
                } elseif ($v['status'] == 3 || $v['status'] == 5) {
                    $pass++;
                }elseif ($v['status'] == 4) {
                    $reject++;
                } else {
                    //
                }
            }

        } else {
            /*$ActivityBase = new \PPOSLib\DB\Orm\Activity();
            $ActivityHoldPlanBase = new \PPOSLib\DB\Orm\ActivityHoldPlan();

            $all = $ActivityBase->getAll([],['activity_id']);
            $activity_ids = array_column($all,'activity_id');

            $ActivityHoldPlanBase->getAll(['activity_id'=>$activity_ids],['activity_id','status']);
            $activity_plan = array_column($all,'status','activity_id');
            */


            /*$ActivityDB = new \PPOSLib\DB\Base\Activity();
            $all = $ActivityDB->esSearchDocInfo([],0,10000,['status']);

            foreach ($all["list"] as $v) {
                if (!isset($v['_source']['status']) || $v['_source']['status'] == 1 || $v['_source']['status'] == 0) {
                    $draft++;
                } elseif ($v['_source']['status'] == 2) {
                    $checking++;
                } elseif ($v['_source']['status'] == 3 || $v['_source']['status'] == 5) {
                    $pass++;
                }elseif ($v['_source']['status'] == 4) {
                    $reject++;
                } else {
                    //
                }
            }*/

            $ActivityDB = new \PPOSLib\DB\Base\Activity();
            $all = $ActivityDB->getAll([],['status']);

            foreach ($all as $v) {
                if ($v['status'] == 1 || $v['status'] == 0) {
                    $draft++;
                } elseif ($v['status'] == 2) {
                    $checking++;
                } elseif ($v['status'] == 3 || $v['status'] == 5) {
                    $pass++;
                }elseif ($v['status'] == 4) {
                    $reject++;
                } else {
                    //
                }
            }
        }

        return  ['all'=>$draft + $reject + $pass + $checking,'checking'=>$checking,'pass'=>$pass,'reject'=>$reject,'draft'=>$draft];

    }

    public function Revoke($data)
    {

        //撤回某个计划,未经过任何一级核查的话，就可以编辑。
        //如果状态是核查中，才可以撤回，如果未经任何节点核查，就撤回，
        //重置为草稿状态
        $PlanOrm = new \PPOSLib\DB\Orm\Plan();
        $PlanData = $PlanOrm->get(['plan_id'=>$data['plan_id']]);
        if (!$PlanData) {
            throw new PPosException("错误的plan_id");
        }

        if ($PlanData['status'] != 2) {
            //不能撤回了
            throw new PPosException("只有待核查状态的记录才可以撤回");
        }

        $CheckOrm = new \PPOSLib\DB\Orm\Check();
        $count = $CheckOrm->getCount(['type_id'=>$data['plan_id'],'type'=>1]);
        if ($count > 1) {
            //已经经过核查了.
            throw new PPosException("该记录不能撤回");
        }

        //撤回，重置为草稿状态
        $PlanOrm->update(['plan_id'=>$data['plan_id']],['status'=>1]);
    }

    /**
     * @param array $data
     * @param array $info
     * @return mixed
     * @throws \PPOSLib\Exception\PPosException
     */
    public function importVerification($data, $info)
    {
        //省市区
        $pasNames = [];
        $tagNames = [];
        foreach ($data as $k => $v) {
            if (!empty($v['province'])) {
                $pasNames[] = $v['province'];
            }
            if (!empty($v['city'])) {
                $pasNames[] = $v['city'];
            }
            if (!empty($v['county'])) {
                $pasNames[] = $v['county'];
            }
            if (!empty($v['type_tag_ids'])) {
                $tagNames[] = $v['type_tag_ids'];
            }
        }
        $pasNamesStr = implode(',', array_unique($pasNames));
        $psaInfo = [];
        if ($pasNamesStr != "") {
            $pas = new ServiceData();
            $pasNamesList = $pas->getPasNamesList($pasNamesStr);
            foreach ($pasNamesList as $k => $v) {
                $psaInfo[$v["name"]] = $v["company_area_id"];
            }
        }
        //通过项目名称获取对应的项目id
        $tagNamesStr = implode(',', array_unique($tagNames));
        $tagInfo = [];
        if($tagNamesStr!=""){
            $s = new ServiceData();
            $tagNamesList = $s->getTagsNamesList("event_activity_plan_project_kind",$tagNamesStr);
            foreach ($tagNamesList as $k => $v){
                $tagInfo[$v["name"]] = $v["tag_id"];
            }
        }
        //校验字段
        $orm = new srcOrm();
        $rs = $orm->importVerification($data, $info, $psaInfo, $tagInfo);
        return $rs;
    }

    /**
     * @param array $data
     * @param array $info
     * @return mixed
     * @throws \PPOSLib\Exception\PPosException
     */
    public function import($data, $info)
    {
        //省市区
        $pasNames = [];
        $tagNames = [];
        foreach ($data as $k => $v) {
            if (!empty($v['province'])) {
                $pasNames[] = $v['province'];
            }
            if (!empty($v['city'])) {
                $pasNames[] = $v['city'];
            }
            if (!empty($v['county'])) {
                $pasNames[] = $v['county'];
            }
            if (!empty($v['type_tag_ids'])) {
                $tagNames[] = $v['type_tag_ids'];
            }
        }
        $pasNamesStr = implode(',', array_unique($pasNames));
        $psaInfo = [];
        $psaLatLng = [];
        if ($pasNamesStr != "") {
            $pas = new ServiceData();
            $pasNamesList = $pas->getPasNamesList($pasNamesStr);
            foreach ($pasNamesList as $k => $v) {
                $psaInfo[$v["name"]] = $v["company_area_id"];
                $psaLatLng[$v["company_area_id"]]["lat"] = $v["lat"];
                $psaLatLng[$v["company_area_id"]]["lng"] = $v["lng"];
            }
        }
        //通过项目名称获取对应的项目id
        $tagNamesStr = implode(',', array_unique($tagNames));
        $tagInfo = [];
        if($tagNamesStr!=""){
            $s = new ServiceData();
            $tagNamesList = $s->getTagsNamesList("event_activity_plan_project_kind",$tagNamesStr);
            foreach ($tagNamesList as $k => $v){
                $tagInfo[$v["name"]] = $v["tag_id"];
            }
        }
        //校验字段
        $orm = new srcOrm();
        $rs = $orm->import($data, $info, $psaInfo,$psaLatLng, $tagInfo);
        return $rs;
    }

}

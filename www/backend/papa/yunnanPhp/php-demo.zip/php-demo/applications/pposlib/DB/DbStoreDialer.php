<?php

namespace PPOSLib\DB;

use Mix\Pool\DialerInterface;

/**
 * Class DatabaseDialer
 * @package Common\Dialers
 * @author liu,jian <coder.keda@gmail.com>
 */
class DbStoreDialer implements DialerInterface
{

        private $_poolMap = array();

        protected static $_poolStatus = false;

       

    /**
     * 拨号
     * @return \PPOSLib\DB\PDOConnection
     */
    public function dial()
    {
        return \PPOSLib\DB\PDOConnection::newInstance("dbStore");

    }

}

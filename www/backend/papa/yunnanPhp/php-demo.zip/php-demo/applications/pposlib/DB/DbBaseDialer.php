<?php

namespace PPOSLib\DB;

use Mix\Pool\DialerInterface;

/**
 * Class DatabaseDialer
 * @package Common\Dialers
 * @author liu,jian <coder.keda@gmail.com>
 */
class DbBaseDialer implements DialerInterface
{

    /**
     * 拨号
     * @return \PPOSLib\DB\PDOConnection
     */
    public function dial()
    {
        return \PPOSLib\DB\PDOConnection::newInstance("dbBase");
    }

}

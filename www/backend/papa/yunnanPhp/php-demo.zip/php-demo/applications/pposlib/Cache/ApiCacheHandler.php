<?php
/**
 * Created by PhpStorm.
 * User: pgf
 * Date: 19-8-19
 * Time: 下午6:16
 */
/**
 * @desc		 异常类
 * ---------------------------------------------------------------------
 * @author	unphp <unphp@qq.com>
 * @date		2014-03-05
 * @copyright	UnPHP 1.1
 * ---------------------------------------------------------------------
 */
namespace PPOSLib\Cache;

class ApiCacheHandler extends \Ppospro\PAGE\Cache\ApiCacheHandler
{

    public function view($type_id,$request_data,$response_data){
        return $response_data;
    }

}
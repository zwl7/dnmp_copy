<?php
namespace PPOSLib\Helpers;
use PPOSLib\Exception\PPosException;
use Ppospro\PAGE\Helpers\HttpService;

/**
 * Class ServiceData
 * @package PPOSLib\Helpers
 */
class CooperServiceData extends HttpService {




    private $zones = [
        'uid' => '/uid/get',
        'uidSlice' => '/uid/getSlice',
        'pushMQ' => '/mq/publish',
        'miniProgramLogin' => '/wxApi/miniProgram/login',
        'jsSdkGet' => '/wxApi/jsSdk/get',
        'checkContent' => '/wxApi/miniProgram/checkContent',
        'checkImages' => '/wxApi/miniProgram/checkImg',
        'miniProgramCode' => '/wxApi/miniProgram/getCode',
        'checkRealNameInfo' => '/wxApi/miniProgram/checkRealNameInfo',
        'miniProgramSendMsm' => '/wxApi/miniProgram/subscribeSend',
        'miniProgramVisitTrend' => '/wxApi/miniProgram/getDailyVisitTrend',
        'miniProgramSummary' => '/wxApi/miniProgram/getDailySummary',
        'miniProgramGetPhone' => '/wxApi/miniProgram/getPhone',
        'shanDongGetUserInfo' => '/shanDong/getUserInfo',
        'umsSelfApply' => '/pay/umsSelfApply',
        'umsUploadFile' => '/pay/umsUploadFile',
        'umsMerchAmount' => '/pay/umsMerchAmount',
        'umsMerchRecord' => '/pay/umsMerchRecord',
        'umsMerchSign' => '/pay/umsMerchSign',
        'umsMerchQuery' => '/pay/umsMerchQuery',
        'umsCompanyAccount' => '/pay/umsCompanyAccount',
        'umsCompanyAccountVerify' => '/pay/umsCompanyAccountVerify',

        //城市业余联赛服务
        'leagueMatchGetCode'      => '/leagueMatch/getCode',
        'leagueMatchPlayer'       => '/leagueMatch/player',
    ];

    public function __construct()
    {
        parent::__construct();
        $this->host = env('COOPER_SERVICE_API');
        //$this->host = "http://192.168.1.43:8192";
        $this->app_key = env('COOPER_SERVICE_API_KEY');

    }

    /**
     * Notes:银联商户进件
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-3-22
     * Time: 上午11:41
     * @param array $data
     * @return mixed
     * @throws \Ppospro\PAGE\Exception\PPosException
     */
    public function umsSelfApply($data = array()){
        $url = $this->host.$this->zones['umsSelfApply'];
//        "accesser_user_id": "202303220318230005" 业务方唯一凭证建议用户ID
//        "bank_acct_name": "何自助", 开户行账号名称
//        "bank_acct_no": "6225880011112222", 卡号
//        "bank_acct_type": "0", 账号类型 0：个人 1：公司
//        "bank_no": "105521000885", 开户行行号
//        "having_fixed_busi_addr": "0", 是否有门店
//        "legal_card_deadline": "2030-12-06", 法人证件截止日期
//        "legal_idcard_no": "320623195607134430", 法人证件号
//        "legal_mobile": "16607461234", 法人电话
//        "legal_name": "何自助", 法人
//        "legal_occupation": "5", //法人职业:0-各类专业、技术人员 1-国家机关、党群组织、企事业单位的负责人 2-办事人员和有关人员 3-商业工作人员 4-服务性工作人员 5-农林牧渔劳动者 6-生产工作、运输工作和部分体力劳动者 7-不便分类的其他劳动者
//        "legal_sex": "5",企业类型为小微商户时必填，参数按国际标准传 C 0-未知的性别 1-男性 2-女性 5-女性改（变）为男性 6-男性改（变）为女性 9-未说明的性别
//        "mccCode": "5331",
//        "mchntType": "1",商户类型，0-实体商户，1-网络商户 2-实体兼线上
//        "reg_mer_type": "02", //注册类型 00：企业商户 01：个人工商户 02：小微商户 03：机关事业单位或社会团体 05:民办非企业
//        "shop_addr_ext": "黄埔区科学城科研路12号",地址
//        "shop_city_id": "460100", 市
//        "shop_country_id": "460105",区
//        "shop_name": "何自助小卖部",店铺名
//        "shop_province_id": "46",省
//        "pic_list": [["document_type"=> "0001","file_path"=>"法人身份证url地址"],["document_type"=> "0011","file_path"=>"法人身份证反面url地址"],["document_type"=> "0025","file_path"=>"银行卡正面照url地址"],["document_type"=> "0007","file_path"=>"自拍照url地址"],["document_type"=> "0034","file_path"=>"网站或APP截图url地址"],["document_type"=> "0019","file_path"=>"第三方证明url地址"],["document_type"=> "0021","file_path"=>"商品照片url地址"]]
        foreach ($data as $k=>$v){
            if (is_numeric($v)){
                $data[$k] = strval($v);
            }
        }
        $data['mccCode'] = "5331";
        $data['legal_sex'] = "0";
        $data['legal_occupation'] = "0";
        $data['product'][]=['product_id'=>"8",'receipt2Line'=>"0"];//固定值
        $body['content_req'] = json_encode($data);
        $body['t_config_id'] = "10570";
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }

    public function umsMerchAmount($data = array()){
        $url = $this->host.$this->zones['umsMerchAmount'];
        $body['req_seq_no'] = $data['req_seq_no'];
        $body['mer_no'] = $data['mer_no'];
        $body['pay_amt'] = $data['pay_amt'];
        $body['t_config_id'] = "10570";
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }

    public function umsMerchRecord($data = array()){
        $url = $this->host.$this->zones['umsMerchRecord'];
        //$body['user_id'] = $data['user_id'];
        $body['req_seq_no'] = $data['req_seq_no'];
        $body['mer_no'] = $data['mer_no'];
        $body['req_date'] = $data['req_date'];
        $body['t_config_id'] = "10570";
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }

    public function umsMerchQuery($data = array()){
        $url = $this->host.$this->zones['umsMerchQuery'];
        //$body['user_id'] = $data['user_id'];
        $body['req_seq_no'] = $data['sign_no'];
        $body['t_config_id'] = "10570";
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }
    public function umsMerchSign($data = array()){
        $url = $this->host.$this->zones['umsMerchSign'];
        //$body['user_id'] = $data['user_id'];
        $body['req_seq_no'] = $data['sign_no'];
        $body['t_config_id'] = "10570";
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }

    public function umsCompanyAccount($data = array()){
        $url = $this->host.$this->zones['umsCompanyAccount'];
        //$body['user_id'] = $data['user_id'];
        $body['req_seq_no'] = $data['sign_no'];
        $body['t_config_id'] = "10570";
        $body['company_account'] = $data['bank_account_num'];
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }
    public function umsCompanyAccountVerify($data = array()){
        $url = $this->host.$this->zones['umsCompanyAccountVerify'];
        //$body['user_id'] = $data['user_id'];
        $body['req_seq_no'] = $data['sign_no'];
        $body['t_config_id'] = $data['t_config_id'];
        $body['trans_amt'] =  $data['trans_amt'];
        $body['company_account'] = $data['bank_account_num'];
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }

    public function umsUploadFile($data = array()){
        $url = $this->host.$this->zones['umsUploadFile'];
        $content_req['file_path'] = $data['file_path'];
        $content_req['document_type'] = $data['document_type'];
        $body['content_req'] = json_encode([$content_req]);
        $body['user_id'] =$data['user_id'];
        $body['t_config_id'] = "10570";
        return $this->sendRequest($url,"POST",$body,1,true,60);
    }
    public function shanDongGetUserInfo($token){
        $url = $this->host.$this->zones['shanDongGetUserInfo'];
        $body["token"] = $token;
        return $this->sendRequest($url,"POST",$body);
    }
    public function miniProgramCode($page,$scene,$env_version="",$company_id=0){
        $url = $this->host.$this->zones['miniProgramCode'];
        $body["page"] = $page;
        $body["scene"] = $scene;
        if ($env_version){
            $body["env_version"] = $env_version;
        }

        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function miniProgramVisitTrend($start_date,$end_date,$company_id){
        $url = $this->host.$this->zones['miniProgramVisitTrend'];
        $body["begin_date"] = $start_date;
        $body["end_date"] = $end_date;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function miniProgramGetPhone($code,$company_id){
        $url = $this->host.$this->zones['miniProgramGetPhone'];
        $body["code"] = $code;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function miniProgramDailySummary($start_date,$end_date,$company_id){
        $url = $this->host.$this->zones['miniProgramSummary'];
        $body["begin_date"] = $start_date;
        $body["end_date"] = $end_date;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function miniProgramSendMsm($openid,$template_id,$data,$page = ""){
        $url = $this->host.$this->zones['miniProgramSendMsm'];
        $body["openid"] = $openid;
        $body["template_id"] = $template_id;
        $body["data"] = $data;
        $body["page"] = $page;
        return $this->sendRequest($url,"POST",$body);
    }

    public function checkRealNameInfo($openid,$RealName,$CredId,$code,$company_id){
        $url = $this->host.$this->zones['checkRealNameInfo'];
        $body["openid"] = $openid;
        $body["real_name"] = $RealName;
        $body["cred_id"] = $CredId;
        $body["code"] = $code;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function checkImages($image_url,$company_id){
        $url = $this->host.$this->zones['checkImages'];
        $body["image_url"] = $image_url;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function checkContent($data,$scene = 1,$version = 2){
        $url = $this->host.$this->zones['checkContent'];
        //content 	string 	是 	需检测的文本内容，文本字数的上限为2500字，需使用UTF-8编码
        //version 	number 	是 	接口版本号，2.0版本为固定值2
        //scene 	number 	是 	场景枚举值（1 资料；2 评论；3 论坛；4 社交日志）
        //openid 	string 	是 	用户的openid（用户需在近两小时访问过小程序）
        $body["content"] = $data['content'];
        $body["openid"] = $data['open_id'];
        $body["version"] = $version;
        $body["scene"] = $scene;
        return $this->sendRequest($url,"POST",$body);
    }

    public function miniProgramLogin($code,$company_id){
        $url = $this->host.$this->zones['miniProgramLogin'];
        $body["code"] = $code;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }

    public function jsSdkGet($host_url,$company_id){
        $url = $this->host.$this->zones['jsSdkGet'];
        $body["url"] = $host_url;
        $body["company_id"] = $company_id;
        return $this->sendRequest($url,"POST",$body);
    }
    public function Uid($name,$count = 1 ,$start_id = 1){
        $url = $this->host.$this->zones['uid'];
        $body["name"] = $name;
        $body["start_id"] = $start_id;
        if($count > 1){
            $url = $this->host.$this->zones['uidSlice'];
            $body["count"] = $count;
        }
        return $this->sendRequest($url,"POST",$body);
    }

    /**
     * Notes:队列发布消息
     * User: chenlu
     * Email: chenlu@papa.com.cn
     * Date: 19-11-26
     * Time: 下午4:58
     * @return array
     * @throws PPosException
     */
    public function pushMQ($exchange_name, $route_key, $data, $delay_time=0)
    {
        $url = $this->host.$this->zones['pushMQ'];
        $body["exchange_name"] = $exchange_name;
        $body["route_key"] = $route_key;
        $body["data"] = $data;
        $body["delay_time"] = $delay_time;
        $body["app_id"]= $this->app_id;
        return $this->sendRequest($url,"POST",$body);
    }

    /**
     * Notes: 获取赛事唯一码
     * User: 闻铃
     * DateTime: 2023/5/24 下午3:08
     * @param $mname 赛事名称（必填）
     * @param string $sname 系列赛子赛事名（非必填）
     * @return mixed
     * @throws \Ppospro\PAGE\Exception\PPosException
     */
    public function leagueMatchGetCode($mname,$sname = ''){
        $url = $this->host.$this->zones['leagueMatchGetCode'];
        $body["mname"] = $mname;
        if (!empty($sname)) {
            $body["sname"] = $sname;
        }
        $body['config'] = $this->pkActivityPushConfig();
        var_dump($body);
        return $this->sendRequest($url,"POST",$body);
    }

    /**
     * Notes:赛事参赛成员上传接口
     * User: 闻铃
     * DateTime: 2023/5/24 下午3:14
     * @param $data
     * @return mixed
     * @throws \Ppospro\PAGE\Exception\PPosException
     */
    public function leagueMatchPlayer($data){
        $url = $this->host.$this->zones['leagueMatchPlayer'];
        $body['data'] = json_encode($data);
        $body['config'] = $this->pkActivityPushConfig();
        var_dump($body);
        return $this->sendRequest($url,"POST",$body);
    }

    public function pkActivityPushConfig()
    {
//        return [
//            'client_id'=>'shf089a007e7c3055f',
//            'client_secret'=>'463c04ebfa0211ed8ee02047477e235c',
//            'client_domain'=>'https://service.sso.movecloud.cn',
//        ];
//        return [
//            'client_id'=>'sh9bc06e132909ac88',
//            'client_secret'=>'c8a642199fd6676da5b149a99f22369e',
//            'client_domain'=>'https://service.sso.movecloud.cn',
//        ];
//
//        return [
//            'client_id'=>'sh9bc06e132909ac',
//            'client_secret'=>'c8a642199fd6676da5b149a99f22369e',
//            'client_domain'=>'https://service.sso.movecloud.cn',
//        ];
        return json_encode([
            'client_id'=>'sh25654cdcc36d8cd3',
            'client_secret'=>'c0611994bf5a81f068423df33de61320',
            'client_domain'=>'https://service.sso.movecloud.cn',
        ]);


    }
}

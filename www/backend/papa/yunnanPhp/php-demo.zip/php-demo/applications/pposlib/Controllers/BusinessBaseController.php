<?php


namespace PPOSLib\Controllers;

use PPOSLib\Helpers\Cache;
use PPOSLib\Helpers\ServiceData;

class BusinessBaseController extends BaseController
{

    public function __construct()
    {
        parent::__construct();

    }

    public function searchByAuth($data)
    {
        if (isset($data['jwt_organ_unit_type'])) {
            //判断当前账号身份，如果是单位，只查询，当前单位自己填报的计划

            //如果是机构，查询当前机构的区域id，以及以下的
            if ($data['jwt_organ_unit_type'] == 1) {
                if ($data['down_unit_ids']!="ALL"){
                    $data['organ_unit_ids'] = explode(',',$data['down_unit_ids']);
                    $data['organ_unit_ids'][] = $data['jwt_organ_unit_id'];
                }
                $data['statuss']=[2,3,4,5,6];
            } elseif ($data['jwt_organ_unit_type'] == 2) {
                $data['organ_unit_id'] = $data['jwt_organ_unit_id'];

            } else {
                //超管，没有限制，不增加搜索条件


            }
        }
        return $data;
    }
}

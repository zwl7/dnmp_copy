<?php
/**
 * Created by PhpStorm.
 * User: PGF
 * Email: pgf@fealive.com
 * Date: 21-3-25
 * Time: 下午5:32
 */
namespace PPOSLib\Config;

use Mix\Core\Bean\AbstractObject;

class Config extends AbstractObject
{
    /**
     * 路由变量规则
     */
    const ROUTE_PATTERNS = [
        'id' => '\d+',
        '{staticField}' => '[\w\-\.]+',
    ];

    /**
     * 路由规则
     */
    const ROUTE_RULES = [
        // 一级路由
        '/ping' => ['Ping', 'Index'],
        '/demo/wx{controller}/{action}' => ['Wx/{controller}', '{action}', 'middleware' => ['First',"Sign",'WxLogin']],
        '/demo/enterRecord/adminRecord' => ['Stadium/EnterRecord', 'adminRecord', 'middleware' => ['First', "Sign", 'CompanyLogin']],
        '/demo/gate/{action}' => ['Stadium/Gate', '{action}', 'middleware' => ['Gate']],
        '/demo/{controller}/{action}' => ['Business/{controller}', '{action}', 'middleware' => ['First',"Sign",'BusinessLogin']],

        '/eventActivity/login/login' => ['Business/Login', 'login', 'middleware' => ['First']],
        '/eventActivity/wx{controller}/{action}' => ['Wx/{controller}', '{action}', 'middleware' => ['First','CompanyLogin']],
        '/eventActivity/{controller}/{action}' => ['Business/{controller}', '{action}', 'middleware' => ['First','CompanyLogin','Before']],
        '/eventActivity/static/{staticPath}/{staticField}' => ['Business/Static', 'Down'],
    ];



    const ERROR_CODES = [
        4000070001=>"通道不存在",
        4000050100=>"无权限提交审核",

    ];

    const API_CACHE_RULE = [
        "_member_wxMember_getAppID"=>["field"=>["tag","host"],"time"=>3600000,"key"=>"oneWxAppID","fun"=>[]],
    ];


}

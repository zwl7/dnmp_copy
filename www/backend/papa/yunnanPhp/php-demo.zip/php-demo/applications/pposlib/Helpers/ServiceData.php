<?php
namespace PPOSLib\Helpers;
use PPOSLib\Exception\PPosException;
use Ppospro\PAGE\Helpers\HttpService;

/**
 * Class ServiceData
 * @package PPOSLib\Helpers
 */
class ServiceData extends HttpService {



    private $zones = [
        'operator' => '/base/personnel/getByIds',
        'personnelRoles' => '/base/personnel/getRolesByIds',

        'searchPersonnel' => '/base/personnel/getRolesByIds',

        'uploadByBase64' => '/base/images/uploadByBase64',
        'loginMp' => '/base/account/loginMp',
        'ConfigInfo' => '/cfg/cfgCommon/getByCode',
		'getPaymentWayInfo' => '/cfg/cfgPaymentWay/get',
        'getShopOrderList' => '/shop/order/list',
        'createOrder' => '/shop/order/create',
        'refundOrder' => '/shop/refund/create',
        'payOrder' => '/shop/order/pay',
		'refundNotice' => '/shop/refund/notice',
        'refund' => '/shop/order/refund',
        'sendMessage' => '/wxMp/message/send',


        //获取机构单位信息
        'getOrganUnitInfo' => '/organUnit/organUnit/getOrganUnitInfo',
        'getInfoByCompanyAreaId' => '/organUnit/organUnit/getInfoByCompanyAreaId',
        'getDataDictionary' => '/organUnit/dataDictionary/get',
        //
        'getOrganUnitCompanyArea' => '/organUnit/companyArea/level',
        'getCompanyAreaIdInfo' => '/organUnit/companyArea/getInfoByIds',
        'getCommunityInfo' => '/organUnit/companyArea/getCommunityInfo',

        //标签管理url---start---

        'getAllTag' => '/organUnit/tag/getAll',
        'getAllTagGroup' => '/organUnit/tagGroup/getAll',

        //---end---
        //操作日志
        'getOperationLog' => '/gateway/interfaceTrace/list',
        'gatewayGetUpdate' => '/gateway/interfaceTrace/getUpdate',
        'getOrganUnitByPersonnelIds' => '/organUnit/organUnit/getOrganUnitByPersonnelIds',

        //
        'getAreaIdByNames' => '/organUnit/organUnit/getAreaIdByNames',
        'getTagAllBySearch' => '/organUnit/tag/getAllBySearch',
        'dataVerificationLogAdd' => '/pub/dataVerificationLog/add',
        'dataImportLogAdd' => '/pub/dataImportLog/add',
        'getParentOrganByArea' => '/organUnit/organUnit/getParentOrganByArea',

        //社区运动会
        'sqSportEventSync' => '/api/v1/sqydh/eventSync' //赛事数据同步
    ];

    public function __construct()
    {
        parent::__construct();

    }
    //获取多个机构单位信息
    public function getOrganUnitInfo($organUnitIds, $field = ""){
        $url = $this->host.$this->zones['getOrganUnitInfo'];
        $search = [];
        if (!empty($organUnitIds)) {
            $search["organ_unit_ids"] = $organUnitIds;
        }
        $body["search"] = $search;
        if (!empty($field)) {
            $body["field"] = $field;
        }
        return $this->sendRequest($url,"POST",$body);
    }
    public function getParentOrganByArea($company_area_id){
        $url = $this->host.$this->zones['getParentOrganByArea'];
        $body["company_area_id"]= $company_area_id;

        return $this->sendRequest($url,"POST",$body);
    }
    public function getTagsNamesList(string $type,string $str){
        $url = $this->host.$this->zones['getTagAllBySearch'];
        $body["type"]= $type;
        $body["names"]= $str;
        $body["select"]= ["tag_id","name"];
        return $this->sendRequest($url,"POST",$body);
    }
    public function getPasNamesList(string $str){
        $url = $this->host.$this->zones['getAreaIdByNames'];
        $body["names"]= $str;
        return $this->sendRequest($url,"POST",$body);
    }
    //导入、核验
    public function dataVerificationLogAdd(array $data){
        $url = $this->host.$this->zones['dataVerificationLogAdd'];
        $body["data"]=json_encode($data);
        return $this->sendRequest($url,"POST",$body);
    }
    public function dataImportLogAdd(array $data){
        $url = $this->host.$this->zones['dataImportLogAdd'];
        $body["data"]=json_encode($data);
        return $this->sendRequest($url,"POST",$body);
    }
    public function getOperationLog($data)
    {
        $url = $this->host.$this->zones['getOperationLog'];
        $body = $data;
        return $this->sendRequest($url,"POST",$body);
    }
    public function gatewayGetUpdate($data)
    {
        $url = $this->host.$this->zones['gatewayGetUpdate'];
        $body = $data;
        return $this->sendRequest($url,"POST",$body);
    }
    public function getOrganUnitByPersonnelIds($data)
    {
        $url = $this->host.$this->zones['getOrganUnitByPersonnelIds'];
        $body = $data;
        return $this->sendRequest($url,"POST",$body);
    }
    public function getOrganUnitCompanyArea($data)
    {
        $url = $this->host.$this->zones['getOrganUnitCompanyArea'];
        $body = $data;
        return $this->sendRequest($url,"POST",$body);
    }
    public function sendMessage($data)
    {
        $url = $this->host.$this->zones['sendMessage'];
        $body = $data;
        return $this->sendRequest($url,"POST",$body);
    }
    public function refundOrder($body){
        $url = $this->host.$this->zones['refundOrder'];
        return $this->sendRequest($url,"POST",$body);
    }

    public function payOrder($body){
        $url = $this->host.$this->zones['payOrder'];
        $body["pay_sence"]="bs";
        $body["discount_info"]='{}';
        return $this->sendRequest($url,"POST",$body);
    }

    public function refundNotice($body){
        $url = $this->host.$this->zones['refundNotice'];
        return $this->sendRequest($url,"POST",$body);
    }

    public function baseLogin($body){
        $url = $this->host.$this->zones['loginMp'];
        return $this->sendRequest($url,"POST",$body);
    }

    public function refund($body){
        $url = $this->host.$this->zones['refund'];
        return $this->sendRequest($url,"POST",$body);
    }
    /**
     * Notes:配置列表
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 20-7-17
     * Time: 上午11:23
     * @param $code
     * @param int $company_id
     * @param int $business_id
     * @param int $stadium_id
     * @return mixed
     * @throws PPosException
     */
    public function ConfigInfo($code,$company_id=0,$business_id=0,$stadium_id=0,$time=0)
    {
        $url = $this->host.$this->zones['ConfigInfo'];
        $body["cfg_code"]= $code;
        $body["company_id"] = $company_id;
        $body["business_id"] = $business_id;
        $body["stadium_id"] = $stadium_id;
        if($time){
            $body["enable_time"] = $time;
        }
        return $this->sendRequest($url,"POST",$body,1,false);
    }


    public function getSysOptionList($type, $column = ""){
        $url = $this->host.$this->zones['sysOptionList'];
        $body["type"]=$type;
        $body["column"]=$column;
        return $this->sendRequest($url,"POST",$body);
    }




	public function uploadByBase64($image_base64, $image_path){
		if(!$image_base64){
			return [];
		}
		//$this->host = "api.ppos.pro:8180";
		$url = $this->host.$this->zones['uploadByBase64'];
		$search["image_base64"]= $image_base64;
		$search["image_path"]= $image_path;
		return $this->sendRequest($url,"POST",$search);
	}

    public function setBusinessId($business_id){
        $this->business_id = $business_id;
    }
    public function setStadiumId($stadium_id){
        $this->stadium_id = $stadium_id;
    }
    public function setPersonnelId($personnel_id){
        $this->personnel_id = $personnel_id;
    }
    public function setCompanyId($company_id){
        $this->company_id = $company_id;
    }


    public function operator(array $ids,$column =''){
        if(!$ids){
            return [];
        }
        $url = $this->host.$this->zones['operator'];
        $body["ids"]= implode(",",$ids);
        $body["column"]=$column;
        return $this->sendRequest($url,"POST",$body);
    }

    /**
     * Notes: 获取员工对应的信息
     * User: 闻铃
     * DateTime: 2023/10/19 09:53
     * @param array $ids
     * @return array|mixed
     * @throws \Ppospro\PAGE\Exception\PPosException
     */
    public function personnelRoles(array $ids){
        if(!$ids){
            return [];
        }
        $url = $this->host.$this->zones['personnelRoles'];
        $body["ids"]= implode(",",$ids);
        return $this->sendRequest($url,"POST",$body);
    }


    //获取shop系统订单
    public function getShopOrderList($page,$size,$order_status,$platform_id){
        $url = $this->host.$this->zones['getShopOrderList'];
        $body["page"]=$page;
        $body["size"]=$size;
        $body["order_status"]=$order_status;
        $body["platform_id"]=$platform_id;
        return $this->sendRequest($url,"POST",$body);
    }


    public function sendByParams(string $url,array $body = [])
    {
        if (isset($this->zones[$url])) {
            return $this->sendRequest($this->host.$this->zones[$url],"POST",$body);
        }
        throw new PPosException("无效的serviceUrl:{$url}");
    }

}

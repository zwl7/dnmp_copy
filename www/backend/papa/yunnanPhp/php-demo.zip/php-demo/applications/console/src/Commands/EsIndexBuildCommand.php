<?php

namespace Console\Commands;

use PPOSLib\Console\EsAction;
use PPOSLib\Console\Xapiand;
use \Ppospro\PAGE\Utils\Dbdriver\MixphpEngine;
use Mix\Console\CommandLine\Flag;
/**
 * Class HelloCommand
 * @package Console\Commands
 * @author liu,jian <coder.keda@gmail.com>
 */
class EsIndexBuildCommand
{
    //php ./bin/mix-console EsIndexBuild  -env .dev -t Activity -c 476
    //php ./bin/mix-console EsIndexBuild  -env .env -t Activity -c 476
    //php ./bin/mix-console EsIndexBuild -env .env -c 476
    public function main()
    {
        go(function (){
            $dbBase = app()->dbBase;
            MixphpEngine::setPool(env("DATABASE_PREFIX").env("DATABASE_DBNAME"),$dbBase);
            $class_sign_report = new EsAction();
            $t = Flag::string(['t', 'type'], 'All');
            $company_id = Flag::string(['c', 'company_id'], 0);
            if($t!='All'){
                $action = 'build'.$t.'Index';
                if(!method_exists ( $class_sign_report , $action )){
                    echo 'type 不正确';
                    return false;
                }
                $class_sign_report->$action($company_id);
                return true;
            }
            $class_sign_report->buildActivityIndex($company_id);
            $class_sign_report->buildPlanIndex($company_id);
        });
        \Swoole\Event::wait();

    }


}

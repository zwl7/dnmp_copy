<?php

namespace Console\Commands;

use Matrix\Exception;
use Mix\Console\CommandLine\Flag;
use PPOSLib\DB\Stadia\TaskConfig;
use PPOSLib\DB\Stadia\TaskList;
use PPOSLib\Exception\PPosException;
use PPOSLib\Logic\StorageGoods;
use Ppospro\PAGE\Utils\Dbdriver\MixphpEngine;
use Ppospro\PAGE\Utils\Des3;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use Mix\Core\Timer;
class ExportCommand
{
    /**
     *  @var \Ppospro\PAGE\Utils\Des3
     */
    protected $_des3;
    protected $_log;
    protected $_business_id;
    protected $_stadium_id;
    protected $_data =[];
    protected $_cellIndex = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ', 'BA', 'BB', 'BC', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BK', 'BL', 'BM', 'BN', 'BO', 'BP', 'BQ', 'BR', 'BS', 'BT', 'BU', 'BV', 'BW', 'BX', 'BY', 'BZ', 'CA', 'CB', 'CC', 'CD', 'CE', 'CF', 'CG', 'CH', 'CI', 'CJ', 'CK', 'CL', 'CM', 'CN', 'CO', 'CP', 'CQ', 'CR', 'CS', 'CT', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ');
    /**
     * 主函数
     */
    public function main()
    {
        $dbBase = app()->dbBase;
        MixphpEngine::setPool(env("DATABASE_PREFIX").env("DATABASE_DBNAME"),$dbBase);
        // 持续定时
        $timer = new Timer();
        $timer->tick(5000, function () {
            $this->checkTask();
        });
    }

    private function checkTask(){

        $conf_mod = new TaskConfig();
        $db = $conf_mod->db();
        $list_mod = new TaskList($db);
        $db->begin();
        $s["status"]=0;
        $task = $list_mod->getOne($s);
        if (empty($task)||$task["status"]!=0){
            $db->commit();
            app()->log->info("无任务");
            return [];
        }
        $s["task_id"]=$task['task_id'];
        $task = $list_mod->getOne($s,[],true);
        if (empty($task)||$task["status"]!=0)
        {
            $db->commit();
            app()->log->info("无任务");
            return [];
        }
        $c["task_code"] = $task["task_code"];
        $c["type"]=4;
        $conf = $conf_mod->getOne($c,["task_path", "task_code"]);
        if(!$conf){
            $db->commit();
            app()->log->error("任务不存在");
            return [];
        }
        $rs = $list_mod->update($s,["status"=>2]);
        if(!$rs){
            $db->commit();
            app()->log->error("任务更新失败");
            return [];
        }
        $db->commit();

        $this->_des3 = new Des3("A7894FGHIdjlvrOPQRqweVWX", 15975346);
        $data = json_decode($task["param"], true);
        $this->_log =  "--------开始处理任务,任务ID:" . $task["task_id"] . "-----------------\n";
        $this->_log .= "任务参数:\n";
        $this->_log .= ($task["param"]) . "\n";
        $action = str_replace("/", "", $conf["task_path"]);
        try{
            $this->_business_id = $task["business_id"];
            $this->_stadium_id = $task["stadium_id"];
            $this->_data = $data;
            $rs = $this->$action($task["task_id"]);
            var_dump($rs);
            app()->log->info($this->_log);
        }catch (\Exception $e){
            //失败任务
            $this->_log .= $e->getFile(). "\n";
            $this->_log .= $e->getLine(). "\n";
            $this->_log .= $e->getMessage(). "\n";
            $rs = $list_mod->update($s,["status"=>0,"result"=>$this->_log]);
            $this->_log .= $e->getTraceAsString(). "\n";
            app()->log->error($this->_log);
        }
    }

    /**
     * 商品库存列表导出
     * @param $task_id
     * @return array
     * @throws PPosException
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     */
    private function storageGoodsListExport($task_id)
    {
        $headTitle = array("product_no" => '商品编号', "sku" => '商品SKU', "product_name" => '商品名称', "bar_code" => '商品条码', "sku_property" => '商品规格', "product_cate_name" => '商品分类', "storage_name" => '所属仓库', "leave_num" => '库存数量', "in_price" => '库存平均成本');
        $data = $this->_data;
        $logic = new StorageGoods($data["authorization"]);
        $data_fun = array($logic,"getList");

        $data["keyword"]= isset($data["keyword"]) ? $data["keyword"] : "";
        $data["storage_id"]= isset($data["storage_id"]) ? $data["storage_id"] : "";
        $data["product_cate_id"]= isset($data["product_cate_id"]) ? $data["product_cate_id"] : 0;
        $this->_data = $data;
        $fun  = function ($data){
            $data["sku_property"] = implode(",",$data["sku_property"]);
            return $data;
        };
        return $this->export($task_id,$headTitle,$data_fun,"商品库存列表",$fun);
    }

    /**
     * 商品盘点列表导出
     * @param $task_id
     * @return array
     * @throws PPosException
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     */
    private function goodsCheckExport($task_id)
    {
        $headTitle = array("product_no" => '商品编号', "sku" => '商品SKU*', "product_name" => '商品名称', "bar_code" => '商品条码', "sku_property" => '商品规格', "product_cate_name" => '商品分类', "storage_name" => '所属仓库', "leave_num" => '库存数量*', "check_num" => '盘点数量*',);
        $logic = new StorageGoods();
        $data_fun = array($logic,"getList");
        $data = $this->_data;
        $data["keyword"]= isset($data["keyword"]) ? $data["keyword"] : "";
        $data["storage_id"]= isset($data["storage_id"]) ? $data["storage_id"] : "";
        $data["product_cate_id"]= isset($data["product_cate_id"]) ? $data["product_cate_id"] : 0;
        $this->_data = $data;
        $fun  = function ($data){
            $data["sku_property"] = implode(",",$data["sku_property"]);
            $data["check_num"] = "";
            return $data;
        };
        return $this->export($task_id,$headTitle,$data_fun,"商品盘点列表",$fun);
    }

    /**
     * 普通型导出
     * @param $task_id
     * @param array $headTitle 表头
     * @param array|string $data_fun 数据回调方式 对象方法:array($obj, "b")
     * @param int $size 每页处理数
     * @return array
     * @throws PPosException
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     */
    private function export($task_id,$headTitle,$data_fun,$file_name,$data_handle_fun=null,$size=500)
    {
        $all_start_time = microtime(true);
        $s_m = memory_get_usage();
        $now_date = date("Ymd", time());
        $uniqid = md5($this->_business_id . $this->_stadium_id . uniqid());
        $list_mod = new TaskList();
        //保存路径
        $savePath = env("APP_PUBLIC_PATH") . '/export/' . $uniqid . "/";
        if (!is_dir($savePath))
        {
            $res = mkdir($savePath, 0755, true);
            if (!$res)
            {
                throw new PPosException("存放下载文件目录创建失败！", 4000608231);
            }
        }
        $file_path = $savePath . $now_date . '_' . $this->_business_id . ".xls";
        /** @var Spreadsheet $objSpreadsheet */
        $objSpreadsheet = new Spreadsheet();
        /* 设置默认文字居左，上下居中 */
        $styleArray = [
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical'   => Alignment::VERTICAL_CENTER,
            ],
        ];
        $objSpreadsheet->getDefaultStyle()->applyFromArray($styleArray);
        /* 设置Excel Sheet */
        $activeSheet = $objSpreadsheet->setActiveSheetIndex(0);
        $cellIndex = $this->_cellIndex;
        $page = 1;
        $is_end = false;
        $start_time = microtime(true);

        $line_num = 1;
        $lineIndex = 0;
        foreach ($headTitle as $text)
        {
            $activeSheet->setCellValueExplicit($cellIndex[$lineIndex] . $line_num, $text, DataType::TYPE_STRING);
            $lineIndex++;
        }
        $data_list = [];

        app()->IsolationFillable->setFillable(
            array(
                "business_id"=>$this->_business_id,
                "stadium_id"=>$this->_stadium_id,
            )
        );
        while (!$is_end)
        {
            $data_list = call_user_func($data_fun, $page, $size,$this->_data);
            foreach ($data_list['list'] as $d)
            {
                if($data_handle_fun){
                    $d = call_user_func($data_handle_fun,$d);
                }
                //下一行数据
                $line_num++;
                $c = 0;
                foreach ($headTitle as $k => $n)
                {
                    if(!isset($d[$k])){
                        $c++;
                        continue;
                    }
                    $cell = $cellIndex[$c] . $line_num;
                    //转义等号 Worksheet!D11282 -> Formula Error: Operator '=' has no operands
                    if(is_array($d[$k])){
                        $d[$k] = implode(",",$d[$k]);
                    }
                    if (strpos($d[$k], '=') === 0)
                    {
                        $d[$k] = "'" . $d[$k];
                    }
                    $activeSheet->setCellValueExplicit($cell, $d[$k], DataType::TYPE_STRING);
                    //下一单元格
                    $c++;
                }
            }
            if ($data_list['page'] * $data_list['size'] >= $data_list["count"])
            {
                $rate = 100;
                $is_end = true;
            } else
            {
                $rate = round($data_list['page'] * $data_list['size'] / $data_list["count"], 3) * 100;
                if ($rate >= 100)
                {
                    $rate = 999.99;
                }
            }

            $page++;
            if ($page > 10000)
            {
                break;
            }
            // 更新任务状态
            $end_time = microtime(true);
            $cat_time = round($end_time - $start_time, 4);
            $log = "耗时:" . $cat_time . "\n";
            $log .= "page:" . $page . "\n";
            $log .= "rate:" . $rate . "\n";
            $e_m = memory_get_usage();
            $log .= "内存使用:" . round(($e_m - $s_m) / 1024 / 1024, 4) . "M" . "\n";
            $this->_log .= $log;
            if ($cat_time > 1 && !$is_end)
            {

                $start_time = $end_time;
                $s["task_id"]=$task_id;
                $u["rate"]=$rate;
                $u["result"]=$log;
                $task = $list_mod->update($s,$u);
                if (!$task)
                {
                    $this->_log .= "任务状态不正确,可能已完成或者取消";
                    $rs["info"] = "任务状态不正确,可能已完成或者取消";
                    return $rs;
                }
            }

        }
        unset($data);

        $objWriter = IOFactory::createWriter($objSpreadsheet, 'Xls');
        $objWriter->save($file_path);
        /* 释放内存 */
        $objSpreadsheet->disconnectWorksheets();
        unset($objSpreadsheet);


        $input["f"] = $file_path ;
        $input["n"] = $file_name ;
        $input["d"] = $now_date ;
        $key = urlencode($this->_des3->encrypt(json_encode($input)));
        $file_path = '/goods/pub/down/exlDown?file_name=' . $key;

        $all_end_time = microtime(true);
        $all_cat_time = round($all_end_time - $all_start_time, 4);

        $this->_log .= "总耗时:" . $all_cat_time;
        $rs = array("page" => $data_list["page"], "size" => $data_list["size"], "total" => $data_list["count"], "rate" => $rate, "is_end" => $is_end, "file_path" => $file_path, "all_cat_time" => $all_cat_time);
        $s["task_id"]=$task_id;
        $u["rate"]=100;
        $u["status"]=1;
        $u["result"]=json_encode($rs);
        $task = $list_mod->update($s,$u);
        if (!$task)
        {
            $this->_log .= "任务状态不正确,可能已完成或者取消";
        }
        return $rs;
    }




    /**
     * 导出案例，TODO 可继续优化
     *
     * @param array  $datas      导出数据，格式['A1' => 'XXXX公司报表', 'B1' => '序号']
     * @param string $fileName   导出文件名称
     * @param array  $options    操作选项，例如：
     *                           bool   print       设置打印格式
     *                           string freezePane  锁定行数，例如表头为第一行，则锁定表头输入A2
     *                           array  setARGB     设置背景色，例如['A1', 'C1']
     *                           array  setWidth    设置宽度，例如['A' => 30, 'C' => 20]
     *                           bool   setBorder   设置单元格边框
     *                           array  mergeCells  设置合并单元格，例如['A1:J1' => 'A1:J1']
     *                           array  formula     设置公式，例如['F2' => '=IF(D2>0,E42/D2,0)']
     *                           array  format      设置格式，整列设置，例如['A' => 'General']
     *                           array  alignCenter 设置居中样式，例如['A1', 'A2']
     *                           array  bold        设置加粗样式，例如['A1', 'A2']
     *                           string savePath    保存路径，设置后则文件保存到服务器，不通过浏览器下载
     * @return bool
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     */
    function exportExcelDemo(array $datas, string $fileName = '', array $options = []): bool
    {
        try {
            if (empty($datas)) {
                return false;
            }

            set_time_limit(0);
            /** @var Spreadsheet $objSpreadsheet */
            $objSpreadsheet = new Spreadsheet();
            /* 设置默认文字居左，上下居中 */
            $styleArray = [
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_LEFT,
                    'vertical'   => Alignment::VERTICAL_CENTER,
                ],
            ];
            $objSpreadsheet->getDefaultStyle()->applyFromArray($styleArray);
            /* 设置Excel Sheet */
            $activeSheet = $objSpreadsheet->setActiveSheetIndex(0);

            /* 打印设置 */
            if (isset($options['print']) && $options['print']) {
                /* 设置打印为A4效果 */
                $activeSheet->getPageSetup()->setPaperSize(PageSetup:: PAPERSIZE_A4);
                /* 设置打印时边距 */
                $pValue = 1 / 2.54;
                $activeSheet->getPageMargins()->setTop($pValue / 2);
                $activeSheet->getPageMargins()->setBottom($pValue * 2);
                $activeSheet->getPageMargins()->setLeft($pValue / 2);
                $activeSheet->getPageMargins()->setRight($pValue / 2);
            }

            /* 行数据处理 */
            foreach ($datas as $sKey => $sItem) {
                /* 默认文本格式 */
                $pDataType = DataType::TYPE_STRING;

                /* 设置单元格格式 */
                if (isset($options['format']) && !empty($options['format'])) {
                    $colRow = Coordinate::coordinateFromString($sKey);

                    /* 存在该列格式并且有特殊格式 */
                    if (isset($options['format'][$colRow[0]]) &&
                        NumberFormat::FORMAT_GENERAL != $options['format'][$colRow[0]]) {
                        $activeSheet->getStyle($sKey)->getNumberFormat()
                            ->setFormatCode($options['format'][$colRow[0]]);

                        if (false !== strpos($options['format'][$colRow[0]], '0.00') &&
                            is_numeric(str_replace(['￥', ','], '', $sItem))) {
                            /* 数字格式转换为数字单元格 */
                            $pDataType = DataType::TYPE_NUMERIC;
                            $sItem     = str_replace(['￥', ','], '', $sItem);
                        }
                    } elseif (is_int($sItem)) {
                        $pDataType = DataType::TYPE_NUMERIC;
                    }
                }

                $activeSheet->setCellValueExplicit($sKey, $sItem, $pDataType);

                /* 存在:形式的合并行列，列入A1:B2，则对应合并 */
                if (false !== strstr($sKey, ":")) {
                    $options['mergeCells'][$sKey] = $sKey;
                }
            }

            unset($datas);

            /* 设置锁定行 */
            if (isset($options['freezePane']) && !empty($options['freezePane'])) {
                $activeSheet->freezePane($options['freezePane']);
                unset($options['freezePane']);
            }

            /* 设置宽度 */
            if (isset($options['setWidth']) && !empty($options['setWidth'])) {
                foreach ($options['setWidth'] as $swKey => $swItem) {
                    $activeSheet->getColumnDimension($swKey)->setWidth($swItem);
                }

                unset($options['setWidth']);
            }

            /* 设置背景色 */
            if (isset($options['setARGB']) && !empty($options['setARGB'])) {
                foreach ($options['setARGB'] as $sItem) {
                    $activeSheet->getStyle($sItem)
                        ->getFill()->setFillType(Fill::FILL_SOLID)
                        ->getStartColor()->setARGB(Color::COLOR_YELLOW);
                }

                unset($options['setARGB']);
            }

            /* 设置公式 */
            if (isset($options['formula']) && !empty($options['formula'])) {
                foreach ($options['formula'] as $fKey => $fItem) {
                    $activeSheet->setCellValue($fKey, $fItem);
                }

                unset($options['formula']);
            }

            /* 合并行列处理 */
            if (isset($options['mergeCells']) && !empty($options['mergeCells'])) {
                $activeSheet->setMergeCells($options['mergeCells']);
                unset($options['mergeCells']);
            }

            /* 设置居中 */
            if (isset($options['alignCenter']) && !empty($options['alignCenter'])) {
                $styleArray = [
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                ];

                foreach ($options['alignCenter'] as $acItem) {
                    $activeSheet->getStyle($acItem)->applyFromArray($styleArray);
                }

                unset($options['alignCenter']);
            }

            /* 设置加粗 */
            if (isset($options['bold']) && !empty($options['bold'])) {
                foreach ($options['bold'] as $bItem) {
                    $activeSheet->getStyle($bItem)->getFont()->setBold(true);
                }

                unset($options['bold']);
            }

            /* 设置单元格边框，整个表格设置即可，必须在数据填充后才可以获取到最大行列 */
            if (isset($options['setBorder']) && $options['setBorder']) {
                $border    = [
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN, // 设置border样式
                            'color'       => ['argb' => 'FF000000'], // 设置border颜色
                        ],
                    ],
                ];
                $setBorder = 'A1:' . $activeSheet->getHighestColumn() . $activeSheet->getHighestRow();
                $activeSheet->getStyle($setBorder)->applyFromArray($border);
                unset($options['setBorder']);
            }

            $fileName = !empty($fileName) ? $fileName : (date('YmdHis') . '.xlsx');

            if (!isset($options['savePath'])) {
                /* 直接导出Excel，无需保存到本地，输出07Excel文件 */
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header(
                    "Content-Disposition:attachment;filename=" . iconv(
                        "utf-8", "GB2312//TRANSLIT", $fileName
                    )
                );
                header('Cache-Control: max-age=0');//禁止缓存
                $savePath = 'php://output';
            } else {
                $savePath = $options['savePath'];
            }

            ob_clean();
            ob_start();
            $objWriter = IOFactory::createWriter($objSpreadsheet, 'Xlsx');
            $objWriter->save($savePath);
            /* 释放内存 */
            $objSpreadsheet->disconnectWorksheets();
            unset($objSpreadsheet);
            ob_end_flush();

            return true;
        } catch (Exception $e) {
            return false;
        }
    }

}

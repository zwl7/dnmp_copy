<?php

namespace Console\Commands;

use PPOSLib\Console\EsAction;
use PPOSLib\Console\Xapiand;
use \Ppospro\PAGE\Utils\Dbdriver\MixphpEngine;
use Mix\Console\CommandLine\Flag;
/**
 * Class HelloCommand
 * @package Console\Commands
 * @author liu,jian <coder.keda@gmail.com>
 */
class EsTestCommand {
    //php ./bin/mix-console EsTest  -env .env -t Activity
    public function main()
    {
        go(function (){
            $dbBase = app()->dbBase;
            MixphpEngine::setPool(env("DATABASE_PREFIX").env("DATABASE_DBNAME"),$dbBase);
            $class_sign_report = new EsAction();
            $company_id = Flag::string(['c', 'company_id'], 0);
            $class_sign_report->searchTest(0);
            //$class_sign_report->buildPlanIndex($company_id);
        });
        \Swoole\Event::wait();

    }
}

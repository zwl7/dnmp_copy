<?php

namespace Console\Commands;

use Mix\Console\CommandLine\Flag;

/**
 * Class HelloCommand
 * @package Console\Commands
 * @author liu,jian <coder.keda@gmail.com>
 */
class HelloCommand
{

    /**
     *
     * 主函数
     */
    //php ./bin/mix-console hl -env .env
    public function main()
    {
        //根据表sql，或者对应的请求参数json字符串
        $tableName = Flag::string(['t', 'tableName'], '');
        $db = app()->dbBase;
        $arr = [];
        $tableName = 'platform_'.$tableName;
        $fields = $db->prepare("SHOW FULL COLUMNS FROM {$tableName}")->queryAll();
        $notField = [
            "id",
            "organ_unit_id",
            "operator",
            "company_id",
            "c_time",
            "u_time",
        ];
        foreach ($fields as $v) {
            if ($v['Comment'] == '表id' || in_array($v['Field'],$notField)) {
                continue;
            }
            $arr[] = [
                'description'=>$v['Comment'],
                'key'=>$v['Field'],
                'value'=>$v['Default'],
            ];
        }
        var_dump(json_encode($arr,JSON_UNESCAPED_UNICODE));

//        $tables = $db->prepare("show tables")->queryAll();
//        $allsql="";
//        foreach ($tables as $t){
//            $ta = current($t);
//            if($ta=="ppospro_seq"){
//                continue;
//            }
//            $sql = 'ALTER TABLE `'.$ta.'` ADD `company_id` INT(11) NOT NULL DEFAULT \'0\' COMMENT \'公司ID\' AFTER `id`, ADD INDEX (`company_id`)';
//            $u_sql = 'UPDATE `'.$ta.'` SET `company_id` = \'1\' WHERE `'.$ta.'`.`id` > 0; ';
//
//            $is_set ='select count(*) from information_schema.columns where table_name = \''.$ta.'\' and column_name = \'company_id\'';
//            $is_set = $db->prepare($is_set)->queryOne();
//            if(current($is_set)==0){
//                $rs = $db->prepare($sql)->execute();
//            }
//            $rs = $db->prepare($u_sql)->execute();
//            $allsql .= $sql.";";
//        }
//        $sql=trim($allsql,",");
//        var_dump($allsql);

    }

}

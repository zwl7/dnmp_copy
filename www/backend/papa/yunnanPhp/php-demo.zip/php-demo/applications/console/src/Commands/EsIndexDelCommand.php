<?php

namespace Console\Commands;

use PPOSLib\Console\EsAction;
use PPOSLib\Console\Member;
use PPOSLib\Console\Xapiand;
use PPOSLib\Helpers\XapiandService;
use \Ppospro\PAGE\Utils\Dbdriver\MixphpEngine;
use Mix\Console\CommandLine\Flag;
/**
 * Class HelloCommand
 * @package Console\Commands
 * @author liu,jian <coder.keda@gmail.com>
 */
class EsIndexDelCommand
{
    //php ./bin/mix-console EsIndexDel -env .env -t Activity -c 476
    //php ./bin/mix-console EsIndexDel -env .env -c 476
    /**
     * 主函数
     */
    public function main()
    {
        go(function (){
            $dbBase = app()->dbBase;
            MixphpEngine::setPool(env("DATABASE_PREFIX").env("DATABASE_DBNAME"),$dbBase);
            $class_sign_report = new EsAction();
            $t = Flag::string(['t', 'type'], 'All');
            $company_id = Flag::string(['c', 'company_id'], 0);
            if($t!='All'){
                $action = 'del'.$t.'Index';
                if(!method_exists ( $class_sign_report , $action )){
                    echo 'type 不正确';
                    return false;
                }
                $class_sign_report->$action($company_id);
                return true;
            }
            $class_sign_report->delActivityIndex();
            $class_sign_report->delPlanIndex();
        });
        \Swoole\Event::wait();

    }

}

<?php

namespace Console\Commands;

use thiagoalessio\TesseractOCR\TesseractOCR;

/**
 * Class HelloCommand
 * @package Console\Commands
 * @author liu,jian <coder.keda@gmail.com>
 */
class OcrCommand
{

    /**
     * Notes:
     * User: PGF
     * Email: pgf@fealive.com
     * Date: 23-3-23
     * Time: 下午2:19
     * @throws \thiagoalessio\TesseractOCR\TesseractOcrException
     */
    //php ./bin/mix-console ocr -n company_area -k
    public function main()
    {
        $path = app()->basePath;
        $ocr= new TesseractOCR($path.'/2.png');
        $ocr->lang('zh_cn')->run();

    }

}

<?php

namespace Console\Commands;

use Mix\Console\CommandLine\Flag;

class CreateModuleCommand
{

    protected $_field=array();
    protected $_updateParam="";
    protected $_searchParam="";
    protected $_addParam="";
    protected $_select="";
    protected $_status="";
    protected $_fieldRules="";
    protected $_pk="";
    protected $_apiDes="";
    protected $_apiGroup="";
    protected $_fillable="";
    protected $_search="";
    protected $_table="";
    protected $_example=[];
    /**
     * 主函数
     */
    //php ./bin/mix-console createModule -env .local -n data_dictionary

    public function main()
    {
        $path = app()->basePath;
        $appPath = app()->basePath."/..";
        //var_dump($path);
        $name = Flag::string(['n', 'name'], '');
        $model = Flag::string(['m', 'model'], '');
        if(!$name){
            echo "模块名(-d)必须\n";
            return false;
        }
        if(!$model){
            $model = "Business";
        }
        $this->_pk = $name.'_id';
        $this->_table = $name;
        $table = env("DATABASE_PREFIX").$name;
        $db = app()->dbBase;
        $fields = $db->prepare("SHOW FULL COLUMNS FROM $table")->queryAll();
        $table_comment = $db->prepare("SELECT TABLE_COMMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '$table'")->queryOne();
        if($table_comment){
			$apides = explode("-",$table_comment['TABLE_COMMENT']);
			if(count($apides)>=2)
			{
				$this->_apiDes = $apides[1];
				$this->_apiGroup = $apides[0];
			}
        }
        $name = str_replace("_", " ", strtolower($name));
        $name = ucwords($name);
        $name = str_replace(" ", "", $name);

        $this->_pk = Flag::string(['k', 'pk'], $this->_pk);
        $this->_apiDes = Flag::string(['d', 'apiDes'], $this->_apiDes);
        $this->_apiGroup = Flag::string(['g', 'apiGroup'], $this->_apiGroup);

        if(!$this->_pk){
            echo "主键(-k)必须\n";
            return false;
        }
        if(!$this->_apiDes){
            echo "接口描述(-d)必须\n";
            return false;
        }
        if(!$this->_apiGroup){
            echo "接口组(-g)必须\n";
            return false;
        }
        $this->_field = $fields;
        $this->analysisField($fields);
        $template[]=[
            "src"=>"{$path}/template/CardLevelController.tmp",
            //"trc"=>"{$path}/template/{$name}Controller.php",
            "trc"=>"$appPath/http/src/Controllers/{$model}/{$name}Controller.php"
        ];
        $template[]=[
            "src"=>"{$path}/template/CardLevelOrm.tmp",
            //"trc"=>"{$path}/template/{$name}Orm.php"
            "trc"=>"$appPath/pposlib/DB/Orm/{$name}.php"
        ];
        $template[]=[
            "src"=>"{$path}/template/CardLevelLogic.tmp",
            //"trc"=>"{$path}/template/{$name}Logic.php"
            "trc"=>"$appPath/pposlib/Logic/{$name}.php"
        ];
        $template[]=[
            "src"=>"{$path}/template/CardLevelForm.tmp",
            //"trc"=>"{$path}/template/{$name}Form.php"
            "trc"=>"$appPath/http/src/Validator/{$name}Form.php"
        ];
        $template[]=[
            "src"=>"{$path}/template/CardLevelDB.tmp",
            //"trc"=>"{$path}/template/{$name}Form.php"
            "trc"=>"$appPath/pposlib/DB/Base/{$name}.php"
        ];
        foreach ($template as $t){
            if(file_exists($t['trc']))
            {
                echo "文件:".$t['trc']."已存在,请确认后重试\n";
                return false;
            }
        }

        echo "model:$name\n";
        echo "pk:$this->_pk\n";
        echo "apiDes:$this->_apiDes\n";
        echo "apiGroup:$this->_apiGroup\n";
        echo "addParam:$this->_addParam";
        echo "select:$this->_select";
        foreach ($template as $t){
            $str = file_get_contents($t['src']);
            $str = str_replace(
                ['{--model--}','CardLevel','cardLevel','level_id',"卡等级","{--apiGroup--}","{--addParam--}","{--select--}","{--status--}","{--fieldRules--}","{--fillable--}","{--search--}","{--searchParam--}","{--updateParam--}","{--example--}","{--table--}"],
                [$model,$name,lcfirst($name),$this->_pk,$this->_apiDes,$this->_apiGroup,$this->_addParam,$this->_select,$this->_status,$this->_fieldRules,$this->_fillable,$this->_search,$this->_searchParam,$this->_updateParam,json_encode($this->_example,JSON_UNESCAPED_UNICODE),$this->_table],
                $str);
            //$str = str_replace("cardLevel",lcfirst($name),$str);
            //$str = str_replace("level_id",$this->_pk,$str);
            file_put_contents($t['trc'],$str,LOCK_EX);
        }
        //php ./bin/mix-console createModule -n Coach -k coach_id -d 教练 -g 教练
        //php ./bin/mix-console createModule -n Student -k student_id -d 学员 -g 学员模块
        //php ./bin/mix-console createModule -n CourseClass -k class_id -d 课程班级 -g 课程班级模块 -env .env
        //php ./bin/mix-console createModule -n Activity -k activity_id -d 活动 -g 活动模块 -env .env
        //php ./bin/mix-console createModule -n Review -k review_id -d 审核 -g 审核模块 -env .env
    }

    protected function analysisField($fields){
        if(!$fields)
        {
            echo "字段不存在,请确认后重试\n";
            return false;
        }

        $_select=[];
        foreach ($this->_field as $k=>$v){
            if(in_array($v['Field'],["id","c_time","u_time"])){
                continue;
            }
            $apiType = "String";
            $rulesType = "string";
            if(strpos($v['Type'],"char") === false&&strpos($v['Type'],"text") === false){
                $apiType = "Number";
                $rulesType = "integer";
            }
            if(strpos($v['Comment'],"日期") !== false){
                $rulesType = "date";
            }
            if(strpos($v['Comment'],"日期") !== false){
                $rulesType = "date";
            }
            if($v['Field']!=$this->_pk){
                $this->_updateParam .= '     * @apiParam {'.$apiType.'} ['.$v['Field'].'] '.$v['Comment']."\n";
                $this->_addParam .= '     * @apiParam {'.$apiType.'} ['.$v['Field'].'] '.$v['Comment']."\n";
            }

            $this->_fillable .= '     "'.$v['Field'].'",    //'.$v['Comment']."\n";

            if($v['Key']){
                if($apiType=="Number"){
                    $this->_search .= '        if (isset($search["'.$v['Field'].'"])){'."\n";
                    $this->_search .= '            $query->setAnd("'.$v['Field'].'",$search["'.$v['Field'].'"]);'."\n";
                    $this->_search .= '        }'."\n";
                    $this->_search .= '        if (isset($search["'.$v['Field'].'s"])){'."\n";
                    $this->_search .= '            $query->setIn("'.$v['Field'].'",$search["'.$v['Field'].'s"]);'."\n";
                    $this->_search .= '        }'."\n";
                }
                if($apiType=="String"){
                    $this->_search .= '        if (isset($search["'.$v['Field'].'"])){'."\n";
                    $this->_search .= '            $query->setAnd("'.$v['Field'].'",$search["'.$v['Field'].'"]."%",ParseQuery::TAG_LIKE);'."\n";
                    $this->_search .= '        }'."\n";
                }

                $this->_searchParam .= '     * @apiParam {'.$apiType.'} ['.$v['Field'].'] '.$v['Comment']."\n";
            }

            $_select[] = '"'.$v['Field'].'"';

            $this->_fieldRules .= '            \''.$v['Field'].'\'  => [\''.$rulesType.'\'],'."\n";

            if(!in_array($v['Field'],["company_id"])){
                $this->_select ='['.implode(",",$_select).']';
                $this->_example[$v['Field']]=$v['Comment'];
            }
            if($v['Field']=='status'){
                $this->_status ='if ($rs["list"][$k]["status"]==1){
                $rs["list"][$k]["status"]="有效";
            }else{
                $rs["list"][$k]["status"]="无效";
            }';
            }

        }

    }

}

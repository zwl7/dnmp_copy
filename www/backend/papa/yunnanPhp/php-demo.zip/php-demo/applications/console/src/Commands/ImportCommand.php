<?php
namespace Console\Commands;
use Mix\Console\CommandLine\Flag;
use PPOSLib\DB\Base\Activity;
use PPOSLib\DB\Base\ActivityHoldDocument;
use PPOSLib\DB\Base\ActivityHoldPlan;
use PPOSLib\DB\Base\ActivityHoldSituation;
use PPOSLib\Exception\PPosException;
use PPOSLib\Helpers\LbsQqServiceData;
use Ppospro\PAGE\Utils\Dbdriver\MixphpEngine;
use Swoole\Exception;

/**
 * Created by PhpStorm.
 * User: PGF
 * Email: pgf@fealive.com
 * Date: 24-3-12
 * Time: 下午4:32
 */
class ImportCommand
{
    protected $_company_id = 0;
    //php ./bin/mix-console import  -env .local -t activity

    /**
     * 主函数
     */
    public function main()
    {
        go(function (){
            $dbBase = app()->dbBase;
            MixphpEngine::setPool(env("DATABASE_PREFIX") . env("DATABASE_DBNAME"), $dbBase);

            $type = Flag::string(['t']);
            $this->_company_id = Flag::string(['c']);

            switch ($type)
            {
                case "activity":
                    $this->activity();
                    break;
                default;
                    echo "type错误";
                    return;
            }
            });
        \Swoole\Event::wait();
    }

    public function activity(){
        $appPath = app()->basePath . "/../../";
        $db = app()->dbBase;

        $unit = $db->prepare("SELECT * FROM `platform_yn_organ_unit`.`platform_organ_unit` WHERE `company_id` = '476' ORDER BY `id` DESC LIMIT 0,1000")->queryAll();
        $unit = array_column($unit,null,'name');

        $sport_tag = $db->prepare("SELECT t.`name`,t.tag_id FROM `platform_yn_organ_unit`.`platform_tag` as t INNER JOIN `platform_yn_organ_unit`.`platform_tag_group` as g ON t.tag_group_id = g.tag_group_id WHERE g.`type` = 'event_activity_plan_project_kind' AND g.`company_id` = '476'")->queryAll();
        $sport_tag_map = array_column($sport_tag,'tag_id','name');

        $activity_special_tag = $db->prepare("SELECT t.`name`,t.tag_id FROM `platform_yn_organ_unit`.`platform_tag` as t INNER JOIN `platform_yn_organ_unit`.`platform_tag_group` as g ON t.tag_group_id = g.tag_group_id WHERE g.`type` = 'event_activity_special' AND g.`company_id` = '476'")->queryAll();
        $activity_special_tag_map = array_column($activity_special_tag,'tag_id','name');
        //print_r($sport_tag_map);

        $ycFile = fopen($appPath.'allact.csv','r');
        $lbs  = new LbsQqServiceData();
        $area_level_map['省级']=1;
        $area_level_map['市级']=2;
        $area_level_map['县级']=3;
        $area_level_map['州市级']=2;
        $area_level_map['乡镇级']=4;
        $no_tag=[];
        $no_unit=[];
        $actDB = new Activity();

        $db = $actDB->db();
        $actHoldDB = new ActivityHoldSituation($db);
        $actDocDB =  new ActivityHoldDocument($db);
        $actHoldPlanDB =  new ActivityHoldPlan($db);

        while ($d = fgetcsv($ycFile)) { //每次读取CSV里面的一行内容
            if ($d[0]>5077){
                continue;
            }
            //print_r($d);
            $add=[];
            $add["company_id"]=476;
            try{
                $db->begin();
                if ($d[5]){
                    $d[5] = str_replace("象棋围棋",'象棋,围棋',$d[5]);
                    $tags = explode(",",$d[5]);
                }else{
                    $tags[]="其他";
                }
                foreach ( $tags as $tag){
                    $tag = str_replace("篮球项目",'篮球',$tag);
                    $tag = str_replace("自行车",'公路自行车',$tag);
                    $tag = str_replace("双抠",'双Q比赛',$tag);
                    $tag = str_replace("双扣",'双Q比赛',$tag);
                    $tag = str_replace("双拐",'双Q比赛',$tag);
                    $tag = str_replace("徙步",'徒步',$tag);
                    $tag = str_replace("田径",'田径其他',$tag);
                    $tag = str_replace("健身舞",'健身操',$tag);
                    $tag = str_replace("健身操舞",'健身操',$tag);
                    $tag = str_replace("武术",'武术套路',$tag);
                    $tag = str_replace("中国象棋",'象棋',$tag);
                    $tag = str_replace("健身操操",'健身操',$tag);
                    $tag = str_replace("操类",'体操其他',$tag);
                    $tag = str_replace("蔑弹弓",'篾弹弓',$tag);

                    $add['type_tag_ids']=[];
                    if (!isset($sport_tag_map[$tag])){
                        echo "运动项目：".$tag."不存在\n";
                        $no_tag[$tag] = $tag;
                    }else{
                        $add['type_tag_ids'][] = $sport_tag_map[$tag];
                    }
                }
                $add['type_tag_ids'] = implode(",",$add['type_tag_ids']);

                if ($d[13]=="云南省红河州屏边县民族体育馆、全民健身活动中心、阿季伍全民健身中心"){
                    $d[13]= '云南省红河州屏边县民族体育馆';
                }
                if (!isset($unit[$d[13]])){
                    $no_unit[$d[13]] = $d[13];
                }else{
                    $add['organ_unit_id'] = $unit[$d[13]]['organ_unit_id'];
                }
                //continue;
                //return;
                $files = [];
                $match_order_doc=[];
                $match_regulation_doc=[];
                $public_opinion_plan=[];
                $event_organization_plan=[];
                $emergency_response_plan=[];
                $prevention_control_plan=[];
                $media_promotion_plan=[];
                $safe_control_plan=[];
                $match_socre = $this->handField($d[27]);//成绩册
                $files = array_merge($files,$match_socre);
                $filing_registration_form = $this->handField($d[28]);//赛事备案表
                $files = array_merge($files,$filing_registration_form);
                $other_field = $this->handField($d[29]);//赛事四个方案
                $files = array_merge($files,$other_field);

                foreach ($files as $f){
                   if (strpos($f['name'],"成绩") !==false&&empty($match_socre)){
                        $match_socre[] = $f;
                   }
                   if (strpos($f['name'],"的通知") !==false){
                        $event_organization_plan[] = $f;
                   }
                   if (strpos($f['name'],"备案") !==false&&empty($filing_registration_form)){
                        $filing_registration_form[] = $f;
                   }
                   if (strpos($f['name'],"秩序") !==false){
                       $match_order_doc[] = $f;
                   }
                   if (strpos($f['name'],"规程") !==false){
                       $match_regulation_doc[] = $f;
                   }
                   if (strpos($f['name'],"舆情") !==false){
                       $public_opinion_plan[] = $f;
                   }
                   if (strpos($f['name'],"组织方案") !==false&&empty($event_organization_plan)){
                       $event_organization_plan[] = $f;
                   }
                   if (strpos($f['name'],"应急") !==false){
                       $emergency_response_plan[] = $f;
                   }
                   if (strpos($f['name'],"疫情") !==false){
                       $prevention_control_plan[] = $f;
                   }
                   if (strpos($f['name'],"宣传") !==false){
                       $media_promotion_plan[] = $f;
                   }
                   if (strpos($f['name'],"风险") !==false){
                       $safe_control_plan[] = $f;
                   }
                }
                //print_r($files);

                if (count($files)>0){
                    $add['is_hold_plan'] = 1;
                    $add['is_hold_situation'] = 1;
                    $add['is_hold_document'] = 1;
                }

                $add['name'] = $d[2];
                $add['operator'] = 999;
                $add['status'] = 3;
                $add['is_community_sport'] = 2;
                $add['area_level'] = $area_level_map[$d[3]];
                $add['address'] = $d[11];
                if (!$add['address']||strpos($add['address'],"云南省相关") !==false||strpos($add['address'],"云南省全省") !==false||$add['address']=="云南省全国"||$add['address']=="云南省全省"||$add['address']=="云南省线上"){
                    $add['address'] = "云南省".$d[13];
                }

                if ($d[0]==3281||$add['address']=="云南省云南省体育科学研究所(云南省国民体质监测中心)"){
                    $add['address'] = "云南昆明市西山区湖滨路57号";

                }
                if ($d[0]==3139){
                    $add['address'] = "云南省昆明市盘龙区东风东路99号";
                 }
                 if ($d[0]==3698){
                    $add['address'] = "云南省西双版纳";
                 }
                 if ($d[0]==3728||$d[0]==5950||$d[0]==5967||$d[0]==5988){
                    $add['address'] = "云南省昆明市西山区滇池路1318号";
                 }

                 if ($d[0]==4115){
                    $add['address'] = "云南省曲靖市体育馆";
                 }
                 if ($d[0]==6044){
                    $add['address'] = "云南省昆明市西山区前卫西路19号附近";
                 }

                $local = $lbs->addressToLocation($add['address']);
                $add['lat'] = $local['location']['lat'];
                $add['lng'] = $local['location']['lng'];
                $info = $lbs->geocoder($add['lat'], $add['lng']);
                //print_r($info['address_reference']);
                $add['street'] = $info['address_reference']['town']['id'];
                $add['province'] = substr($add['street'],0,2);
                $add['city'] = substr($add['street'],0,4);
                $add['county'] = substr($add['street'],0,6);

                $add = $actDB->createOne($add,false);
                if ($d[9]){
                    $add['start_time'] = strtotime($d[9]) ;
                }
                if ($d[10]){
                    $add['end_time'] = strtotime($d[10]);
                }
                $add['join_num'] = intval($d[12]);

                switch ($d[18]){
                    case "线上":
                     $add['hold_way'] = 1;
                     break;
                     case "线下":
                     $add['hold_way'] = 2;
                     break;
                    default :
                     $add['hold_way'] = 3;

                }

                $add['match_situation'] = 2;
                $add['is_use_public_stadium'] = 2;

                $add['now_number'] = intval($d[14])??1; //当前届次
                $add['match_number'] = 1;
                $add["event_cycle"] = $d[15];    //赛事周期
                $add["contacts_name"] = $d[23];    //联系人
                $add["contact_way"] = $d[24];   //联系方式
                $add["first_unit_name"] =  $d[8];    //第一主办单位名称
                $add["other_unit_name"] = "";    //其他主办单位名称
                $add["hold_unit_name"] = "";   //承办单位名称
                $add["held_hold_unit_name"] = "";    //协办单位名称
                $add["do_unit_name"] =$d[8];    //执行单位名称
                $add["report_unit_name"] = $d[13];    //上报单位名称
                $add["year"] = $d[1];    //资金情况

                $add["des"] = $d[25];    //赛事简介
                if ($d[26]){
                    $add["des"] .=" 备注：".$d[26];
                }
                $add["total_money"] = intval($d[17])*10000;    //活动经费总额，单位元，保留两位小数
                $add["source_of_subsidy_funds"] = 2;    //是否使用体彩金，1是，2否
                $price_from = explode("、",$d[16]);

                $price_info=[];
                foreach ($price_from as $n){
                    if (strpos($n,"体彩公益金") !==false){
                        $add["source_of_subsidy_funds"] = 1;    //是否使用体彩金，1是，2否
                        $price_info[]=array(
                            "price"=>"0","year"=>$add["year"],"name"=>"","type_id"=>3
                        );
                        continue;
                    }
                    //type_id 项目资金类型 1:中央预算内  2:中央体彩金 3:省体彩金 4:自筹资金 5:市级资金 6：区级资金
                    if (strpos($n,"区级财政") !==false||strpos($n,"财政资金") !==false||strpos($n,"本级") !==false||strpos($n,"县财政") !==false){
                        $price_info[]=array(
                            "price"=>"0","year"=>$add["year"],"name"=>"","type_id"=>6
                        );
                        continue;
                    }
                    if (strpos($n,"上级资金") !==false||strpos($n,"市级补助") !==false||strpos($n,"上级补助") !==false||strpos($n,"市级资金") !==false){
                        $price_info[]=array(
                            "price"=>"0","year"=>$add["year"],"name"=>"","type_id"=>5
                        );
                        continue;
                    }
                    if (strpos($n,"中央") !==false){
                        $price_info[]=array(
                            "price"=>"0","year"=>$add["year"],"name"=>"","type_id"=>1
                        );
                        continue;
                    }
                    $price_info[]=array(
                            "price"=>"0","year"=>$add["year"],"name"=>$n,"type_id"=>4
                    );
                }
                $add["price_info"] = json_encode($price_info);    //资金情况
                if ($d['6']){
                    $special = explode(",",$d['6']);
                    foreach ($special as $tag){
                        if (isset($activity_special_tag_map[$tag])){
                            $add['tag_ids'][] = $activity_special_tag_map[$tag];
                        }
                    }
                    $add['tag_ids'] = implode(",",$add['tag_ids']);
                }

                $actHoldDB->createOne($add);
                $add['cover_img'] = $d[30];//赛事封面
                $add['activity_img'] = $d[31];//赛事图片
                $add['activity_url'] = $d[32];//宣传视频
                if (count($match_socre)>0){
                    $add['match_socre_doc'] = $match_socre[0]['url'];
                    $add['match_socre_doc_name'] = $match_socre[0]['name'];
                }
                if (count($match_order_doc)>0){
                     $add['match_order_doc'] = $match_order_doc[0]['url'];
                     $add['match_order_doc_name'] = $match_order_doc[0]['name'];
                }
                if (count($match_regulation_doc)>0){
                    $add['match_regulation_doc'] = $match_regulation_doc[0]['url'];
                    $add['match_regulation_doc_name'] = $match_regulation_doc[0]['name'];
                }
                $actDocDB->createOne($add);

                if (count($filing_registration_form)>0){
                    $add['filing_registration_form'] = $filing_registration_form[0]['url'];
                    $add['filing_registration_form_name'] = $filing_registration_form[0]['name'];
                }
                if (count($event_organization_plan)>0){
                    $add['event_organization_plan'] = $event_organization_plan[0]['url'];
                    $add['event_organization_plan_name'] = $event_organization_plan[0]['name'];
                }
                if (count($emergency_response_plan)>0){
                    $add['emergency_response_plan'] = $emergency_response_plan[0]['url'];
                    $add['emergency_response_plan_name'] = $emergency_response_plan[0]['name'];
                }
                if (count($prevention_control_plan)>0){
                    $add['prevention_control_plan'] = $prevention_control_plan[0]['url'];
                    $add['prevention_control_plan_name'] = $prevention_control_plan[0]['name'];
                }
                if (count($media_promotion_plan)>0){
                    $add['media_promotion_plan'] = $media_promotion_plan[0]['url'];
                    $add['media_promotion_plan_name'] = $media_promotion_plan[0]['name'];
                }
                if (count($public_opinion_plan)>0){
                    $add['public_opinion_plan'] = $public_opinion_plan[0]['url'];
                    $add['public_opinion_plan_name'] = $public_opinion_plan[0]['name'];
                }
                if (count($safe_control_plan)>0){
                    $add['safe_control_plan'] = $safe_control_plan[0]['url'];
                    $add['safe_control_plan_name'] = $safe_control_plan[0]['name'];
                }
                if (count($other_field)>0){
                    $add['other_plan'] = json_encode($other_field);
                }
                $add['plan_des']="";
                $actHoldPlanDB->createOne($add,false);
                $db->commit();
                echo "处理第{$d[0]}成功："."\n";
            }catch (\Exception $e){
                print_r($d);
                print_r($add);
                echo "处理第{$d[0]}错误："."\n";
                echo ($e->getMessage())."\n";
                echo ($e->getFile()).$e->getLine()."\n";
                echo ($e->getTraceAsString())."\n";
                return;
            }
            //return;
            \Swoole\Coroutine::sleep(0.02);
            //return;
        }
        //$db->rollback();
        //$db->commit();
        //print_r($no_tag);
        //$this->importOrange($no_unit);
        //$this->importUnit($no_unit);
        //print_r($no_unit);
        return ;
    }

    private function handField($data){
        $rs=[];
        $field = explode(",",$data);
        //print_r($data);
        foreach ($field as $f){
            $a = explode('】（',$f);
            if (count($a)==2){
                //print_r($a);
                 $rs[] = array(
                    "name"=>mb_substr(trim($a[0]), 1, null, 'utf-8'),
                    "url"=>strstr(trim($a[1]),'）',true),
                 );
            }

        }
        //print_r($rs);
        return $rs;
    }

    private function importOrange($units){
        $db = app()->dbBase;
        $uid = 329;//确定好uid
        foreach ($units as $unit){
            $type = 1;
            $level_id =1;
             if (strpos($unit,"教体局") ===false){
                 continue;
             }

             if (strpos($unit,"市") !==false||strpos($unit,"州") !==false){
                 $level_id = 2;
             }
             if (strpos($unit,"县") !==false||strpos($unit,"区") !==false){
                 $level_id = 3;
             }
             $like="";
             if (!$like){
                $like = strstr($unit,"县教体局",true);
             }
             if (!$like){
                 $like = strstr($unit,"州教体局",true);
             }
             if (!$like){
                 $like = strstr($unit,"市教体局",true);
             }
            if (!$like){
                 $like = strstr($unit,"区教体局",true);
             }
             if ($like){
                 $like =  "%$like%";
             }
             switch ($unit){
                 case "云县教体局":
                     $level_id = 3;
                     $like="云县";
                     break;
                 case "曲靖市麒麟区教体局":
                     $level_id = 3;
                     $like="%麒麟%";
                     break;
                 case "高新区教体局":
                     $level_id = 4;
                     $like="%昆明国家高新技术产业开发区%";
                     break;
                 case "阳宗海管委会教体局":
                     $level_id = 4;
                     $like="%阳宗海%";
                     break;
                 case "昆明市呈贡区教体局":
                     $level_id = 3;
                     $like="%呈贡区%";
                     break;


             }
             $sql = "SELECT * FROM `platform_yn_organ_unit`.`platform_company_area` WHERE `company_id` = '476' and `name` LIKE '{$like}'";
             if ($level_id==2){
                 $sql.=' AND `company_area_id` BETWEEN \'1000\' AND \'9999\'';
             }elseif ($level_id==3){
                 $sql.=' AND `company_area_id` BETWEEN \'100000\' AND \'999999\'';
             }elseif ($level_id==4){
                 $sql.=' AND `company_area_id` BETWEEN \'100000000\' AND \'999999999\'';
             }

             $company_area = $db->prepare($sql)->queryAll();
             if (count($company_area)!=1){
                 $sql = "SELECT * FROM `platform_yn_organ_unit`.`platform_company_area` WHERE `company_id` = '476' and `name` LIKE '{$like}'";
                 $sql.=' AND `company_area_id` BETWEEN \'100000\' AND \'999999\'';
                 $company_area = $db->prepare($sql)->queryAll();
             }
             if (count($company_area)!=1){
                 echo $sql."\n";
                 echo $unit."\n";
                 return;
             }
             $company_area_id = $company_area[0]['company_area_id'];
            $sql = "INSERT INTO `platform_yn_organ_unit`.`platform_organ_unit` ( `organ_unit_id`, `company_id`, `operator`, `company_area_id`, `manage_organ_id`, `level_id`, `type`, `kind_id`, `name`, `social_credit_code`, `contact_name`, `contact_way`, `address`, `img`, `status`, `c_time`, `u_time`) VALUES ( {$uid}, 476, 9999, {$company_area_id}, 0, {$level_id}, {$type}, 0, '{$unit}', '', '', '', '', '', 1, 1710226244, 0);";
            $db->prepare($sql)->execute();
            $uid++;
        }
        //return $rs;
    }

    private function importUnit($units){
        $db = app()->dbBase;
        $uid = 341;
        $orange = $db->prepare("SELECT * FROM `platform_yn_organ_unit`.`platform_organ_unit` WHERE `company_id` = '476' AND type = 1")->queryAll();
        $orange_map = array_column($orange,null,"company_area_id");
        foreach ($units as $unit){
            $type = 2;
            $level_id =1;
             if (strpos($unit,"教体局") !==false){
                 continue;
             }

             if (strpos($unit,"市") !==false||strpos($unit,"州") !==false){
                 $level_id = 2;
             }
             if (strpos($unit,"县") !==false||strpos($unit,"区") !==false){
                 $level_id = 3;
             }
             $like="";
             if (!$like){
                $like = strstr($unit,"区",true);
             }
             if (!$like){
                 $like = strstr($unit,"县",true);
             }
             if (!$like){
                 $like = strstr($unit,"市",true);
             }
            if (!$like){
                 $like = strstr($unit,"州",true);
             }
             if ($like){
                 $like =  "%$like%";
             }
             switch ($unit){
                 case "大理国际奥林匹克体育中心":
                     $level_id = 2;
                     $like="%大理%";
                     break;
                 case "云南省文山州马关县逢春体育馆":
                     $level_id = 3;
                     $like="%马关%";
                     break;
                 case "云南省文山州马关县安平体育馆":
                     $level_id = 3;
                     $like="%马关%";
                     break;
                 case "云南省红河州屏边县民族体育馆、全民健身活动中心、阿季伍全民健身中心":
                     $unit = "云南省红河州屏边县民族体育馆";
                     $level_id = 3;
                     $like="%屏边%";
                     break;
                 case "云南省拓东体育场":
                     $level_id = 1;
                     $like="%云南省%";
                     break;
                 case "云南省普洱市普洱市体育运动中心北部健身馆":
                     $level_id = 2;
                     $like="%普洱市%";
                     break;


             }
             $sql = "SELECT * FROM `platform_yn_organ_unit`.`platform_company_area` WHERE `company_id` = '476' and `name` LIKE '{$like}'";
             if ($level_id==1){
                 $sql .= ' AND `company_area_id` BETWEEN \'10\' AND \'99\'';
             }elseif ($level_id==2){
                 $sql.=' AND `company_area_id` BETWEEN \'1000\' AND \'9999\'';
             }elseif ($level_id==3){
                 $sql.=' AND `company_area_id` BETWEEN \'100000\' AND \'999999\'';
             }elseif ($level_id==4){
                 $sql.=' AND `company_area_id` BETWEEN \'100000000\' AND \'999999999\'';
             }

             $company_area = $db->prepare($sql)->queryAll();
             if (count($company_area)!=1){
                 $sql = "SELECT * FROM `platform_yn_organ_unit`.`platform_company_area` WHERE `company_id` = '476' and `name` LIKE '{$like}'";
                 $sql.=' AND `company_area_id` BETWEEN \'100000\' AND \'999999\'';
                 $company_area = $db->prepare($sql)->queryAll();
             }
             if (count($company_area)!=1){
                 echo $sql."\n";
                 echo $unit."\n";
                 return;
             }
             $company_area_id = $company_area[0]['company_area_id'];
             $manage_organ_id=0;
             if (isset($orange_map[$company_area_id])){
                    $manage_organ_id = $orange_map[$company_area_id]['organ_unit_id'];
             }else{
                 echo $unit."\n";
                 echo '管理机构不存在'."\n";
                 echo $company_area_id."\n";
                 return;
             }

             $kind_id = 0;
             if (strpos($unit,"社会体育指导") !==false){
                 $kind_id = 6;
             }
             if (strpos($unit,"活动中心") !==false){
                 $kind_id = 10;
             }
            if (strpos($unit,"协会") !==false){
                 $kind_id = 7;
             }
             if (strpos($unit,"奥林匹克体育中心") !==false||strpos($unit,"体育场") !==false||strpos($unit,"体育馆") !==false||strpos($unit,"健身馆") !==false){
                 $kind_id = 8;
             }
             if (strpos($unit,"体质测评") !==false){
                 $kind_id = 9;
             }
             if ($kind_id==0){
                 echo $unit."\n";
                 echo '单位类型不存在'."\n";
                 return;
             }
            $sql = "INSERT INTO `platform_yn_organ_unit`.`platform_organ_unit` ( `organ_unit_id`, `company_id`, `operator`, `company_area_id`, `manage_organ_id`, `level_id`, `type`, `kind_id`, `name`, `social_credit_code`, `contact_name`, `contact_way`, `address`, `img`, `status`, `c_time`, `u_time`) VALUES ( {$uid}, 476, 9999, {$company_area_id}, {$manage_organ_id}, {$level_id}, {$type}, {$kind_id}, '{$unit}', '', '', '', '', '', 1, 1710226244, 0);";
            $db->prepare($sql)->execute();
            $uid++;
        }
        //return $rs;
    }
}
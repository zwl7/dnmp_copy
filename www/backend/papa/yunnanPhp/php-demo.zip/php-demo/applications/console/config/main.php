<?php

// Console应用配置
return [

    // 应用名称
    'appName'          => 'mix-console',

    // 应用版本
    'appVersion'       => '0.0.0',

    // 应用调试
    'appDebug'         => env('APP_DEBUG'),

    // 基础路径
    'basePath'         => dirname(__DIR__),

    // 命令命名空间
    'commandNamespace' => 'Console\Commands',

    // 命令
    'commands'         => [

        'hl' => [
            'Hello',
            'description' => "\tEcho demo.",
            'options'     => [
                [['n', 'name'], 'description' => 'Your name'],
                [['t', 'tableName'], 'description' => 'tableName'],
                ['say', 'description' => "\tSay ..."],
            ],
        ],
        'ocr' => [
            'Ocr',
            'description' => "\tEcho demo.",
            'options'     => [
                [['n', 'name'], 'description' => 'Your name'],
                ['say', 'description' => "\tSay ..."],
            ],
        ],
        'co' => [
            'Coroutine',
            'description' => "\tCoroutine demo",
        ],

        'wg' => [
            'WaitGroup',
            'description' => "\tWaitGroup demo",
        ],

        'cop' => [
            'CoroutinePool',
            'description' => "\tCoroutine pool demo",
        ],

        'copd' => [
            'CoroutinePoolDaemon',
            'description' => "\tCoroutine pool daemon demo",
            'options'     => [
                [['d', 'daemon'], 'description' => 'Run in the background'],
            ],
        ],

        'tr' => [
            'Timer',
            'description' => "\tTimer demo",
        ],
        'export' => [
            'Export',
            'description' => "\t导出",
        ],
        'createModule' => [
            'CreateModule',
            'description' => "\tCreate Module.",
            'options'     => [
                [['n', 'name'], 'description' => '模块名'],
                [['k', 'pk'], 'description' => '主键'],
                [['d', 'apiDec'], 'description' => '接口描述'],
                [['g', 'apiGroup'], 'description' => '接口模块'],
            ],
        ],
        'EsIndexBuild' => [
            'EsIndexBuild',
            'description' => "\tEs 创建索引.",
            'options'     => [
                [['t', 'type'], 'description' => '重建模块名[All|Activity|Plan]'],
                [['c', 'company_id'], 'description' => '[公司ID]'],
            ],
        ],
        'EsIndexDel' => [
            'EsIndexDel',
            'description' => "\tEs 删除索引.",
            'options'     => [
                [['t', 'type'], 'description' => '删除模块名[All|Activity|Plan]'],
                [['c', 'company_id'], 'description' => '[公司ID]'],
            ],
        ],
        'EsTest' => [
            'EsTest',
            'description' => "\tEs 测试.",
            'options'     => [
                [['c', 'company_id'], 'description' => '[公司ID]'],
            ],
        ],
        'import' => [
            'Import',
            'options'     => [
                [['t'], 'description' => '类型'],
            ],
            'description' => "\t导如",
        ],

    ],

    // 组件配置
    'components'       => [

        // 错误
        'error'     => [
            // 依赖引用
            'ref' => beanname(Mix\Console\Error::class),
        ],

        // 日志
        'log'       => [
            // 依赖引用
            'ref' => beanname(Mix\Log\Logger::class),
        ],

        /*// 连接池
        'dbPool'    => [
            // 依赖引用
            'ref' => beanname(Mix\Database\Pool\ConnectionPool::class),
        ],*/

        'dbStore'    => [
            // 依赖引用
            'ref' => "dbStore",
        ],
        'dbBase'    => [
            // 依赖引用
            'ref' => "dbBase",
        ],

        // 连接池
        'redisPool' => [
            // 依赖引用
            'ref' => beanname(Mix\Redis\Pool\ConnectionPool::class),
        ],
        //隔离字段
        'IsolationFillable'       => [
            // 依赖引用
            'ref' => "IsolationFillable",
        ],
    ],

    // 依赖配置
    'beans'            => [

        // 隔离字段
        [
            // 名称
            'name'       => 'IsolationFillable',
            // 类路径
            'class'      => PPOSLib\Helpers\IsolationFillable::class,
            // 属性
            'properties' => [
            ],
        ],

        // 错误
        [
            // 类路径
            'class'      => Mix\Console\Error::class,
            // 属性
            'properties' => [
                // 错误级别
                'level' => E_ALL,
            ],
        ],

        // 日志
        [
            // 类路径
            'class'      => Mix\Log\Logger::class,
            // 属性
            'properties' => [
                // 日志记录级别
                'levels'  => ['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug'],
                // 处理器
                'handler' => [
                    // 依赖引用
                    'ref' => beanname(Mix\Log\MultiHandler::class),
                ],
            ],
        ],

        // 日志处理器
        [
            // 类路径
            'class'      => Mix\Log\MultiHandler::class,
            // 属性
            'properties' => [
                // 日志处理器集合
                'handlers' => [
                    // 标准输出处理器
                    [
                        // 依赖引用
                        'ref' => beanname(Mix\Log\StdoutHandler::class),
                    ],
                    // 文件处理器
                    [
                        // 依赖引用
                        'ref' => beanname(Mix\Log\FileHandler::class),
                    ],
                ],
            ],
        ],

        // 日志标准输出处理器
        [
            // 类路径
            'class' => Mix\Log\StdoutHandler::class,
        ],

        // 日志文件处理器
        [
            // 类路径
            'class'      => Mix\Log\FileHandler::class,
            // 属性
            'properties' => [
                // 日志目录
                'dir'         => 'logs',
                // 日志轮转类型
                'rotate'      => Mix\Log\FileHandler::ROTATE_DAY,
                // 最大文件尺寸
                'maxFileSize' => 0,
            ],
        ],

        // 连接池
        [
            // 类路径
            'class'      => Mix\Database\Pool\ConnectionPool::class,
            // 属性
            'properties' => [
                // 最多可空闲连接数
                'maxIdle'   => 5,
                // 最大连接数
                'maxActive' => 50,
                // 拨号器
                'dialer'    => [
                    // 依赖引用
                    'ref' => beanname(Common\Dialers\DatabaseDialer::class),
                ],
            ],
        ],

        // 连接池拨号
        [
            // 类路径
            'class' => Common\Dialers\DatabaseDialer::class,
        ],

        // 连接池
        [
            // 类路径
            'class'      => Mix\Redis\Pool\ConnectionPool::class,
            // 属性
            'properties' => [
                // 最多可空闲连接数
                'maxIdle'   => 5,
                // 最大连接数
                'maxActive' => 50,
                // 拨号器
                'dialer'    => [
                    // 依赖引用
                    'ref' => beanname(Common\Dialers\RedisDialer::class),
                ],
            ],
        ],

        // 连接池拨号
        [
            // 类路径
            'class' => Common\Dialers\RedisDialer::class,
        ],

        // 数据库
        [
            // 类路径
            'class'      => Mix\Database\Coroutine\PDOConnection::class,
            // 属性
            'properties' => [
                // 数据源格式
                'dsn'           => env('DATABASE_DSN'),
                // 数据库用户名
                'username'      => env('DATABASE_USERNAME'),
                // 数据库密码
                'password'      => env('DATABASE_PASSWORD'),
                // 驱动连接选项: http://php.net/manual/zh/pdo.setattribute.php
                'driverOptions' => [
                    // 设置默认的提取模式: \PDO::FETCH_OBJ | \PDO::FETCH_ASSOC
                    \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                ],
            ],
        ],
        // store连接池
        [
            "name" =>"storePool",
            // 类路径
            'class'      => Http\Components\DBPool::class,
            // 属性
            'properties' => [
                //
                'dbName'=>env('DATABASE_PREFIX').env('DATABASE_DBNAME'),
                // 最多可空闲连接数
                'maxIdle'   => 10,
                // 最大连接数
                'maxActive' => 20,
                // 拨号器
                'dialer'    => [
                    // 依赖引用
                    'ref' => "DbStoreDialer",
                ],
            ],
        ],
        // store连接池拨号
        [
            "name"=>"DbStoreDialer",
            //'class' => Common\Dialers\DatabaseDialer::class,
            'class' => \Ppospro\PAGE\DB\DbStoreDialer::class,
        ],
        // store数据库
        [
            // 名称
            'name'       => 'dbStore',
            // 类路径
            //'class'      => Mix\Database\Coroutine\PDOConnection::class,
            'class'      => \Ppospro\PAGE\DB\PDOPerConnection::class,
            // 属性
            'properties' => [

                'prefix'        => env('DATABASE_PREFIX'),

                // 数据库名
                'dbname'           => env('DATABASE_DBNAME'),
                'host'           => env('DATABASE_HOST'),
                'port'           => env('DATABASE_PORT'),
                'charset'           => env('DATABASE_CHARSET'),
                // 数据库用户名
                'username'      => env('DATABASE_USERNAME'),
                // 数据库密码
                'password'      => env('DATABASE_PASSWORD'),
                // 驱动连接选项: http://php.net/manual/zh/pdo.setattribute.php
                'driverOptions' => [
                    // 设置默认的提取模式: \PDO::FETCH_OBJ | \PDO::FETCH_ASSOC
                    \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                ],
                // 监听器
                'listener'      => [
                    // 依赖引用
                    'ref' => beanname(\Ppospro\PAGE\Listeners\DatabaseListener::class),
                ],
            ],
        ],

        // base数据库
        [
            // 名称
            'name'       => 'dbBase',
            // 类路径
            //'class'      => Mix\Database\Coroutine\PDOConnection::class,
            'class'      => \Ppospro\PAGE\DB\PDOPerConnection::class,
            // 属性
            'properties' => [

                'prefix'        => env('DATABASE_PREFIX'),

                // 数据库名
                'dbname'           => env('DATABASE_DBNAME'),
                'host'           => env('DATABASE_HOST'),
                'port'           => env('DATABASE_PORT'),
                'charset'           => env('DATABASE_CHARSET'),
                // 数据库用户名
                'username'      => env('DATABASE_USERNAME'),
                // 数据库密码
                'password'      => env('DATABASE_PASSWORD'),
                // 驱动连接选项: http://php.net/manual/zh/pdo.setattribute.php
                'driverOptions' => [
                    // 设置默认的提取模式: \PDO::FETCH_OBJ | \PDO::FETCH_ASSOC
                    \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                ],
                // 监听器
                'listener'      => [
                    // 依赖引用
                    'ref' => beanname(\Ppospro\PAGE\Listeners\DatabaseListener::class),
                ],
            ],
        ],

        // 数据库监听器
        [
            // 类路径
            'class' => \Ppospro\PAGE\Listeners\DatabaseListener::class,
        ],

        // redis
        [
            // 类路径
            'class'      => Mix\Redis\Coroutine\RedisConnection::class,
            // 属性
            'properties' => [
                // 主机
                'host'     => env('REDIS_HOST'),
                // 端口
                'port'     => env('REDIS_PORT'),
                // 数据库
                'database' => env('REDIS_DATABASE'),
                // 密码
                'password' => env('REDIS_PASSWORD'),
            ],
        ],

        // 数据库
        [
            // 类路径
            'class'      => Mix\Database\Persistent\PDOConnection::class,
            // 属性
            'properties' => [
                // 数据源格式
                'dsn'           => env('DATABASE_DSN'),
                // 数据库用户名
                'username'      => env('DATABASE_USERNAME'),
                // 数据库密码
                'password'      => env('DATABASE_PASSWORD'),
                // 驱动连接选项: http://php.net/manual/zh/pdo.setattribute.php
                'driverOptions' => [
                    // 设置默认的提取模式: \PDO::FETCH_OBJ | \PDO::FETCH_ASSOC
                    \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                ],
            ],
        ],

        // redis
        [
            // 类路径
            'class'      => Mix\Redis\Persistent\RedisConnection::class,
            // 属性
            'properties' => [
                // 主机
                'host'     => env('REDIS_HOST'),
                // 端口
                'port'     => env('REDIS_PORT'),
                // 数据库
                'database' => env('REDIS_DATABASE'),
                // 密码
                'password' => env('REDIS_PASSWORD'),
            ],
        ],

    ],

];
